<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;

// Récupère l'application
$app = Factory::getApplication();

// Démarre le composant (DI + provider)
$component = $app->bootComponent('com_mediausage');

// Crée le dispatcher et lance le contrôleur
$component->getDispatcher($app)->dispatch();
