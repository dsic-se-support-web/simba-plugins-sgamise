<?php

namespace Joomla\Component\Mediausage\Administrator\View\Dashboard;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Extension\ExtensionHelper;


class HtmlView extends BaseHtmlView
{
    public $totalSize;
    public $percent;
    public $files;
    public $folders;
    public $usageByType;
    public $topFilesByType;
    public $quotaUsed;
    public $quotaLimit;
    public $quotaRemaining;
    public $orphanFiles;
    public $showOrphanFiles;
    public $componentVersion;


    public function display($tpl = null)
    {
        $this->_setPath('template', __DIR__ . '/tmpl');

        $params = \Joomla\CMS\Component\ComponentHelper::getParams('com_mediausage');
        $this->showOrphanFiles = (bool) $params->get('enable_orphan_files', 1);        

        $model = $this->getModel();
        $data = $model->getCachedFileData();

        // Récupérer les données du quota depuis le modèle
        $quotaData = $model->getQuotaFromCSV();
        $this->quotaUsed = $quotaData['quota_used'];
        $this->quotaLimit = $quotaData['quota_limit'];
        $this->quotaRemaining = $quotaData['quota_remaining'];
        // Pourcentage : images VS quota global
        $this->totalSize  = $data['total_size'];
        $this->percent = $this->quotaLimit > 0
        ? ($this->quotaUsed / $this->quotaLimit) * 100
        : 0;
    
        $this->files      = $data['files'];
        $this->folders    = $model->getTreeStats($this->files);
        $this->usageByType = $model->getUsageByType($this->files);
        $this->topFilesByType = $model->getTopFilesByType($this->files, 50);
        $this->orphanFiles = $model->getOrphanFiles($this->files);

        $wa = Factory::getApplication()
        ->getDocument()
        ->getWebAssetManager();
    
        // Enregistrement de Chart.js
        $wa->registerAndUseScript(
            'mediausage.chartjs',
            Uri::root() . 'administrator/components/com_mediausage/media/chart.umd.min.js',
            [],
            ['defer' => true]
        );

        // Passer les données PHP au JS
        $wa->addInlineScript(
            'window.mediaUsageData = ' . json_encode($this->usageByType, JSON_THROW_ON_ERROR) . ';',
            ['type' => 'text/javascript', 'defer' => true]
        );

        // Graphique d'occupation par type de fichier
        $wa->addInlineScript("
        document.addEventListener('DOMContentLoaded', function() {
            if (typeof Chart === 'undefined' || !window.mediaUsageData) return;
        
            const ctx = document.getElementById('mediaUsageChart');
            if (!ctx) return;
        
            const labels = Object.keys(window.mediaUsageData);
            const values = Object.values(window.mediaUsageData).map(v => Math.round(v / 1024 / 1024));
        
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: labels.map(l => l.charAt(0).toUpperCase() + l.slice(1)),
                    datasets: [{
                        label: 'Mo',
                        data: values,
                        backgroundColor: ['#4e73df','#1cc88a','#36b9cc','#f6c23e','#e74a3b']
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'right' },
                        tooltip: { callbacks: { label: ctx => ctx.label + ': ' + ctx.raw + ' Mo' } }
                    }
                }
            });
        });
        ", ['type' => 'text/javascript', 'defer' => true]);

        // Barre d'occupation globale
        $wa->addInlineScript("
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('quotaUsageChart');
            if (!ctx) return;
        
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Quota'],
                    datasets: [{
                        label: 'Utilisé (%)',
                        data: [" . round($this->percent, 2) . "],
                        backgroundColor: '#007bff',
                        borderRadius: 10,
                        barPercentage: 1.0
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: {
                            max: 100,
                            ticks: { callback: value => value + '%' }
                        },
                        y: { display: false }
                    },
                    plugins: {
                        legend: { display: false },
                        tooltip: { callbacks: { label: ctx => ctx.raw + '%' } }
                    }
                }
            });
        });
        ", ['type' => 'text/javascript', 'defer' => true]);

        // Récupération de la version du composant
        $this->componentVersion = '—';
        $extensionTable = Table::getInstance('Extension');
        if ($extensionTable->load(['element' => 'com_mediausage', 'type' => 'component'])) {
            $manifest = json_decode($extensionTable->manifest_cache, true);
            $this->componentVersion = $manifest['version'] ?? '—';
        }

        // Ensuite seulement, appeler addToolbar()
        $this->addToolbar();

        parent::display($tpl);
    }

    // Titres et boutons de la toolbar
    protected function addToolbar(): void
    {
        ToolbarHelper::title(
            Text::_('COM_MEDIAUSAGE_DASHBOARD_TITLE') .
            ' <span class="badge bg-secondary ms-2">v' . htmlspecialchars($this->componentVersion) . '</span>',
            'stack'
        );
        
        ToolbarHelper::custom(
            'dashboard.clearCache',
            'refresh',
            '',
            Text::_('COM_MEDIAUSAGE_FORCE_RECALC'),
            false
        );
 
        ToolbarHelper::custom(
            'dashboard.exportCsv',
            'download',
            '',
            Text::_('COM_MEDIAUSAGE_EXPORT_CSV'),
            false
        );

        // Bouton à affichage conditionnel
        if ($this->showOrphanFiles) {
            ToolbarHelper::custom(
                'dashboard.exportOrphansCsv',
                'download',
                '',
                Text::_('COM_MEDIAUSAGE_EXPORT_ORPHANS_CSV'),
                false
            );
        }
    }
    
}