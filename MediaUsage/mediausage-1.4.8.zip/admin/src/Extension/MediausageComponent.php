<?php

namespace Joomla\Component\Mediausage\Administrator\Extension;

use Joomla\CMS\Extension\MVCComponent;
use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Factory;


defined('_JEXEC') or die;

class MediausageComponent extends MVCComponent
{
    public function boot(CMSApplicationInterface $app)
    {
        // Langue
        $lang = $app->getLanguage();
        $lang->load('com_mediausage', JPATH_ADMINISTRATOR);
    
        // CSS uniquement pour l'admin
        if ($app->isClient('administrator')) {
            $wa = Factory::getApplication()
                ->getDocument()
                ->getWebAssetManager();
    
            $wa->registerAndUseStyle(
                'com_mediausage.config',
                'administrator/components/com_mediausage/media/config.css'
            );
        }
    
        return $this;
    }
}