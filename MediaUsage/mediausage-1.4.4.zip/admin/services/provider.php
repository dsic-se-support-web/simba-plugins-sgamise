<?php
defined('_JEXEC') or die;

use Joomla\CMS\Extension\ComponentInterface;
use Joomla\CMS\Extension\Service\Provider\ComponentDispatcherFactory;
use Joomla\CMS\Extension\Service\Provider\MVCFactory;
use Joomla\CMS\Dispatcher\ComponentDispatcherFactoryInterface;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class implements ServiceProviderInterface
{
    public function register(Container $container): void
    {
        // error_log('MEDIAUSAGE PROVIDER CHARGE'); //debug

        // Enregistrement du composant
        $container->registerServiceProvider(
            new MVCFactory(
                'Joomla\\Component\\Mediausage', // <--- Important : namespace racine du composant
                JPATH_ADMINISTRATOR . '/components/com_mediausage/src'
            )
        );
        

        // DISPATCHER
        $container->registerServiceProvider(
            new ComponentDispatcherFactory(
                'Joomla\\Component\\Mediausage' // <--- Important : namespace racine du composant
            )
        );
        
        $container->set(
            ComponentInterface::class,
            function (Container $container) {
                $component = new \Joomla\Component\Mediausage\Administrator\Extension\MediausageComponent(
                    $container->get(ComponentDispatcherFactoryInterface::class)
                );
        
                $component->setMVCFactory(
                    $container->get(MVCFactoryInterface::class)
                );
        
                // Boot du composant
                $app = \Joomla\CMS\Factory::getApplication();
                $component->boot($app);
        
                return $component;
            }
        );

        //error_log('Mediausage Provider::exécuté'); //Debug
    }
};
