<?php

namespace Joomla\Component\Mediausage\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

class DisplayController extends BaseController
{
    protected $default_view = 'dashboard';

    public function display($cachable = false, $urlparams = [])
    {
        $view   = $this->input->get('view');
        $layout = $this->input->get('default');

        // Check for edit form.
        if ($view == 'view' && $layout == 'default') {

            $this->setRedirect(Route::_('index.php?option=com_mediausage&view=default', false));

            return false;
        }

        parent::display();

        return $this;
    }
}
