<?php

namespace Joomla\Component\Mediausage\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;

class DashboardModel extends BaseDatabaseModel
{
    /**
     * Récupère les paramètres du composant com_mediausage.
     *
     * @return \Joomla\Registry\Registry Paramètres du composant
     */
    protected function getParams()
    {
        return ComponentHelper::getParams('com_mediausage');
    }

    /**
     * Liste des fichiers techniques à ignorer (pour recherche d'orphelins)
     *
     * @return string[]
     */
    protected function getTechnicalFilenames(): array
    {
        return [
            'index.html',
            'index.htm',
            '.htaccess',
        ];
    }

    /**
     * Indique si un fichier est un fichier technique à ignorer (pour recherche d'orphelins)
     *
     * @param string $path Chemin absolu ou relatif
     * @return bool
     */
    protected function isTechnicalFile(string $path): bool
    {
        return in_array(
            basename($path),
            $this->getTechnicalFilenames(),
            true
        );
    }

    /**
     * Détermine le type MIME d’un fichier.
     *
     * Utilise mime_content_type() si disponible, sinon retourne "unknown".
     * Les erreurs sont volontairement silencieuses pour éviter les warnings.
     *
     * @param string $path Chemin absolu du fichier
     * @return string Type MIME ou "unknown"
     */
    private function safeMimeType(string $path): string
    {
        if (function_exists('mime_content_type')) {
            return @mime_content_type($path) ?: 'unknown';
        }
    
        return 'unknown';
    }

    /**
     * Normalise un chemin de fichier ou dossier.
     *
     * - Remplace les antislashs par des slashs
     * - Supprime les slashs multiples
     * - Supprime les slashs de début et de fin
     *
     * @param string $path Chemin à normaliser
     * @return string Chemin normalisé
     */
    private function normalizePath(string $path): string
    {
        $path = str_replace('\\', '/', $path);
        $path = preg_replace('#/+#', '/', $path);
    
        return trim($path, '/');
    }
    

    /**
     * Récupère les informations de quota disque depuis le fichier CSV ../repquota.csv.
     *
     * Le fichier doit contenir au minimum les colonnes :
     * - BlockUsed
     * - BlockHardLimit
     *
     * Les valeurs sont converties en octets.
     *
     * @return array{
     *   quota_used:int,
     *   quota_limit:int,
     *   quota_remaining:string
     * }
     */
    public function getQuotaFromCSV(): array
    {
        $chemin_fichier_csv = '../repquota.csv';
        
        if (!file_exists($chemin_fichier_csv)) {
            return [
                'quota_used' => 0,
                'quota_limit' => 0,
                'quota_remaining' => 'Illimité',
            ];
        }

        $rows   = array_map('str_getcsv', file($chemin_fichier_csv));
        $header = array_shift($rows);
        $csv    = array();

        foreach ($rows as $row) {
            $csv[] = array_combine($header, $row);
        }

        if (count($csv)) {
            $usedBytes  = (int) $csv[0]['BlockUsed'] * 1024;
            $limitBytes = (int) $csv[0]['BlockHardLimit'] * 1024;

            $quota_remaining = ($limitBytes === 0)
                ? 'Illimité'
                : $this->formatSize($limitBytes - $usedBytes);

            return [
                'quota_used'  => $usedBytes,
                'quota_limit' => $limitBytes,
                'quota_remaining' => $quota_remaining,
            ];
        } else {
            return [
                'quota_used' => 0,
                'quota_limit' => 0,
                'quota_remaining' => 'Illimité',
            ];
        }
    }

    /**
     * Formate une taille en octets vers une unité lisible.
     *
     * @param int $size Taille en octets
     * @return string Taille formatée (Ko, Mo, Go, …)
     */
    protected function formatSize(int $size): string
    {
        $units = ['octets', 'Ko', 'Mo', 'Go', 'To'];
        $i = 0;
    
        while ($size >= 1024 && $i < count($units) - 1) {
            $size /= 1024;
            $i++;
        }
    
        return round($size, 2) . ' ' . $units[$i];
    }

    /**
     * Retourne les données du scan du dossier /images avec cache Joomla.
     *
     * Le cache est invalidé automatiquement si :
     * - le contenu du dossier /images change
     * - les paramètres du composant sont modifiés
     *
     * @return array{
     *   files:array,
     *   total_size:int
     * }
     */
    public function getCachedFileData(): array
    {
        $cache = Factory::getCache('com_mediausage', 'callback');
        $cache->setCaching(true);
        $cache->setLifeTime(0); // durée du cache illimitée - Peut-être limitée avec valeur en ms
    
        $signature = sha1(
            $this->getImagesSignature()
            . '|' . serialize($this->getParams()->toArray())
        );       
    
        return $cache->get(
            [$this, 'scanImagesDirectory'],
            ['images-scan-' . $signature]
        );
    }

    /**
     * Analyse récursivement le dossier /images.
     *
     * Retourne la liste des fichiers lisibles avec :
     * - chemin absolu
     * - taille
     * - type MIME
     *
     * @return array{
     *   files:array,
     *   total_size:int
     * }
     */
    public function scanImagesDirectory(): array
    {
        $path = JPATH_ROOT . '/images';
    
        if (!is_dir($path) || !is_readable($path)) {
            return [
                'files' => [],
                'total_size' => 0,
            ];
        }
    
        $files = [];
    
        try {
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator(
                    $path,
                    \FilesystemIterator::SKIP_DOTS
                )
            );
    
            foreach ($iterator as $file) {
                /** @var \SplFileInfo $file */
    
                if (!$file->isFile() || !$file->isReadable()) {
                    continue;
                }
    
                $files[] = [
                    'path' => $file->getPathname(),
                    'size' => $file->getSize(),
                    'mime' => $this->safeMimeType($file->getPathname()),
                ];
            }
    
        } catch (\Throwable $e) {
            \Joomla\CMS\Factory::getApplication()->enqueueMessage(
                'Analyse des médias impossible sur cet environnement',
                'warning'
            );
    
            return [
                'files' => [],
                'total_size' => 0,
            ];
        }
    
        return [
            'files'      => $files,
            'total_size' => array_sum(array_column($files, 'size')),
        ];
    }

    /**
     * Génère une signature du dossier /images.
     *
     * La signature est basée sur :
     * - le nombre total de fichiers
     * - la date de modification la plus récente
     *
     * Utilisée pour invalider le cache du scan filesystem.
     *
     * @return string Hash de signature
     */
    protected function getImagesSignature(): string
    {
        $path = JPATH_ROOT . '/images';
        $lastModified = 0;
        $count = 0;

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            /** @var \SplFileInfo $file */
            $count++;
            $lastModified = max($lastModified, $file->getMTime());
        }

        return sha1($count . '|' . $lastModified);
    }

    /**
     * Calcule l’espace disque utilisé par dossier.
     *
     * @param array $files Liste des fichiers scannés
     * @return array<string,int> Taille cumulée par dossier
     */
    public function getTreeStats(array $files): array
    {
        $folders = [];

        foreach ($files as $file) {
            $dir = dirname($file['path']);
            $folders[$dir] = ($folders[$dir] ?? 0) + $file['size'];
        }

        arsort($folders);
        return $folders;
    }

    /**
     * Retourne la correspondance types de fichiers / extensions.
     *
     * @return array<string, string[]> Mapping type → extensions
     */
    protected function getFileTypeMap(): array
    {
        return [
            'images' => ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'],
            'documents' => ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt'],
            'videos' => ['mp4', 'webm', 'mov', 'avi', 'mkv'],
            'audio' => ['mp3', 'wav', 'ogg', 'aac'],
        ];
    }

    /**
     * Calcule l’espace disque utilisé par type de fichier.
     *
     * @param array $files Liste des fichiers scannés
     * @return array<string,int> Taille cumulée par type
     */
    public function getUsageByType(array $files): array
    {
        $types = array_fill_keys(
            array_keys($this->getFileTypeMap()),
            0
        );
    
        $types['others'] = 0;
    
        $map = $this->getFileTypeMap();
    
        foreach ($files as $file) {
            $ext = strtolower(pathinfo($file['path'], PATHINFO_EXTENSION));
            $matched = false;
    
            foreach ($map as $type => $extensions) {
                if (in_array($ext, $extensions, true)) {
                    $types[$type] += $file['size'];
                    $matched = true;
                    break;
                }
            }
    
            if (!$matched) {
                $types['others'] += $file['size'];
            }
        }
    
        arsort($types);
    
        return $types;
    }
    
    /**
     * Retourne les fichiers les plus volumineux par type.
     *
     * Les fichiers techniques (index.html, .htaccess) sont exclus.
     *
     * @param array $files Liste complète des fichiers scannés
     * @param int $limit Nombre maximum de fichiers par type
     * @return array<string,array>
     */
    public function getTopFilesByType(array $files, int $limit = 50): array
    {
        $map = $this->getFileTypeMap();
    
        $result = [];
        foreach ($map as $type => $_) {
            $result[$type] = [];
        }
        $result['others'] = [];
    
        foreach ($files as $file) {
    
            // Exclure index.html
            if (basename($file['path']) === 'index.html') {
                continue;
            }
            
            // Exclure .htaccess
            if (basename($file['path']) === '.htaccess') {
                continue;
            }

            // Calcul du chemin relatif
            $file['relative_path'] = $this->getRelativePath($file['path']);
    
            $ext = strtolower(pathinfo($file['path'], PATHINFO_EXTENSION));
            $matched = false;
    
            foreach ($map as $type => $extensions) {
                if (in_array($ext, $extensions, true)) {
                    $result[$type][] = $file;
                    $matched = true;
                    break;
                }
            }
    
            if (!$matched) {
                $result['others'][] = $file;
            }
        }
    
        // Tri décroissant et limitation
        foreach ($result as $type => &$typeFiles) {
            usort($typeFiles, fn ($a, $b) => $b['size'] <=> $a['size']);
            $typeFiles = array_slice($typeFiles, 0, $limit);
        }
    
        return $result;
    }
    
    /**
     * Retourne le chemin relatif depuis JPATH_ROOT/images
     */
    private function getRelativePath(string $fullPath): string
    {
        $fullPath = $this->normalizePath($fullPath);
        $base     = $this->normalizePath(JPATH_ROOT . '/images');
    
        return ltrim(str_replace($base, '', $fullPath), '/');
    }
    

    /**
     * Indique si un fichier ou dossier est exclu du scan des fichiers orphelins via la configuration du coposant.
     *
     * @param string $relativePath Chemin relatif (ex: images/foo/bar.jpg)
     * @return bool True si exclu
     */
    protected function isExcluded(string $relativePath): bool
    {
        $relativePath = $this->normalizePath($relativePath);
    
        foreach ($this->getEffectiveExcludedFolders() as $folder) {
    
            $folder = $this->normalizePath('images/' . $folder);
    
            if (
                $relativePath === $folder ||
                str_starts_with($relativePath, $folder . '/')
            ) {
                return true;
            }
        }
    
        return false;
    }

    /**
     * Retourne la liste des fichiers médias orphelins.
     *
     * Un fichier est considéré comme orphelin si :
     * - il est présent dans le Media Manager sous /images
     * - il n’est référencé dans aucun contenu Joomla
     * - si son dossier parent n'est pas exclu du scan par la configuration du composant
     *
     * @param array $files Liste complète des fichiers médias scannés
     * @return array Liste des fichiers orphelins
     */
    public function getOrphanFiles(array $files): array
    {
        $params = $this->getParams();
        // Si analyse désactivée → pas de calcul
        if (!(bool) $params->get('enable_orphan_files', 1)) {
            return [];
        }

        $index  = $this->getMediaReferenceIndex();
        $orphans = [];
    
        foreach ($files as $file) {

            if ($this->isTechnicalFile($file['path'])) {
                continue;
            }
    
            $relative = 'images/' . $this->getRelativePath($file['path']);
            $relative = $this->normalizeMediaPath($relative);
    
            // Racine /images
            $scanRoot = (bool) $params->get('scan_images_root', 1);
            $isRootFile = preg_match('#^images/[^/]+$#', $relative);
    
            if (!$scanRoot && $isRootFile) {
                continue;
            }
    
            if ($this->isExcluded($relative)) {
                continue;
            }

            if (!isset($index[$relative])) {
                $file['relative_path'] = $relative;
                $orphans[] = $file;
            }
        }
    
        return $orphans;
    }
    

    /**
     * Retourne la liste des dossiers exclus par défaut du scan (valeur par défaut dans la configuration du composant).
     *
     * @return string[] Liste des dossiers exclus
     */
    protected function getDefaultExcludedFolders(): array
    {
        return [
            'banners',
            'convertforms',
            'headers',
            'Modele',
            'Pages_d_erreur',
            'Service',
            'Tuiles',
        ];
    }
    
    /**
     * Retourne la liste effective des dossiers exclus.
     *
     * - Utilise la configuration du composant si définie
     * - Sinon applique les exclusions par défaut
     *
     * @return string[] Liste des dossiers exclus
     */
    protected function getEffectiveExcludedFolders(): array
    {
        $params   = $this->getParams();
        $excluded = (array) $params->get('exclude_folders', []);
    
        // Nettoyage
        $excluded = array_filter($excluded, static function ($v) {
            return $v !== '' && $v !== '0' && $v !== null;
        });
    
        // Valeur par défaut = exclusions dossiers standards
        if (empty($excluded)) {
            return $this->getDefaultExcludedFolders();
        }
    
        return $excluded;
    }

    /**
     * Normalise un chemin de média pour comparaison.
     *
     * - Supprime le domaine
     * - Supprime les paramètres d’URL
     * - Décode les URL encodées
     * - Uniformise les slashs
     *
     * @param string $path Chemin brut
     * @return string Chemin média normalisé
     */
    private function normalizeMediaPath(string $path): string
    {
        // Supprimer domaine
        $path = preg_replace('#^https?://[^/]+/#', '', $path);
    
        // Supprimer paramètres ?v=...
        $path = strtok($path, '?');
    
        // Décoder URL
        $path = urldecode($path);
    
        // Uniformiser slashs
        $path = str_replace('\\', '/', $path);
        $path = preg_replace('#/+#', '/', $path);
    
        return ltrim($path, '/');
    }

    /**
     * Définit les tables et colonnes contenant des références de médias.
     *
     * @return array<int, array{0:string,1:string[]}>
     */
    private function getMediaReferenceColumns(): array
    {
        return [
            ['#__content', ['introtext', 'fulltext', 'images', 'urls']],
            ['#__modules', ['content', 'params']],
            ['#__menu', ['params']],
            ['#__fields_values', ['value']],
            ['#__extensions', ['params']],
        ];
    }

    /**
     * Retourne l’index des références médias utilisées dans Joomla.
     *
     * - Utilise un cache Joomla (callback) pour éviter de rescanner la base de données
     *   à chaque affichage du dashboard.
     * - L’index est un tableau associatif de chemins normalisés :
     *     [
     *         'images/foo/bar.jpg' => true,
     *         'images/docs/file.pdf' => true,
     *         ...
     *     ]
     * - La signature du cache dépend :
     *   - de la structure des tables/colonnes analysées
     *   - des paramètres du composant
     *
     * Le cache est invalidé via la tâche "Forcer le recalcul".
     *
     * @return array<string, bool> Index des médias utilisés
     */
    protected function getMediaReferenceIndex(): array
    {
        static $index = null;
    
        if ($index !== null) {
            return $index;
        }
    
        $cache = Factory::getCache('com_mediausage', 'callback');
        $cache->setCaching(true);
        $cache->setLifeTime(0); // illimité
    
        // Signature : structure DB + config (sécurité)
        $signature = sha1(
            serialize($this->getMediaReferenceColumns())
            . '|' . serialize($this->getParams()->toArray())
        );
    
        $index = $cache->get(
            [$this, 'buildMediaReferenceIndex'],
            ['media-reference-index-' . $signature]
        );
    
        return $index;
    }   

    /**
     * Extrait les chemins de médias depuis un texte (HTML, JSON, CSS, params).
     *
     * Détecte :
     * - src="", href=""
     * - url(...) en CSS
     * - champs JSON (image, src)
     * - fallback par extension connue
     *
     * Les chemins retournés sont :
     * - normalisés
     * - relatifs à la racine Joomla (ex: images/foo/bar.jpg)
     *
     * @param string $text Contenu à analyser
     * @return string[] Liste des chemins médias détectés
     */
    private function extractMediaPaths(string $text): array
    {
        $paths = [];
    
        $patterns = [
            // src="", href=""
            '#(?:src|href)\s*=\s*["\']([^"\']*images/[^"\']+)["\']#i',
    
            // url(...)
            '#url\((["\']?)(images/[^"\')]+)\1\)#i',
    
            // JSON "image":"images/..."
            '#"(?:image|src)"\s*:\s*"([^"]*images/[^"]+)"#i',
    
            // fallback large
            '#images/[a-z0-9/_\.-]+\.(?:jpg|jpeg|png|gif|webp|svg|pdf|mp4|webm|mp3)#i',
        ];
    
        foreach ($patterns as $pattern) {
            preg_match_all($pattern, $text, $matches);
            foreach ($matches[1] ?? $matches[0] as $path) {
                $paths[] = $this->normalizeMediaPath($path);
            }
        }
    
        return $paths;
    }

    /**
     * Construit l’index des références médias réellement utilisées.
     *
     * - Parcourt les tables Joomla susceptibles de contenir des références de médias
     * - Extrait les chemins via extractMediaPaths()
     * - Normalise les chemins pour éviter les faux négatifs
     *
     * Cette méthode est volontairement pas mise en cache.
     * Le cache Joomla est géré par getMediaReferenceIndex().
     *
     * @return array<string, bool> Index des chemins médias utilisés
     */
    public function buildMediaReferenceIndex(): array
    {
        $db    = Factory::getDbo();
        $index = [];
    
        foreach ($this->getMediaReferenceColumns() as [$table, $columns]) {
    
            $quotedColumns = array_map(
                fn ($c) => $db->quoteName($c),
                $columns
            );
    
            $query = $db->getQuery(true)
                ->select($quotedColumns)
                ->from($db->quoteName($table));
    
            $db->setQuery($query);
    
            foreach ($db->loadRowList() as $row) {
                foreach ($row as $value) {
    
                    if (!$value) {
                        continue;
                    }
    
                    foreach ($this->extractMediaPaths($value) as $path) {
                        $index[$path] = true;
                    }
                }
            }
        }
    
        return $index;
    }
    
}
