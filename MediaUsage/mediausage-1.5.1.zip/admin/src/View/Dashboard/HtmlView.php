<?php

namespace Joomla\Component\Mediausage\Administrator\View\Dashboard;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Extension\ExtensionHelper;


class HtmlView extends BaseHtmlView
{
    public $totalSize;
    public $percent;
    public $files;
    public $folders;
    public $usageByType;
    public $topFilesByType;
    public $quotaUsed;
    public $quotaLimit;
    public $quotaRemaining;
    public $orphanFiles;
    public $showOrphanFiles;
    public $componentVersion;
    public $pagination;
    public $limit;
    public $start;
    public $total;


    public function display($tpl = null)
    {
        $this->_setPath('template', __DIR__ . '/tmpl');

        $params = \Joomla\CMS\Component\ComponentHelper::getParams('com_mediausage');
        $this->showOrphanFiles = (bool) $params->get('enable_orphan_files', 1);        

        $model = $this->getModel();
        $data = $model->getCachedFileData();

        // Récupérer les données du quota depuis le modèle
        $quotaData = $model->getQuotaFromCSV();
        $this->quotaUsed = $quotaData['quota_used'];
        $this->quotaLimit = $quotaData['quota_limit'];
        $this->quotaRemaining = $quotaData['quota_remaining'];
        // Pourcentage : images VS quota global
        $this->totalSize  = $data['total_size'];
        $this->percent = $this->quotaLimit > 0
        ? ($this->quotaUsed / $this->quotaLimit) * 100
        : 0;
    
        $this->files      = $data['files'];
        $this->folders    = $model->getTreeStats($this->files);
        $this->usageByType = $model->getUsageByType($this->files);
        $this->topFilesByType = $model->getTopFilesByType($this->files, 50);
        $this->orphanFiles = $model->getOrphanFiles($this->files);

        $allOrphans = $model->getOrphanFiles($this->files);
        // Pagination des résultats de fichiers orphelins
        $paginated = $model->getPaginatedOrphanFiles($allOrphans);
        $this->orphanFiles     = $paginated['items'];
        $this->pagination     = $paginated['pagination'];
        $this->orphanFilesAll = $allOrphans;
        $this->limit = (int) $model->getState('list.limit', 20);
        $this->start = (int) $model->getState('list.start', 0);
        

        $wa = Factory::getApplication()
        ->getDocument()
        ->getWebAssetManager();
    
        // Enregistrement de Chart.js
        $wa->registerAndUseScript(
            'mediausage.chartjs',
            Uri::root() . 'administrator/components/com_mediausage/media/chart.umd.min.js',
            [],
            ['defer' => true]
        );

        // Valeurs de couleurs thème clair et sombre
        $wa->addInlineScript("
        function bsColor(name) {
            const root = getComputedStyle(document.documentElement);
            const rgb = root.getPropertyValue(name + '-rgb').trim();
        
            if (rgb) {
                return 'rgb(' + rgb + ')';
            }
        
            // fallback
            return '#0d6efd';
        }
        ", ['type' => 'text/javascript', 'defer' => true]);

        // Passage des données PHP au JS
        $wa->addInlineScript(
            'window.mediaUsageData = ' . json_encode($this->usageByType, JSON_THROW_ON_ERROR) . ';',
            ['type' => 'text/javascript', 'defer' => true]
        );

        // Graphique Donut - Occupation par type de fichier
        $wa->addInlineScript("
        document.addEventListener('DOMContentLoaded', function() {
            if (typeof Chart === 'undefined' || !window.mediaUsageData) return;
        
            const ctx = document.getElementById('mediaUsageChart');
            if (!ctx) return;
        
            const labels = Object.keys(window.mediaUsageData);
            const values = Object.values(window.mediaUsageData).map(v => {
                const mo = v / 1024 / 1024;
                return Math.round(mo * 1000) / 1000; // arrondi à 3 décimales
            });
        
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: labels.map(l => l.charAt(0).toUpperCase() + l.slice(1)),
                    datasets: [{
                        label: 'Mo',
                        data: values,
                        backgroundColor: [
                            '#0d6efd', // bleu
                            '#198754', // vert
                            '#0dcaf0', // cyan
                            '#ffc107', // jaune
                            '#dc3545'  // rouge
                        ],
                        borderColor: bsColor('--bs-body-bg'),
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'right',
                            labels: {
                                color: bsColor('--bs-body-color'),
                                boxWidth: 15
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: ctx => {
                                    const raw = ctx.raw;
                                    if (raw < 1) {
                                        return ctx.label + ': ' + Math.round(raw * 1024) + ' Ko';
                                    }
                                    return ctx.label + ': ' + raw.toFixed(2) + ' Mo';
                                }
                            }
                        }
                    }
                }
            });
        });
        ", ['type' => 'text/javascript', 'defer' => true]);

        // Graphique Barre - Occupation globale
        $wa->addInlineScript("
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('quotaUsageChart');
            if (!ctx) return;
        
            const percent = Math.min(" . round($this->percent, 2) . ", 100);
        
            let barColor;
        
            // Couleur progressive de la barre en fonction de l'occupation
            if (percent < 60) {
                barColor = '#198754'; // vert
            } else if (percent < 80) {
                barColor = '#fd7e14'; // orange
            } else {
                barColor = '#dc3545'; // rouge
            }
        
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Quota'],
                    datasets: [{
                        label: 'Utilisé (%)',
                        data: [percent],
                        backgroundColor: barColor,
                        borderRadius: 10
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: {
                            max: 100,
                            ticks: {
                                color: bsColor('--bs-body-color'),
                                callback: value => value + '%'
                            },
                            grid: {
                                color: bsColor('--bs-border-color')
                            }
                        },
                        y: {
                            display: false
                        }
                    },
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: ctx => ctx.raw + '%'
                            }
                        }
                    }
                }
            });
        });
        ", ['type' => 'text/javascript', 'defer' => true]);

        // Récupération de la version du composant pour affichage
        $this->componentVersion = '—';
        $extensionTable = Table::getInstance('Extension');
        if ($extensionTable->load(['element' => 'com_mediausage', 'type' => 'component'])) {
            $manifest = json_decode($extensionTable->manifest_cache, true);
            $this->componentVersion = $manifest['version'] ?? '—';
        }

        // Appelle de addToolbar()
        $this->addToolbar();

        parent::display($tpl);
    }

    // Titres et boutons de la Toolbar
    protected function addToolbar(): void
    {
        ToolbarHelper::title(
            Text::_('COM_MEDIAUSAGE_DASHBOARD_TITLE') .
            ' <span class="badge bg-secondary ms-2">v' . htmlspecialchars($this->componentVersion) . '</span>',
            'stack'
        );
        
        ToolbarHelper::custom(
            'dashboard.clearCache',
            'refresh',
            '',
            Text::_('COM_MEDIAUSAGE_FORCE_RECALC'),
            false
        );
 
        ToolbarHelper::custom(
            'dashboard.exportCsv',
            'download',
            '',
            Text::_('COM_MEDIAUSAGE_EXPORT_CSV'),
            false
        );

        // Bouton à affichage conditionnel
        if ($this->showOrphanFiles) {
            ToolbarHelper::custom(
                'dashboard.exportOrphansCsv',
                'download',
                '',
                Text::_('COM_MEDIAUSAGE_EXPORT_ORPHANS_CSV'),
                false
            );
        }
    }

    /**
     * Retourne l'unité en Mo ou Ko selon la taille.
     *
     * @param int $size Taille en octets
     * @return string
     */
    function formatFileSize(int $size): string
    {
        if ($size >= 1024 * 1024) {
            return round($size / 1024 / 1024, 2) . ' Mo';
        }
    
        return round($size / 1024, 2) . ' Ko';
    }
}