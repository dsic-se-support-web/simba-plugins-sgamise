<?php
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

?>

<form action="index.php?option=com_mediausage&view=dashboard"
      method="post"
      name="adminForm"
      id="adminForm">

    <!-- Titre de la page -->
    <!-- <h1><?//= Text::_('COM_MEDIAUSAGE_DASHBOARD_TITLE') ?></h1> -->

    <h3><?= Text::_('COM_MEDIAUSAGE_DASHBOARD_GLOBAL_USAGE') ?></h3>
    <!-- Occupation globale -->
    <div class="card mb-4">
        <p style="text-align:center; margin-top:1em; font-weight:bold; color:#d9534f;"><strong><?= Text::_('COM_MEDIAUSAGE_GLOBAL_QUOTA_DISCLAIMER') ?></p>
        <div class="card-body d-flex align-items-center flex-wrap">
            <!-- Texte à gauche -->
            <div style="flex: 0 0 250px; min-width: 200px; margin-right: 20px;">
                <p><strong><?= Text::_('COM_MEDIAUSAGE_TOTAL_SIZE') ?> :</strong> <?= $this->formatFileSize($this->totalSize) ?></p>
                <hr style="width:75%;"/>
                <p><strong><?= Text::_('COM_MEDIAUSAGE_GLOBAL_QUOTA') ?> :</strong> <?= $this->formatFileSize($this->quotaLimit) ?></p>
                <p><strong><?= Text::_('COM_MEDIAUSAGE_QUOTA_USED') ?> :</strong> <?= $this->formatFileSize($this->quotaUsed) ?></p>
                <p><strong><?= Text::_('COM_MEDIAUSAGE_QUOTA_REMAINING') ?> :</strong> <?= $this->quotaRemaining ?></p>
                <p><strong><?= Text::_('COM_MEDIAUSAGE_USAGE_PERCENT') ?> :</strong> <?= round($this->percent, 1) ?>%</p>
            </div>

            <!-- Graphique à droite, flexible -->
            <div style="flex: 1 1 auto; min-width: 200px; height:50px;">
                <canvas id="quotaUsageChart" style="width:100%; height:100%;"></canvas>
            </div>
        </div>
    </div>

    <!-- Occupation par type de fichier -->
    <h3 class="mt-4"><?= Text::_('COM_MEDIAUSAGE_DASHBOARD_FOLDERS') ?></h3>
    <!-- Occupation par type de fichier - Graphique -->
    <div style="display:flex; justify-content:center; margin-bottom:1rem;">
        <!-- Bloc encadré centré -->
        <div style="width:400px; max-width:90%; padding:15px; border:1px solid #ddd; border-radius:8px; box-shadow: 0 2px 6px rgba(0,0,0,0.05);">
            <canvas id="mediaUsageChart"></canvas>
        </div>
    </div>
    <!-- Occupation par type de fichier - Tableau -->
    <table class="table table-striped">
        <thead>
            <tr>
                <th><?= Text::_('COM_MEDIAUSAGE_TYPE') ?></th>
                <th><?= Text::_('COM_MEDIAUSAGE_SIZE') ?></th>
                <th><?= Text::_('COM_MEDIAUSAGE_PERCENT') ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($this->usageByType as $type => $size): ?>
                <?php $percent = $this->totalSize > 0 ? ($size / $this->totalSize) * 100 : 0; ?>
                <tr>
                    <td><?= ucfirst($type) ?></td>
                    <td><?= $this->formatFileSize($size) ?></td>
                    <td><?= round($percent, 1) ?>%</td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Top 50 -->
    <h3 class="mt-5"><?= Text::_('COM_MEDIAUSAGE_DASHBOARD_FILES') ?></h3>

        <div class="accordion" id="topFilesAccordion">
            <?php foreach ($this->topFilesByType as $type => $files): ?>
                <?php if (empty($files)) continue; ?>
                <?php $typeId = 'accordion-' . $type; ?>

                <div class="accordion-item">
                    <h2 class="accordion-header" id="heading-<?= $typeId ?>">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?= $typeId ?>" aria-expanded="false" aria-controls="collapse-<?= $typeId ?>">
                            <?= ucfirst($type) ?> (<?= count($files) ?> fichiers)
                        </button>
                    </h2>
                    <div id="collapse-<?= $typeId ?>" class="accordion-collapse collapse" aria-labelledby="heading-<?= $typeId ?>" data-bs-parent="#topFilesAccordion">
                        <div class="accordion-body p-0">
                            <table class="table table-sm table-striped mb-0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?= Text::_('COM_MEDIAUSAGE_FILE') ?></th>
                                        <th><?= Text::_('COM_MEDIAUSAGE_SIZE') ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($files as $i => $file): ?>
                                        <tr>
                                            <td><?= $i + 1 ?></td>
                                            <td><code><?= htmlspecialchars($file['relative_path']) ?></code></td>
                                            <td><?= $this->formatFileSize($file['size']) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>


    <!-- Affichage de la liste des fichiers orphelins si activé dans la configuration -->
    <?php if ($this->showOrphanFiles) : ?>
        <h3 class="mt-5" id="orphans-table">
            <?= Text::_('COM_MEDIAUSAGE_ORPHAN_FILES') ?>
            (<span id="orphans-count"><?= count($this->orphanFilesAll) ?></span>)
        </h3>

        <div style="border:2px solid #d9534f; padding:15px; background-color:#fff5f5; border-radius:4px;">
            <h3 style="margin-top:0; font-weight:bold; color:#d9534f;">
                <?= Text::_('COM_MEDIAUSAGE_ORPHAN_FILES_DISCLAIMER') ?>
            </h3>
            <p><?= Text::_('COM_MEDIAUSAGE_ORPHAN_FILES_DISCLAIMER_DETAIL1') ?></p>
            <p><?= Text::_('COM_MEDIAUSAGE_ORPHAN_FILES_DISCLAIMER_DETAIL2') ?></p>
        </div>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th><?= Text::_('COM_MEDIAUSAGE_FILE') ?></th>
                    <th><?= Text::_('COM_MEDIAUSAGE_SIZE') ?></th>
                    <th><?= Text::_('COM_MEDIAUSAGE_ORPHAN_SCORE') ?></th>
                    <th><?= Text::_('COM_MEDIAUSAGE_STATUS') ?></th>
                </tr>
            </thead>
            <tbody id="orphans-tbody">
                <?= $this->loadTemplate('orphans'); ?>
            </tbody>
        </table>

        <?php
            $limit       = $this->limit;
            $limit       = max(1, (int) $this->limit);
            $total       = count($this->orphanFilesAll);
            $currentPage = (int) floor($this->start / $limit) + 1;
            $totalPages  = (int) ceil($total / $limit);
        ?>

        <nav id="orphans-pagination">
            <?= $this->loadTemplate('pagination'); ?>
        </nav>
    <?php endif; ?>

    <!-- Message de rescan -->
    <?= HTMLHelper::_('form.token'); ?>
        <input type="hidden" name="task" value="">

        <div id="scan-overlay"
        style="display:none;
                position:fixed;
                inset:0;
                background:rgba(255,255,255,0.85);
                z-index:9999;
                text-align:center;
                padding-top:20%;">
        <div class="spinner-border text-primary" role="status"></div>
        <p class="mt-3 fw-bold"><?= Text::_('COM_MEDIAUSAGE_SCAN_RUNNING') ?></p>
    </div>
</form>

<script>
// Message d'attente de scan en cours
document.addEventListener('DOMContentLoaded', () => {
    const toolbar = document.querySelector('.toolbar');
    if (!toolbar) return;

    toolbar.addEventListener('click', e => {
        const btn = e.target.closest('[onclick*="dashboard.clearCache"]');
        if (btn) {
            document.getElementById('scan-overlay').style.display = 'block';
        }
    });
});
</script>

<script>
document.addEventListener('click', function (e) {
    const link = e.target.closest('#orphans-pagination a');
    if (!link) return;

    e.preventDefault();

    fetch(link.href)
        .then(r => r.json())
        .then(data => {
            document.getElementById('orphans-tbody').innerHTML = data.rows;
            document.getElementById('orphans-pagination').innerHTML = data.pagination;

            document.getElementById('orphans-table')
                .scrollIntoView({ behavior: 'smooth' });
        });
});
</script>