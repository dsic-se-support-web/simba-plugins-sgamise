<?php
use Joomla\CMS\Language\Text;
?>
<?php foreach ($this->orphanFiles as $i => $file): ?>
<tr>
    <td><?= $this->start + $i + 1 ?></td>
    <td><code><?= htmlspecialchars($file['relative_path']) ?></code></td>
    <td><?= $this->formatFileSize($file['size']) ?></td>
    <td><?= $file['score'] ?>%</td>
    <td>
        <?= $file['score'] >= 80 ? Text::_('COM_MEDIAUSAGE_IS_ORPHAN_FILE')
        : ($file['score'] >= 50 ? Text::_('COM_MEDIAUSAGE_MAYBE_ORPHAN_FILE') : Text::_('COM_MEDIAUSAGE_NOT_ORPHAN_FILE')) ?>
    </td>
</tr>
<?php endforeach; ?>
