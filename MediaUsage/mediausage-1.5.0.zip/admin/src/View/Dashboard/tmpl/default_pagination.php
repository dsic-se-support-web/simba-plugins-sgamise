<?php
/**
 * @var Joomla\CMS\Pagination\Pagination $this->pagination
 */

if (empty($this->pagination)) {
    return;
}

$totalPages   = (int) $this->pagination->pagesTotal;
$currentPage  = (int) $this->pagination->pagesCurrent;

if ($totalPages > 1) : ?>
    <nav class="d-flex justify-content-center mt-3">
        <ul class="pagination">
            <?php for ($p = 1; $p <= $totalPages; $p++) :
                $start = ($p - 1) * $this->pagination->limit;
            ?>
                <li class="page-item <?= ($p === $currentPage) ? 'active' : '' ?>">
                    <a class="page-link"
                       href="index.php?option=com_mediausage&task=dashboard.loadOrphansPage&limitstart=<?= $start ?>">
                        <?= $p ?>
                    </a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
<?php endif; ?>
