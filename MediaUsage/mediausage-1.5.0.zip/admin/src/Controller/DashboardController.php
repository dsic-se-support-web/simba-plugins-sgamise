<?php

namespace Joomla\Component\Mediausage\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;

class DashboardController extends BaseController
{
    public function clearCache(): void
    {
        Factory::getCache('com_mediausage')->clean();

        $this->setRedirect(
            Route::_('index.php?option=com_mediausage&view=dashboard', false),
            Text::_('COM_MEDIAUSAGE_RECALC_SUCCESS')
        );
    }

    // Export CSV du top 50
    public function exportCsv(): void
    {
        $model = $this->getModel('Dashboard');
        $data  = $model->getCachedFileData();
        $top   = $model->getTopFilesByType($data['files'], 50);
    
        $filename = 'mediausage_top50_' . date('Ymd_His') . '.csv';
    
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
    
        $out = fopen('php://output', 'w');
    
        fputcsv($out, ['Type', 'Chemin', 'Taille (octets)']);
    
        foreach ($top as $type => $files) {
            foreach ($files as $file) {
                fputcsv($out, [
                    $type,
                    $file['relative_path'],
                    $file['size']
                ]);
            }
        }
    
        fclose($out);
        Factory::getApplication()->close();
    }

    // Export CSV des fichiers orphelins
    public function exportOrphansCsv(): void
    {
        $model = $this->getModel('Dashboard');
    
        $data        = $model->getCachedFileData();
        $orphanFiles = $model->getOrphanFiles($data['files']);
    
        $filename = 'mediausage_orphan_files_' . date('Ymd_His') . '.csv';
    
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
    
        $out = fopen('php://output', 'w');
    
        // En-tête CSV
        fputcsv($out, [
            'Chemin',
            'Taille (octets)',
            'Type MIME',
            'Score orphelin (%)',
            'Statut'
        ], ';');
    
        foreach ($orphanFiles as $file) {

            $score = (int) ($file['score'] ?? 0);
    
            // Libellé du statut
            if ($score >= 80) {
                $status = 'Orphelin certain';
            } elseif ($score >= 50) {
                $status = 'Orphelin probable';
            } elseif ($score > 0) {
                $status = 'Doute';
            } else {
                $status = 'Utilisé';
            }
    
            fputcsv($out, [
                $file['relative_path'],
                $file['size'],
                $file['mime'] ?? '',
                $score,
                $status
            ], ';');
        }
    
        fclose($out);
        Factory::getApplication()->close();
    }

    // Tâche Ajax pour pagination
    public function loadOrphansPage(): void
    {
        $model = $this->getModel('Dashboard');
        $model->populateState();
    
        $data        = $model->getCachedFileData();
        $orphanFiles = $model->getOrphanFiles($data['files']);
        $page        = $model->getPaginatedOrphanFiles($orphanFiles);

        $view = $this->getView('Dashboard', 'html');
    
        $view->addTemplatePath(
            JPATH_COMPONENT_ADMINISTRATOR . '/src/View/Dashboard/tmpl'
        );
    
        $view->setLayout('default');
        $view->orphanFiles = $page['items'];
        $view->start = (int) $model->getState('list.start', 0);
        $view->limit = (int) $model->getState('list.limit', 20);
        $view->pagination = $page['pagination'];
    
        $htmlRows = $view->loadTemplate('orphans');
        $htmlPagination = $view->loadTemplate('pagination');

        echo json_encode([
            'rows' => $htmlRows,
            'pagination' => $htmlPagination,
        ]);
    
        Factory::getApplication()->close();
    }    
}