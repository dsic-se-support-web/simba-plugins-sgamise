<?php

use Joomla\CMS\Router\Route;

if (empty($this->pagination)) {
    return;
}

$totalPages  = (int) $this->pagination->pagesTotal;
$currentPage = (int) $this->pagination->pagesCurrent;
$limit       = (int) $this->pagination->limit;

if ($totalPages <= 1) {
    return;
}

$makeUrl = static function (int $page) use ($limit) {

    $start = ($page - 1) * $limit;

    return Route::_(
        'index.php?option=com_mediausage'
        . '&task=dashboard.loadOrphansPage'
        . '&limitstart=' . $start
    );
};
?>

<nav class="d-flex justify-content-center mt-3">
    <ul class="pagination">
        <?php if ($currentPage > 1) : ?>
            <li class="page-item">
                <a class="page-link" href="<?= $makeUrl(1) ?>">&laquo;</a>
            </li>

            <li class="page-item">
                <a class="page-link" href="<?= $makeUrl($currentPage - 1) ?>">&lt;</a>
            </li>
        <?php endif; ?>

        <?php
            // 4 premières pages
            for ($i = 1; $i <= min(4, $totalPages); $i++) :
        ?>
            <li class="page-item <?= $i == $currentPage ? 'active' : '' ?>">
                <a class="page-link" href="<?= $makeUrl($i) ?>"><?= $i ?></a>
            </li>
        <?php endfor; ?>


        <?php if ($totalPages > 7) : ?>
            <li class="page-item disabled">
                <span class="page-link">…</span>
            </li>
        <?php endif; ?>


        <?php
            // 3 dernières pages
            $startLast = max(5, $totalPages - 2);
            for ($i = $startLast; $i <= $totalPages; $i++) :
        ?>
            <li class="page-item <?= $i == $currentPage ? 'active' : '' ?>">
                <a class="page-link" href="<?= $makeUrl($i) ?>"><?= $i ?></a>
            </li>
        <?php endfor; ?>


        <?php if ($currentPage < $totalPages) : ?>
            <li class="page-item">
                <a class="page-link" href="<?= $makeUrl($currentPage + 1) ?>">&gt;</a>
            </li>

            <li class="page-item">
                <a class="page-link" href="<?= $makeUrl($totalPages) ?>">&raquo;</a>
            </li>
        <?php endif; ?>
    </ul>
</nav>