<?php
/**
 * Template principal — liste des soumissions ConvertForms.
 *
 * Affiché via : index.php?option=com_cfsubmit (layout par défaut)
 *
 * Ce template gère trois zones :
 *   1. Sélecteur de formulaire (formulaire GET)
 *   2. Panneau de filtres dynamiques repliable (Bootstrap Collapse)
 *   3. Tableau paginé des soumissions + bouton de suppression par ligne
 *
 * Données disponibles injectées par HtmlView :
 *   $this->forms        → liste des formulaires ConvertForms publiés
 *   $this->formId       → ID du formulaire actuellement sélectionné
 *   $this->submissions  → toutes les soumissions du formulaire (enrichies par prepare())
 *   $this->filterFields → champs filtrables (dropdown/radio) avec leurs valeurs uniques
 *   $this->activeFilters → filtres actifs transmis dans l'URL (tableau fieldName → valeur)
 *   $this->limit        → nombre d'éléments par page
 *   $this->limitstart   → offset de pagination
 */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;

$baseUrl       = Route::_('index.php?option=com_cfsubmit');
$activeFilters = $this->activeFilters;

// Enregistrement du JS de confirmation de suppression via WebAssetManager.
// On évite intentionnellement un attribut "onsubmit" HTML inline qui serait
// bloqué par les Content Security Policy (CSP) strictes de Joomla 5+.
// "type: module" permet d'utiliser les modules ES6 et garantit que le script
// s'exécute après le chargement du DOM (équivalent d'un DOMContentLoaded).
Factory::getApplication()->getDocument()->getWebAssetManager()
    ->addInlineScript(<<<'JS'
        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('.cfsubmit-delete-form').forEach(function (form) {
                form.addEventListener('submit', function (e) {
                    // Le message de confirmation est stocké dans data-confirm
                    // pour éviter tout contenu dynamique PHP dans le JS
                    if (!window.confirm(form.dataset.confirm)) {
                        e.preventDefault();
                    }
                });
            });
        });
    JS, [], ['type' => 'module']);
?>

<div class="container-fluid p-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="d-flex align-items-center gap-2">
            <h1 class="h3 mb-0">Soumissions ConvertForms</h1>
            <?php if ($this->canConfig) : ?>
                <a href="<?php echo Route::_('index.php?option=com_config&view=component&component=com_cfsubmit'); ?>"
                    class="btn btn-outline-secondary btn-sm"
                    title="Configuration des accès aux formulaires">
                    Configuration des accès aux formulaires
                    <span class="icon-cog" aria-hidden="true"></span>
                </a>
            <?php endif; ?>
        </div>
        <?php if ($this->formId) : ?>
            <?php // Bouton affiché uniquement si un formulaire est sélectionné 
            ?>
            <a href="<?php echo $baseUrl . '&view=cfsubmit&layout=submit&form_id=' . (int) $this->formId; ?>"
                class="btn btn-success">
                <span class="icon-plus" aria-hidden="true"></span>
                Nouvelle soumission
            </a>
        <?php endif; ?>
    </div>

    <?php // Formulaire GET : recharge la page avec le form_id sélectionné dans l'URL 
    ?>
    <form method="get" action="<?php echo Route::_('index.php'); ?>" class="mb-3">
        <input type="hidden" name="option" value="com_cfsubmit">
        <?php // Réinitialise la pagination à 0 à chaque changement de formulaire 
        ?>
        <input type="hidden" name="limitstart" value="0">
        <div class="row align-items-end g-2">
            <div class="col-auto">
                <label for="form_id" class="form-label fw-bold mb-1">Formulaire</label>
                <select name="form_id" id="form_id" class="form-select" style="min-width:250px">
                    <option value="">-- Sélectionner --</option>
                    <?php foreach ($this->forms as $form) : ?>
                        <option value="<?php echo (int) $form->id; ?>"
                            <?php echo ($this->formId === (int) $form->id) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($form->name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary">Afficher</button>
            </div>
        </div>
    </form>

    <?php if ($this->formId) : ?>

        <?php // Le panneau de filtres n'est affiché que s'il existe des champs filtrables ?>
        <form method="get" action="<?php echo Route::_('index.php'); ?>" class="mb-3">
            <input type="hidden" name="option" value="com_cfsubmit">
            <input type="hidden" name="form_id" value="<?php echo (int) $this->formId; ?>">
            <input type="hidden" name="limitstart" value="0">
            <?php // On reporte les filtres dropdown actifs pour que la recherche se cumule aux filtres ?>
            <?php foreach ($activeFilters as $k => $v) : ?>
                <?php if ($v !== '') : ?>
                    <input type="hidden" name="filters[<?php echo htmlspecialchars($k); ?>]" value="<?php echo htmlspecialchars($v); ?>">
                <?php endif; ?>
            <?php endforeach; ?>
            <?php if ($this->limit !== 10) : ?>
                <input type="hidden" name="limit" value="<?php echo (int) $this->limit; ?>">
            <?php endif; ?>
            <div class="input-group" style="max-width:400px">
                <input type="search" class="form-control" name="search"
                       placeholder="Rechercher dans les soumissions..."
                       value="<?php echo htmlspecialchars($this->search); ?>">
                <button class="btn btn-outline-secondary" type="submit">
                    <span class="icon-search" aria-hidden="true"></span>
                </button>
                <?php if ($this->search !== '') : ?>
                    <a href="<?php echo Route::_('index.php?option=com_cfsubmit&form_id=' . (int) $this->formId
                        . (empty(array_filter($activeFilters)) ? '' : '&' . http_build_query(['filters' => $activeFilters]))); ?>"
                       class="btn btn-outline-secondary" title="Effacer la recherche">
                        <span class="icon-times" aria-hidden="true"></span>
                    </a>
                <?php endif; ?>
            </div>
        </form>

        <?php // Le panneau de filtres n'est affiché que s'il existe des champs filtrables
        ?>
        <?php if (!empty($this->filterFields)) : ?>
            <div class="mb-2">
                <?php
                // Le panneau est automatiquement ouvert si au moins un filtre est actif.
                // Bootstrap Collapse gère l'affichage/masquage côté JS.
                $hasActiveFilter = !empty(array_filter($activeFilters));
                ?>
                <button class="btn btn-outline-secondary btn-sm" type="button"
                    data-bs-toggle="collapse" data-bs-target="#cfsubmit-filters"
                    aria-expanded="<?php echo $hasActiveFilter ? 'true' : 'false'; ?>"
                    aria-controls="cfsubmit-filters">
                    <span class="icon-filter" aria-hidden="true"></span>
                    Filtres
                </button>
            </div>

            <div class="collapse <?php echo $hasActiveFilter ? 'show' : ''; ?>" id="cfsubmit-filters">
                <?php // Formulaire GET séparé pour les filtres — n'interfère pas avec le sélecteur 
                ?>
                <form method="get" action="<?php echo Route::_('index.php'); ?>" class="mb-4 p-3 bg-light border rounded">
                    <input type="hidden" name="option" value="com_cfsubmit">
                    <input type="hidden" name="form_id" value="<?php echo (int) $this->formId; ?>">
                    <input type="hidden" name="limitstart" value="0">
                    <?php if ($this->search !== '') : ?>
                        <input type="hidden" name="search" value="<?php echo htmlspecialchars($this->search); ?>">
                    <?php endif; ?>
                    <div class="row g-3 align-items-end">

                        <?php foreach ($this->filterFields as $fieldName => $fieldDef) : ?>
                            <div class="col-auto">
                                <label class="form-label" for="filter-<?php echo htmlspecialchars($fieldName); ?>">
                                    <?php echo htmlspecialchars($fieldDef['label']); ?>
                                </label>
                                <?php
                                // Les valeurs disponibles dans ce select sont uniquement celles
                                // présentes dans les soumissions (pas toutes les options du formulaire)
                                ?>
                                <select class="form-select"
                                    name="filters[<?php echo htmlspecialchars($fieldName); ?>]"
                                    id="filter-<?php echo htmlspecialchars($fieldName); ?>">
                                    <option value="">-- Tous --</option>
                                    <?php foreach ($fieldDef['values'] as $val) : ?>
                                        <option value="<?php echo htmlspecialchars($val); ?>"
                                            <?php echo (($activeFilters[$fieldName] ?? '') === $val) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($val); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endforeach; ?>

                        <div class="col-auto">
                            <label class="form-label" for="filtre-limit">Éléments par page</label>
                            <select class="form-select" name="limit" id="filtre-limit">
                                <?php foreach ([10 => '10', 50 => '50', 100 => '100'] as $val => $label) : ?>
                                    <option value="<?php echo $val; ?>"
                                        <?php echo ($this->limit === $val) ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-auto d-flex gap-2">
                            <button type="submit" class="btn btn-primary">Filtrer</button>
                            <?php // Réinitialiser = retour sur la liste sans filtres ni pagination 
                            ?>
                            <a href="<?php echo $baseUrl . '&form_id=' . (int) $this->formId; ?>"
                                class="btn btn-secondary">Réinitialiser</a>
                        </div>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <?php
        // --- Filtrage PHP cumulatif ---
        // Les soumissions sont toutes chargées en mémoire depuis la View.
        // On applique ici le filtrage côté PHP (et non en SQL) car les valeurs à comparer
        // viennent de prepared_fields, qui sont construits après le chargement SQL.
        // $cmp : comparaison insensible à la casse et aux espaces en UTF-8
        $cmp = fn(string $a, string $b) =>
        mb_strtolower(trim($a), 'UTF-8') === mb_strtolower(trim($b), 'UTF-8');

        $soumissionsFiltrees = [];
        foreach ($this->submissions as $submission) {
            $match = true;
            foreach ($activeFilters as $fieldName => $filterVal) {
                if ($filterVal === '') continue;
                $subVal = $submission->prepared_fields[$fieldName]->value ?? '';
                if (!$cmp($subVal, $filterVal)) {
                    $match = false;
                    break;
                }
            }
            if ($match) {
                $soumissionsFiltrees[] = $submission;
            }
        }

        // Étape 2 : recherche texte libre (s'applique sur le résultat des filtres dropdown)
        // On cherche uniquement dans les champs texte — les champs dropdown/radio sont exclus
        // car ils sont déjà couverts par les filtres (leur nom est dans $this->filterFields).
        // La normalisation NFD décompose les caractères accentués (é → e + ◌́) puis supprime
        // les diacritiques, rendant la recherche insensible à la casse ET aux accents.
        $normalize = fn(string $s): string => mb_strtolower(
            preg_replace('/[\x{0300}-\x{036F}]/u', '', \Normalizer::normalize($s, \Normalizer::FORM_D)),
            'UTF-8'
        );
        $search = $normalize(trim($this->search));
        if ($search !== '') {
            $selectFieldNames = array_keys($this->filterFields);
            $soumissionsFiltrees = array_values(array_filter(
                $soumissionsFiltrees,
                function ($submission) use ($search, $normalize, $selectFieldNames) {
                    foreach ($submission->prepared_fields as $fieldName => $field) {
                        if (in_array($fieldName, $selectFieldNames, true)) continue;
                        if (str_contains($normalize((string) ($field->value ?? '')), $search)) {
                            return true;
                        }
                    }
                    return false;
                }
            ));
        }

        // --- Calcul de la pagination ---
        $limit      = $this->limit;
        $limitstart = $this->limitstart;
        $total      = count($soumissionsFiltrees);
        $totalPages = max(1, (int) ceil($total / $limit));
        // Sécurité : si limitstart dépasse le nombre de pages (ex: après filtrage),
        // on le ramène à la dernière page disponible
        $limitstart  = min($limitstart, ($totalPages - 1) * $limit);
        $currentPage = (int) floor($limitstart / $limit) + 1;
        // array_slice extrait uniquement la "page" courante depuis le tableau complet
        $paginated   = array_slice($soumissionsFiltrees, $limitstart, $limit);
        ?>

        <?php if (empty($soumissionsFiltrees)) : ?>
            <div class="alert alert-info">Aucune soumission ne correspond aux filtres.</div>
        <?php else : ?>

            <p class="text-muted small mb-2">
                <?php echo $total; ?> soumission(s) —
                page <?php echo $currentPage; ?> / <?php echo $totalPages; ?>
            </p>

            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-light border-bottom border-2">
                        <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Champs soumis</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($paginated as $submission) : ?>
                            <tr>
                                <td><?php echo (int) $submission->id; ?></td>
                                <?php // HTMLHelper::date() formate la date SQL en tenant compte du fuseau horaire Joomla 
                                ?>
                                <td class="text-nowrap"><?php echo HTMLHelper::date($submission->created, 'd/m/Y H:i'); ?></td>
                                <td>
                                    <?php if (!empty($submission->prepared_fields)) : ?>
                                        <?php
                                        // Affichage sous forme de liste de définition HTML (dl/dt/dd)
                                        // dt = label du champ, dd = valeur affichable (value_html inclut les liens de téléchargement)
                                        // Les champs avec une valeur vide sont masqués
                                        ?>
                                        <dl class="mb-0 row">
                                            <?php foreach ($submission->prepared_fields as $fieldName => $field) : ?>
                                                <?php if ((string) $field->value !== '') : ?>
                                                    <dt class="col-sm-4 small text-muted">
                                                        <?php echo htmlspecialchars($field->label ?? $fieldName); ?>
                                                    </dt>
                                                    <dd class="col-sm-8">
                                                        <?php // value_html est déjà échappé et formaté par ConvertForms::prepare() 
                                                        ?>
                                                        <?php echo $field->value_html; ?>
                                                    </dd>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </dl>
                                    <?php else : ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex gap-1">
                                        <a href="<?php echo Route::_('index.php?option=com_cfsubmit&view=cfsubmit&layout=edit&id=' . (int) $submission->id . '&form_id=' . (int) $this->formId); ?>"
                                           class="btn btn-sm btn-outline-primary" title="Modifier">
                                            <span class="icon-edit" aria-hidden="true"></span>
                                        </a>
                                        <form method="post" action="<?php echo Route::_('index.php'); ?>"
                                            class="cfsubmit-delete-form"
                                            data-confirm="Supprimer la soumission #<?php echo (int) $submission->id; ?> ?">
                                            <input type="hidden" name="option" value="com_cfsubmit">
                                            <input type="hidden" name="controller" value="submission">
                                            <input type="hidden" name="task" value="submission.delete">
                                            <input type="hidden" name="id" value="<?php echo (int) $submission->id; ?>">
                                            <input type="hidden" name="form_id" value="<?php echo (int) $this->formId; ?>">
                                            <input type="hidden" name="<?php echo Session::getFormToken(); ?>" value="1">
                                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Supprimer">
                                                <span class="icon-trash" aria-hidden="true"></span>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($totalPages > 1) : ?>
                <?php
                // Construction de l'URL de base pour la pagination en préservant
                // les filtres actifs et la limite par page dans chaque lien
                $paginationBase = $baseUrl . '&form_id=' . (int) $this->formId . '&limit=' . $limit;
                foreach ($activeFilters as $k => $v) {
                    if ($v !== '') $paginationBase .= '&filters[' . urlencode($k) . ']=' . urlencode($v);
                }
                if ($this->search !== '') {
                    $paginationBase .= '&search=' . urlencode($this->search);
                }
                ?>
                <nav aria-label="Pagination">
                    <ul class="pagination">
                        <li class="page-item <?php echo ($currentPage <= 1) ? 'disabled' : ''; ?>">
                            <a class="page-link" href="<?php echo $paginationBase . '&limitstart=' . (($currentPage - 2) * $limit); ?>">
                                Précédent
                            </a>
                        </li>
                        <?php for ($p = 1; $p <= $totalPages; $p++) : ?>
                            <li class="page-item <?php echo ($p === $currentPage) ? 'active' : ''; ?>">
                                <a class="page-link" href="<?php echo $paginationBase . '&limitstart=' . (($p - 1) * $limit); ?>">
                                    <?php echo $p; ?>
                                </a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?php echo ($currentPage >= $totalPages) ? 'disabled' : ''; ?>">
                            <a class="page-link" href="<?php echo $paginationBase . '&limitstart=' . ($currentPage * $limit); ?>">
                                Suivant
                            </a>
                        </li>
                    </ul>
                </nav>
            <?php endif; ?>

        <?php endif; ?>
    <?php endif; ?>

</div>