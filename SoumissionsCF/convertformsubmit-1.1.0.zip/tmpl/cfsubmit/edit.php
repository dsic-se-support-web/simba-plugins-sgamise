<?php
/**
 * Template de modification d'une soumission existante.
 *
 * Affiché via : index.php?option=com_cfsubmit&view=cfsubmit&layout=edit&id=X&form_id=Y
 *
 * Chaque champ est pré-rempli avec la valeur existante de la soumission.
 * Pour les fichiers : le fichier actuel est affiché avec un lien, un input file
 * optionnel permet de le remplacer. Si rien n'est uploadé, l'ancien est conservé.
 *
 * Données disponibles injectées par HtmlView :
 *   $this->formId    → identifiant du formulaire ConvertForms
 *   $this->formDef   → définition complète du formulaire (champs, types, options)
 *   $this->submission → objet de la soumission avec params (tableau associatif)
 */
defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;

$mediaParams      = ComponentHelper::getParams('com_media');
$allowedExtString = $mediaParams->get('restrict_uploads_extensions', 'pdf,doc,docx,xls,xlsx,jpg,jpeg,png,gif');
$acceptAttr       = implode(',', array_map(fn($e) => '.' . trim($e), explode(',', $allowedExtString)));

$formId     = (int) $this->formId;
$submission = $this->submission;
$formDef    = $this->formDef;
$fields     = ($formDef && !empty($formDef['fields'])) ? $formDef['fields'] : [];
$formName   = $formDef['name'] ?? 'Formulaire #' . $formId;
$existing   = $submission ? ($submission->params ?? []) : [];
?>

<div class="container-fluid p-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">
            Modifier la soumission #<?php echo (int) $submission->id; ?>
            — <?php echo htmlspecialchars($formName); ?>
        </h1>
        <a href="<?php echo Route::_('index.php?option=com_cfsubmit&form_id=' . $formId); ?>"
           class="btn btn-secondary">
            <span class="icon-arrow-left" aria-hidden="true"></span>
            Retour
        </a>
    </div>

    <?php if (empty($fields) || !$submission) : ?>
        <div class="alert alert-warning">Impossible de charger la soumission ou la définition du formulaire.</div>
    <?php else : ?>

        <form method="post" action="<?php echo Route::_('index.php'); ?>"
              enctype="multipart/form-data" class="card p-4">

            <input type="hidden" name="option"     value="com_cfsubmit">
            <input type="hidden" name="controller" value="submission">
            <input type="hidden" name="task"       value="submission.update">
            <input type="hidden" name="id"         value="<?php echo (int) $submission->id; ?>">
            <input type="hidden" name="form_id"    value="<?php echo $formId; ?>">
            <input type="hidden" name="<?php echo Session::getFormToken(); ?>" value="1">

            <?php
            $hiddenTypes = ['submit', 'recaptcha', 'hcaptcha', 'turnstile', 'honeypot', 'pagebreak'];

            foreach ($fields as $field) :
                $type     = $field['type'] ?? 'text';
                $name     = $field['name'] ?? '';
                $label    = $field['label'] ?? $name;
                $required = !empty($field['required']);

                $rawChoices = $field['choices']['choices'] ?? [];
                $options    = [];
                foreach ($rawChoices as $c) {
                    $lbl = trim($c['label'] ?? '');
                    if ($lbl === '') continue;
                    $val       = ($c['value'] ?? '') !== '' ? $c['value'] : $lbl;
                    $options[] = ['label' => $lbl, 'value' => $val];
                }

                if (!$name || in_array($type, $hiddenTypes)) continue;

                // Valeur actuelle de ce champ dans la soumission
                $currentValue = $existing[$name] ?? '';
            ?>
                <div class="mb-3">
                    <label class="form-label fw-semibold" for="field-<?php echo htmlspecialchars($name); ?>">
                        <?php echo htmlspecialchars($label); ?>
                        <?php if ($required) : ?>
                            <span class="text-danger" title="Obligatoire">*</span>
                        <?php endif; ?>
                    </label>

                    <?php if ($type === 'textarea') : ?>
                        <textarea class="form-control"
                                  id="field-<?php echo htmlspecialchars($name); ?>"
                                  name="fields[<?php echo htmlspecialchars($name); ?>]"
                                  rows="4"
                                  <?php echo $required ? 'required' : ''; ?>><?php echo htmlspecialchars((string) $currentValue); ?></textarea>

                    <?php elseif ($type === 'dropdown' || $type === 'select') : ?>
                        <select class="form-select"
                                id="field-<?php echo htmlspecialchars($name); ?>"
                                name="fields[<?php echo htmlspecialchars($name); ?>]"
                                <?php echo $required ? 'required' : ''; ?>>
                            <option value="">-- Sélectionner --</option>
                            <?php foreach ($options as $opt) : ?>
                                <option value="<?php echo htmlspecialchars($opt['value']); ?>"
                                    <?php echo ($currentValue === $opt['value']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($opt['label']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>

                    <?php elseif ($type === 'radio') : ?>
                        <?php foreach ($options as $opt) : ?>
                            <div class="form-check">
                                <input class="form-check-input" type="radio"
                                       id="field-<?php echo htmlspecialchars($name . '-' . $opt['value']); ?>"
                                       name="fields[<?php echo htmlspecialchars($name); ?>]"
                                       value="<?php echo htmlspecialchars($opt['value']); ?>"
                                       <?php echo ($currentValue === $opt['value']) ? 'checked' : ''; ?>
                                       <?php echo $required ? 'required' : ''; ?>>
                                <label class="form-check-label"
                                       for="field-<?php echo htmlspecialchars($name . '-' . $opt['value']); ?>">
                                    <?php echo htmlspecialchars($opt['label']); ?>
                                </label>
                            </div>
                        <?php endforeach; ?>

                    <?php elseif ($type === 'checkbox' || $type === 'checkboxes') : ?>
                        <?php
                        // Les valeurs cochées sont stockées concaténées "val1, val2"
                        $checkedValues = array_map('trim', explode(',', (string) $currentValue));
                        ?>
                        <?php foreach ($options as $opt) : ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox"
                                       id="field-<?php echo htmlspecialchars($name . '-' . $opt['value']); ?>"
                                       name="fields[<?php echo htmlspecialchars($name); ?>][]"
                                       value="<?php echo htmlspecialchars($opt['value']); ?>"
                                       <?php echo in_array($opt['value'], $checkedValues) ? 'checked' : ''; ?>>
                                <label class="form-check-label"
                                       for="field-<?php echo htmlspecialchars($name . '-' . $opt['value']); ?>">
                                    <?php echo htmlspecialchars($opt['label']); ?>
                                </label>
                            </div>
                        <?php endforeach; ?>

                    <?php elseif ($type === 'fileupload') : ?>
                        <?php
                        // $currentValue peut être un chemin string ou un tableau de chemins
                        $filePaths = is_array($currentValue) ? $currentValue : ($currentValue !== '' ? [$currentValue] : []);
                        ?>
                        <?php if (!empty($filePaths)) : ?>
                            <div class="mb-2">
                                <?php foreach ($filePaths as $path) : ?>
                                    <div class="d-flex align-items-center gap-2 mb-1">
                                        <span class="icon-file" aria-hidden="true"></span>
                                        <a href="<?php echo htmlspecialchars(Uri::root() . ltrim($path, '/')); ?>"
                                           target="_blank" class="small">
                                            <?php echo htmlspecialchars(basename($path)); ?>
                                        </a>
                                    </div>
                                    <?php // Champ caché pour conserver l'ancien fichier si rien n'est uploadé ?>
                                    <input type="hidden"
                                           name="existing_files[<?php echo htmlspecialchars($name); ?>]"
                                           value="<?php echo htmlspecialchars($path); ?>">
                                <?php endforeach; ?>
                                <div class="form-text text-muted">Uploader un nouveau fichier remplacera l'actuel.</div>
                            </div>
                        <?php endif; ?>
                        <input class="form-control" type="file"
                               id="field-<?php echo htmlspecialchars($name); ?>"
                               name="files[<?php echo htmlspecialchars($name); ?>][]"
                               accept="<?php echo htmlspecialchars($acceptAttr); ?>"
                               multiple>
                        <div class="form-text">Formats acceptés : <?php echo htmlspecialchars($allowedExtString); ?></div>

                    <?php elseif ($type === 'date') : ?>
                        <input class="form-control" type="date"
                               id="field-<?php echo htmlspecialchars($name); ?>"
                               name="fields[<?php echo htmlspecialchars($name); ?>]"
                               value="<?php echo htmlspecialchars((string) $currentValue); ?>"
                               <?php echo $required ? 'required' : ''; ?>>

                    <?php elseif ($type === 'email') : ?>
                        <input class="form-control" type="email"
                               id="field-<?php echo htmlspecialchars($name); ?>"
                               name="fields[<?php echo htmlspecialchars($name); ?>]"
                               value="<?php echo htmlspecialchars((string) $currentValue); ?>"
                               <?php echo $required ? 'required' : ''; ?>>

                    <?php elseif ($type === 'number') : ?>
                        <input class="form-control" type="number"
                               id="field-<?php echo htmlspecialchars($name); ?>"
                               name="fields[<?php echo htmlspecialchars($name); ?>]"
                               value="<?php echo htmlspecialchars((string) $currentValue); ?>"
                               <?php echo $required ? 'required' : ''; ?>>

                    <?php else : ?>
                        <input class="form-control" type="text"
                               id="field-<?php echo htmlspecialchars($name); ?>"
                               name="fields[<?php echo htmlspecialchars($name); ?>]"
                               value="<?php echo htmlspecialchars((string) $currentValue); ?>"
                               <?php echo $required ? 'required' : ''; ?>>
                    <?php endif; ?>

                </div>
            <?php endforeach; ?>

            <div class="d-flex gap-2 mt-3">
                <button type="submit" class="btn btn-success">
                    <span class="icon-save" aria-hidden="true"></span>
                    Enregistrer les modifications
                </button>
                <a href="<?php echo Route::_('index.php?option=com_cfsubmit&form_id=' . $formId); ?>"
                   class="btn btn-secondary">Annuler</a>
            </div>

        </form>

    <?php endif; ?>

</div>
