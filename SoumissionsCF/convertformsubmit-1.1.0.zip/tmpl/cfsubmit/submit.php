<?php
/**
 * Template du formulaire de création d'une nouvelle soumission.
 *
 * Affiché via : index.php?option=com_cfsubmit&view=cfsubmit&layout=submit&form_id=X
 *
 * Ce template génère dynamiquement les champs HTML à partir de la définition
 * du formulaire ConvertForms ($this->formDef). Chaque type de champ ConvertForms
 * est traduit en son équivalent HTML natif.
 *
 * À la soumission, le POST est traité par SubmissionController::save().
 *
 * Données disponibles injectées par HtmlView :
 *   $this->formId  → identifiant du formulaire ConvertForms
 *   $this->formDef → définition complète du formulaire (champs, types, options)
 */
defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;

// On récupère la liste des extensions autorisées depuis la configuration de com_media.
// C'est la même whitelist que celle vérifiée côté serveur dans SubmissionController::save()
// via MediaHelper::canUpload() — les deux doivent rester cohérents.
$mediaParams      = ComponentHelper::getParams('com_media');
$allowedExtString = $mediaParams->get('restrict_uploads_extensions', 'pdf,doc,docx,xls,xlsx,jpg,jpeg,png,gif');
// Transformation en attribut HTML "accept" : "pdf,jpg" → ".pdf,.jpg"
$acceptAttr       = implode(',', array_map(fn($e) => '.' . trim($e), explode(',', $allowedExtString)));

$formId   = (int) $this->formId;
$formDef  = $this->formDef;
// $formDef['fields'] est indexé par nom de champ (clé = nom du champ)
$fields   = ($formDef && !empty($formDef['fields'])) ? $formDef['fields'] : [];
$formName = $formDef['name'] ?? 'Formulaire #' . $formId;
?>

<div class="container-fluid p-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Nouvelle soumission — <?php echo htmlspecialchars($formName); ?></h1>
        <a href="<?php echo Route::_('index.php?option=com_cfsubmit&form_id=' . $formId); ?>"
           class="btn btn-secondary">
            <span class="icon-arrow-left" aria-hidden="true"></span>
            Retour
        </a>
    </div>

    <?php if (empty($fields)) : ?>
        <div class="alert alert-warning">Impossible de charger la définition du formulaire.</div>
    <?php else : ?>

        <?php
        // enctype multipart/form-data obligatoire pour l'upload de fichiers
        // Route::_() génère une URL Joomla correcte (tient compte du SEF si activé)
        ?>
        <form method="post" action="<?php echo Route::_('index.php'); ?>"
              enctype="multipart/form-data" class="card p-4">

            <?php // Champs cachés nécessaires au routage Joomla MVC ?>
            <input type="hidden" name="option"     value="com_cfsubmit">
            <input type="hidden" name="controller" value="submission">
            <input type="hidden" name="task"       value="submission.save">
            <input type="hidden" name="form_id"    value="<?php echo $formId; ?>">
            <?php // Token CSRF de Joomla — vérifié par $this->checkToken() dans le Controller ?>
            <input type="hidden" name="<?php echo Session::getFormToken(); ?>" value="1">

            <?php
            // Types de champs ConvertForms à ne pas afficher (non-interactifs ou techniques)
            $hiddenTypes = ['submit', 'recaptcha', 'hcaptcha', 'turnstile', 'honeypot', 'pagebreak'];

            foreach ($fields as $field) :
                $type     = $field['type'] ?? 'text';
                $name     = $field['name'] ?? '';
                $label    = $field['label'] ?? $name;
                $required = !empty($field['required']);

                // Dans ConvertForms, les options des champs à choix (dropdown, radio, checkbox)
                // sont stockées sous $field['choices']['choices'], chaque entrée ayant 'label' et 'value'.
                // Si 'value' est vide, on utilise le label comme valeur (comportement natif ConvertForms).
                $rawChoices = $field['choices']['choices'] ?? [];
                $options    = [];
                foreach ($rawChoices as $c) {
                    $lbl = trim($c['label'] ?? '');
                    if ($lbl === '') continue;
                    $val       = ($c['value'] ?? '') !== '' ? $c['value'] : $lbl;
                    $options[] = ['label' => $lbl, 'value' => $val];
                }

                // On saute les champs sans nom et les champs purement techniques
                if (!$name || in_array($type, $hiddenTypes)) continue;
            ?>
                <div class="mb-3">
                    <label class="form-label fw-semibold" for="field-<?php echo htmlspecialchars($name); ?>">
                        <?php echo htmlspecialchars($label); ?>
                        <?php if ($required) : ?>
                            <span class="text-danger" title="Obligatoire">*</span>
                        <?php endif; ?>
                    </label>

                    <?php if ($type === 'textarea') : ?>
                        <textarea class="form-control"
                                  id="field-<?php echo htmlspecialchars($name); ?>"
                                  name="fields[<?php echo htmlspecialchars($name); ?>]"
                                  rows="4"
                                  <?php echo $required ? 'required' : ''; ?>></textarea>

                    <?php elseif ($type === 'dropdown' || $type === 'select') : ?>
                        <?php // Les valeurs sont envoyées dans fields[nomDuChamp] ?>
                        <select class="form-select"
                                id="field-<?php echo htmlspecialchars($name); ?>"
                                name="fields[<?php echo htmlspecialchars($name); ?>]"
                                <?php echo $required ? 'required' : ''; ?>>
                            <option value="">-- Sélectionner --</option>
                            <?php foreach ($options as $opt) : ?>
                                <option value="<?php echo htmlspecialchars($opt['value']); ?>">
                                    <?php echo htmlspecialchars($opt['label']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>

                    <?php elseif ($type === 'radio') : ?>
                        <?php // Un seul choix possible → name sans [] ?>
                        <?php foreach ($options as $opt) : ?>
                            <div class="form-check">
                                <input class="form-check-input" type="radio"
                                       id="field-<?php echo htmlspecialchars($name . '-' . $opt['value']); ?>"
                                       name="fields[<?php echo htmlspecialchars($name); ?>]"
                                       value="<?php echo htmlspecialchars($opt['value']); ?>"
                                       <?php echo $required ? 'required' : ''; ?>>
                                <label class="form-check-label"
                                       for="field-<?php echo htmlspecialchars($name . '-' . $opt['value']); ?>">
                                    <?php echo htmlspecialchars($opt['label']); ?>
                                </label>
                            </div>
                        <?php endforeach; ?>

                    <?php elseif ($type === 'checkbox' || $type === 'checkboxes') : ?>
                        <?php // Choix multiples possibles → name avec [] pour créer un tableau ?>
                        <?php foreach ($options as $opt) : ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox"
                                       id="field-<?php echo htmlspecialchars($name . '-' . $opt['value']); ?>"
                                       name="fields[<?php echo htmlspecialchars($name); ?>][]"
                                       value="<?php echo htmlspecialchars($opt['value']); ?>">
                                <label class="form-check-label"
                                       for="field-<?php echo htmlspecialchars($name . '-' . $opt['value']); ?>">
                                    <?php echo htmlspecialchars($opt['label']); ?>
                                </label>
                            </div>
                        <?php endforeach; ?>

                    <?php elseif ($type === 'fileupload') : ?>
                        <?php
                        // Les fichiers sont envoyés dans files[nomDuChamp][] (tableau pour le multi-upload).
                        // Le nom du champ est séparé de "fields" pour faciliter le traitement
                        // dans SubmissionController::save() ($rawFields vs $_FILES['files']).
                        ?>
                        <input class="form-control" type="file"
                               id="field-<?php echo htmlspecialchars($name); ?>"
                               name="files[<?php echo htmlspecialchars($name); ?>][]"
                               accept="<?php echo htmlspecialchars($acceptAttr); ?>"
                               multiple
                               <?php echo $required ? 'required' : ''; ?>>
                        <div class="form-text">
                            Formats acceptés : <?php echo htmlspecialchars($allowedExtString); ?>
                        </div>

                    <?php elseif ($type === 'date') : ?>
                        <input class="form-control" type="date"
                               id="field-<?php echo htmlspecialchars($name); ?>"
                               name="fields[<?php echo htmlspecialchars($name); ?>]"
                               <?php echo $required ? 'required' : ''; ?>>

                    <?php elseif ($type === 'email') : ?>
                        <input class="form-control" type="email"
                               id="field-<?php echo htmlspecialchars($name); ?>"
                               name="fields[<?php echo htmlspecialchars($name); ?>]"
                               <?php echo $required ? 'required' : ''; ?>>

                    <?php elseif ($type === 'number') : ?>
                        <input class="form-control" type="number"
                               id="field-<?php echo htmlspecialchars($name); ?>"
                               name="fields[<?php echo htmlspecialchars($name); ?>]"
                               <?php echo $required ? 'required' : ''; ?>>

                    <?php else : ?>
                        <?php // Fallback : tous les types non reconnus → champ texte simple ?>
                        <input class="form-control" type="text"
                               id="field-<?php echo htmlspecialchars($name); ?>"
                               name="fields[<?php echo htmlspecialchars($name); ?>]"
                               <?php echo $required ? 'required' : ''; ?>>
                    <?php endif; ?>

                </div>
            <?php endforeach; ?>

            <div class="d-flex gap-2 mt-3">
                <button type="submit" class="btn btn-success">
                    <span class="icon-save" aria-hidden="true"></span>
                    Enregistrer
                </button>
                <a href="<?php echo Route::_('index.php?option=com_cfsubmit&form_id=' . $formId); ?>"
                   class="btn btn-secondary">Annuler</a>
            </div>

        </form>

    <?php endif; ?>

</div>
