# ConvertFormSubmit

Besoin exprimé et réalisé par DRH-MI (Mathieu LUCIEN).

Composant permettant la saisie de soumissions à un formulaire via le back office de Joomla. Les soumissions peuvent alors être affichées en front office sous la forme d'un tableau de données via un module ConvertForm.
