<?php
/**
 * Contrôleur d'affichage par défaut du composant.
 *
 * Joomla appelle ce contrôleur quand aucun paramètre "controller" n'est précisé
 * dans l'URL (ou quand task=display). Il hérite de BaseController::display()
 * qui se charge de :
 *   1. Instancier la View correspondante (ici : View\Cfsubmit\HtmlView)
 *   2. Appeler HtmlView::display() pour préparer et afficher les données
 *
 * La propriété $default_view indique quelle View charger par défaut.
 */
namespace Cfsubmit\Component\Cfsubmit\Administrator\Controller;

use Joomla\CMS\MVC\Controller\BaseController;

class DisplayController extends BaseController
{
    // Nom de la View utilisée quand aucune view n'est précisée dans l'URL.
    // Joomla ira chercher src/View/Cfsubmit/HtmlView.php
    protected $default_view = 'cfsubmit';
}
