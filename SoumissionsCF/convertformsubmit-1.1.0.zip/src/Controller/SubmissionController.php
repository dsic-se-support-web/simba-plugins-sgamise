<?php
/**
 * Contrôleur des actions métier sur les soumissions.
 *
 * Joomla route ici toutes les requêtes dont le paramètre URL "controller=submission".
 * Chaque méthode publique correspond à une "task" :
 *   - submission.delete → supprime une soumission
 *   - submission.save   → crée une nouvelle soumission (avec upload de fichier éventuel)
 *
 * Règle importante : aucun HTML ici. Le contrôleur traite, puis redirige toujours
 * vers une URL via setRedirect(). C'est le pattern POST-Redirect-GET.
 */
namespace Cfsubmit\Component\Cfsubmit\Administrator\Controller;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\Database\DatabaseInterface;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Helper\MediaHelper;

class SubmissionController extends BaseController
{
    /**
     * Supprime une soumission ConvertForms de la base de données.
     *
     * Appelé via POST avec task=submission.delete, id=X, form_id=Y.
     * Le token CSRF est vérifié avant toute action pour prévenir les attaques CSRF.
     */
    public function delete(): void
    {
        // Vérifie le token de session Joomla pour prévenir les attaques CSRF
        $this->checkToken();

        $input  = $this->app->getInput();
        $db     = Factory::getContainer()->get(DatabaseInterface::class);
        $id     = $input->getInt('id', 0);
        $formId = $input->getInt('form_id', 0);

        if ($id > 0) {
            // Charge la soumission pour vérifier qu'elle appartient bien au formulaire
            // indiqué dans le POST — évite qu'un utilisateur supprime une soumission
            // d'un autre formulaire en falsifiant le paramètre "id".
            $query = $db->getQuery(true)
                ->select(['id', 'form_id'])
                ->from($db->quoteName('#__convertforms_conversions'))
                ->where($db->quoteName('id') . ' = ' . $id);
            $submission = $db->setQuery($query)->loadObject();

            if (!$submission || (int) $submission->form_id !== $formId) {
                $this->app->enqueueMessage('Soumission invalide.', 'error');
                $this->setRedirect($returnUrl);
                return;
            }

            // Pour les non-super-admins, vérifie que l'utilisateur a accès à ce formulaire.
            // Même logique que HtmlView : on construit la carte form_id → groupes autorisés.
            $identity = $this->app->getIdentity();
            if (!$identity->authorise('core.admin')) {
                if (!$this->isFormAllowed($formId)) {
                    $this->app->enqueueMessage('Accès refusé.', 'error');
                    $this->setRedirect($returnUrl);
                    return;
                }
            }

            // Suppression directe dans la table ConvertForms
            $query = $db->getQuery(true)
                ->delete($db->quoteName('#__convertforms_conversions'))
                ->where($db->quoteName('id') . ' = ' . $id);
            $db->setQuery($query)->execute();

            $this->app->enqueueMessage('Soumission #' . $id . ' supprimée.', 'success');
        }

        // Retour sur la liste filtrée par formulaire
        $returnUrl = 'index.php?option=com_cfsubmit' . ($formId ? '&form_id=' . $formId : '');
        $this->setRedirect($returnUrl);
    }

    /**
     * Enregistre une nouvelle soumission créée manuellement depuis l'administration.
     *
     * Appelé via POST (multipart/form-data) avec task=submission.save.
     * Traite les champs texte/select/radio dans $_POST['fields']
     * et les fichiers uploadés dans $_FILES['files'].
     *
     * Note : $_POST est lu directement car Joomla InputFilter peut supprimer des
     * valeurs dans les tableaux imbriqués contenant des espaces ou des accents dans les clés.
     */
    public function save(): void
    {
        // Vérifie le token de session Joomla pour prévenir les attaques CSRF
        $this->checkToken();

        $input     = $this->app->getInput();
        $formId    = $input->getInt('form_id', 0);
        $returnUrl = 'index.php?option=com_cfsubmit' . ($formId ? '&form_id=' . $formId : '');

        if (!$formId) {
            $this->app->enqueueMessage('Formulaire invalide.', 'error');
            $this->setRedirect($returnUrl);
            return;
        }

        // Lecture directe de $_POST pour préserver les clés avec espaces/accents/apostrophes.
        // Joomla InputFilter avec le filtre 'array' les supprimerait.
        $rawFields = $_POST['fields'] ?? [];
        $params    = [];

        foreach ($rawFields as $name => $value) {
            // On supprime uniquement les caractères de contrôle (null bytes, etc.)
            // mais on conserve espaces, accents, apostrophes car ce sont les vrais
            // noms de champs tels que définis dans ConvertForms.
            $name = preg_replace('/[\x00-\x1F\x7F]/', '', (string) $name);
            if ($name === '') continue;

            if (is_array($value)) {
                // Champs à choix multiples (checkboxes) → concaténation des valeurs
                $value = array_map('strip_tags', $value);
                $params[$name] = implode(', ', array_filter($value, fn($v) => $v !== ''));
            } else {
                // Champ simple → on retire uniquement les balises HTML
                $params[$name] = strip_tags((string) $value);
            }
        }

        // --- Traitement des fichiers uploadés ---
        $uploadedFiles = $_FILES['files'] ?? [];
        $mediaHelper   = new MediaHelper();
        $hasFileError  = false;

        if (!empty($uploadedFiles['name'])) {
            // Dossier de destination identique à celui utilisé par ConvertForms en frontend
            $uploadDir = JPATH_ROOT . '/media/com_convertforms/uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            foreach ($uploadedFiles['name'] as $fieldName => $fileList) {
                // Nettoyage du nom de champ (clé du tableau $_FILES)
                $fieldName = preg_replace('/[\x00-\x1F\x7F]/', '', (string) $fieldName);
                if ($fieldName === '') continue;

                $filePaths = [];
                $fileList  = (array) $fileList;
                $tmpList   = (array) ($uploadedFiles['tmp_name'][$fieldName] ?? []);
                $errList   = (array) ($uploadedFiles['error'][$fieldName] ?? []);
                $sizList   = (array) ($uploadedFiles['size'][$fieldName] ?? []);

                foreach ($fileList as $i => $originalName) {
                    // On ignore les fichiers non transmis ou en erreur
                    if (($errList[$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) continue;

                    // Validation via MediaHelper de Joomla :
                    // - vérifie que l'extension n'est pas exécutable (.php, .exe, etc.)
                    // - vérifie que l'extension est dans la whitelist de com_media
                    // - enqueue automatiquement un message d'erreur si le fichier est refusé
                    $fileInfo = [
                        'name'     => $originalName,
                        'tmp_name' => $tmpList[$i],
                        'size'     => $sizList[$i] ?? 0,
                        'error'    => $errList[$i],
                    ];

                    if (!$mediaHelper->canUpload($fileInfo)) {
                        $hasFileError = true;
                        continue;
                    }

                    // Génération d'un nom de fichier unique pour éviter les collisions
                    $ext      = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
                    $safeName = uniqid('upload_') . ($ext ? '.' . $ext : '');
                    $dest     = $uploadDir . $safeName;

                    // move_uploaded_file() est la seule façon sécurisée de déplacer un fichier uploadé
                    if (move_uploaded_file($tmpList[$i], $dest)) {
                        // On stocke le chemin relatif (depuis JPATH_ROOT) comme ConvertForms le fait
                        $filePaths[] = '/media/com_convertforms/uploads/' . $safeName;
                    }
                }

                if (!empty($filePaths)) {
                    // Un seul fichier → valeur scalaire ; plusieurs → tableau (comme ConvertForms)
                    $params[$fieldName] = count($filePaths) === 1 ? $filePaths[0] : $filePaths;
                }
            }
        }

        // Si un fichier a été refusé, on revient sur le formulaire sans enregistrer
        if ($hasFileError) {
            $this->setRedirect('index.php?option=com_cfsubmit&view=cfsubmit&layout=submit&form_id=' . $formId);
            return;
        }

        // --- Insertion en base de données ---
        $db   = Factory::getContainer()->get(DatabaseInterface::class);
        $now  = Factory::getDate()->toSql();
        // getNullDate() retourne la valeur nulle acceptée par la colonne datetime (ex: 0000-00-00)
        $null = $db->getNullDate();

        $row = (object) [
            'form_id'     => $formId,
            'campaign_id' => 0,
            'user_id'     => $this->app->getIdentity()->id, // Utilisateur connecté
            'visitor_id'  => null,
            // $params est le tableau associatif fieldName → value, sérialisé en JSON.
            // C'est le même format que ConvertForms utilise pour ses propres soumissions.
            'params'      => json_encode($params, JSON_UNESCAPED_UNICODE),
            'state'       => 1, // 1 = publié
            'created'     => $now,
            'modified'    => $null,
        ];

        $db->insertObject('#__convertforms_conversions', $row);

        $this->app->enqueueMessage('Soumission enregistrée avec succès.', 'success');
        $this->setRedirect($returnUrl);
    }

    /**
     * Met à jour une soumission existante.
     *
     * Appelé via POST avec task=submission.update, id=X, form_id=Y.
     * Les champs texte remplacent les valeurs existantes.
     * Les fichiers : si un nouveau fichier est fourni il remplace l'ancien,
     * sinon l'ancien chemin est conservé depuis un champ caché.
     */
    public function update(): void
    {
        $this->checkToken();

        $input     = $this->app->getInput();
        $id        = $input->getInt('id', 0);
        $formId    = $input->getInt('form_id', 0);
        $returnUrl = 'index.php?option=com_cfsubmit' . ($formId ? '&form_id=' . $formId : '');

        if (!$id || !$formId) {
            $this->app->enqueueMessage('Soumission invalide.', 'error');
            $this->setRedirect($returnUrl);
            return;
        }

        $db = Factory::getContainer()->get(DatabaseInterface::class);

        // Charge la soumission pour vérification et mise à jour
        $query = $db->getQuery(true)
            ->select(['params', 'form_id'])
            ->from($db->quoteName('#__convertforms_conversions'))
            ->where($db->quoteName('id') . ' = ' . $id);
        $existing = $db->setQuery($query)->loadObject();

        if (!$existing) {
            $this->app->enqueueMessage('Soumission introuvable.', 'error');
            $this->setRedirect($returnUrl);
            return;
        }

        // Vérifie que la soumission appartient bien au formulaire du POST
        if ((int) $existing->form_id !== $formId) {
            $this->app->enqueueMessage('Soumission invalide.', 'error');
            $this->setRedirect($returnUrl);
            return;
        }

        // Pour les non-super-admins, vérifie l'accès au formulaire
        $identity = $this->app->getIdentity();
        if (!$identity->authorise('core.admin') && !$this->isFormAllowed($formId)) {
            $this->app->enqueueMessage('Accès refusé.', 'error');
            $this->setRedirect($returnUrl);
            return;
        }

        $params = json_decode($existing->params, true) ?? [];

        // Écrase les champs texte avec les nouvelles valeurs
        foreach ($_POST['fields'] ?? [] as $name => $value) {
            $name = preg_replace('/[\x00-\x1F\x7F]/', '', (string) $name);
            if ($name === '') continue;

            if (is_array($value)) {
                $value = array_map('strip_tags', $value);
                $params[$name] = implode(', ', array_filter($value, fn($v) => $v !== ''));
            } else {
                $params[$name] = strip_tags((string) $value);
            }
        }

        // Cas limite : un champ de type fichier n'existait pas dans la soumission d'origine
        // (champ ajouté au formulaire après la soumission). Dans ce cas $params[$name] n'est
        // pas défini, et le champ caché existing_files[fieldName] du template edit.php le fournit.
        // Pour les champs déjà présents en base, $params[$name] est déjà défini (chargé plus haut),
        // donc la condition isset() les ignore — la valeur DB est conservée sans passer par ici.
        // Si un nouveau fichier est uploadé (boucle suivante), il écrasera $params[$name].
        foreach ($_POST['existing_files'] ?? [] as $name => $path) {
            $name = preg_replace('/[\x00-\x1F\x7F]/', '', (string) $name);
            $path = (string) $path;
            if ($name === '' || isset($params[$name])) continue;
            // Validation du préfixe : on n'accepte que les chemins dans le dossier uploads
            // de ConvertForms pour éviter de stocker des chemins arbitraires manipulés
            // côté navigateur (ex: "../../config/database.php").
            if (!str_starts_with($path, '/media/com_convertforms/uploads/')) continue;
            $params[$name] = $path;
        }

        // Traitement des nouveaux fichiers uploadés (remplace l'existant si fourni)
        $uploadedFiles = $_FILES['files'] ?? [];
        $mediaHelper   = new MediaHelper();
        $hasFileError  = false;

        if (!empty($uploadedFiles['name'])) {
            $uploadDir = JPATH_ROOT . '/media/com_convertforms/uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            foreach ($uploadedFiles['name'] as $fieldName => $fileList) {
                $fieldName = preg_replace('/[\x00-\x1F\x7F]/', '', (string) $fieldName);
                if ($fieldName === '') continue;

                $filePaths = [];
                $fileList  = (array) $fileList;
                $tmpList   = (array) ($uploadedFiles['tmp_name'][$fieldName] ?? []);
                $errList   = (array) ($uploadedFiles['error'][$fieldName] ?? []);
                $sizList   = (array) ($uploadedFiles['size'][$fieldName] ?? []);

                foreach ($fileList as $i => $originalName) {
                    if (($errList[$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) continue;

                    $fileInfo = [
                        'name'     => $originalName,
                        'tmp_name' => $tmpList[$i],
                        'size'     => $sizList[$i] ?? 0,
                        'error'    => $errList[$i],
                    ];

                    if (!$mediaHelper->canUpload($fileInfo)) {
                        $hasFileError = true;
                        continue;
                    }

                    $ext      = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
                    $safeName = uniqid('upload_') . ($ext ? '.' . $ext : '');
                    $dest     = $uploadDir . $safeName;

                    if (move_uploaded_file($tmpList[$i], $dest)) {
                        $filePaths[] = '/media/com_convertforms/uploads/' . $safeName;
                    }
                }

                if (!empty($filePaths)) {
                    $params[$fieldName] = count($filePaths) === 1 ? $filePaths[0] : $filePaths;
                }
            }
        }

        if ($hasFileError) {
            $this->setRedirect('index.php?option=com_cfsubmit&view=cfsubmit&layout=edit&id=' . $id . '&form_id=' . $formId);
            return;
        }

        $now = Factory::getDate()->toSql();
        $query = $db->getQuery(true)
            ->update($db->quoteName('#__convertforms_conversions'))
            ->set($db->quoteName('params')   . ' = ' . $db->quote(json_encode($params, JSON_UNESCAPED_UNICODE)))
            ->set($db->quoteName('modified') . ' = ' . $db->quote($now))
            ->where($db->quoteName('id')     . ' = ' . $id);
        $db->setQuery($query)->execute();

        $this->app->enqueueMessage('Soumission #' . $id . ' modifiée avec succès.', 'success');
        $this->setRedirect($returnUrl);
    }

    /**
     * Vérifie que l'utilisateur connecté a accès au formulaire donné selon la
     * configuration du composant (paramètre forms_access).
     *
     * Retourne true si aucune règle n'est définie pour ce formulaire (accès ouvert)
     * ou si l'utilisateur appartient à l'un des groupes autorisés.
     * Même logique que dans HtmlView pour la liste des formulaires visibles.
     */
    private function isFormAllowed(int $formId): bool
    {
        $params      = ComponentHelper::getParams('com_cfsubmit');
        $formsAccess = (array) $params->get('forms_access', []);
        $userGroups  = array_map('intval', $this->app->getIdentity()->getAuthorisedGroups());

        $formGroupMap = [];
        foreach ($formsAccess as $rule) {
            $rule  = (array) $rule;
            $fid   = (int) ($rule['form_id'] ?? 0);
            $group = (int) ($rule['groups'] ?? 0);
            if ($fid && $group) {
                $formGroupMap[$fid][] = $group;
            }
        }

        // Si aucune règle n'est définie pour ce formulaire → accès autorisé par défaut
        if (!isset($formGroupMap[$formId])) {
            return true;
        }

        return !empty(array_intersect($userGroups, $formGroupMap[$formId]));
    }
}
