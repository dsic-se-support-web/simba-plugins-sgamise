<?php
/**
 * Classe principale du composant com_cfsubmit.
 *
 * Joomla l'instancie au démarrage de chaque requête adressée au composant.
 * Elle hérite de MVCComponent qui fournit le comportement standard :
 * gestion des ACL, initialisation du dispatcher, etc.
 *
 * Aucune logique métier ici — c'est intentionnel. Tout est dans les Controllers
 * et la View. Cette classe peut être enrichie plus tard si on a besoin de
 * surcharger des comportements de MVCComponent (ex: routes personnalisées).
 */
namespace Cfsubmit\Component\Cfsubmit\Administrator\Extension;

use Joomla\CMS\Extension\MVCComponent;

class CfsubmitComponent extends MVCComponent {}
