<?php

/**
 * Point d'entrée du conteneur d'injection de dépendances (DI) de Joomla.
 *
 * Ce fichier est chargé automatiquement par Joomla au démarrage du composant.
 * Il enregistre les services nécessaires (fabrique MVC, dispatcher, classe principale)
 * dans le conteneur DI global, ce qui permet à Joomla d'instancier le composant
 * correctement via son architecture MVC 4/5.
 */
defined('_JEXEC') or die;

// Enregistrement manuel du namespace PSR-4 du composant.
// Nécessaire car le composant est installé via "Découvrir" et non via un package ZIP —
// dans ce cas Joomla n'écrit pas le namespace dans son cache autoload_psr4.php.
JLoader::registerNamespace('Cfsubmit\\Component\\Cfsubmit\\Administrator', __DIR__ . '/../src'); //Utile uniquement en dev (pas besoin de reinstaller le zip)

use Joomla\CMS\Dispatcher\ComponentDispatcherFactoryInterface;
use Joomla\CMS\Extension\ComponentInterface;
use Joomla\CMS\Extension\Service\Provider\ComponentDispatcherFactory;
use Joomla\CMS\Extension\Service\Provider\MVCFactory;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Cfsubmit\Component\Cfsubmit\Administrator\Extension\CfsubmitComponent;

return new class implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        // Enregistre la fabrique MVC : permet à Joomla de créer automatiquement
        // les Controllers, Views et Models à partir du namespace du composant.
        $container->registerServiceProvider(new MVCFactory('\\Cfsubmit\\Component\\Cfsubmit'));

        // Enregistre la fabrique de dispatcher : gère le routage des requêtes
        // vers le bon Controller en fonction du paramètre "task" dans l'URL.
        $container->registerServiceProvider(new ComponentDispatcherFactory('\\Cfsubmit\\Component\\Cfsubmit'));

        // Enregistre la classe principale du composant dans le conteneur DI.
        // Joomla l'instancie pour initialiser le composant (permissions, routing, etc.).
        $container->set(
            ComponentInterface::class,
            function (Container $container) {
                return new CfsubmitComponent(
                    $container->get(ComponentDispatcherFactoryInterface::class)
                );
            }
        );
    }
};
