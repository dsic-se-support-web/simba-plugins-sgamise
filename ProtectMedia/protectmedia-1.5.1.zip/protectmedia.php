<?php
/**
 * Plugin System - Protect Media
 *
 * Plugin système Joomla 5.4 permettant de protéger des fichiers et dossiers
 * du Media Manager contre la suppression et d'empêcher l'import de fichier ou la
 * création de dossiers dans les dossiers protégés.
 *
 * - La protection est gérée exclusivement par les super-administrateurs
 * - Les utilisateurs non super-admin ne peuvent pas supprimer les éléments protégés
 * - Une interface visuelle est injectée dans le Media Manager
 * - La protection est stockée dans les paramètres du plugin
 *
 * @package     Joomla.Plugin
 * @subpackage  System.ProtectMedia
 */

defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Response\JsonResponse;
use Joomla\Registry\Registry;

class PlgSystemProtectmedia extends CMSPlugin
{
    protected $app;
    protected $autoloadLanguage = true;

    /**
     * Injection des assets dans Media Manager
     */
    public function onAfterDispatch()
    {
        $app = Factory::getApplication();

        // Ne charger que sur com_media dans le backend
        if ($app->isClient('administrator') &&
            $app->input->getCmd('option') === 'com_media')
        {
            $doc = $app->getDocument();
            $wa  = $doc->getWebAssetManager();

            // Chargement du JS + CSS
            $wa->registerAndUseScript(
                'protectmedia.visual',
                'media/protectmedia/js/visual.js',
                [],
                ['type' => 'module']
            );

            $wa->registerAndUseStyle(
                'protectmedia.visual',
                'media/protectmedia/css/visual.css'
            );

            // Exposer données au JS
            $protectedList = $this->params->get('protected_files', '');
            $protected = array_filter(array_map('trim', explode("\n", $protectedList)));

            // Normalisation des chemins envoyés au JS
            $protected = array_map(function($p){
                return str_replace('\\', '/', $p);
            }, $protected);

            $doc->addScriptOptions('protectmedia', [
                'protected' => array_values($protected),
                'isSuperAdmin' => $app->getIdentity()->authorise('core.admin')
            ]);
        }
    }


    /**
     * Empêcher la suppression des fichiers / dossiers protégés
     */
     public function onContentBeforeDelete($context, $data)
     {
         if (!in_array($context, ['com_media.file', 'com_media.folder'], true)) {
             return true;
         }
     
         $user = Factory::getApplication()->getIdentity();
     
         // Super-admin : autorisé
         if ($user->authorise('core.admin')) {
             return true;
         }
     
         // Récupération du chemin (objet ou tableau)
         $filepath = '';
     
         if (is_object($data)) {
             $filepath = $data->filepath ?? $data->path ?? '';
         } elseif (is_array($data)) {
             $filepath = $data['filepath'] ?? $data['path'] ?? '';
         }
     
         if (!$filepath) {
             return true;
         }
     
         $filepath = trim(str_replace('\\', '/', $filepath), '/');
     
         if (!str_starts_with($filepath, 'images/')) {
             $filepath = 'images/' . $filepath;
         }
     
         $protectedList = $this->params->get('protected_files', '');
         $protected = array_filter(array_map(
             fn($p) => trim(str_replace('\\', '/', $p), '/'),
             explode("\n", $protectedList)
         ));
     
         foreach ($protected as $protectedPath) {
             if ($filepath === $protectedPath || str_starts_with($filepath, $protectedPath . '/')) {
                 throw new \Exception("Ce fichier ou dossier est protégé et ne peut pas être supprimé.");
             }
         }
     
         return true;
     }


    /**
     * Empêche l'upload et la création de dossier dans un dossier protégé
     */
    public function onAfterRoute()
    {
        $app = Factory::getApplication();

        // Backend uniquement
        if (!$app->isClient('administrator')) {
            return;
        }

        // Uniquement com_media
        if ($app->input->getCmd('option') !== 'com_media') {
            return;
        }

        // Tâches d'upload et de création de dossier
        $task = $app->input->getCmd('task');
        if (!in_array($task, [
            'file.upload',
            'api.files.upload',
            'folder.create',
            'api.folders.create'
        ], true)) {
            return;
        }

        $user = $app->getIdentity();

        // Super admin autorisé
        if ($user->authorise('core.admin')) {
            return;
        }

        // Récupération du dossier cible
        $folder = $app->input->getString('path', '');

        if (!$folder) {
            return;
        }

        // Normalisation des chemins
        $folder = str_replace('\\', '/', $folder);
        $folder = preg_replace('#^local-[^:]+:/#', '', $folder);
        $folder = trim($folder, '/');

        if (!str_starts_with($folder, 'images/')) {
            $folder = 'images/' . $folder;
        }

        // Chargement de la liste des éléments protégée
        $protectedList = $this->params->get('protected_files', '');

        $protected = array_filter(array_map(
            fn($p) => trim(str_replace('\\', '/', $p), '/'),
            explode("\n", $protectedList)
        ));

        foreach ($protected as $protectedPath) {

            if (
                $folder === $protectedPath ||
                str_starts_with($folder, $protectedPath . '/')
            ) {
                throw new \Exception("Ce dossier est protégé : opération interdite (upload ou création de dossier).");
            }
        }
    }

    /**
     * AJAX : Bascule de protection pour super-admin uniquement
     */
    public function onAjaxProtectmedia()
    {
        $app = Factory::getApplication();
        $user = $app->getIdentity();

        // Autorisations
        if (!$user->authorise('core.admin')) {
            echo new JsonResponse(null, 'Accès refusé', true);
            $app->close();
        }

        $input = $app->input;
        $file  = trim($input->getString('file', ''));

        if (!$file) {
            echo new JsonResponse(null, 'Chemin non fourni', true);
            return;
        }

        // Normalisation des chemins AJAX
        $file = str_replace('\\', '/', $file);
        if (!str_starts_with($file, 'images/')) {
            $file = 'images/' . ltrim($file, '/');
        }

        // Lecture des paramètres du plugin
        $plugin = PluginHelper::getPlugin('system', 'protectmedia');
        $params = new Registry($plugin->params);

        $protectedList = $params->get('protected_files', '');
        $protected = array_filter(array_map('trim', explode("\n", $protectedList)));

        // Normalisation des chemins de TOUTE la liste existante (fix si mauvaise normalisation)
        $protected = array_map(fn($p) => str_replace('\\', '/', $p), $protected);

        // Bascule protégé / déprotégé avec gestion récursive
        if (in_array($file, $protected)) {

            // Déprotéger : enlever dossier + contenu
            $itemsToRemove = [$file];

            // Si c'est un dossier, enlever la protection sur son contenu
            if (is_dir(JPATH_ROOT . '/' . $file)) {
                $children = $this->getFolderContentRecursive($file);
                $itemsToRemove = array_merge($itemsToRemove, $children);
            }

            $protected = array_diff($protected, $itemsToRemove);

        } else {

            // Protéger : ajouter dossier + contenu
            $itemsToAdd = [$file];

            if (is_dir(JPATH_ROOT . '/' . $file)) {
                $children = $this->getFolderContentRecursive($file);
                $itemsToAdd = array_merge($itemsToAdd, $children);
            }

            $protected = array_unique(array_merge($protected, $itemsToAdd));
        }

        // Normalisation des chemins avant enregistrement dans les paramètres du plugin
        $protected = array_map(fn($p) => str_replace('\\', '/', $p), $protected);

        // Sauvegarde des paramètres du plugin
        $params->set('protected_files', implode("\n", $protected));

        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->update('#__extensions')
            ->set('params = ' . $db->quote($params->toString()))
            ->where('element = ' . $db->quote('protectmedia'))
            ->where('folder = ' . $db->quote('system'));

        $db->setQuery($query);
        $db->execute();

        echo new JsonResponse(['protected' => array_values($protected)], 'OK', false);
        $app->close();
    }

	/**
	 * Retourne tous les chemins contenus dans un dossier (récursif)
	 */
	private function getFolderContentRecursive($folderPath)
	{
		$basePath = JPATH_ROOT . '/' . $folderPath;
		$results = [];

		if (!is_dir($basePath)) {
			return $results;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator($basePath, RecursiveDirectoryIterator::SKIP_DOTS),
			RecursiveIteratorIterator::SELF_FIRST
		);

		foreach ($iterator as $file) {

			$relative = str_replace(JPATH_ROOT . '/', '', $file->getPathname());

            // Normalisation des chemins enfants
			$relative = str_replace('\\', '/', $relative);

			$results[] = $relative;
		}

		return $results;
	}

}
