/**
 * visual.js – Joomla 5.4 Media Manager Protect Media
 * 
 */

(function () {

    function initProtectMedia() {

        const options = Joomla.getOptions("protectmedia") || {
            protected: [],
            isSuperAdmin: false
        };

        let protectedItems = options.protected || [];
        const isSuperAdmin = options.isSuperAdmin;

        /**
         * Récupère le dossier courant réel depuis l'URL :
         * ex : path=local-images:/sampledata/cassiopeia
         *     -> images/sampledata/cassiopeia
         */
        function getCurrentFolder() {

            const url = new URL(window.location.href);
            let raw = url.searchParams.get("path") || "local-images:/";

            // Suppression de "local-images:/"
            raw = raw.replace(/^local-[^:]+:\//, "");

            if (!raw) return "images";
            return "images/" + raw;
        }

        /**
         * Retourne le chemin complet du fichier/dossier
         * ex : images/sampledata/cassiopeia/logo.png
         */
        function extractFullPath(item) {

            const name = item.querySelector(".media-browser-item-info")
                         ?.textContent.trim();

            if (!name) return null;

            const folder = getCurrentFolder();
            return folder + "/" + name;
        }

        /**
         * Applique l'état protégé (cadenas + style + disable delete)
         */
        function applyProtectedVisual(item, fullPath) {

            // Style général
            item.classList.add("is-protected");

            // Icône cadenas
            if (!item.querySelector(".pm-lock")) {
                const lock = document.createElement("span");
                lock.className = "pm-lock";
                lock.textContent = "🔒";
                item.appendChild(lock);
            }

            // Désactive la suppression depuis le menu contextuel de chaque vignette
            const deleteBtn = item.querySelector(".action-delete");
            if (deleteBtn) {
                deleteBtn.classList.add("disabled");
            }
        }

        /**
         * Retire la protection visuelle
         */
        function removeProtectedVisual(item) {

            item.classList.remove("is-protected");

            const lock = item.querySelector(".pm-lock");
            if (lock) lock.remove();

            const deleteBtn = item.querySelector(".action-delete");
            if (deleteBtn) {
                deleteBtn.classList.remove("disabled");
            }
        }

        /**
         * Ajoute le bouton Protéger/Déprotéger
         */
        function addToggleButton(item, fullPath, isProtected) {

            if (!isSuperAdmin) return;
            if (item.querySelector(".pm-toggle-btn")) return;

            const btn = document.createElement("button");
            btn.classList.add("pm-toggle-btn");

            if (isProtected) {
                btn.classList.add("unprotect");
                btn.textContent = "Déprotéger";
            } else {
                btn.classList.add("protect");
                btn.textContent = "Protéger";
            }

            btn.addEventListener("click", () =>
                toggleProtection(btn, item, fullPath)
            );

            item.appendChild(btn);
        }

        /**
         * Appel AJAX Joomla pour basculer la protection
         */
        function toggleProtection(btn, item, fullPath) {

            fetch("index.php?option=com_ajax&plugin=protectmedia&format=json", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "file=" + encodeURIComponent(fullPath)
            })
            .then(r => r.json())
            .then(resp => {

                if (!resp.success) {
                    alert("Erreur : " + resp.message);
                    return;
                }

                protectedItems = resp.data.protected;

                const isProtected = protectedItems.includes(fullPath);

                if (isProtected) {

                    applyProtectedVisual(item, fullPath);

                    btn.textContent = "Déprotéger";
                    btn.classList.remove("protect");
                    btn.classList.add("unprotect");

                } else {

                    removeProtectedVisual(item);

                    btn.textContent = "Protéger";
                    btn.classList.remove("unprotect");
                    btn.classList.add("protect");
                }
            })
            .catch(console.error);
        }

        /**
         * Traitement principal des items
         */
        function processMediaItems() {

            const items = document.querySelectorAll(".media-browser-item");

            items.forEach(item => {

                const fullPath = extractFullPath(item);
                if (!fullPath) return;

                const isProtected = protectedItems.includes(fullPath);

                // Appliquer style si protégé
                if (isProtected) {
                    applyProtectedVisual(item, fullPath);
                } else {
                    removeProtectedVisual(item);
                }

                // Bouton toggle
                addToggleButton(item, fullPath, isProtected);
            });
			
			updateGlobalDeleteButton();
        }


        /**
         * Gestion du bouton Supprimer
         */
		function updateGlobalDeleteButton() {

			const globalDeleteBtn = document.querySelector("#mediaDelete");
			if (!globalDeleteBtn) return;

			// Trouver les éléments sélectionnés
			const selectedItems = document.querySelectorAll(".media-browser-item.selected");

			let disable = false;

			selectedItems.forEach(item => {
				const fullPath = extractFullPath(item);
				if (protectedItems.includes(fullPath)) {
					disable = true;
				}
			});

			if (disable) {
				globalDeleteBtn.classList.add("disabled");
				globalDeleteBtn.setAttribute("disabled", "disabled");
				globalDeleteBtn.style.pointerEvents = "none";
				globalDeleteBtn.style.opacity = "0.5";
			} else {
				globalDeleteBtn.classList.remove("disabled");
				globalDeleteBtn.removeAttribute("disabled");
				globalDeleteBtn.style.pointerEvents = "";
				globalDeleteBtn.style.opacity = "";
			}
		}


        /**
         * Observervateur pour tenir compte des changements pendant la navigation dans le media manager
         */
        function observeMediaChanges() {

            function start() {

                const container = document.querySelector(".media-browser-items");
                if (!container) {
                    setTimeout(start, 200);
                    return;
                }

                const observer = new MutationObserver(() => {
                    processMediaItems();
                });

                observer.observe(container, {
                    childList: true,
                    subtree: true
                });

                processMediaItems();
            }

            start();
        }

		/* On applique la désactivation du bouton Supprimer à chaque changement de vue du media manager et quand au moins 1 élément est sélectionné */
		document.addEventListener("click", (e) => {
			if (e.target.closest(".media-browser-item")) {
				// La classe "selected" est appliquée par Joomla juste après le clic,
				// donc un petit délai garantit que le DOM est à jour.
				setTimeout(updateGlobalDeleteButton, 30);
			}
		});

        observeMediaChanges();
    }

    document.addEventListener("DOMContentLoaded", initProtectMedia);

})();
