# protectmedia

Plugin système pour protéger de la suppression les fichiers sélectionnés dans les medias

# Fonctionnement

Ajoute un bouton de protection sur les vignettes des fichiers. Le bouton n'est actif que pour les super-admins.

