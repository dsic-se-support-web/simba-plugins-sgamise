<?php
/**
 * Plugin System - Protect Media
 */

defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Response\JsonResponse;
use Joomla\Registry\Registry;

class PlgSystemProtectmedia extends CMSPlugin
{
    protected $app;
    protected $autoloadLanguage = true;

    /**
     * Injection des assets dans Media Manager
     */
    public function onAfterDispatch()
    {
        $app = Factory::getApplication();

        // Ne charger que sur com_media dans le backend
        if ($app->isClient('administrator') &&
            $app->input->getCmd('option') === 'com_media')
        {
            $doc = $app->getDocument();
            $wa  = $doc->getWebAssetManager();

            // Chargement du JS + CSS
            $wa->registerAndUseScript(
                'protectmedia.visual',
                'media/protectmedia/js/visual.js',
                [],
                ['type' => 'module']
            );

            $wa->registerAndUseStyle(
                'protectmedia.visual',
                'media/protectmedia/css/visual.css'
            );

            // Exposer données au JS
            $protectedList = $this->params->get('protected_files', '');
            $protected = array_filter(array_map('trim', explode("\n", $protectedList)));

            // Normalisation des chemins envoyés au JS
            $protected = array_map(function($p){
                return str_replace('\\', '/', $p);
            }, $protected);

            $doc->addScriptOptions('protectmedia', [
                'protected' => array_values($protected),
                'isSuperAdmin' => $app->getIdentity()->authorise('core.admin')
            ]);
        }
    }

    /**
     * Empêcher la suppression des fichiers / dossiers protégés
     */

     public function onContentBeforeDelete($context, $data)
     {
         if (!in_array($context, ['com_media.file', 'com_media.folder'], true)) {
             return true;
         }
     
         $user = Factory::getApplication()->getIdentity();
     
         // Super-admin : autorisé
         if ($user->authorise('core.admin')) {
             return true;
         }
     
         // Récupération du chemin (objet ou tableau)
         $filepath = '';
     
         if (is_object($data)) {
             $filepath = $data->filepath ?? $data->path ?? '';
         } elseif (is_array($data)) {
             $filepath = $data['filepath'] ?? $data['path'] ?? '';
         }
     
         if (!$filepath) {
             return true;
         }
     
         $filepath = trim(str_replace('\\', '/', $filepath), '/');
     
         if (!str_starts_with($filepath, 'images/')) {
             $filepath = 'images/' . $filepath;
         }
     
         $protectedList = $this->params->get('protected_files', '');
         $protected = array_filter(array_map(
             fn($p) => trim(str_replace('\\', '/', $p), '/'),
             explode("\n", $protectedList)
         ));
     
         foreach ($protected as $protectedPath) {
             if ($filepath === $protectedPath || str_starts_with($filepath, $protectedPath . '/')) {
                 throw new \Exception("Ce fichier ou dossier est protégé et ne peut pas être supprimé.");
             }
         }
     
         return true;
     }

    // public function onContentBeforeDelete($context, $data)
    // {
    //     if (!in_array($context, ['com_media.file', 'com_media.folder'], true)) {
    //         return true;
    //     }

    //     $user = Factory::getApplication()->getIdentity();

    //     // Super admin → tout est permis
    //     if ($user->authorise('core.admin')) {
    //         return true;
    //     }

    //     // Liste protégée
    //     $protectedList = $this->params->get('protected_files', '');
    //     $protected = array_filter(array_map('trim', explode("\n", $protectedList)));

    //     // Normalisation des chemins
    //     $protected = array_map(fn($p) => str_replace('\\', '/', $p), $protected);

    //     if (!$protected) {
    //         return true;
    //     }

    //     // Récupérer la liste des fichier
    //     //$filepath = $data['filepath'] ?? $data['path'] ?? '';
    //     $filepath = '';

    //     if (is_object($data)) {
    //         $filepath = $data->filepath ?? $data->path ?? '';
    //     } elseif (is_array($data)) {
    //         $filepath = $data['filepath'] ?? $data['path'] ?? '';
    //     }

    //     $filepath = trim($filepath, '/');

    //     if (!str_starts_with($filepath, 'images/')) {
    //         $filepath = 'images/' . $filepath;
    //     }

    //     // Normalisation des chemins avant comparaison
    //     $filepath = str_replace('\\', '/', $filepath);

    //     // Vérification protection + protection récursive dossiers (évite le contournement de la protection)
    //     foreach ($protected as $protectedPath) {

    //         $protectedPath = trim(str_replace('\\', '/', $protectedPath), '/');

    //         // Fichier ou dossier protégé
    //         if ($filepath === $protectedPath) {
    //             throw new \Exception("Ce fichier ou dossier est protégé et ne peut pas être supprimé.");
    //         }

    //         // Protection récursive des sous-dossiers
    //         if (str_starts_with($filepath, $protectedPath . '/')) {
    //             throw new \Exception("Ce dossier protégé ne peut pas être supprimé.");
    //         }
    //     }

    //     return true;
    // }

    /**
     * AJAX : Bascule de protection pour super-admin uniquement
     */
    public function onAjaxProtectmedia()
    {
        $app = Factory::getApplication();
        $user = $app->getIdentity();

        // Autorisation
        if (!$user->authorise('core.admin')) {
            echo new JsonResponse(null, 'Accès refusé', true);
            $app->close();
        }

        $input = $app->input;
        $file  = trim($input->getString('file', ''));

        if (!$file) {
            echo new JsonResponse(null, 'Chemin non fourni', true);
            return;
        }

        // Normalisation des chemins AJAX
        $file = str_replace('\\', '/', $file);        // 🔧 FIX
        if (!str_starts_with($file, 'images/')) {
            $file = 'images/' . ltrim($file, '/');
        }

        // Lecture des paramètres actuels du plugin
        $plugin = PluginHelper::getPlugin('system', 'protectmedia');
        $params = new Registry($plugin->params);

        $protectedList = $params->get('protected_files', '');
        $protected = array_filter(array_map('trim', explode("\n", $protectedList)));

        // Normalisation des chemins de TOUTE la liste existante (fix si mauvaise normalisation)
        $protected = array_map(fn($p) => str_replace('\\', '/', $p), $protected);

        // Bacsule protégé / déprotégé avec gestion récursive
        if (in_array($file, $protected)) {

            // Déprotéger : enlever dossier + contenu
            $itemsToRemove = [$file];

            // Si c'est un dossier, enlever la protection sur son contenu
            if (is_dir(JPATH_ROOT . '/' . $file)) {
                $children = $this->getFolderContentRecursive($file);
                $itemsToRemove = array_merge($itemsToRemove, $children);
            }

            $protected = array_diff($protected, $itemsToRemove);

        } else {

            // Protéger : ajouter dossier + contenu
            $itemsToAdd = [$file];

            if (is_dir(JPATH_ROOT . '/' . $file)) {
                $children = $this->getFolderContentRecursive($file);
                $itemsToAdd = array_merge($itemsToAdd, $children);
            }

            $protected = array_unique(array_merge($protected, $itemsToAdd));
        }

        // Normalisation des chemins avant enregistrement dans les paramètres du plugin
        $protected = array_map(fn($p) => str_replace('\\', '/', $p), $protected);

        // Sauvegarde des paramètres du plugin
        $params->set('protected_files', implode("\n", $protected));

        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->update('#__extensions')
            ->set('params = ' . $db->quote($params->toString()))
            ->where('element = ' . $db->quote('protectmedia'))
            ->where('folder = ' . $db->quote('system'));

        $db->setQuery($query);
        $db->execute();

        echo new JsonResponse(['protected' => array_values($protected)], 'OK', false);
        $app->close();
    }

	/**
	 * Retourne tous les chemins contenus dans un dossier (récursif)
	 */
	private function getFolderContentRecursive($folderPath)
	{
		$basePath = JPATH_ROOT . '/' . $folderPath;
		$results = [];

		if (!is_dir($basePath)) {
			return $results;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator($basePath, RecursiveDirectoryIterator::SKIP_DOTS),
			RecursiveIteratorIterator::SELF_FIRST
		);

		foreach ($iterator as $file) {

			$relative = str_replace(JPATH_ROOT . '/', '', $file->getPathname());

            // Normalisation des chemins enfants
			$relative = str_replace('\\', '/', $relative);

			$results[] = $relative;
		}

		return $results;
	}

}
