<?php
/**
 * Vue principale du composant com_cfsubmit.
 *
 * Rôle de la View dans l'architecture MVC Joomla :
 * - Elle prépare TOUTES les données nécessaires à l'affichage
 * - Elle les expose via $this->xxx pour les rendre accessibles dans les templates
 * - Elle ne contient aucun HTML (c'est le rôle des fichiers tmpl/)
 *
 * Cette View gère deux layouts :
 *   - default : tableau paginé des soumissions avec filtres
 *   - submit  : formulaire de création d'une nouvelle soumission
 */
namespace Cfsubmit\Component\Cfsubmit\Administrator\View\Cfsubmit;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\Database\DatabaseInterface;
use ConvertForms\Form;

class HtmlView extends BaseHtmlView
{
    public function display($tpl = null): void
    {
        // ConvertForms est un composant Joomla 3 (pas de PSR-4).
        // On doit l'inclure manuellement avant d'utiliser ses classes.
        require_once JPATH_ADMINISTRATOR . '/components/com_convertforms/autoload.php';
        require_once JPATH_ADMINISTRATOR . '/components/com_convertforms/models/conversion.php';

        $db  = Factory::getContainer()->get(DatabaseInterface::class);
        $app = Factory::getApplication();

        // Vérification du droit d'accès : seuls les utilisateurs ayant le droit
        // "core.manage" sur com_cfsubmit peuvent accéder au composant.
        // Les Super Utilisateurs passent toujours (authorise() retourne true pour eux).
        if (!$app->getIdentity()->authorise('core.manage', 'com_cfsubmit')) {
            throw new \RuntimeException(\Joomla\CMS\Language\Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }

        // Le form_id est transmis dans l'URL pour savoir quel formulaire afficher
        $this->formId = $app->getInput()->getInt('form_id', 0);

        // --- Layout "submit" : formulaire de création d'une nouvelle soumission ---
        if ($this->getLayout() === 'submit') {
            // On charge la définition complète du formulaire ConvertForms (tous les champs,
            // leurs types, leurs options) pour pouvoir générer le formulaire HTML dynamiquement.
            // Le 3e paramètre "true" = ignore l'état publié/dépublié du formulaire.
            $this->formDef = $this->formId ? Form::load($this->formId, false, true) : null;
            parent::display($tpl);
            return;
        }

        // --- Layout "default" : liste des soumissions ---

        // Récupère tous les formulaires ConvertForms publiés pour le sélecteur
        $query = $db->getQuery(true)
            ->select($db->quoteName(['id', 'name']))
            ->from($db->quoteName('#__convertforms'))
            ->where($db->quoteName('state') . ' = 1')
            ->order($db->quoteName('name') . ' ASC');
        $allForms = $db->setQuery($query)->loadObjectList();

        // --- Filtre d'accès par formulaire ---
        // Les Super Utilisateurs voient tous les formulaires sans restriction.
        // Pour les autres, on applique les règles définies dans la config du composant.
        // Si aucune règle n'est définie pour un formulaire, il reste visible par tous.
        $identity = $app->getIdentity();
        if ($identity->authorise('core.admin')) {
            $this->forms = $allForms;
        } else {
            $params      = ComponentHelper::getParams('com_cfsubmit');
            $formsAccess = (array) $params->get('forms_access', []);
            $userGroups  = array_map('intval', $identity->getAuthorisedGroups());

            $formGroupMap = [];
            foreach ($formsAccess as $rule) {
                $rule   = (array) $rule;
                $formId = (int) ($rule['form_id'] ?? 0);
                $group  = (int) ($rule['groups'] ?? 0);
                if ($formId && $group) {
                    $formGroupMap[$formId][] = $group;
                }
            }

            $this->forms = array_values(array_filter($allForms, function ($form) use ($formGroupMap, $userGroups) {
                $formId = (int) $form->id;
                if (!isset($formGroupMap[$formId])) {
                    return true;
                }
                return !empty(array_intersect($userGroups, $formGroupMap[$formId]));
            }));
        }

        // Paramètres de pagination et de filtrage transmis dans l'URL
        $this->limit      = in_array($app->getInput()->getInt('limit', 10), [10, 50, 100])
            ? $app->getInput()->getInt('limit', 10) : 10;
        $this->limitstart = max(0, $app->getInput()->getInt('limitstart', 0));
        // Tableau associatif fieldName → valeur du filtre actif (vide si pas de filtre)
        $this->activeFilters = $app->getInput()->get('filters', [], 'array');

        $this->submissions   = [];
        $this->filterFields  = [];

        if ($this->formId) {
            // Chargement de toutes les soumissions du formulaire sélectionné.
            // On joint #__convertforms pour récupérer le nom du formulaire.
            // state IN (1,2) = publié ou archivé (on exclut la corbeille : state=-2)
            $query = $db->getQuery(true)
                ->select(['a.*', 'f.name AS form_name'])
                ->from($db->quoteName('#__convertforms_conversions', 'a'))
                ->join('LEFT', $db->quoteName('#__convertforms', 'f') . ' ON f.id = a.form_id')
                ->where($db->quoteName('a.form_id') . ' = ' . $this->formId)
                ->whereIn($db->quoteName('a.state'), [1, 2])
                ->order($db->quoteName('a.created') . ' DESC');
            $rows = $db->setQuery($query)->loadObjectList();

            // ConvertFormsModelConversion::prepare() enrichit chaque ligne brute de la DB :
            // - décode le JSON de la colonne "params" en tableau PHP
            // - ajoute la propriété "prepared_fields" sur chaque $row, un tableau associatif
            //   fieldName → objet avec {label, value, value_html} prêts à afficher
            $submissionModel = new \ConvertFormsModelConversion(['ignore_request' => true]);

            foreach ($rows as $row) {
                // La colonne "params" est du JSON en base. prepare() attend un tableau PHP.
                if (is_string($row->params)) {
                    $row->params = json_decode($row->params, true) ?? [];
                }
                $submissionModel->prepare($row);
            }

            $this->submissions = $rows;

            // --- Construction des filtres dynamiques ---
            // On génère des filtres uniquement pour les champs à choix (dropdown, radio)
            // car ce sont les seuls dont les valeurs sont prévisibles et finies.
            $filterableTypes = ['dropdown', 'radio'];

            // Form::load() retourne la définition complète du formulaire ConvertForms :
            // structure des champs, types, options, etc.
            $formDef = Form::load($this->formId, false, true);

            if ($formDef && !empty($formDef['fields'])) {
                foreach ($formDef['fields'] as $field) {
                    if (!isset($field['type']) || !in_array($field['type'], $filterableTypes)) {
                        continue;
                    }

                    $fieldName  = strtolower($field['name'] ?? '');
                    $fieldLabel = $field['label'] ?? $fieldName;
                    if (!$fieldName) continue;

                    // On collecte uniquement les valeurs réellement présentes dans les soumissions
                    // (pas toutes les options possibles du formulaire) pour éviter les filtres vides.
                    $uniqueValues = [];
                    foreach ($rows as $row) {
                        $val = $row->prepared_fields[$fieldName]->value ?? '';
                        if ($val !== '' && !in_array($val, $uniqueValues)) {
                            $uniqueValues[] = $val;
                        }
                    }
                    sort($uniqueValues);

                    if (!empty($uniqueValues)) {
                        $this->filterFields[$fieldName] = [
                            'label'  => $fieldLabel,
                            'values' => $uniqueValues,
                        ];
                    }
                }
            }
        }

        // Passe la main au template tmpl/cfsubmit/default.php
        parent::display($tpl);
    }
}
