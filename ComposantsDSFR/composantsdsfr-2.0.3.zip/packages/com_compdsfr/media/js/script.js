import { fetchComponents, parseSelectedComponent }
    from './api/component-api.js';

import { insertOrReplaceComponent, setContentEditor, getAllComponentInEditor, deleteElementInEditor }
    from './editor/tinymce-bridge.js';

import { renderForm }
    from './form/renderer.js';

import { updateConditionalFields }
    from './form/conditional-fields.js';

import { generate }
    from './dsfr/generator.js';

import { preview, cleanPreview}
    from './dsfr/preview.js';

const editorId = Joomla.getOptions('compdsfr_data').editorId;
let currentComponent = null;
let selectedComponentIndex = null;
let components = [];


/**
 * Initialisation de l'interface
 */
document.addEventListener('DOMContentLoaded',init);

/**
 * Gestion des événements de clique sur les règles
 */
document.addEventListener('click', event => {
        const toggle = event.target.closest('#guidelines-toggle');

        if (!toggle) {
            return;
        }

        const wrapper = document.getElementById('form-guidelines');

        wrapper.classList.toggle('is-open');
    }
);

/**
 * Initialisation du composant
 *
 * @return void
 */
async function init() {

    components = await fetchComponents();

    document.getElementById('btn-back').addEventListener('click', backHome);

    await loadComponentFromEditor()
    buildMenu();

}


/**
 * Construction du menu des composants
 * 
 * @return void
 */
function buildMenu() {

    const menu = document.getElementById('component-menu');

    menu.innerHTML = '';

    components.forEach((component, index) => {
        
        if (!component.label) {
            return;
        }
    
        const btn = document.createElement('button');
    
        btn.type = 'button';
    
        btn.className ='list-group-item list-group-item-action py-3';
        btn.innerText = component.label;
        btn.onclick = () => {
            selectedComponentIndex = index;
        
            document
                .querySelectorAll('#component-menu .list-group-item')
                .forEach(item => item.classList.remove('is-active'));
        
            btn.classList.add('is-active');
        
            loadComponent(index);
        };
    
        menu.appendChild(btn);
    });
}

/**
 * Affichage de la description du composant
 *
 * @param {object} description Les données de description
 * @return void
 */
function renderDescription(description = {}) {

    const summaryContainer = document.getElementById('form-summary');
    const guidelines = document.getElementById('form-guidelines');
    const content = document.getElementById('form-description');

    if (!summaryContainer || !guidelines || !content) {
        return;
    }

    // SUMMARY
    summaryContainer.innerText = description.summary || '';

    let html = '';

    if (description.usage) {
        html += `
            <div class="dsfr-desc-block">
                <strong>Bon usage</strong>
                <p>${description.usage}</p>
            </div>
        `;
    }

    if (
        description.reference
        && description.reference.url
    )
    {
        html += `
            <div class="dsfr-desc-block">
                <strong>Références officielles</strong>
                <p>
                    <a href="${description.reference.url}" target="_blank" rel="noopener noreferrer">
                        ${description.reference.label || description.reference.url}
                    </a>
                </p>
            </div>
        `;
    }

    if (description.accessibility) {
        html += `
            <div class="dsfr-desc-block">
                <strong>Accessibilité</strong>
                <p>${description.accessibility}</p>
            </div>
        `;
    }

    if (description.warning) {

        html += `
            <div class="dsfr-desc-block dsfr-desc-warning">
                <strong>Attention</strong>
                <p>${description.warning}</p>
            </div>
        `;
    }

    if (Array.isArray(description.dos) && description.dos.length) {
        html += `
            <div class="dsfr-desc-block">
                <strong>À faire</strong>

                <ul>
                    ${description.dos.map(item => `
                        <li>${item}</li>
                    `).join('')}
                </ul>
            </div>
        `;
    }

    if (Array.isArray(description.donts) && description.donts.length) {
        html += `
            <div class="dsfr-desc-block">
                <strong>À éviter</strong>

                <ul>
                    ${description.donts.map(item => `
                        <li>${item}</li>
                    `).join('')}
                </ul>
            </div>
        `;
    }

    content.innerHTML = html;

    // Affichage du panneau seulement si contenu
    guidelines.classList.toggle('d-none', html.trim() === '');
}

/**
 * Charge tous les composants qui sont dans l'éditeur pour les modifier
 *
 * @return void
 */
async function loadComponentFromEditor() {
    const componentsInEditor = getAllComponentInEditor(editorId);
    if (components.length === 0) return;

    for(const i in componentsInEditor){
        const c = componentsInEditor[i];
        const result = await parseSelectedComponent(c);
        const propsObject = result.data;

        const compName = components.find(c => c.name === propsObject.component).label + "-" + (parseInt(i)+1);

        const ulComp = document.getElementById('list-composant');
        const li = document.createElement('li');

        const divTitle = document.createElement('div');
        divTitle.classList.add('title-composant');
        divTitle.textContent = compName;

        const btnDelete = document.createElement('button');
        btnDelete.classList.add('fr-icon-delete-fill', 'btn-delete-composant', 'fr-btn--sm', 'fr-btn', 'fr-btn--tertiary-no-outline');

        btnDelete.onclick = (e) => {
            e.stopPropagation();
            const msgConfirm = document.getElementById('msg-confirm-delete-composant');
            msgConfirm.classList.toggle('d-none', false);
            document.getElementById('composant-name').textContent = compName;
            document.getElementById('btn-cancel-composant').onclick = () => {
                msgConfirm.classList.toggle('d-none', true);
            }
            document.getElementById('btn-delete-composant').onclick = () => {
                li.remove();
                deleteElementInEditor(editorId, propsObject.dsfr_id)
                msgConfirm.classList.toggle('d-none', true);
            }
        };

        li.appendChild(divTitle);
        li.appendChild(btnDelete);

        li.onclick = async () => {
            await loadSelectedComponent(c);
        };

        ulComp.appendChild(li);
    }
    
}


function backHome() {
    currentComponent.values = [];
    currentComponent = null;
    document.getElementById('form-title').innerText = ''

    renderDescription('');
    document.getElementById('btn-back').classList.add('d-none');

    document.getElementById('form-actions').classList.add('d-none');
    document.getElementById('empty-state') ?.classList.remove('d-none');
    document.getElementById('form-wrapper') ?.classList.add('d-none');
    document
    .querySelectorAll('#component-menu .list-group-item')
    .forEach(item => item.classList.remove('is-active'));
    cleanPreview();
}

/**
 * Chargement d'un composant spécifique
 *
 * @param {number} index L'index du composant
 * @return void
 */
function loadComponent(index) {

    currentComponent = components[index];

    document.getElementById('form-title').innerText = currentComponent.label;

    renderDescription(currentComponent.description || {});
    cleanPreview();
    document.getElementById('btn-back').classList.remove('d-none');

    document.getElementById('form-actions').classList.remove('d-none');
    document.getElementById('empty-state') ?.classList.add('d-none');
    document.getElementById('form-wrapper') ?.classList.remove('d-none');
    document.querySelector('html').scrollTop = 0

    renderForm(currentComponent);
}


/**
 * Chargement d'un composant sélectionné
 *
 * @param {string} html Le HTML du composant sélectionné
 * @return void
 */
async function loadSelectedComponent(html) {

    const result = await parseSelectedComponent(html);

    if (!result.data) {
        return;
    }

    const parsedData = result.data;

    const componentIndex = components.findIndex(c => c.name === parsedData.component);

    if (componentIndex === -1) {
        return;
    }

    components[componentIndex].values = parsedData;

    selectedComponentIndex = componentIndex;

    loadComponent(componentIndex);
    
    const buttons = document.querySelectorAll(
        '#component-menu .list-group-item'
    );
    
    buttons.forEach(btn => btn.classList.remove('is-active'));
    
    buttons[componentIndex]?.classList.add('is-active');

    hydrateForm(parsedData);

    updateConditionalFields(currentComponent);
}

/**
 * Hydratation du formulaire avec les données existantes
 *
 * @param {object} data Les données à utiliser pour remplir le formulaire
 * @return void
 */
function hydrateForm(data) {

    const form = document.getElementById('dynamic-component-form');

    if (!form) {
        return;
    }

    const editors = document.querySelectorAll('.dsfr-tinymce')
    if(editors){
    
        editors.forEach(editorDiv => {
            setContentEditor(editorDiv, data[editorDiv.dataset.name])
        });
    }
    
    for (const [key, value] of Object.entries(data)) {

        const fields = form.querySelectorAll(`[name="${key}"]`);

        fields.forEach(field => {

            if (field.type === 'radio') {
                field.checked = String(field.value) === String(value);
            } else {
                field.value = value ?? '';
            }
        });
    }
}

/**
 * Génération et insertion du composant
 *
 * @return void
 */
async function genererEtInserer() {

    const html = await generate(currentComponent);
    
    if (!html) {
        return;
    }

    insertOrReplaceComponent(editorId, html);

    window.parent.Joomla
        ?.Modal
        ?.getCurrent()
        ?.close();
}




window.genererEtInserer = genererEtInserer;

window.preview = () => preview(() => generate(currentComponent));





