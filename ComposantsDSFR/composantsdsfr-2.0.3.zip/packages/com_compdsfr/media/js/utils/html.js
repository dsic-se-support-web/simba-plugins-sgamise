/**
 * Échappe une chaîne pour une insertion dans le HTML
 *
 * @param {string} value
 * @return {string}
 */
export function escapeHtml(value = '') {

    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

/**
 * Échappe une chaîne pour une insertion dans un attribut HTML
 *
 * @param {string} value
 * @return {string}
 */
export function escapeAttribute(value = '') {

    return escapeHtml(value);
}

/**
 * Retire uniquement le <p> racine ajouté par TinyMCE.
 *
 * Les balises HTML internes sont intégralement conservées.
 *
 * @param {string} html
 * @return {string}
 */
export function unwrapEditorContent(html = '') {

    const container = document.createElement('div');

    container.innerHTML = String(html).trim();

    const children = Array.from(container.children);

    // TinyMCE renvoie généralement un unique <p> autour du contenu.
    if (
        children.length === 1 &&
        children[0].tagName.toLowerCase() === 'p'
    ) {
        return children[0].innerHTML.trim();
    }

    return container.innerHTML.trim();
}