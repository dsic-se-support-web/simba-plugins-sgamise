import { renderPreview } from '../api/component-api.js';

/**
 * Génère et affiche l'aperçu
 *
 * @param {Function} generateFn La fonction de génération
 * @return {Promise<void>}
 */
export async function preview(generateFn) {

    const shortcode = await generateFn();

    if (!shortcode) {
        return;
    }

    let iframe = document.querySelector('#preview-container iframe');

    if (!iframe) {
        initPreview();
    }

    const result = await renderPreview(shortcode);

    updatePreview(result.data.html);
}

/**
 * Nettoie l'aperçu.
 *
 * @return {void}
 */
export function cleanPreview(){
    updatePreview('')
}

/**
 * Met à jour l'aperçu dans l'iframe
 *
 * @param {string} html Le HTML à afficher
 * @return {void}
 */
export function updatePreview(html) {

    const iframe = document.querySelector('#preview-container iframe');

    if (!iframe) {
        return;
    }

    const doc = iframe.contentDocument;
    const wrapper = doc.getElementById('preview-wrapper');

    if (wrapper) {
        wrapper.innerHTML = html;
    }

    // Re-init DSFR
    const win = iframe.contentWindow;

    if (win.dsfr?.start) {
        win.dsfr.start();
    }

    // Auto resize iframe
    setTimeout(() => {iframe.style.height = doc.body.scrollHeight + 'px';}, 50);
}

/**
 * Initialise l'iframe de prévisualisation
 *
 * @return {void}
 */
export function initPreview() {

    const previewContainer = document.getElementById('preview-container');
    previewContainer.innerHTML = '';
    const iframe = document.createElement('iframe');
    iframe.id = 'dsfr-preview-frame';
    iframe.style.width = '100%';
    iframe.style.border = 'none';

    previewContainer.appendChild(iframe);

    const dsfrPaths = Joomla.getOptions('dsfr_paths');
    const styles = dsfrPaths.css
        .map(h => `<link rel="stylesheet" href="${h}">`)
        .join('');
    const scripts = dsfrPaths.js
        .map(src => `<script type="module" src="${src}"></script>`)
        .join('');
    const previewFixes = `
        <style>
            body {
                padding: 24px;
                overflow-x: hidden;
            }

            /* =====================================
               FIX CITATION IMAGE DANS PREVIEW
            ===================================== */

            .fr-quote {
                overflow: visible !important;
                position: relative !important;
            }

            .fr-quote__image {
                position: relative !important;
                left: auto !important;
                top: auto !important;
                width: 160px !important;
                height: 160px !important;
                margin-top: 1rem !important;
            }

            .fr-quote__image img {
                display: block !important;
                width: 100% !important;
                height: 100% !important;
                object-fit: cover !important;
                border-radius: 50% !important;
            }
        </style>
    `;

    const doc = iframe.contentDocument;

    doc.open();

    doc.write(`
        <!DOCTYPE html>
        <html>
            <head>

                ${styles}

                ${previewFixes}

            </head>

            <body>
                <div id="preview-wrapper"></div>

                ${scripts}

            </body>
        </html>
    `);

    doc.close();
}