import {escapeHtml, escapeAttribute} from '../../utils/html.js';

/**
 * Calcule les valeurs pour le composant Notice
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeNoticeValues(values) {

    const noticeClasses = ['fr-notice'];

    if (values.type) {
        noticeClasses.push(`fr-notice--${values.type}`);
    } else {
        noticeClasses.push('fr-notice--info');
    }

    if (values.closable === '1') {
        noticeClasses.push('fr-notice--closable');
    }

    const titleClasses = ['fr-notice__title'];

    if (values.has_icon === '1') {
        titleClasses.push(values.icon || 'fr-icon-checkbox-circle-line');
    }

    const roleAttr = values.role_notice === '1'
        ? ' role="notice"'
        : '';
    const descriptionHtml = values.hasDescription === '1' && values.content
            ? `<span class="fr-notice__desc">
                    ${(values.content)}
                </span>`
            : '';
    const isBlank = values.blank === '1';
    const targetAttr = isBlank
        ? ' target="_blank"'
        : '';
    const relAttr = isBlank
        ? ' rel="noopener external"'
        : '';
    const titleAttr = values.link_title?.trim()
        ? ` title="${escapeAttribute(values.link_title)}"`
        : '';
    const linkHtml = values.hasLink === '1' && values.link_label && values.link_url
            ? `<a class="fr-notice__link" href="${escapeAttribute(values.link_url)}" ${targetAttr} ${relAttr} ${titleAttr}>
                    ${escapeHtml(values.link_label)}
                </a>`
            : '';
    const closeButton = values.closable === '1'
            ? `<button class="fr-btn--close fr-btn" title="Masquer le bandeau" type="button">
                    Masquer le bandeau
                </button>`
            : '';

    values.notice_html = `
        <div class="${noticeClasses.join(' ')}"${roleAttr}>
            <div class="fr-container">
                <div class="fr-notice__body">

                    <${values.tag}>

                        <span class="${titleClasses.join(' ')}">
                            ${escapeHtml(values.title || '')}
                        </span>

                        ${descriptionHtml}

                        ${linkHtml}

                    </${values.tag}>

                    ${closeButton}

                </div>
            </div>
        </div>
    `;

    return values;
}