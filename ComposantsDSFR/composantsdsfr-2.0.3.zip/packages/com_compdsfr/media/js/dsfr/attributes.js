import { getFirstElement } from '../utils/dom.js';

/**
 * Injecte les attributs DSFR dans le HTML généré
 *
 * @param {string} html Le HTML à modifier
 * @param {string} componentName Le nom du composant
 * @param {string} dsfrId L'ID DSFR
 * @return {string} Le HTML modifié
 */
export function injectDsfrAttributes(html, componentName, dsfrId) {

    const first = getFirstElement(html);

    if (!first) {
        return html;
    }

    first.setAttribute('data-dsfr-component', componentName);
    
    first.setAttribute('contentEditable', componentName === 'table');

    first.setAttribute('data-dsfr-id', dsfrId);

    return first.outerHTML;
}

/**
 * Injecte les propriétés DSFR dans le HTML généré
 *
 * @param {string} html Le HTML à modifier
 * @param {string} componentName Le nom du composant
 * @param {object} values Les valeurs à injecter
 * @return {string} Le HTML modifié
 */
export function injectDsfrProps(html, componentName, values) {
    const first = getFirstElement(html);

    if (!first) {
        return html;
    }

    first.setAttribute('data-dsfr-props', encodeURIComponent(JSON.stringify({
            ...values,
            component: componentName
        }))
    );

    return first.outerHTML;
}