import { initEditor } from "../editor/tinymce-bridge.js";

/**
 * Initialise le constructeur d'accordéons
 *
 * @param {Array} existingAccordions Accordéons existants
 * @return void
 */
export function initAccordionBuilder(existingAccordions = []) {

    const container = document.getElementById('accordion-builder');
    const addBtn = document.getElementById('add-accordion');

    if (!container || !addBtn) {
        return;
    }


    container.innerHTML = '';

    addBtn.replaceWith(addBtn.cloneNode(true));

    const newAddBtn = document.getElementById('add-accordion');

    newAddBtn.addEventListener('click', () => addAccordion(container));

    if (Array.isArray(existingAccordions) && existingAccordions.length) {
        existingAccordions.forEach(
            accordion => addAccordion(
                container,
                accordion
            )
        );
    }
}

/**
 * Ajoute un accordéon au builder
 *
 * @param {HTMLElement} container Conteneur du builder
 * @param {object} data Données de l'accordéon
 * @return void
 */
export function addAccordion(container,data = {}) {

    const accordionId = data.id || generateAccordionId();
    const label = data.label || '';
    const content = data.content || '';
    const isExpanded = data.isExpanded === '1';
    const wrapper = document.createElement('div');

    wrapper.className = 'card p-3 mb-3';
    wrapper.dataset.id = accordionId;

    wrapper.innerHTML = `
        <div class="mb-3">
            <label class="form-label">
                Libellé de l'accordéon
            </label>

            <input type="text" class="form-control accordion-label" value="${escapeHtml(label)}" placeholder="Titre de l'accordéon">
        </div>

        <div class="mb-3">
            <label class="form-label">
                Ouvert par défaut
            </label>

            <select class="form-select accordion-expanded">
                <option value="0" ${!isExpanded ? 'selected' : ''}> Non </option>
                <option value="1" ${isExpanded ? 'selected' : ''}> Oui </option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">
                Contenu
            </label>

            <div id='editor-placeholder'></div>
        </div>

        <div class="small text-muted mb-3">
            ID : ${accordionId}
        </div>

        <button type="button" class="btn btn-danger btn-sm remove-accordion"> Supprimer l'accordéon </button>
    `;


    wrapper
        .querySelector('.remove-accordion')
        .addEventListener(
            'click',
            () => {

                wrapper.remove();
            }
        );

    container.appendChild(wrapper);
    initEditor(wrapper, content);
}


/**
 * Génère un ID unique pour un accordéon
 *
 * @return {string} ID unique
 */
function generateAccordionId() {

    return (
        'accordion-' +
        Date.now() +
        '-' +
        Math.random()
            .toString(36)
            .substring(2, 9)
    );
}

/**
 * Échappe les caractères HTML
 *
 * @param {string} str Chaîne à échapper
 * @return {string} Chaîne échappée
 */
function escapeHtml(str = '') {

    const div = document.createElement('div');
    div.textContent = str;

    return div.innerHTML;
}