import { bindConditionalFields }
    from './conditional-fields.js';

import { initTabsBuilder }
    from './tabs-builder.js';

import { initAccordionBuilder }
    from './accordion-builder.js';

import { initCardBuilder }
    from './card-builder.js';

import { initTileBuilder }
    from './tile-builder.js';
import { initEditor } from '../editor/tinymce-bridge.js';

/**
 * Affiche le formulaire d’un composant
 *
 * @param {object} component Configuration du composant
 * @return void
 */
export function renderForm(component) {

    const container = document.getElementById('dynamic-form-container');
    const form = document.createElement('form');

    container.innerHTML = '';

    form.id = 'dynamic-component-form';
    form.innerHTML = component.fields
        .map(renderField)
        .join('');
    form.innerHTML += `<input type="hidden" name="dsfr_id" value="">`;

    container.appendChild(form);

    const editors = container.querySelectorAll('.dsfr-tinymce'); 
    if(editors){
        editors.forEach((tiny)=> {
            initEditor(tiny)
        })
    
    }
    
    if (component.name === 'tabs') {
    
        const existingTabs = component.values?.tabs || [];
    
        initTabsBuilder(existingTabs);
    }

    if (component.name === 'accordion') {
        initAccordionBuilder(component.values?.accordions || []);
    }

    if (component.name === 'card') {
        initCardBuilder(component.values?.cards || []);
    }

    if (component.name === 'tile') {
        initTileBuilder(component.values?.tiles || []);
    }

    bindMediaFields(form);

    bindArticleFields(form);

    bindConditionalFields(component);
}


/**
 * Lie les champs de sélection d'article
 *
 * @param {HTMLElement} form Le formulaire
 * @return void
 */
function bindArticleFields(form)
{
    form
    .querySelectorAll('.dsfr-article-picker')
    .forEach(button => {

        button.addEventListener('click', () => {

            const hidden = button.closest('.input-group').querySelector('.article-id');

            const titleField = button.closest('.input-group').querySelector('.article-title');

            window.dsfrCurrentArticlePicker = {
                idField: hidden,
                titleField
            };

            // Ouverture de la modale de sélection des liens vers articles
            window.ArticleManager = window.open(
                'index.php?option=com_content&view=articles&layout=modal&tmpl=component',
                'ArticleManager',
                'width=1200,height=700,resizable=yes'
            );
        });
    });
}

/**
 * Lie les champs de médias
 *
 * @param {HTMLElement} form Le formulaire
 * @return void
 */
function bindMediaFields(form) {

    form.querySelectorAll('.dsfr-media-picker') .forEach(button => {

            const targetName = button.dataset.target;
            const input = form.querySelector(`[name="${targetName}"]`);
            const preview = button.closest('.field-wrapper').querySelector('.dsfr-media-preview');
            const hasPreview = button.dataset.preview === '1';

            /**
             * Affiche preview
             */
            const updatePreview = (url) => {
                if (!hasPreview || !preview) {
                    return;
                }

                if (!url) {
                    preview.innerHTML = '';
                    return;
                }

                // Convertit URL relative -> absolue
                let finalUrl = url;

                // local-images:/foo.jpg
                if (finalUrl.startsWith('local-images:/')) {
                    finalUrl = finalUrl.replace('local-images:/',`${window.location.origin}/images/`);
                }

                // images/foo.jpg
                else if (!finalUrl.startsWith('http') && !finalUrl.startsWith('/')) {
                    finalUrl =`${window.location.origin}/${finalUrl}`;
                }

                preview.innerHTML = `<img src="${finalUrl}" alt="" style="max-width:200px; height:auto; border-radius:6px;">`;
            };

            /**
             * Preview si collage manuel
             */
            input.addEventListener('input', () => {
                updatePreview(input.value);
            });

            input.addEventListener('change', () => {
                updatePreview(input.value);
            });

            /**
             * Preview initiale
             */
            if (input.value) {
                updatePreview(input.value);
            }

            setTimeout(() => {
                input.dispatchEvent(new Event('input', { bubbles: true }));
            }, 0);

            button.addEventListener('click', () => {

                const fieldId = `dsfr-media-${Date.now()}`;
                const messageHandler = (event) => {

                    if (!event.data) {
                        return;
                    }

                    if (event.data.messageType === 'joomla:media-select' && event.data.fieldid === fieldId) {

                        const data = event.data;
                        let imageUrl = data.url || data.path || data.uri || '';

                        if (!imageUrl) {
                            return;
                        }

                        input.value = imageUrl;

                        updatePreview(imageUrl);

                        window.removeEventListener('message', messageHandler);
                    }
                };

                window.addEventListener('message', messageHandler);

                const url =`index.php?option=com_media&view=media&tmpl=component&asset=com_compdsfr&fieldid=${fieldId}`;

                window.open(url, 'MediaManager', 'width=1200,height=700,resizable=yes');
            });
        });
}

/**
 * Génère un champ de formulaire
 *
 * @param {object} field Configuration du champ
 * @return {string} Code HTML du champ
 */
function renderField(field) {

    switch (field.type) {
        case 'editor': 
            return `
            <div class="mb-3 field-wrapper dsfr-tinymce" data-name='${field.name}' data-visible-if='${JSON.stringify(field.visibleIf || "")}'>
                <label class="form-label">
                    ${field.label}
                </label>

                <div id='editor-placeholder'></div>

            </div>
            `
        case 'text':
            return `
                <div class="mb-3 field-wrapper" data-visible-if='${JSON.stringify(field.visibleIf || "")}'>
                    <label class="form-label">
                        ${field.label}
                    </label>

                    <input type="text" name="${field.name}" class="form-control" ${field.required ? 'required' : ''}>
                </div>
            `;

        case 'url':
            return `
                <div class="mb-3 field-wrapper" data-visible-if='${JSON.stringify(field.visibleIf || "")}'>
                    <label class="form-label">
                        ${field.label}
                    </label>
            
                    <input type="url" name="${field.name}" class="form-control">
                </div>
            `;

        case 'select':
            return `
                <div class="mb-3 field-wrapper" data-visible-if='${JSON.stringify(field.visibleIf || "")}'>
                    <label class="form-label">
                        ${field.label}
                    </label>

                    <select name="${field.name}" class="form-select">
                        ${field.options.map(option => `
                            <option
                                value="${option.value}"
                                ${option.value === field.default ? 'selected' : ''}>
                                ${option.label}
                            </option>
                        `).join('')}
                    </select>
                </div>
            `;

            case 'radio':
                return `
                    <div class="mb-3 field-wrapper" data-visible-if='${JSON.stringify(field.visibleIf || "")}'>
                        <label class="form-label d-block">
                            ${field.label}
                        </label>

                        ${field.options.map(option => `
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="${field.name}" value="${option.value}" ${option.value === field.default ? 'checked' : ''}>

                                <label class="form-check-label">
                                    ${option.label}
                                </label>

                            </div>
                        `).join('')}
                    </div>
                `;
            
            case 'textarea':
                return `
                    <div class="mb-3 field-wrapper" data-visible-if='${JSON.stringify(field.visibleIf || "")}'>
                        <label class="form-label">
                            ${field.label}
                        </label>
            
                        <textarea name="${field.name}" class="form-control" rows="5"></textarea>
                    </div>
                `;

            case 'notice':
                return `
                    <div class="mb-3 field-wrapper" data-visible-if='${JSON.stringify(field.visibleIf || "")}'>
                        <div class="alert alert-warning dsfr-form-notice">
                            ${field.content}
                        </div>
                    </div>
                `;

            case 'info':
                return `
                    <div class="mb-3 field-wrapper" data-visible-if='${JSON.stringify(field.visibleIf || "")}'>
                        <div class="alert alert-info dsfr-form-notice">
                            ${field.content}
                        </div>
                    </div>
                `;

            case 'media':
                return `
                    <div class="mb-3 field-wrapper" data-visible-if='${JSON.stringify(field.visibleIf || "")}'>
                        <label class="form-label">
                            ${field.label}
                        </label>

                        <div class="input-group">
                            <input type="text" name="${field.name}" class="form-control">

                            <button type="button" class="fr-btn fr-btn--secondary dsfr-media-picker" data-target="${field.name}" data-preview="${field.preview !== false ? '1' : '0'}">
                                Sélectionner
                            </button>
                        </div>

                        ${
                            field.preview !== false
                                ? '<div class="dsfr-media-preview mt-2"></div>'
                                : ''
                        }
                    </div>
                `;

            case 'tabs-builder':
                return `
                    <div class="mb-3">
                        <label class="form-label">
                            ${field.label}
                        </label>

                        <div id="tabs-builder"></div>

                        <button type="button" id="add-tab" class="fr-btn fr-mt-3v">
                            Ajouter un onglet
                        </button>
                    </div>
                `;

            case 'accordion-builder':
                return `
                    <div class="mb-3">
                        <label class="form-label">
                            ${field.label}
                        </label>
                    
                        <div id="accordion-builder"></div>
                    
                        <button type="button" id="add-accordion" class="fr-btn fr-mt-3v">
                            Ajouter un accordéon
                        </button>
                    </div>
                `;

            case 'card-builder':
                return `
                    <div class="mb-3">

                        <label class="form-label">
                            ${field.label}
                        </label>

                        <div id="card-builder"></div>

                        <button type="button" id="add-card" class="fr-btn fr-mt-3v">
                            Ajouter une carte
                        </button>

                    </div>
                `;

            case 'article-picker':
                return `
                <div class="mb-3 field-wrapper">
                    <label class="form-label">
                        ${field.label}
                    </label>
                
                    <div class="input-group">
                        <input type="hidden" name="${field.name}" class="article-id" value="">
                
                        <input type="text" class="form-control article-title" readonly>
                
                        <button type="button" class="fr-btn fr-btn--secondary dsfr-article-picker" data-target="${field.name}">
                            Sélectionner un article
                        </button>
                    </div>
                </div>
                `;

            case 'tile-builder':
                return `
                    <div class="mb-3">

                        <label class="form-label">
                            ${field.label}
                        </label>

                        <div id="tile-builder"></div>
                            <button type="button" id="add-tile" class="fr-btn fr-mt-3v">
                                Ajouter une tuile
                            </button>
                    </div>
                `;

         
    }

    return '';
}