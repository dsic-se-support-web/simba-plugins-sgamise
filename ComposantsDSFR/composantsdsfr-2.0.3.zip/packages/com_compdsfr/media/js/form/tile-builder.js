let counter = 0;

window.addEventListener('message', event => {

    if (!event.data || event.data.messageType !== 'comdsfr:article-select') {
        return;
    }

    if (!window.dsfrCurrentArticlePicker) {
        return;
    }

    if (window.dsfrCurrentArticlePicker.type !== 'tile') {
        return;
    }

    const {idField, titleField} = window.dsfrCurrentArticlePicker;
    idField.value = event.data.id;
    titleField.value = event.data.title;
    const tile = idField.closest('.dsfr-tile-item');

    if (tile) {

        let articleUrl = tile.querySelector('.tile-article-url');

        if (!articleUrl) {
            articleUrl = document.createElement('input');
            articleUrl.type = 'hidden';
            articleUrl.className = 'tile-article-url';

            tile.appendChild(articleUrl);
        }

        articleUrl.value = event.data.url;
    }

    window.dsfrCurrentArticlePicker = null;

    if (window.ArticleManager) {
        window.ArticleManager.close();
    }
});

/**
 * Initialise le constructeur de tuiles
 *
 * @param {Array} existingtiles Tuiles existantes
 * @return void
 */
export function initTileBuilder(existingtiles = []) {

    const container = document.getElementById('tile-builder');

    if (!container) {
        return;
    }

    container.innerHTML = '';

    counter = 0;

    const addButton = document.getElementById('add-tile');

    if (addButton) {

        addButton.onclick = () => {

            const currentCount = container.querySelectorAll('.dsfr-tile-item').length;

            if (currentCount >= 4) {

                Joomla.renderMessages({
                    warning: ['Le composant Carte est limité à 4 cartes.']
                });

                return;
            }

            addtile(container);

            const countField = document.querySelector('[name="tiles_count"]');

            if (countField) {
                countField.value = currentCount + 1;
            }
        };
    }

    const count = Math.max(parseInt(document.querySelector('[name="tiles_count"]')?.value || 1), existingtiles.length);

    for (let i = 0; i < count; i++) {

        const data = existingtiles[i] || {};

        addtile(container, data);

        if (data.article_id && !data.article_title) {
        
            fetch(`index.php?option=com_compdsfr&task=display.getArticle&id=${data.article_id}`)
            .then(r => r.json())
            .then(r => {
        
                if (!r.success) {
                    return;
                }
        
                const tile = container.lastElementChild;
        
                tile.querySelector('.tile-article-title').value = r.data.title;
            });
        }
    }

    document.querySelector('[name="tiles_count"]')?.addEventListener('change', event => {
    
            const wanted = parseInt(event.target.value);
            const current = container.querySelectorAll('.dsfr-tile-item').length;
    
            if (wanted > current) {
    
                for (let i = current; i < wanted; i++) {
                    addtile(container);
                }
    
                return;
            }
    
            if (wanted < current) {
    
                const tiles = container.querySelectorAll('.dsfr-tile-item');
    
                for (let i = current; i > wanted; i--) {
                    tiles[i - 1].remove();
                }
            }
        }
    );
}

/**
 * Lie les champs de médias à une tuile
 *
 * @param {HTMLElement} wrapper Wrapper de la tuile
 * @return void
 */
function bindtileMedia(wrapper)
{
    const button = wrapper.querySelector('.tile-media-picker');
    const input = wrapper.querySelector('.tile-pictogram');
    const preview = wrapper.querySelector('.tile-pictogram-preview');

    if (!button || !input) {
        return;
    }

    const updatePreview = (url) => {

        if (!preview) {
            return;
        }

        if (!url) {
            preview.innerHTML = '';
            return;
        }

        let finalUrl = url;

        // même logique que citation
        if (finalUrl.startsWith('local-images:/')) {
            finalUrl = finalUrl.replace('local-images:/', `${window.location.origin}/images/`);
        }
        else if (!finalUrl.startsWith('http') && !finalUrl.startsWith('/')) {
            finalUrl = `${window.location.origin}/${finalUrl}`;
        }

        preview.innerHTML = `<img src="${finalUrl}" style="max-width:200px;height:auto;border-radius:6px;">`;
    };

    // preview initiale
    updatePreview(input.value);

    input.addEventListener('input', () => {
        updatePreview(input.value);
    });

    button.addEventListener('click', () => {

        const fieldId = `tile-media-${Date.now()}`;
        const handler = (event) => {

            if (!event.data) return;

            if (event.data.messageType === 'joomla:media-select' && event.data.fieldid === fieldId) {
                let imageUrl = event.data.url || event.data.path || event.data.uri || '';

                if (!imageUrl) return;

                input.value = imageUrl;
                updatePreview(imageUrl);

                window.removeEventListener('message', handler);
            }
        };

        window.addEventListener('message', handler);

        const url = `index.php?option=com_media&view=media&tmpl=component` + `&asset=com_compdsfr&fieldid=${fieldId}`;

        window.open(url, 'MediaManager', 'width=1200,height=700,resizable=yes');
    });
}

/**
 * Lie les champs de téléchargement à une tuile
 *
 * @param {HTMLElement} wrapper Wrapper de la tuile
 * @return void
 */
function bindDownloadMedia(wrapper)
{
    const button = wrapper.querySelector('.tile-download-picker');
    const input = wrapper.querySelector('.tile-download-url');

    if (!button || !input) {
        return;
    }

    button.addEventListener('click', () => {

        const fieldId = `tile-download-${Date.now()}`;
        const handler = (event) => {

            if (!event.data) {
                return;
            }

            if (event.data.messageType === 'joomla:media-select' && event.data.fieldid === fieldId) {
                const url =
                    event.data.url
                    || event.data.path
                    || event.data.uri
                    || '';

                input.value = url;

                window.removeEventListener('message', handler);
            }
        };

        window.addEventListener('message', handler);

        const url =
            `index.php?option=com_media&view=media&tmpl=component`
            + `&asset=com_compdsfr`
            + `&fieldid=${fieldId}`;

        window.open(url, 'MediaManager', 'width=1200,height=700,resizable=yes');
    });
}

/**
 * Ajoute une tuile au builder
 *
 * @param {HTMLElement} container Conteneur du builder
 * @param {object} data Données de la tuile
 * @return void
 */
function addtile(container, data = {}) {

    const wrapper = document.createElement('div');
    const linkType = data.link_type || 'article';

    wrapper.className = 'tile p-3 mb-3 dsfr-tile-item';

    wrapper.innerHTML = `
    <h4>Tuile ${++counter}</h4>

    <button type="button" class="btn btn-danger btn-sm remove-tile fr-mb-2v">
        Supprimer la tuile
    </button>

    <input class="form-control tile-title mb-2" placeholder="Titre" value="${data.title || ''}">

    <textarea class="form-control tile-description mb-2" placeholder="Description">${data.description || ''}</textarea>

    <input class="form-control tile-detail mb-2" placeholder="Détail (optionnel)" value="${data.detail || ''}">

    <label class="form-label fr-mt-5v">
        Type de lien
    </label>

    <select class="form-select tile-link-type fr-mb-3v">
        <option value="article" ${linkType === 'article' ? 'selected' : ''}>
            Article Joomla
        </option>

        <option value="url" ${linkType === 'url' ? 'selected' : ''}>
            URL externe
        </option>
    </select>

    <div class="tile-link-article">

        <input type="hidden" class="tile-article-id" value="${data.article_id || ''}">

        <input type="hidden" class="tile-article-url" value="${data.article_url || ''}">

        <div class="input-group">
            <input type="text" class="form-control tile-article-title" readonly value="${data.article_title || ''}">

            <button type="button" class="fr-btn fr-btn--secondary tile-select-article">
                Sélectionner
            </button>
        </div>
    </div>

    <div class="tile-link-url">
        <input type="url" class="form-control tile-url" value="${data.url || ''}">
    </div>

    <label class="form-label fr-mt-5v">
        Mode téléchargement
    </label>

    <select class="form-select tile-download fr-mb-3v">
        <option value="0" ${(data.download || '0') === '0' ? 'selected' : ''}>
            Non
        </option>

        <option value="1" ${(data.download || '0') === '1' ? 'selected' : ''}>
            Oui
        </option>
    </select>

    <div class="tile-download-fields">
        <label class="form-label fr-mt-5v">
            Fichier à télécharger
        </label>

        <div class="input-group fr-mb-3v">
            <input type="text" class="form-control tile-download-url" value="${data.download_url || ''}">

            <button type="button" class="fr-btn fr-btn--secondary tile-download-picker">
                Sélectionner
            </button>
        </div>
    </div>

    <label class="form-label fr-mt-5v">
        Pictogramme d'illustration de la tuile
    </label>

    <div class="input-group fr-mt-3v">
        <input type="text" class="form-control tile-pictogram" placeholder="Pictogramme" value="${data.pictogram || ''}">

        <button type="button" class="fr-btn fr-btn--secondary tile-media-picker">
            Sélectionner
        </button>
    </div>

    <div class="alert alert-info dsfr-form-notice fr-mb-3v">
        Utilisez la fonctionnalité "obtenir un lien" dans l'explorateur de médias puis collez-le dans ce champ
    </div>

    <div class="tile-pictogram-preview fr-mt-2v"></div>
    `;

    container.appendChild(wrapper);

    bindtileMedia(wrapper);

    bindDownloadMedia(wrapper);

    wrapper.querySelector('.remove-tile') ?.addEventListener('click', () => {
    
        wrapper.remove();
    
        const count = container.querySelectorAll('.dsfr-tile-item').length;
        const countField = document.querySelector('[name="tiles_count"]');
    
        if (countField) {
            countField.value = count;
        }
    });

    const linkTypeSelect = wrapper.querySelector('.tile-link-type');
    const articleBlock = wrapper.querySelector('.tile-link-article');
    const urlBlock = wrapper.querySelector('.tile-link-url');

    function refreshLinkMode()
    {
        const type = linkTypeSelect.value;

        articleBlock.style.display = type === 'article'
                ? ''
                : 'none';
        urlBlock.style.display = type === 'url'
                ? ''
                : 'none';
    }

    const downloadSelect = wrapper.querySelector('.tile-download');
    const downloadFields = wrapper.querySelector('.tile-download-fields');

    function refreshDownloadMode()
    {
        const download = downloadSelect.value === '1';

        downloadFields.style.display = download
                ? ''
                : 'none';
        linkTypeSelect.disabled = download;
        articleBlock.style.display = download
                ? 'none'
                : (
                    linkTypeSelect.value === 'article'
                        ? ''
                        : 'none'
                );
        urlBlock.style.display = download
                ? 'none'
                : (
                    linkTypeSelect.value === 'url'
                        ? ''
                        : 'none'
                );
    }

    refreshLinkMode();
    refreshDownloadMode();

    linkTypeSelect.addEventListener('change', () => {
            refreshLinkMode();
            refreshDownloadMode();
        }
    );

    downloadSelect.addEventListener('change', refreshDownloadMode);
  
    wrapper.querySelector('.tile-select-article')
    ?.addEventListener('click', () => {
    
        const titleField = wrapper.querySelector('.tile-article-title');
        const idField = wrapper.querySelector('.tile-article-id');
    
        window.dsfrCurrentArticlePicker = {
            type: 'tile',
            idField,
            titleField
        };
  
        const fieldId = 'tile_article_' + Date.now();
        idField.dataset.fieldid = fieldId;
        
        const url = 'index.php?option=com_compdsfr' + '&view=modalarticles' + '&tmpl=component';
    
        window.ArticleManager = window.open(url, 'ArticleManager', 'width=1200,height=700,resizable=yes');
    });
}