import { initEditor } from "../editor/tinymce-bridge.js";


/**
 * Initialise le constructeur d'onglets
 *
 * @param {Array} existingTabs Onglets existants
 * @return void
 */
export function initTabsBuilder(existingTabs = []) {

    const container = document.getElementById('tabs-builder');
    const addBtn = document.getElementById('add-tab');


    if (!container || !addBtn) {
        return;
    }

    addBtn.replaceWith(addBtn.cloneNode(true));

    const newAddBtn = document.getElementById('add-tab');

    newAddBtn.addEventListener('click', () => {
        addTab(container);
    });

    if (existingTabs.length) {
        existingTabs.forEach(tab => addTab(container, tab));
    } else {
        addTab(container);
    }
}

/**
 * Ajoute un onglet au builder
 *
 * @param {HTMLElement} container Conteneur du builder
 * @param {object} data Données de l'onglet
 * @return void
 */
export function addTab(
    container,
    data = {}
) {

    const wrapper =
        document.createElement('div');

    const label =
        data.label || '';

    const content =
        data.content || '';


    wrapper.className =
        'card p-3 mb-3';
    wrapper.innerHTML = `
    <input
        type="text"
        class="form-control mb-2 tab-label"
        value="${escapeHtml(label)}"
        placeholder="Libellé">
    
    <div id='editor-placeholder'></div>

    <button
        type="button"
        class="btn btn-danger btn-sm mt-2 remove-tab">

        Supprimer
    </button>
    `;

    
    wrapper
        .querySelector('.remove-tab')
        .addEventListener('click', () => {
            wrapper.remove();
        });

    container.appendChild(wrapper);
        
    initEditor(wrapper, content);
}


/**
 * Échappe les caractères HTML
 *
 * @param {string} str Chaîne à échapper
 * @return {string} Chaîne échappée
 */
function escapeHtml(str = '') {

    const div = document.createElement('div');
    div.textContent = str;

    return div.innerHTML;
}