import {computeComponentValues}
    from '../dsfr/computeds/index.js';
import { getContentEditor } from '../editor/tinymce-bridge.js';

/**
 * Rassemble les valeurs saisies dans le formulaire
 *
 * @return Objet contenant les valeurs des champs, y compris ceux des builders.
 */
export function getFormValues() {

    const form = document.getElementById('dynamic-component-form');

    if (!form) {
        return {};
    }

    const formData = new FormData(form);
    const values = Object.fromEntries(formData.entries());
    const tabsBuilder = document.getElementById('tabs-builder');
    const accordionBuilder = document.getElementById('accordion-builder');
    const cardBuilder = document.getElementById('card-builder');
    const tileBuilder = document.getElementById('tile-builder');

    if (tabsBuilder) {

        values.tabs = [];

        tabsBuilder
            .querySelectorAll('.card')
            .forEach(card => {

                const label = card.querySelector('.tab-label') ?.value || '';

                const content = getContentEditor(card);

                values.tabs.push({
                    label,
                    content
                });
            });
    }

    if (accordionBuilder) {

        values.accordions = [];
    
        accordionBuilder.querySelectorAll('.card').forEach(card => {
    
                const label = card.querySelector('.accordion-label') ?.value || '';
                const id = card.dataset.id;
                const isExpanded = card.querySelector('.accordion-expanded') ?.value || '0';

                const content = getContentEditor(card);
    
                values.accordions.push({
                    id,
                    label,
                    content,
                    isExpanded
                });
            });
    }

    if (cardBuilder) {
        values.cards = [];
        cardBuilder.querySelectorAll('.dsfr-card-item').forEach(card => {
                values.cards.push({
                    title: card.querySelector('.card-title')?.value || '',
                    description: card.querySelector('.card-description')?.value || '',
                    link_type: card.querySelector('.card-link-type')?.value || '',
                    article_id: card.querySelector('.card-article-id')?.value || '',
                    article_url: card.querySelector('.card-article-url')?.value || '',
                    article_title: card.querySelector('.card-article-title')?.value || '',
                    url: card.querySelector('.card-url')?.value || '',
                    download_url: card.querySelector('.card-download')?.value || '',
                    image_url: card.querySelector('.card-image')?.value || '',
                    image_alt: card.querySelector('.card-alt')?.value || ''
                });
            });
    }

    if (tileBuilder) {
        values.tiles = [];   
        tileBuilder.querySelectorAll('.dsfr-tile-item').forEach(tile => {
            values.tiles.push({
                title: tile.querySelector('.tile-title')?.value || '',
                description: tile.querySelector('.tile-description')?.value || '',
                detail: tile.querySelector('.tile-detail')?.value || '',
                tiles_count: document.querySelectorAll('.dsfr-tile-item').length,
                link_type: tile.querySelector('.tile-link-type')?.value || '',
                article_id: tile.querySelector('.tile-article-id')?.value || '',
                article_url: tile.querySelector('.tile-article-url')?.value || '',
                article_title: tile.querySelector('.tile-article-title')?.value || '',
                url: tile.querySelector('.tile-url')?.value || '',
                pictogram: tile.querySelector('.tile-pictogram')?.value || '',
                horizontal: tile.querySelector('.tile-horizontal')?.checked
                    ? '1'
                    : '0',
                download: tile.querySelector('.tile-download')?.value || '',
                download_url: tile.querySelector('.tile-download-url')?.value || '',
                variation: tile.querySelector('.tile-variation')?.value || '',
                target_blank: tile.querySelector('.tile-target-blank')?.checked
                    ? '1'
                    : '0',
                size: tile.querySelector('.tile-size')?.value || 'md'
            });
        });
    }

    const editors =  document.querySelectorAll('.dsfr-tinymce')
    if(editors){
        editors.forEach(editorDiv => {
            values[editorDiv.dataset.name] = getContentEditor(editorDiv);
        });
    }
    
    return values;
}

/**
 * Applique les calculs spécifiques à un composant
 *
 * @param {component} Configuration du composant
 * @param {values} Valeurs saisies
 * @return Valeurs calculées prêtes à être utilisées dans le template.
 */
export function computeValues(component,values) {
    return computeComponentValues(component,values);
}