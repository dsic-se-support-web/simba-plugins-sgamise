/**
 * Récupère l'instance TinyMCE associée à un éditeur
 *
 * @param {string} editorId ID de l'éditeur
 * @return {Object|null} Instance TinyMCE ou null
 */
export function getEditor(editorId) {

    return window.parent.tinymce?.get(editorId);
}


/**
 * Insère ou remplace un composant dans l'éditeur TinyMCE
 *
 * @param {string} editorId ID de l'éditeur
 * @param {string} html HTML du composant à insérer
 * @return void
 */
export function insertOrReplaceComponent(editorId, html) {

    const editor = getEditor(editorId);

    if (!editor) {
        return;
    }

    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const first = doc.body.firstElementChild;
    const dsfrId = first?.getAttribute('data-dsfr-id');

    if (dsfrId) {

        const existingNode = editor.dom.select(`[data-dsfr-id="${dsfrId}"]`)[0];

        if (existingNode) {
            const nextSibling = existingNode.nextElementSibling;
            const previousSibling = existingNode.previousElementSibling;
            if(!previousSibling || !previousSibling.matches('p')) html = '<p></p>' + html
            if(!nextSibling || !nextSibling.matches('p')) html += '<p></p>';
            
            editor.dom.setOuterHTML(
                existingNode,
                html
            );

        }else {
            html = '<p></p>' + html + '<p></p>'; // éviter un bug joomla
            editor.insertContent(html);
        }
    }

}

/**
 * Insère et initialise l'éditeur TinyMCE
 *
 * @param {string} container Conteneur parent contenant l'éditeur
 * @param {string} content Contenu à ajouter si besoin à l'init 
 * @return void
 */
export function initEditor(container, content=''){
    const id = crypto.randomUUID().slice(0, 8);
    const regexId = /default/gi;
    const regexX = /editorX/gi;
    const html = document.getElementById('template-editor').innerHTML.replace(regexId, id).replace(regexX, 'editor0');
    
    container.querySelector('#editor-placeholder').outerHTML = html;

    container.querySelector(`joomla-field-subform[name="${id}[editor]"]`).addRow();    
    // Gestion des impuretés quand on ajoute un éditeur
    // Enlever les labels vides
    container.querySelectorAll('div.control-group > div.control-label label').forEach((el) => {
        if (el.innerHTML.trim() === '') {
            el.remove();
        }
    });
    container.querySelectorAll('div.control-group > div.control-label,div.control-group > div.controls').forEach((el) => {
        if (el.innerHTML.trim() === '') {
            el.remove();
        }
    });
    container.querySelectorAll('div.control-group').forEach((el) => {
        if (el.innerHTML.trim() === '') {
            el.remove();
        }
    });
    
    // Supprimer les attributs name
    container.querySelectorAll(`[name^="${id}["]`).forEach((el) => {
        el.removeAttribute('name');
    });

    if(content) setContentEditor(container, content);
}

/**
 * Récupère le contenu d'un éditeur
 *
 * @param {string} container Conteneur parent contenant l'éditeur
 * @return {string} le contenu de l'éditeur
 */
export function getContentEditor(container){
    let content = '';
    const editorId = getEditorIdFromContainer(container);

    if (window.tinymce) {
        tinymce.triggerSave();
    }
    
    const tiny = window.tinymce;

    if (tiny && editorId) {
        const editor = tiny.get(editorId);
        content = editor ? editor.getContent() : '';
    }
    return content;
}

/**
 * Récupère l'id d'un éditeur
 *
 * @param {string} container Conteneur parent contenant l'éditeur
 * @return void 
 */
function getEditorIdFromContainer(container){
    const textarea = container.querySelector('textarea');
    if(textarea){
        return textarea.id;
    }
    return 0;
}

/**
 * Insère du contenu dans un éditeur
 *
 * @param {string} container Conteneur parent contenant l'éditeur
 * @param {string} content Contenu à insérer dans l'éditeur 
 * @return void 
 */
export function setContentEditor(container, content){
    const editorId = getEditorIdFromContainer(container);

    const tiny = window.tinymce;

    const editorTiny = tiny.get(editorId);
    if (editorTiny) {
        editorTiny.on('init', function() {
            if(tiny){
                tiny.get(editorId).execCommand('mceInsertContent', false, content);
            }                 
        });
    }
}

/**
 * Récupère tous les composants présent dans l'éditeur
 * @param {string} editorId ID de l'éditeur
 * @return {Array} Liste des composants
 */
export function getAllComponentInEditor(editorId) {

    try {
        const componentsHTML = []
        const editor = getEditor(editorId);
        if (!editor) {
            return '';
        }

        const components = editor.dom.select(
            `[data-dsfr-component]`
        );

        components.forEach((c)=>{
            let component = null;
            let current = c;
    
            while (current) {
    
                if (current.nodeType === 1 && current.hasAttribute('data-dsfr-component')) {
                    component = current;
                    break;
                }
    
                current = current.parentElement;
            }
    
            if (component && component.getAttribute('data-dsfr-component') === 'card') {
    
                const dsfrId = component.getAttribute('data-dsfr-id');
    
                if (dsfrId) {
    
                    const root = editor.getBody().querySelector(`[data-dsfr-id="${dsfrId}"]`);
    
                    if (root) {
                        component = root;
                    }
                }
            }
            
            componentsHTML.push(component?.outerHTML);
        })
        return componentsHTML || [];

    } catch (e) {

        console.warn('Erreur TinyMCE', e);

        return [];
    }
}

/**
 * Supprime un composant de l'éditeur
 * @param {string} editorId ID de l'éditeur
 * @param {string} dsfrId ID du composant à supprimer 
 * @return void
 */
export function deleteElementInEditor(editorId, dsfrId){
    try {

        const editor = getEditor(editorId);
        if (!editor) {
            return;
        }
        const components = editor.dom.select(`[data-dsfr-id="${dsfrId}"]`);

        if (components.length > 0) {
            editor.dom.remove(components[0]);
        }
    } catch (e) {

        console.warn('Erreur TinyMCE', e);

        return;
    }
}
