import { fetchJson } from '../utils/fetch.js';

const BASE = 'index.php?option=com_compdsfr';

/**
 * Récupère la liste des composants DSFR
 *
 * @return {Promise<Array>} La liste des composants
 */
export async function fetchComponents() {

    const result = await fetchJson(`${BASE}&task=display.getComponents&format=json`);

    return result.data || [];
}

/**
 * Parse un composant existant à partir de son HTML
 *
 * @param {string} html Le HTML du composant
 * @return {Promise<object>} Les données du composant
 */
export async function parseSelectedComponent(html) {

    const params = new URLSearchParams();
    params.append('html', html);

    return fetchJson(`${BASE}&task=display.getSelectedComponent&format=json`,
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: params.toString()
        }
    );
}

/**
 * Génère l'aperçu d'un composant
 *
 * @param {string} shortcode Le shortcode à prévisualiser
 * @return {Promise<object>} Le résultat de la prévisualisation
 */
export async function renderPreview(shortcode) {

    const formData = new FormData();

    formData.append('shortcode', shortcode);
    formData.append(Joomla.getOptions('csrf.token'), '1');

    return fetchJson(`${BASE}&task=display.render&format=json`,
        {
            method: 'POST',
            body: formData
        }
    );
}


