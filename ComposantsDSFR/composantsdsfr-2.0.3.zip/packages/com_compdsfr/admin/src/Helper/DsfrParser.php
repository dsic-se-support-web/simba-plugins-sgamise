<?php

namespace Joomla\Component\CompDsfr\Administrator\Helper;

defined('_JEXEC') or die;

use DOMDocument;
use DOMElement;
use DOMXPath;

class DsfrParser
{
    /**
     * Mapping des composants DSFR vers leurs parsers
     */
    private const COMPONENT_PARSERS = [
        'accordion' => 'parseAccordion',  // Accordéons
        'alert'     => 'parseAlert',      // Alerte
        'notice'    => 'parseNotice',     // Bandeau d'information
        'bouton'    => 'parseButton',     // Bouton
        'carte'     => 'parseCard',       // Carte
        'citation'  => 'parseCitation',   // Citation
        'tooltip'   => 'parseTooltip',    // Infobulle
        'callout'   => "parseCallout",    // Mise en avant
        'highlight' => 'parseHighlight',  // Mise en exergue
        'tabs'      => 'parseTabs',       // Onglets
        'table'     => 'parseTable',      // Tableau
        'download'  => 'parseDownload',   // Téléchargement
        'tile'      => 'parseTile',       // Tuiles
        'video'     => 'parseVideo',      // Video
    ];

    /**
     * Point d'entrée principal pour analyser un composant
     * 
     * @param string $html HTML à analyser
     * @return array|null
     */
    public static function parseComponent(string $html): ?array
    {
        $html = trim($html);
    
        if ($html === '') {
            return null;
        }
    
        [$dom, $xpath] = self::createDom($html);
    
        $node = $xpath->query('//*[@data-dsfr-component]')->item(0);
    
        if (!$node instanceof DOMElement) {
            return null;
        }
    
        $componentName = $node->getAttribute('data-dsfr-component');
    
        if ($componentName === '') {
            return null;
        }
    
        // PRIORITÉ ABSOLUE AU SNAPSHOT JSON
        $storedProps = self::extractStoredProps($node);
    
        if ($storedProps !== null) {
            return $storedProps;
        }
    
        $method = self::COMPONENT_PARSERS[$componentName] ?? null;
    
        if (!$method || !method_exists(self::class, $method)) {
            return null;
        }
    
        return self::$method($node, $xpath);
    }

    /**
     * Parse du composant Alert
     *
     * @param DOMElement $node Le noeud DOM de l'alerte
     * @param DOMXPath $xpath L'objet XPath
     * @return array Les données de l'alerte
     */
    private static function parseAlert(DOMElement $node, DOMXPath $xpath): array {
    
        $classes = self::getClasses($node);
        $titleNode = $xpath->query('.//*[contains(@class, "fr-alert__title")]', $node)->item(0);
        $title = $titleNode ? trim($titleNode->textContent) : '';
        $contentNode = $xpath->query('.//p[not(contains(@class, "fr-alert__title"))]', $node)->item(0);
        $content = $contentNode ? trim($contentNode->textContent) : '';
    
        return [
            'component' => 'alert',
            'type' => self::extractVariant($classes,
                [
                    'success',
                    'error',
                    'warning'
                ],
                'fr-alert--',
                'info'
            ),
            'size' => in_array('fr-alert--sm', $classes, true)
                ? 'sm'
                : 'md',
            'closable' => in_array('fr-alert--closable', $classes, true)
                ? '1'
                : '0',
            'title' => $title,
            'content' => $content
        ];
    }


    /**
     * Parse du composant Bouton
     *
     * @param DOMElement $node Le noeud DOM du bouton
     * @param DOMXPath $xpath L'objet XPath
     * @return array Les données du bouton
     */
    private static function parseButton(DOMElement $node, DOMXPath $xpath): array {

        $classes = self::getClasses($node);

        return [
            'component'      => 'bouton',
            'button_type'    => strtolower($node->tagName),
            'has_icon'       => self::extractIcon($classes) !== '' ? '1' : '0',
            'dsfr_id'        => self::attr($node, 'data-dsfr-id'),
            'label'          => self::text($node),
            'url'            => self::attr($node, 'href'),
            'target_blank'   => self::hasTargetBlank($node),
            'style'          => self::extractVariant($classes,
                [
                    'secondary',
                    'tertiary',
                    'tertiary-no-outline',
                ]
            ),
            'size'           => self::extractVariant($classes, ['sm', 'lg']),
            'fullwidth'      => self::hasClass($classes, 'fr-btn--full-width'),
            'disabled'       => self::isDisabled($node),
            'icon'           => self::extractIcon($classes),
            'icon_position'  => self::extractButtonIconPosition($classes),
            'aria_label'     => self::attr($node, 'aria-label'),
        ];
    }


    /**
     * Parse du composant Mise en Avant
     *
     * @param DOMElement $node Le noeud DOM de la mise en avant
     * @param DOMXPath $xpath L'objet XPath
     * @return array Les données de la mise en avant
     */
     private static function parseCallout(DOMElement $node, DOMXPath $xpath): array {
    
        $classes = self::getClasses($node);
        $titleNode = $xpath->query('.//*[contains(@class,"fr-callout__title")]', $node)->item(0);
        $contentNode = $xpath->query('.//*[contains(@class,"fr-callout__text")]', $node)->item(0);
        $buttonNode = $xpath->query('.//*[contains(@class,"fr-btn")]', $node)->item(0);
        $accent = '';
    
        foreach ($classes as $class) {
            if (str_starts_with($class, 'fr-callout--')) {
                $accent = str_replace('fr-callout--', '', $class);
    
                break;
            }
        }
    
        $icon = '';
    
        foreach ($classes as $class) {
            if (str_starts_with($class, 'fr-icon-')) {
                $icon = $class;
                break;
            }
        }
    
        $titleTag = 'h3';
    
        if ($titleNode instanceof DOMElement) {
            $titleTag = strtolower($titleNode->tagName);
        }
    
        return [
            'component' => 'callout',
            'content' => $contentNode
                ? trim($contentNode->textContent)
                : '',
            'has_title' => $titleNode
                ? '1'
                : '0',
            'title' => $titleNode
                ? trim($titleNode->textContent)
                : '',
            'title_tag' => $titleTag,
            'accent' => $accent,
            'has_icon' => $icon
                ? '1'
                : '0',
            'icon' => $icon,
            'has_button' => $buttonNode
            ? '1'
            : '0',
            'button_label' => $buttonNode
                ? trim($buttonNode->textContent)
                : '',
            'button_url' => ($buttonNode instanceof DOMElement && strtolower($buttonNode->tagName) === 'a')
                ? $buttonNode->getAttribute('href')
                : ''
        ];
    }

    /**
     * Parse du composant Mise en Exergue
     *
     * @param DOMElement $node Le noeud DOM de la mise en exergue
     * @param DOMXPath $xpath L'objet XPath
     * @return array Les données de la mise en exergue
     */
     private static function parseHighlight(DOMElement $node, DOMXPath $xpath): array {
    
        $classes = self::getClasses($node);
        $accent = '';
    
        foreach ($classes as $class) {
            if (str_starts_with($class, 'fr-highlight--') && !in_array(
                    $class,
                    [
                        'fr-highlight--sm',
                        'fr-highlight--lg'
                    ],
                    true
                )
            ) {
                $accent = str_replace('fr-highlight--', '', $class);
    
                break;
            }
        }
    
        $size = 'md';
    
        if (in_array('fr-highlight--sm', $classes, true)) {
            $size = 'sm';
        }
    
        if (in_array('fr-highlight--lg', $classes, true)) {
            $size = 'lg';
        }
    
        return [
            'component' => 'highlight',
            'content' => trim($node->textContent),
            'accent' => $accent,
            'size' => $size
        ];
    }

    /**
     * Parse du composant Citation
     *
     * @param DOMElement $node Le noeud DOM de la citation
     * @param DOMXPath $xpath L'objet XPath
     * @return array Les données de la citation
     */
    private static function parseCitation(DOMElement $node, DOMXPath $xpath): array {

        $contentNode = $xpath->query('.//blockquote/p', $node)->item(0);
        $authorNode = $xpath->query('.//*[contains(@class, "fr-quote__author")]', $node)->item(0);
        $sourceNode = $xpath->query('.//*[contains(@class, "fr-quote__source")]/li', $node)->item(0);
        $imageNode = $xpath->query('.//*[contains(@class, "fr-quote__image")]//img', $node)->item(0);
        $classes = self::getClasses($node);
        $size = in_array('fr-quote--lg', $classes, true)
            ? 'lg'
            : 'xl';
        $accent = '';
        
        foreach ($classes as $class) {
            if (str_starts_with($class, 'fr-quote--') && $class !== 'fr-quote--lg') {
                $accent = str_replace('fr-quote--', '', $class);
        
                break;
            }
        }

        return [
            'component' => 'citation',
            'content' => $contentNode
                ? trim($contentNode->textContent)
                : '',
            'author' => $authorNode
                ? trim($authorNode->textContent)
                : '',
            'source' => $sourceNode
                ? trim($sourceNode->textContent)
                : '',
            'hasImage' => $imageNode instanceof DOMElement
                ? '1'
                : '0',
            'image_url' => $imageNode instanceof DOMElement
                ? $imageNode->getAttribute('src')
                : '',
            'image_alt' => $imageNode instanceof DOMElement
                ? $imageNode->getAttribute('alt')
                : '',
            'size' => $size,
            'accent' => $accent
        ];
    }

    /**
     * Parse du composant Notice
     *
     * @param DOMElement $node Le noeud DOM de la notice
     * @param DOMXPath $xpath L'objet XPath
     * @return array Les données de la notice
     */
    private static function parseNotice(DOMElement $node, DOMXPath $xpath): array {
        
        $classes = self::getClasses($node);
        $titleNode = $xpath->query('.//*[contains(@class, "fr-notice__title")]', $node)->item(0);
        $descNode = $xpath->query('.//*[contains(@class, "fr-notice__desc")]', $node)->item(0);
        $linkNode = $xpath->query('.//*[contains(@class, "fr-notice__link")]', $node)->item(0);
        $wrapperNode = $titleNode?->parentNode;
        $tag = 'p';
    
        if ($wrapperNode instanceof DOMElement) {
            $tag = strtolower($wrapperNode->tagName);
        }
    
        return [
            'component' => 'notice',
            'title' => $titleNode
                ? trim($titleNode->textContent)
                : '',
            'tag' => $tag,
            'type' => self::extractVariant(
                $classes,
                [
                    'info',
                    'warning',
                    'alert',
                    'weather-orange',
                    'weather-red',
                    'weather-purple',
                    'cyberattack',
                    'attack',
                    'witness',
                    'kidnapping'
                ],
                'fr-notice--',
                'info'
            ),
            'role_notice' => $node->getAttribute('role') === 'notice'
                ? '1'
                : '0',
            'icon' => self::extractIcon($classes),
            'hasDescription' => $descNode instanceof DOMElement
                ? '1'
                : '0',
            'content' => $descNode
                ? trim($descNode->textContent)
                : '',
            'hasLink' => $linkNode instanceof DOMElement
                ? '1'
                : '0',
            'link_label' => $linkNode
                ? trim($linkNode->textContent)
                : '',
            'link_url' => $linkNode instanceof DOMElement
                ? $linkNode->getAttribute('href')
                : '',
            'link_title' => $linkNode instanceof DOMElement
                ? $linkNode->getAttribute('title')
                : '',
            'blank' => ($linkNode instanceof DOMElement && $linkNode->getAttribute('target') === '_blank')
                ? '1'
                : '0',
            'closable' => in_array('fr-notice--closable', $classes, true)
                ? '1'
                : '0'
        ];
    }

    /**
     * Parse un composant Infobulle (Tooltip)
     *
     * @param DOMElement $node Le noeud DOM de l'infobulle
     * @param DOMXPath $xpath L'objet XPath
     * @return array Les données de l'infobulle
     */
    private static function parseTooltip(DOMElement $node, DOMXPath $xpath): array {

        $triggerNode = $xpath->query('.//button | .//a', $node)->item(0);

        $tooltipNode = $xpath->query('.//*[contains(@class, "fr-tooltip")]', $node)->item(0);
        $classes = $triggerNode instanceof DOMElement ? self::getClasses($triggerNode) : [];
        $support = 'button';

        if ($triggerNode instanceof DOMElement && strtolower($triggerNode->tagName) === 'a') {
            $support = 'link';
        }

        $trigger = 'hover';

        if ($support === 'button' && in_array('fr-btn--tooltip', $classes, true)) {
            $trigger = 'click';
        }

        $label = $triggerNode instanceof DOMElement ? trim($triggerNode->textContent) : '';

        return [
            'component' => 'tooltip',
            'trigger' => $trigger,
            'support' => $support,
            'label' => $label,
            'url' => ($support === 'link' && $triggerNode instanceof DOMElement)
                ? $triggerNode->getAttribute('href')
                : '',
            'content' => $tooltipNode instanceof DOMElement
                ? trim($tooltipNode->textContent)
                : ''
        ];
    }

    /**
     * Parse du composant Tableau
     *
     * @param DOMElement $node Le noeud DOM du tableau
     * @param DOMXPath $xpath L'objet XPath
     * @return array|null Les données du tableau ou null si erreur
     */
    private static function parseTable(DOMElement $node, DOMXPath $xpath): ?array {
        $classes = self::getClasses($node);
    
        $tableNode = $xpath->query('.//table')->item(0);
        if (!$tableNode instanceof DOMElement) {
            return null;
        }

        // Calcul dynamique des lignes (count des <tr>)
        $rowsNodes = $xpath->query('.//tbody/tr', $tableNode);
        $rowsCount = $rowsNodes->length > 0 ? $rowsNodes->length : $xpath->query('.//tr', $tableNode)->length;

        // Calcul dynamique des colonnes (count des <th> ou <td> dans le premier <tr>)
        $firstRow = $xpath->query('.//tr', $tableNode)->item(0);
        $colsCount = $firstRow ? $xpath->query('./th | ./td', $firstRow)->length : 4;
        $captionNode = $xpath->query('.//caption')->item(0);
        
        // Extraction propre du titre et de la description (captionDetail)
        $caption = '';
        $captionDetail = '';
        
        if ($captionNode) {
            // Si une description existe dans un <span class="fr-text--regular">, on l'isole
            $detailNode = $xpath->query('.//span[contains(@class, "fr-text--regular")]', $captionNode)->item(0);
            if ($detailNode) {
                $captionDetail = trim($detailNode->textContent);
                // Le titre principal correspond au texte de la caption moins celui du span
                $caption = trim(str_replace($detailNode->textContent, '', $captionNode->textContent));
            } else {
                $caption = trim($captionNode->textContent);
            }
        }
        
        // Détection des classes sur la balise caption
        $noCaption = in_array('fr-table--no-caption', $classes, true);
        $captionBottom = in_array('fr-table--caption-bottom', $classes, true);
        $bordered = in_array('fr-table--bordered', $classes, true);
        $noScroll = in_array('fr-table--no-scroll', $classes, true);
        $multiline = in_array('fr-table--multiline', $classes, true);
        $allowedSizes = ['sm', 'lg'];

        foreach ($allowedSizes as $candidate) {
            if (in_array('fr-table--' . $candidate, $classes, true)) {
                $size = $candidate;
                break;
            }
        }
    
        return [
            'component'     => 'table',
            'rows'          => $rowsCount,
            'cols'          => $colsCount,
            'caption'       => $caption,
            'captionDetail' => $captionDetail,
            'noCaption'     => $noCaption ? '1' : '0',
            'captionBottom' => $captionBottom ? '1' : '0',
            'bordered'      => $bordered ? '1' : '0',
            'noScroll'      => $noScroll ? '1' : '0',
            'multiline'     => $multiline ? '1' : '0',
            'size'          => $size
        ];
    }

    /**
     * Parse du composant Lien de Téléchargement
     *
     * @param DOMElement $node Le noeud DOM du téléchargement
     * @param DOMXPath $xpath L'objet XPath
     * @return array Les données du téléchargement
     */
    private static function parseDownload(DOMElement $node, DOMXPath $xpath): array {
    
        $classes = self::getClasses($node);
        $size = 'md';

        if (in_array('fr-link--sm', $classes, true)) {
            $size = 'sm';
        }

        if (in_array('fr-link--lg', $classes, true)) {
            $size = 'lg';
        }

        return [
            'component' => 'download', 'label' => trim($node->textContent),
            'href' => $node->getAttribute('href'),
            'disabled' => ($node->getAttribute('aria-disabled') === 'true')
                ? '1'
                : '0',
            'size' => $size
        ];
    }

    /**
     * Parse du composant Onglets
     *
     * @param DOMElement $node Le noeud DOM des onglets
     * @param DOMXPath $xpath L'objet XPath
     * @return array Les données des onglets
     */
    private static function parseTabs(DOMElement $node,DOMXPath $xpath): array {
    
        $tabs = [];
        $buttons = $xpath->query('.//*[contains(@class,"fr-tabs__tab")]', $node);
    
        foreach ($buttons as $index => $button) {
            $label = trim($button->textContent);
            $panel = $xpath->query('.//*[contains(@class,"fr-tabs__panel")]', $node)->item($index);
            $tabs[] = [
                'label' => $label,
                'content' => $panel
                    ? self::innerHtml($panel)
                    : ''
            ];
        }
    
        return [
            'component' => 'tabs',
            'has_icon' => strpos($buttons->item(0)?->getAttribute('class') ?? '', 'fr-tabs__tab--icon-left') !== false
                    ? '1'
                    : '0',
            'icon' =>
                self::extractIcon(
                    self::getClasses(
                        $buttons->item(0)
                    )
                ),
            'tabs' => $tabs
        ];
    }

    /**
     * Parse du composant Accordéon
     *
     * @param DOMElement $node Le noeud DOM de l'accordéon
     * @param DOMXPath $xpath L'objet XPath
     * @return array Les données de l'accordéon
     */
    private static function parseAccordion(DOMElement $node, DOMXPath $xpath): array {
    
        $grouped = $xpath->query('.//*[contains(@class,"fr-accordions-group")]', $node)->length > 0;
        $sections = $xpath->query('.//*[contains(@class,"fr-accordion")]', $node);
        $accordions = [];

        foreach ($sections as $section) {
            $button = $xpath->query('.//*[contains(@class,"fr-accordion__btn")]', $section)->item(0);
            $collapse = $xpath->query('.//*[contains(@class,"fr-collapse")]', $section)->item(0);
            $accordions[] = [
                'id' => $collapse?->getAttribute('id') ?? '',
                'label' => $button
                    ? trim($button->textContent)
                    : '',
                'isExpanded' => $button?->getAttribute('aria-expanded') === 'true'
                        ? '1'
                        : '0',
                'content' => $collapse instanceof DOMElement
                        ? self::innerHtml($collapse)
                        : ''
            ];
        }
    
        return [
            'component' => 'accordion',
            'grouped' => $grouped ? '1' : '0',
            'accordions' => $accordions
        ];
    }

    /**
     * Parse du composant Carte
     *
     * @param DOMElement $node Le noeud DOM de la carte
     * @param DOMXPath $xpath L'objet XPath
     * @return array Les données de la carte
     */
    private static function parseCard(DOMElement $node, DOMXPath $xpath): array {
    
        $cards = [];
    
        $cardNodes = $xpath->query('.//*[contains(@class,"fr-card")]', $node);
    
        foreach ($cardNodes as $cardNode) {
            $titleNode = $xpath->query('.//*[contains(@class,"fr-card__title")]', $cardNode)->item(0);
            $descNode = $xpath->query('.//*[contains(@class,"fr-card__desc")]', $cardNode)->item(0);
            $linkNode = $xpath->query('.//a', $titleNode)->item(0);
            $cards[] = [
                'title' => trim($titleNode?->textContent ?? ''),
                'description' => trim($descNode?->textContent ?? ''),
                'url' => $linkNode?->getAttribute('href') ?? ''
            ];
        }
    
        return [
            'component' => 'card',
            'cards_count' => count($cards),
            'cards' => $cards
        ];
    }

    /**
     * Parse du composant Tuile
     *
     * @param DOMElement $node Le noeud DOM de la tuile
     * @param DOMXPath $xpath L'objet XPath
     * @return array Les données de la tuile
     */
    private static function parseTile(DOMElement $node, DOMXPath $xpath): array {
    
        $tiles = [];
    
        $tileNodes = $xpath->query('.//*[contains(@class,"fr-tile")]', $node);
    
        foreach ($tileNodes as $tileNode) {
            $titleNode = $xpath->query('.//*[contains(@class,"fr-tile__title")]', $tileNode)->item(0);
            $descNode = $xpath->query('.//*[contains(@class,"fr-tile__desc")]', $tileNode)->item(0);
            $detailNode = $xpath->query('.//*[contains(@class,"fr-tile__detail")]', $tileNode)->item(0);
            $linkNode = $xpath->query('.//a', $titleNode)->item(0);
            $isDownload = false;
            $downloadUrl = '';

            if ($linkNode instanceof DOMElement) {
                $isDownload = $linkNode->hasAttribute('download');
                $downloadUrl = $linkNode->getAttribute('href');
            }
            $tiles[] = [
                'title' => trim($titleNode?->textContent ?? ''),
                'description' => trim($descNode?->textContent ?? ''),
                'detail' => trim($detailNode?->textContent ?? ''),
                'url' => $linkNode?->getAttribute('href') ?? '',
                'download' => $isDownload
                        ? '1'
                        : '0',
                'download_url' => $isDownload
                        ? $downloadUrl
                        : ''
            ];
        }
    
        return [
            'component' => 'tile',
            'tiles_count' => count($tiles),
            'tiles' => $tiles
        ];
    }

    /**
     * Parse du composant Vidéo
     *
     * @param DOMElement $node Le noeud DOM de la vidéo
     * @param DOMXPath $xpath L'objet XPath
     * @return array Les données de la vidéo
     */
    private static function parseVideo(DOMElement $node, DOMXPath $xpath): array {
    
        $iframe = $xpath->query('.//iframe', $node)->item(0);
    
        $content = $xpath->query('.//*[contains(@class,"fr-modal__content")]', $node)->item(0);

        $style = $iframe?->getAttribute('style') ?? '';

        $width = '';
        
        if (preg_match('/max-width\s*:\s*(\d+)px/i', $style, $matches)) {
            $width = $matches[1];
        }
    
        return [
            'component' => 'video',
            'title' => $iframe?->getAttribute('title') ?? '',
            'url' => $iframe?->getAttribute('src') ?? '',
            'width' => $width,
            'custom_size' => $width !== '' ? '1' : '0',
            'ratio' => str_contains($iframe?->getAttribute('class') ?? '', 'fr-responsive-vid--4x3') ? '4x3' : '16x9',
            'transcription' => $content instanceof DOMElement
                ? self::innerHtml($content)
                : ''
        ];
    }

    /**
     * Création d'un DOMDocument à partir de HTML
     *
     * @param string $html Le HTML à parser
     * @return array Un tableau contenant le DOMDocument et le DOMXPath
     */
    private static function createDom(string $html): array {
        $dom = new DOMDocument();

        libxml_use_internal_errors(true);


        $dom->loadHTML(
            mb_encode_numericentity(
                self::wrapHtml($html),
                [0x80, 0x10FFFF, 0, ~0],
                'UTF-8'
            )
        );

        libxml_clear_errors();

        return [$dom, new DOMXPath($dom)];
    }

    /**
     * Extraction du HTML interne d'un élément
     *
     * @param DOMElement $element L'élément DOM
     * @return string Le HTML interne
     */
    private static function innerHtml(DOMElement $element): string {
        $html = '';
    
        foreach ($element->childNodes as $child) {
            $html .= $element->ownerDocument
                ->saveHTML($child);
        }
    
        return trim($html);
    }

    /**
     * Encapsulation du HTML dans une structure HTML valide
     *
     * @param string $html Le HTML à encapsuler
     * @return string Le HTML encapsulé
     */
    private static function wrapHtml(string $html): string
    {
        return <<<HTML
        <!DOCTYPE html>
        <html>
        <body>
        {$html}
        </body>
        </html>
        HTML;
    }

    /**
     * Extraction des propriétés stockées dans data-dsfr-props
     *
     * @param DOMElement $node L'élément DOM
     * @return array|null Les données extraites ou null
     */
    private static function extractStoredProps(DOMElement $node): ?array {
        if (!$node->hasAttribute('data-dsfr-props')) {
            return null;
        }
    
        $json = urldecode($node->getAttribute('data-dsfr-props'));
    
        $data = json_decode($json, true);
    
        if (!is_array($data)) {
            return null;
        }
    
        if (!isset($data['component']) && $node->hasAttribute('data-dsfr-component')) {
            $data['component'] = $node->getAttribute('data-dsfr-component');
        }
    
        return $data;
    }

    /**
     * Extraction des classes CSS d'un élément
     *
     * @param DOMElement $node L'élément DOM
     * @return array Les classes CSS
     */
    private static function getClasses(DOMElement $node): array {
        $classAttr = trim($node->getAttribute('class'));

        if ($classAttr === '') {
            return [];
        }

        return preg_split('/\s+/', $classAttr);
    }

    /**
     * Vérifie si une classe est présente
     *
     * @param array $classes Les classes CSS
     * @param string $class La classe à vérifier
     * @return string '1' si présente, '0' sinon
     */
    private static function hasClass(array $classes, string $class): string {
        return in_array($class, $classes, true)
            ? '1'
            : '0';
    }

    /**
     * Extraction d'une variante à partir des classes CSS
     *
     * @param array $classes Les classes CSS
     * @param array $variants Les variantes possibles
     * @param string $prefix Le préfixe des classes
     * @param string $default La valeur par défaut
     * @return string La variante trouvée ou la valeur par défaut
     */
    private static function extractVariant(array $classes, array $variants, string $prefix = 'fr-btn--', string $default = ''): string {
        foreach ($variants as $variant) {
            if (in_array($prefix . $variant, $classes, true)) {
                return $variant;
            }
        }

        return $default;
    }

    /**
     * Extraction d'une icône à partir des classes CSS
     *
     * @param array $classes Les classes CSS
     * @return string La classe d'icône ou une chaîne vide
     */
    private static function extractIcon(array $classes): string {
        foreach ($classes as $class) {
            if (str_starts_with($class, 'fr-icon-')) {
                return $class;
            }
        }
        return '';
    }

    /**
     * Extraction de la position de l'icône d'un bouton
     *
     * @param array $classes Les classes CSS
     * @return string La position de l'icône
     */
    private static function extractButtonIconPosition(array $classes): string {
        if (in_array('fr-btn--icon-right', $classes, true)) {
            return 'right';
        }

        if (in_array('fr-btn--icon', $classes, true)) {
            return 'icon_only';
        }

        return 'left';
    }

    /**
     * Vérifie si un bouton a target="_blank"
     *
     * @param DOMElement $node L'élément DOM
     * @return string '1' si présent, '0' sinon
     */
    private static function hasTargetBlank(DOMElement $node): string {
        return ($node->getAttribute('target') === '_blank')
            ? '1'
            : '0';
    }

    /**
     * Vérifie si un élément est désactivé
     *
     * @param DOMElement $node L'élément DOM
     * @return string '1' si désactivé, '0' sinon
     */
    private static function isDisabled(DOMElement $node): string {
        if ($node->hasAttribute('disabled')) {
            return '1';
        }

        if ($node->getAttribute('aria-disabled') === 'true') {
            return '1';
        }

        return '0';
    }

    /**
     * Récupère l'attribut d'un élément
     *
     * @param DOMElement $node L'élément DOM
     * @param string $name Le nom de l'attribut
     * @param string $default La valeur par défaut
     * @return string La valeur de l'attribut ou la valeur par défaut
     */
    private static function attr(DOMElement $node, string $name, string $default = ''): string {
        return $node->hasAttribute($name)
            ? $node->getAttribute($name)
            : $default;
    }

    /**
     * Récupère le contenu texte d'un élément
     *
     * @param DOMElement $node L'élément DOM
     * @return string Le texte de l'élément
     */
    private static function text(DOMElement $node): string {
        return trim($node->textContent);
    }
}