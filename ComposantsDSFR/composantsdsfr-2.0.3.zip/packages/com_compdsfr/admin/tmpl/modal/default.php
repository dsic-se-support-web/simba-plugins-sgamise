<?php 
defined('_JEXEC') or die; 

use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormFactoryInterface;

$this->document->setHtml5(true);

$this->document->addScriptOptions('com_dsfr', [
    'root' => Uri::root()
]);

$wa = $this->document->getWebAssetManager();

$templatePath = Uri::root(true) . '/templates/cassiopeia_dsfr';

$wa->registerScript(
    'com_compdsfr.script',
    'media/com_compdsfr/js/script.js',
    [],
    [
        'type'  => 'module',
        'defer' => true
    ]
);

$wa->useScript('com_compdsfr.script');

$this->document->addStyleSheet($templatePath . '/dsfr/dsfr.min.css');
$this->document->addStyleSheet($templatePath . '/dsfr/core/core.min.css');
$this->document->addStyleSheet($templatePath . '/dsfr/utility/utility.min.css');
$this->document->addStyleSheet($templatePath . '/user.css');

$wa->registerStyle('com_compdsfr.style', 'media/com_compdsfr/css/style.css');
$wa->useStyle('com_compdsfr.style');

$this->document->addScriptOptions('dsfr_paths', [
    'css' => [
        $templatePath . '/dsfr/dsfr.min.css',
        $templatePath . '/dsfr/core/core.min.css',
        $templatePath . '/dsfr/utility/utility.min.css',
        $templatePath . '/dsfr/DSFRChart/DSFRChart.css',
        $templatePath . '/user.css'
    ],
    'js' => [
        $templatePath . '/dsfr/dsfr.module.min.js',
        $templatePath . '/dsfr/core/core.module.min.js',
        $templatePath . '/dsfr/DSFRChart/DSFRChart.js'
    ]
]);

$formsPath = JPATH_SITE . '/media/com_compdsfr/templates';

if (is_dir($formsPath)) { 
    $files = glob($formsPath . '/editor.xml'); 
    $file = $files[0];
    $formFactory = Factory::getContainer()->get(FormFactoryInterface::class);
                
    $key = 'default';

    $form = $formFactory->createForm($key, ['control' => $key]);
    
    $form->loadFile($file);
    
} 
?> 

<div class="modal-layout"> 
    <div id="template-editor" class='d-none'>
        <?php echo $form->renderFieldset('items')?>
    </div> 
    <div class="sidebar"> 
        <div class="sidebar-header">
            <button type="button" id="btn-back" class="fr-btn fr-btn--tertiary-no-outline fr-icon-arrow-left-line fr-btn--icon-left d-none">
                Retour accueil
            </button> 
            <h1 class="h6 mb-0 text-uppercase fw-bold text-muted">Composants</h1> 
        </div> 
        <div class="list-group list-group-flush" id="component-menu"></div> 
    </div> 

    <div class="main-content">
        <!-- Écran d'accueil -->
        <div id="empty-state" class="empty-state">
            <div class="fr-callout">
                <h2 class="fr-callout__title">
                    Bibliothèque de composants DSFR
                </h2>

                <p>
                    Sélectionnez un composant dans le menu latéral
                    pour accéder à ses paramètres.
                </p>
            </div>

            <div class="empty-state-help">
                Vous pourrez ensuite :
                <ul>
                    <li>Configurer ses options</li>
                    <li>Prévisualiser le rendu DSFR</li>
                    <li>Insérer automatiquement le composant dans l'article</li>
                </ul>
            </div>

            <div class="empty-state-edit-list mt-4">
                <h3 class="m-0 mb-1">Modification des composants</h3>
                <p class="text-muted m-0 mb-1">Voici les composants présents dans votre article, dans l'ordre où ils apparaissent. Cliquez sur un composant pour le modifier :</p>
                <div class="fr-alert fr-alert--warning mb-1 d-none" id='msg-confirm-delete-composant'>
                    <h3 class="fr-alert__title">Attention !</h3>
                    <p>Êtes-vous sûr de vouloir supprimer le composant : <span id='composant-name'></span> ? Il sera supprimé définitivement.</p>
                    <div class="text-end">
                        <button type="button" class="fr-btn fr-icon-close-circle-fill fr-btn--icon-left" id="btn-cancel-composant">
                            Annuler
                        </button>
                        <button type="button" class="fr-btn fr-icon-delete-fill fr-btn--icon-left fr-btn--secondary" id="btn-delete-composant">
                            Confirmer
                        </button>
                    </div>
                </div>
                <ul id="list-composant">
                </ul>
            </div>


        </div>

        <!-- Formulaire -->
        <div id="form-wrapper" class="d-none">
            <div id="form-header" class="dsfr-form-header">
                <h2 id="form-title" class="dsfr-form-title">
                </h2>

                <p id="form-summary" class="dsfr-form-summary"></p>
        </div>

        <div id="form-guidelines" class="dsfr-guidelines d-none">

            <button type="button" id="guidelines-toggle" class="dsfr-guidelines-toggle">

                <span>
                    Usage et recommandations
                </span>

                <span class="dsfr-guidelines-icon">
                    ▾
                </span>
            </button>

            <div id="form-description"
                class="dsfr-guidelines-content">
            </div>

        </div>

            <div id="dynamic-form-container"></div>

            <div id="form-actions" class="mt-4 d-none text-end border-top pt-3">
                <button type="button" class="fr-btn" onclick="genererEtInserer()">
                    <span class="icon-check fr-mr-2v"></span>
                    Insérer dans l'article
                </button>

                <button type="button" id="btn-preview" class="fr-btn" onclick="preview()">
                    <span class="icon-eye fr-mr-2v"></span>
                    Générer l'aperçu
                </button>
            </div>

            <div class="alert alert-warning dsfr-form-notice">
                <strong>Important !</strong> La prévisulisation ci-dessous est indicative et l'affichage après insertion dans l'éditeur d'article peut différer de la prévisualisation. Certaines actions visuelles ne sont pas actives.
                Exemple : ouverture et fermeture des accordéons ou onglets.<br/><br/>
                Pour voir le rendu réel avec toutes les fonctionnalités, enregistrez votre article et prévisualisez-le.
            </div>

            <div id="preview-container"
                style="margin-top:20px; border:1px dashed #ccc; padding:10px; min-height:200px;">
            </div>

        </div>
    </div>
</div>
