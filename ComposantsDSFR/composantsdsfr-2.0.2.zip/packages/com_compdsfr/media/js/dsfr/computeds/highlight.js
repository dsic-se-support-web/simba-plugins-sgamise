import { escapeHtml } from '../../utils/html.js';

/**
 * Calcule les valeurs pour le composant Highlight
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeHighlightValues(values) {

    const classes = ['fr-highlight'];

    if (values.accent) {
        classes.push(`fr-highlight--${values.accent}`);
    }

    let textClass = '';

    switch (values.size) {

        case 'sm':
            textClass = 'fr-text--sm';
            break;

        case 'lg':
            textClass = 'fr-text--lg';
            break;

        default:
            textClass = '';
            break;
    }

    const content = unwrapEditorContent(values.content || '');

    values.content = content;

    values.highlight_html = `
        <div class="${classes.join(' ')}">
            <p${textClass ? ` class="${textClass}"` : ''}>${content}</p>
        </div>
    `.trim();

    return values;
}

/**
 * Retire uniquement le <p> racine ajouté par TinyMCE.
 *
 * Les balises HTML internes sont intégralement conservées.
 *
 * @param {string} html
 * @return {string}
 */
function unwrapEditorContent(html = '') {

    const container = document.createElement('div');

    container.innerHTML = String(html).trim();

    const children = Array.from(container.children);

    // TinyMCE renvoie généralement un unique <p> autour du contenu.
    if (
        children.length === 1 &&
        children[0].tagName.toLowerCase() === 'p'
    ) {
        return children[0].innerHTML.trim();
    }

    return container.innerHTML.trim();
}