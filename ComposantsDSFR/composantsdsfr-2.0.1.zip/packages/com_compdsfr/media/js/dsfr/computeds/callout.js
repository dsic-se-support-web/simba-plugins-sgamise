import {escapeHtml, escapeAttribute} from '../../utils/html.js';

/**
 * Calcule les valeurs pour le composant Callout
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeCalloutValues(values) {

    const classes = ['fr-callout'];

    if (values.accent) {
        classes.push(`fr-callout--${values.accent}`);
    }

    if (values.has_icon === '1') {
        classes.push(values.icon || 'fr-icon-checkbox-circle-line');
    }

    let titleHtml = '';

    if (values.has_title === '1' && values.title) {

        const allowedTags = [
            'h2',
            'h3',
            'h4',
            'h5',
            'h6',
            'p'
        ];

        const tag = allowedTags.includes(values.title_tag)
            ? values.title_tag
            : 'h3';

        titleHtml = `
            <${tag} class="fr-callout__title">
                ${escapeHtml(values.title)}
            </${tag}>
        `;
    }

    let buttonHtml = '';

    if (values.has_button === '1' && values.button_label) {

        buttonHtml = `
            <a href="${escapeAttribute(values.button_url || '#')}" class="fr-btn">
                ${escapeHtml(values.button_label)}
            </a>
        `;
    }

    values.callout_html = `
        <div class="${classes.join(' ')}">

            ${titleHtml}

            <p class="fr-callout__text">
                ${(values.content || '')}
            </p>

            ${buttonHtml}

        </div>
    `;

    return values;
}