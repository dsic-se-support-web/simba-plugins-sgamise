import {escapeHtml} from '../../utils/html.js';

/**
 * Calcule les valeurs pour le composant Alert
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeAlertValues(values) {

    const classes = ['fr-alert'];

    classes.push(computeTypeClass(values.type));

    if (values.size === 'sm') {
        classes.push('fr-alert--sm');
    }

    if (values.closable === '1') {
        classes.push('fr-alert--closable');
    }

    const closeButton = values.closable === '1'
        ? `
            <button type="button" class="fr-btn--close fr-btn" title="Masquer le message" onClick="const alert = this.parentNode; alert.parentNode.removeChild(alert)">
                Masquer le message
            </button>
        `
        : '';

    const titleHtml = values.title?.trim()
        ? `
            <p class="fr-alert__title">
                ${escapeHtml(values.title)}
            </p>
        `
        : '';

    const contentHtml = values.content?.trim()
        ? `
            <p>
                ${(values.content)}
            </p>
        `
        : '';

    values.alert_html = `
        <div class="${classes.join(' ')}">
            ${titleHtml}
            ${contentHtml}
            ${closeButton}
        </div>
    `;

    return values;
}

/**
 * Calcule la classe de type pour une alerte
 *
 * @param {string} type Le type d'alerte
 * @return {string} La classe CSS correspondante
 */
function computeTypeClass(type) {

    const map = {
        info: 'fr-alert--info',
        success: 'fr-alert--success',
        error: 'fr-alert--error',
        warning: 'fr-alert--warning'
    };

    return map[type] || 'fr-alert--info';
}