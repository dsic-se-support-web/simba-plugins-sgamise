<?php

defined('_JEXEC') or die;

use Joomla\CMS\Extension\ExtensionHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;

class pkg_comdsfrInstallerScript
{
    /**
     * Exécuté après l'installation ou la mise à jour du package.
     */
    public function postflight(
        string $type,
        InstallerAdapter $adapter
    ): bool {
        $this->enablePlugin('comdsfr', 'editors-xtd');
        $this->enablePlugin('syscomdsfr', 'system');

        return true;
    }

    /**
     * Active un plugin Joomla.
     */
    private function enablePlugin(
        string $element,
        string $folder
    ): void {
        $extension = ExtensionHelper::getExtensionRecord(
            $element,
            'plugin',
            0,
            $folder
        );

        if (!$extension) {
            Factory::getApplication()->enqueueMessage(
                sprintf(
                    'Le plugin %s (%s) n\'a pas été trouvé dans #__extensions.',
                    $element,
                    $folder
                ),
                'warning'
            );

            return;
        }

        if ((int) $extension->enabled === 1) {
            return;
        }

        $db = Factory::getContainer()
            ->get(\Joomla\Database\DatabaseInterface::class);

        $query = $db->getQuery(true)
            ->update($db->quoteName('#__extensions'))
            ->set($db->quoteName('enabled') . ' = 1')
            ->where(
                $db->quoteName('extension_id') .
                ' = ' .
                (int) $extension->extension_id
            );

        $db->setQuery($query);
        $db->execute();
    }
}
