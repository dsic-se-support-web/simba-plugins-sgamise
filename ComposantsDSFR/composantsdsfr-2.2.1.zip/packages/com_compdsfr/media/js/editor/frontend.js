/**
 * Désactive l'édition des tableaux DSFR sur le front-office.
 *
 * L'attribut contenteditable reste volontairement présent
 * dans le HTML enregistré en base afin de permettre l'édition
 * dans TinyMCE.
 */
function disableDsfrTableEditing() {

    document
        .querySelectorAll('[data-dsfr-component="table"][contenteditable]')
        .forEach((element) => {
            element.removeAttribute('contenteditable');
        });
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', disableDsfrTableEditing);
} else {
    disableDsfrTableEditing();
}
