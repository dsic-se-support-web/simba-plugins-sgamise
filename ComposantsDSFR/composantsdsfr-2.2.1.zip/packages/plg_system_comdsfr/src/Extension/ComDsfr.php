<?php

declare(strict_types=1);
namespace Joomla\Plugin\System\ComDsfr\Extension;

use Joomla\CMS\Event\Application\BeforeCompileHeadEvent;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\SubscriberInterface;

final class ComDsfr extends CMSPlugin implements SubscriberInterface
{
    /**
     * Événements auxquels le plugin souscrit.
     */
    public static function getSubscribedEvents(): array
    {
        return [
            'onBeforeCompileHead' => 'onBeforeCompileHead',
        ];
    }

    /**
     * Charge les assets DSFR nécessaires au front-office.
     */
    public function onBeforeCompileHead(
        BeforeCompileHeadEvent $event
    ): void {

        $app = $event->getApplication();

        // Sécurité : uniquement le site public.
        if (!$app->isClient('site')) {
            return;
        }

        $document = $event->getDocument();

        $wa = $document->getWebAssetManager();

        $wa->registerAndUseScript(
            'com_compdsfr.frontend',
            'com_compdsfr/editor/frontend.js'
        );
        
    }
}
