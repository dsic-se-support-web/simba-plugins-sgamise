<?php

namespace Joomla\Component\CompDsfr\Administrator\View\Modalarticles;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\Database\DatabaseInterface;

class HtmlView extends BaseHtmlView
{
    public array $articles = [];

    public function display($tpl = null)
    {
        $db = Factory::getContainer()
            ->get(DatabaseInterface::class);

        $app = Factory::getApplication();

        $search = trim($app->input->getString('filter_search'));

        $orderCol = $app->input->getCmd('filter_order', 'a.title');

        $orderDir = $app->input->getCmd('filter_order_Dir', 'ASC');

        $allowedOrders = [
            'a.id',
            'a.title',
            'a.catid'
        ];

        if (!in_array($orderCol, $allowedOrders, true)) {
            $orderCol = 'a.title';
        }

        $orderDir = strtoupper($orderDir) === 'DESC'
                ? 'DESC'
                : 'ASC';

        $query = $db->getQuery(true)
            ->select([
                'a.id',
                'a.title',
                'a.catid',
                'a.language',
                'c.title AS category'
            ])
            ->join('LEFT', '#__categories c ON c.id = a.catid')
            ->from('#__content AS a')
            ->where('a.state = 1');

        if ($search !== '') {

            $query->where('a.title LIKE ' . $db->quote('%' . $search . '%'));
        }

        $query->order($orderCol . ' ' . $orderDir);

        $db->setQuery($query);

        $this->articles = $db->loadObjectList();
        $this->search = $search;
        $this->orderCol = $orderCol;
        $this->orderDir = $orderDir;

        parent::display($tpl);
    }
}