<?php

defined('_JEXEC') or die;

use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="/media/system/css/joomla-fontawesome.min.css">
<link rel="stylesheet" href="/media/vendor/bootstrap/css/bootstrap.min.css">
</head>

<body class="p-4">

<h2>Sélection d'un article</h2>

<form method="get" class="mb-4">
    <input type="hidden" name="option" value="com_compdsfr">

    <input type="hidden" name="view" value="modalarticles">

    <input type="hidden" name="tmpl" value="component">

    <div class="row">
        <div class="col-md-6">
            <input type="text" class="form-control" name="filter_search" placeholder="Rechercher un article..." value="<?= htmlspecialchars($this->search) ?>">
        </div>

        <div class="col-md-3">
            <select name="filter_order" class="form-select">
                <option value="a.title" <?= $this->orderCol === 'a.title' ? 'selected' : '' ?>>
                    Titre
                </option>

                <option value="a.id" <?= $this->orderCol === 'a.id' ? 'selected' : '' ?>>
                    ID
                </option>

                <option value="a.catid" <?= $this->orderCol === 'a.catid' ? 'selected' : '' ?>>
                    Catégorie
                </option>
            </select>
        </div>

        <div class="col-md-2">
            <select name="filter_order_Dir" class="form-select">
                <option value="ASC" <?= $this->orderDir === 'ASC' ? 'selected' : '' ?>>
                    Croissant
                </option>

                <option value="DESC" <?= $this->orderDir === 'DESC' ? 'selected' : '' ?>>
                    Décroissant
                </option>
            </select>
        </div>

        <div class="col-md-1">
            <button type="submit" class="btn btn-primary w-100">
                OK
            </button>
        </div>
    </div>

</form>

<table class="table table-striped">

<thead>
<tr>
    <th>
        <a href="?option=com_compdsfr&view=modalarticles&tmpl=component&filter_order=a.id&filter_order_Dir=<?= $this->orderDir === 'ASC' ? 'DESC' : 'ASC' ?>">
            ID
        </a>
    </th>

    <th>
        <a href="?option=com_compdsfr&view=modalarticles&tmpl=component&filter_order=a.title&filter_order_Dir=<?= $this->orderDir === 'ASC' ? 'DESC' : 'ASC' ?>">
            Titre
        </a>
    </th>

    <th>Catégorie</th>

    <th></th>
</tr>
</thead>

    <tbody>

    <?php foreach ($this->articles as $article) :

        $url = RouteHelper::getArticleRoute($article->id, $article->catid, $article->language);
    ?>

        <tr>
            <td>
                <?= (int) $article->id ?>
            </td>

            <td>
                <?= htmlspecialchars($article->title) ?>
            </td>

            <td>
                <?= htmlspecialchars($article->category) ?>
            </td>

            <td>
                <button class="btn btn-primary select-article" data-id="<?= (int) $article->id ?>" data-title="<?= htmlspecialchars($article->title) ?>" data-url="<?= htmlspecialchars($url) ?>">
                    Sélectionner
                </button>
            </td>
        </tr>

    <?php endforeach; ?>

    </tbody>

</table>

<script>
document.querySelectorAll('.select-article')
.forEach(button => {

    button.addEventListener('click', () => {

        window.opener.postMessage({
            messageType : 'comdsfr:article-select',
            id : button.dataset.id,
            title : button.dataset.title,
            url : button.dataset.url
        }, '*');

        window.close();
    });
});
</script>

</body>
</html>