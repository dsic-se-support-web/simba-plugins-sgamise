import { getFirstElement } from '../utils/dom.js';

export function injectDsfrAttributes(
    html,
    componentName,
    dsfrId
) {

    const first = getFirstElement(html);

    if (!first) {
        return html;
    }

    first.setAttribute(
        'data-dsfr-component',
        componentName
    );

    first.setAttribute(
        'data-dsfr-id',
        dsfrId
    );

    return first.outerHTML;
}

export function injectDsfrProps(
    html,
    componentName,
    values
) {
    const first = getFirstElement(html);

    if (!first) {
        return html;
    }

    first.setAttribute(
        'data-dsfr-props',
        encodeURIComponent(JSON.stringify({
            ...values,
            component: componentName
        }))
    );

    return first.outerHTML;
}