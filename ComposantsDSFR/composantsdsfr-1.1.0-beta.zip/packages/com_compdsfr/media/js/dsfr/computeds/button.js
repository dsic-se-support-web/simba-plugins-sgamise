export function computeButtonValues(values) {

    values.tag =
        values.url
            ? 'a'
            : 'button';

    values.href_attr =
        values.url
            ? `href="${values.url}"`
            : '';

    values.target_attr =
        values.target_blank === '1'
            ? 'target="_blank" rel="noopener"'
            : '';

    values.style_class =
        values.style
            ? `fr-btn--${values.style}`
            : '';

    values.size_class =
        values.size
            ? `fr-btn--${values.size}`
            : '';

    values.width_class =
        values.fullwidth === '1'
            ? 'fr-btn--full-width'
            : '';

    values.icon_class =
        values.icon || '';

    values.icon_position_class =
        computeIconPosition(values);

    values.disabled_attr =
        computeDisabled(values);

    values.label_content =
        values.icon_position === 'icon_only'
            ? '&nbsp;'
            : values.label;

    values.icon_class =
        values.icon || '';

    values.icon_class =
        values.icon?.trim() || '';

    values.aria_label_attr =
        computeAria(values);

    return values;
}

function computeIconPosition(values) {

    if (!values.icon) {
        return '';
    }

    switch (values.icon_position) {

        case 'right':
            return 'fr-btn--icon-right';

        case 'icon_only':
            return 'fr-btn--icon';

        default:
            return 'fr-btn--icon-left';
    }
}

function computeDisabled(values) {

    if (values.disabled !== '1') {
        return '';
    }

    if (values.url) {
        return 'aria-disabled="true" tabindex="-1"';
    }

    return 'disabled';
}

function computeAria(values) {

    if (values.icon_position !== 'icon_only') {
        return '';
    }

    return `aria-label="${
        values.aria_label || values.label
    }"`;
}