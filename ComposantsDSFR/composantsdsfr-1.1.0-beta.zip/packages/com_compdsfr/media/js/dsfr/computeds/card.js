export function computeCardValues(values) {

    const count = values.cards?.length || 1;

    let colClass = 'fr-col-12';

    if (count === 2) {
        colClass = 'fr-col-md-6';
    }

    if (count === 3) {
        colClass = 'fr-col-md-4';
    }

    if (count === 4) {
        colClass = 'fr-col-md-3';
    }

    const cardClasses = [];

    if (values.enlarge === '1') {
        cardClasses.push('fr-enlarge-link');
    }

    if (values.size !== 'md') {
        cardClasses.push(`fr-card--${values.size}`);
    }

    if (values.horizontal === '1') {
        cardClasses.push('fr-card--horizontal');
    }

    if (values.variant) {
        cardClasses.push(`fr-card--${values.variant}`);
    }

    values.cards_html = (values.cards || [])
            .map(card => buildCard(
                card,
                values,
                cardClasses.join(' '),
                colClass
            ))
            .join('');

    return values;
}

function buildCard(card, global, classes, colClass) {

    const titleTag = global.title_level || 'h3';

    const target =
        card.target_blank === '1'
            ? ' target="_blank" rel="noopener" '
            : '';

            let href = '#';

    if (
        card.link_type === 'article'
        && card.article_url
    ) {
        href = card.article_url;
    }
            
    if (card.link_type === 'url') {
        href = card.url || '#';
    }
            
    if (card.link_type === 'download') {
        href = card.download_url || '#';
    }

    const imageHtml =
        card.image_url
            ? `
            <div class="fr-card__header">
                <div class="fr-card__img">
                    <img class="fr-responsive-img" src="${card.image_url}" alt="${card.image_alt || ''}">
                </div>
            </div>`
            : '';

    const descriptionHtml = card.description
            ? `<p class="fr-card__desc">${card.description}</p>`
            : '';

    const detailHtml = card.detail
            ? `
            <div class="fr-card__end">
                <ul class="fr-card__detail">
                    <li>${card.detail}</li>
                </ul>
            </div>`
            : '';

    return `
    <div class="${colClass}">
        <div class="fr-card ${classes}">
            <div class="fr-card__body">
                <div class="fr-card__content">

                    <${titleTag} class="fr-card__title">
                        <a href="${href}" ${target}>
                            ${card.title || ''}
                        </a>
                    </${titleTag}>

                    ${descriptionHtml}

                    ${detailHtml}

                </div>
            </div>

            ${imageHtml}

        </div>
    </div>`;
}