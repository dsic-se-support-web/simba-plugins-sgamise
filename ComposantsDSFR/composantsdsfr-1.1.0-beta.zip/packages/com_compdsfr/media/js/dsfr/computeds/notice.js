export function computeNoticeValues(values) {

    values.type_class =
        values.type
            ? `fr-notice--${values.type}`
            : 'fr-notice--info';

    values.closable_class =
        values.closable === '1'
            ? 'fr-notice--closable'
            : '';

    values.role_attr =
        values.role_notice === '1'
            ? 'role="notice"'
            : '';

    values.icon_class =
        values.icon
            ? values.icon.trim()
            : '';

    values.description_html =
        values.hasDescription === '1'
        && values.content
            ? `
                <span class="fr-notice__desc">
                    ${values.content}
                </span>
            `
            : '';

        const isBlank =
            values.blank === '1';
        
        const targetAttr =
            isBlank
                ? 'target="_blank"'
                : '';
        
        const relAttr =
            isBlank
                ? 'rel="noopener external"'
                : '';
        
        const titleAttr =
            values.link_title?.trim()
                ? `title="${values.link_title}"`
                : '';
        
        values.link_html =
            values.hasLink === '1'
            && values.link_label
            && values.link_url
                ? `
                    <a
                        class="fr-notice__link"
                        href="${values.link_url}"
                        ${targetAttr}
                        ${relAttr}
                        ${titleAttr}>
                        ${values.link_label}
                    </a>
                `
                : '';

    values.close_button =
        values.closable === '1'
            ? `
                <button
                    class="fr-btn--close fr-btn"
                    title="Masquer le bandeau"
                    type="button">
                    Masquer le bandeau
                </button>
            `
            : '';

    return values;
}