export function computeTileValues(values)
{
    const count = values.tiles?.length || 1;

    let colClass = 'fr-col-12';

    if (count === 2) {
        colClass = 'fr-col-md-6';
    }

    if (count === 3) {
        colClass = 'fr-col-md-4';
    }

    if (count === 4) {
        colClass = 'fr-col-md-3';
    }

    const tileClasses = [];

    if (values.enlarge === '1') {
        tileClasses.push('fr-enlarge-link');
    }

    if (values.horizontal === '1') {
        tileClasses.push('fr-tile--horizontal');
    }

    if (values.size !== 'md') {
        tileClasses.push(`fr-tile--${values.size}`);
    }
    
    switch (values.variation)
    {
        case 'grey':
            tileClasses.push('fr-tile--grey');
            break;
    
        case 'no-border':
            tileClasses.push('fr-tile--no-border');
            break;
    
        case 'no-background':
            tileClasses.push('fr-tile--no-background');
            break;
    
        case 'shadow':
            tileClasses.push('fr-tile--shadow');
            break;
    }

    values.tiles_html =
        (values.tiles || [])
        .map(tile =>
            buildTile(
                tile,
                values,
                tileClasses.join(' '),
                colClass
            )
        )
        .join('');

    return values;
}

function buildTile(tile, global, classes, colClass)
{
    const titleTag = global.title_level || 'h3';

    const tileClasses = [classes];

    if (tile.download === '1') {
        tileClasses.push('fr-tile--download');
    }
    
    switch (tile.variation)
    {
        case 'grey':
            tileClasses.push('fr-tile--grey');
            break;
    
        case 'no-border':
            tileClasses.push('fr-tile--no-border');
            break;
    
        case 'no-background':
            tileClasses.push('fr-tile--no-background');
            break;
    
        case 'shadow':
            tileClasses.push('fr-tile--shadow');
            break;
    }

    let href = '#';

    let extraAttributes = '';

    if (tile.link_type === 'article' && tile.article_url) {
        href = tile.article_url;
    }

    if (tile.link_type === 'url') {
        href = tile.url || '#';
    }

    if (tile.download === '1')
    {
        href = tile.download_url || '#';
        extraAttributes = ' download="" data-fr-assess-file=""';
    }

    const downloadDetail = tile.download === '1'
        ? '<span class="fr-link__detail">bytes</span>'
        : '';

    return `
    <div class="${colClass}">
        <div class="fr-tile ${tileClasses.join(' ')}">
            <div class="fr-tile__body">
                <div class="fr-tile__content">
                
                    <${titleTag} class="fr-tile__title">
                        <a href="${href}"${extraAttributes}>
                            ${tile.title || ''}
                            ${downloadDetail}
                        </a>
                    </${titleTag}>
                    
                    ${
                        tile.description
                        ? `<p class="fr-tile__desc">${tile.description}</p>`
                        : ''
                    }
                    
                    ${
                        tile.detail
                        ? `<p class="fr-tile__detail">${tile.detail}</p>`
                        : ''
                    }
                </div>
            </div>
            
            ${
                tile.pictogram
                ? `
                <div class="fr-tile__header">
                    <div class="fr-tile__pictogram">
                        <img src="${tile.pictogram}" class="fr-responsive-img" alt="">
                    </div>
                </div>
                `
                : ''
            }
        </div>
    </div>
    `;
}