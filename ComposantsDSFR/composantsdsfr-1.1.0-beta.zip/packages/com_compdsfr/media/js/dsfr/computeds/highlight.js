export function computeHighlightValues(values) {

    values.accent_class =
        values.accent
            ? `fr-highlight--${values.accent}`
            : '';

    values.size_class = '';

    switch (values.size) {

        case 'sm':
            values.size_class =
                'fr-text--sm';
            break;

        case 'lg':
            values.size_class =
                'fr-text--lg';
            break;

        default:
            values.size_class = '';
            break;
    }

    return values;
}