export function computeTabsValues(values) {

    const tabs = values.tabs || [];

    const uid =
        values.dsfr_id ||
        `tabs-${Date.now()}`;

    const iconClass =
        values.has_icon === '1'
            ? `${values.icon || 'fr-icon-checkbox-circle-line'} fr-tabs__tab--icon-left`
            : '';

    values.tabs_buttons = tabs
        .map((tab, index) => {

            const selected =
                index === 0;

            return `
                <li role="presentation">
                    <button
                        type="button"
                        id="${uid}-tab-${index}"
                        class="fr-tabs__tab ${iconClass}"
                        tabindex="${selected ? '0' : '-1'}"
                        role="tab"
                        aria-selected="${selected}"
                        aria-controls="${uid}-panel-${index}">

                        ${tab.label}
                    </button>
                </li>
            `;
        })
        .join('');

    values.tabs_panels = tabs
        .map((tab, index) => {

            const selected =
                index === 0
                    ? ' fr-tabs__panel--selected'
                    : '';

            return `
                <div
                    id="${uid}-panel-${index}"
                    class="fr-tabs__panel${selected}"
                    role="tabpanel"
                    aria-labelledby="${uid}-tab-${index}"
                    tabindex="0">

                    ${tab.content}
                </div>
            `;
        })
        .join('');

    return values;
}