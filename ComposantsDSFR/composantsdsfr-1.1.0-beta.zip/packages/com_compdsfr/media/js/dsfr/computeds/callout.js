export function computeCalloutValues(values) {

    values.accent_class =
        values.accent
            ? `fr-callout--${values.accent}`
            : '';

    values.title_html = '';

    if (
        values.has_title === '1'
        && values.title
    ) {

        const tag =
            values.title_tag || 'h3';

        values.title_html = `
            <${tag} class="fr-callout__title">
                ${values.title}
            </${tag}>
        `;
    }

    if (
        values.has_icon === '1'
        && values.icon
    ) {

        values.accent_class +=
            ` ${values.icon}`;
    }

    values.button_html = '';

    if (
        values.has_button === '1'
        && values.button_label
    ) {
    
        values.button_html = `
            <a
                href="${values.button_url || '#'}"
                class="fr-btn">
                ${values.button_label}
            </a>
        `;
    }

    return values;
}