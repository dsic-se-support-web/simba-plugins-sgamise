export function computeCitationValues(values) {

    /**
     * IMPORTANT :normalise l'URL image pour preview
     */
    values.image_url = normalizeImageUrl(
        values.image_url
    );

    values.size_class =
        values.size === 'lg'
            ? 'fr-quote--lg'
            : '';

    values.accent_class =
        values.accent
            ? `fr-quote--${values.accent}`
            : '';

    const source = values.source?.trim() || '';

    const isUrl =
        /^https?:\/\/[^\s]+$/i.test(source);

    values.source_html =
        source
            ? (
                isUrl
                    ? `
                        <li>
                            <a
                                href="${source}"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="fr-link">
                                ${source}
                            </a>
                        </li>
                    `
                    : `<li>${source}</li>`
            )
            : '';

    values.image_html =
        values.hasImage === '1'
        && values.image_url
            ? `
                <div class="fr-quote__image">
                    <img
                        src="${values.image_url}"
                        alt="${values.image_alt || ''}"
                        class="fr-responsive-img">
                </div>
            `
            : '';

    return values;
}

function normalizeImageUrl(url) {

    if (!url) {
        return '';
    }

    const options = Joomla.getOptions('com_dsfr') || {};
    const root = options.root || window.location.origin + '/';

    // local-images:/foo.jpg
    if (url.startsWith('local-images:/')) {

        return root.replace(/\/$/, '') +
            '/images/' +
            url.replace('local-images:/', '');
    }

    // déjà absolue
    if (
        url.startsWith('http://')
        || url.startsWith('https://')
    ) {
        return url;
    }

    // /images/foo.jpg
    if (url.startsWith('/')) {
        return root.replace(/\/$/, '') + url;
    }

    // images/foo.jpg
    return root + url.replace(/^\/+/, '');
}