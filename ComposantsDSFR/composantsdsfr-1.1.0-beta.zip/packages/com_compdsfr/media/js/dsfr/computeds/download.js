export function computeDownloadValues(values) {

    values.link_id =
        values.dsfr_id || '';

    values.disabled_attr =
        values.disabled === '1'
            ? 'aria-disabled="true"'
            : '';

    values.size_class = '';

    if (values.size === 'sm') {
        values.size_class = 'fr-link--sm';
    }

    if (values.size === 'lg') {
        values.size_class = 'fr-link--lg';
    }

    return values;
}