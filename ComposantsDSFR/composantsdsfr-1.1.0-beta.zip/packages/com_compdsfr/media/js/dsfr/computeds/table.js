export function computeTableValues(values) {
    const cols = parseInt(values.cols || 5);
    const rows = parseInt(values.rows || 5);

    values.table_id = `table-${Math.floor(Math.random() * 10000)}`;

    // 1. En-têtes (Inchangé)
    values.headCells = Array.from(
        { length: cols },
        (_, i) => ({
            cellContent: `th${i}`
        })
    );

    // 2. Lignes du corps : On génère directement la chaîne HTML des <td> pour chaque ligne
    values.bodyRows = Array.from(
        { length: rows },
        (_, rowIndex) => {
            let cellsHtml = '';
            for (let colIndex = 0; colIndex < cols; colIndex++) {
                cellsHtml += `<td>Cellule ${rowIndex}-${colIndex}</td>`;
            }

            return {
                rowId: `${values.table_id}-row-key-${rowIndex + 1}`,
                rowKey: rowIndex + 1,
                cellsRawHtml: cellsHtml // Contient la suite de <td>...</td> de la ligne
            };
        }
    );

    values.captionHtml = '';

    if (values.captionDetail) {
        values.captionHtml =
            `<br><span class="fr-text--regular">${values.captionDetail}</span>`;
    }

    const classes = [];

    if (values.bordered === '1') {
        classes.push('fr-table--bordered');
    }

    if (values.noScroll === '1') {
        classes.push('fr-table--no-scroll');
    }

    if (values.multiline === '1') {
        classes.push('fr-table--multiline');
    }

    if (values.captionBottom === '1') {
        classes.push('fr-table--caption-bottom');
    }

    if (values.noCaption === '1') {
        classes.push('fr-table--no-caption');
    }

    if (
        values.size &&
        values.size !== 'md'
    ) {
        classes.push(`fr-table--${values.size}`);
    }

    values.table_classes = classes.join(' ');

    return values;

    return values;
}