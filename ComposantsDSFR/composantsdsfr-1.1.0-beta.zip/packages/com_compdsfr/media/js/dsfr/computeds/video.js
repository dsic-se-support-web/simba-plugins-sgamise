export function computeVideoValues(values)
{
    const width = parseInt(values.width || 800, 10);

    const ratioClass = values.ratio === '4x3'
        ? 'fr-responsive-vid--4x3'
        : '';

    const sizeAttributes = values.custom_size === '1'
            ? `style="max-width:${width}px;"`
            : '';

    const uid = 'transcription-' + Date.now();

    values.video_html = `
<figure class="fr-content-media--sm" role="group">
    <iframe class="fr-responsive-vid ${ratioClass}" title="${values.title}" src="${values.url}" ${sizeAttributes} allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen="allowfullscreen">
    </iframe>

    <div class="fr-transcription" id="${uid}">
        <button type="button" class="fr-transcription__btn" aria-expanded="false" aria-controls="fr-transcription-collapse-${uid}">
            Transcription
        </button>

        <div class="fr-collapse" id="fr-transcription-collapse-${uid}">
            <div class="fr-transcription__footer">
                <div class="fr-transcription__actions-group">
                    <button aria-controls="fr-transcription-modal-${uid}" data-fr-opened="false" type="button" class="fr-btn--fullscreen fr-btn">
                        Agrandir
                    </button>
                </div>
            </div>

            <dialog
                id="fr-transcription-modal-${uid}"
                class="fr-modal">
                <div class="fr-container fr-container--fluid fr-container-md">
                    <div class="fr-grid-row fr-grid-row--center">
                        <div class="fr-col-12 fr-col-md-10 fr-col-lg-8">
                            <div class="fr-modal__body">
                                <div class="fr-modal__header">
                                    <button aria-controls="fr-transcription-modal-${uid}" title="Fermer" type="button" class="fr-btn--close fr-btn">
                                        Fermer
                                    </button>
                                </div>
                                <div class="fr-modal__content">
                                    ${values.transcription}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </dialog>
        </div>
    </div>
</figure>
    `;

    return values;
}