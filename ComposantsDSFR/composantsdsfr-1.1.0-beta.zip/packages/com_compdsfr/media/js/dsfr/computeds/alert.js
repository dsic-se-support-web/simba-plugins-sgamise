export function computeAlertValues(values) {

    values.type_class =
        computeTypeClass(values.type);

    values.size_class =
        values.size === 'sm'
            ? 'fr-alert--sm'
            : '';

    values.closable_class =
        values.closable === '1'
            ? 'fr-alert--closable'
            : '';

        values.close_button =
            values.closable === '1'
                ? `
                    <button
                        type="button"
                        class="fr-btn--close fr-btn"
                        title="Masquer le message"
                        onClick="const alert = this.parentNode; alert.parentNode.removeChild(alert)">
                        Masquer le message
                    </button>
                `
            : '';

    return values;
}

function computeTypeClass(type) {

    const map = {
        info: 'fr-alert--info',
        success: 'fr-alert--success',
        error: 'fr-alert--error',
        warning: 'fr-alert--warning'
    };

    return map[type] || 'fr-alert--info';
}