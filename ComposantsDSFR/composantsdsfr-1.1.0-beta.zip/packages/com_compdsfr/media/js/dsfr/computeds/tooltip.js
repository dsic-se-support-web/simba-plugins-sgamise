export function computeTooltipValues(values) {

    const tooltipId =
        values.dsfr_id + '-tooltip';

    values.tooltip_id = tooltipId;

    const trigger =
        values.trigger || 'hover';

    const support =
        values.support || 'button';

    const label =
        (values.label || '').trim();

    /**
     * MODE LIEN
     */

    if (support === 'link') {

        values.button_html = `
            <a
                aria-describedby="${tooltipId}"
                href="${values.url || '#'}"
                class="fr-link">
                ${label}
            </a>
        `;

        return values;
    }

    /**
     * MODE BOUTON SURVOL
     */

    if (trigger === 'hover') {

        values.button_html = `
            <button
                aria-describedby="${tooltipId}"
                type="button"
                class="fr-btn">
                ${label}
            </button>
        `;

        return values;
    }

    /**
     * MODE BOUTON CLIC
     */

    values.button_html = `
        <button
            aria-describedby="${tooltipId}"
            type="button"
            class="fr-btn fr-btn--tooltip">
            ${label || 'infobulle'}
        </button>
    `;

    return values;
}