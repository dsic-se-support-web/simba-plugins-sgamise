export function renderTemplate(template, data) {
    let html = processTemplate(template, data);

    return cleanupHtml(html);
}

function processTemplate(template, context) {

    // ========================
    // Gestion des {{#each}}
    // ========================

    template = template.replace(
        /\{\{#\s*each\s+([^\}]+)\}\}([\s\S]*?)\{\{\/each\}\}/g,
        (match, key, content) => {

            const items = getValue(context, key.trim());

            if (!Array.isArray(items)) {
                return '';
            }

            return items
                .map(item => processTemplate(content, item))
                .join('');
        }
    );

    // ========================
    // Gestion des {{#if}}
    // ========================

    template = template.replace(
        /\{\{#\s*if\s+([^\}]+)\}\}([\s\S]*?)\{\{\/if\}\}/g,
        (match, condition, content) => {

            const value = getValue(context, condition.trim());

            return value ? processTemplate(content, context) : '';
        }
    );

    // ========================
    // Variables
    // ========================

    template = template.replace(
        /\{\{([^#\/][^}]*)\}\}/g,
        (match, key) => {

            const value = getValue(context, key.trim());

            return value ?? '';
        }
    );

    return template;
}

function getValue(obj, path) {

    return path
        .split('.')
        .reduce(
            (current, part) =>
                current && current[part] !== undefined
                    ? current[part]
                    : undefined,
            obj
        );
}

function cleanupHtml(html) {

    return html
        .replace(/\s+(?!download|data-fr-assess-file)[^\s=]+=""/g, '') // Exclusion de flag spéciaux du nettoyage
        .replace(/\s+/g, ' ')
        .replace(/class=" "/g, '')
        .replace(/\s{2,}/g, ' ')
        .trim();
}