import { fetchJson } from '../utils/fetch.js';

const BASE = 'index.php?option=com_compdsfr';

export async function fetchComponents() {

    const result = await fetchJson(
        `${BASE}&task=display.getComponents&format=json`
    );

    return result.data || [];
}

export async function parseSelectedComponent(html) {

    const params = new URLSearchParams();
    params.append('html', html);

    return fetchJson(
        `${BASE}&task=display.getSelectedComponent&format=json`,
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: params.toString()
        }
    );
}

export async function renderPreview(shortcode) {

    const formData = new FormData();

    formData.append('shortcode', shortcode);
    formData.append(Joomla.getOptions('csrf.token'), '1');

    return fetchJson(
        `${BASE}&task=display.render&format=json`,
        {
            method: 'POST',
            body: formData
        }
    );
}

export async function fetchArticles() {

    return fetchJson(
        'index.php?option=com_compdsfr&task=display.getArticles&format=json'
    );

}