let counter = 0;

export function initAccordionBuilder(existingAccordions = []) {

    counter = 0;

    const container = document.getElementById('accordion-builder');

    const addBtn = document.getElementById('add-accordion');

    if (!container || !addBtn) {
        return;
    }

    destroyAccordionEditors();

    container.innerHTML = '';

    addBtn.replaceWith(addBtn.cloneNode(true));

    const newAddBtn = document.getElementById('add-accordion');

    newAddBtn.addEventListener('click', () => addAccordion(container));

    if (Array.isArray(existingAccordions) && existingAccordions.length) {
        existingAccordions.forEach(
            accordion => addAccordion(
                container,
                accordion
            )
        );
    }
}

export function addAccordion(container,data = {}) {

    const index = counter++;
    const accordionId = data.id || generateAccordionId();
    const label = data.label || '';
    const content = data.content || '';
    const isExpanded = data.isExpanded === '1';
    const wrapper = document.createElement('div');

    wrapper.className = 'card p-3 mb-3';

    wrapper.dataset.id = accordionId;

    wrapper.innerHTML = `
        <div class="mb-3">
            <label class="form-label">
                Libellé de l'accordéon
            </label>

            <input type="text" class="form-control accordion-label" value="${escapeHtml(label)}" placeholder="Titre de l'accordéon">
        </div>

        <div class="mb-3">
            <label class="form-label">
                Ouvert par défaut
            </label>

            <select class="form-select accordion-expanded">
                <option value="0" ${!isExpanded ? 'selected' : ''}> Non </option>
                <option value="1" ${isExpanded ? 'selected' : ''}> Oui </option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">
                Contenu
            </label>

            <textarea id="accordion-content-${index}" class="form-control accordion-content" rows="10"></textarea>
        </div>

        <div class="small text-muted mb-3">
            ID : ${accordionId}
        </div>

        <button type="button" class="btn btn-danger btn-sm remove-accordion"> Supprimer l'accordéon </button>
    `;

    const textarea = wrapper.querySelector('.accordion-content');

    textarea.value = content;

    wrapper
        .querySelector('.remove-accordion')
        .addEventListener(
            'click',
            () => {
                destroyEditor(
                    textarea.id
                );
                wrapper.remove();
            }
        );

    container.appendChild(wrapper);

    requestAnimationFrame(() => initTinyMce(textarea));
}

function initTinyMce(textarea) {

    const tiny = window.parent?.tinymce || window.tinymce;

    if (!tiny || !textarea || !textarea.id) {
        return;
    }

    if (tiny.get(textarea.id)) {
        return;
    }

    requestAnimationFrame(() => {

        tiny.init({
            target: textarea,
            height: 300,
            menubar: false,
            branding: false,
            promotion: false,
            plugins: [
                'lists',
                'link',
                'table',
                'code'
            ],
            toolbar:
                'undo redo | bold italic underline | bullist numlist | link table | code'
        });
    });
}

function destroyEditor(editorId) {

    const tiny = window.tinymce || window.parent?.tinymce;

    if (!tiny) {
        return;
    }

    const editor = tiny.get(editorId);

    if (editor) {
        editor.remove();
    }
}

function destroyAccordionEditors() {

    const tiny = window.tinymce || window.parent?.tinymce;

    if (!tiny || !tiny.editors) {
        return;
    }

    Object.values(tiny.editors).forEach(editor => {
        if (editor?.id && editor.id.startsWith('accordion-content-')) {
            editor.remove();
        }
    });
}

function generateAccordionId() {

    return (
        'accordion-' +
        Date.now() +
        '-' +
        Math.random()
            .toString(36)
            .substring(2, 9)
    );
}

function escapeHtml(str = '') {

    const div = document.createElement('div');

    div.textContent = str;

    return div.innerHTML;
}