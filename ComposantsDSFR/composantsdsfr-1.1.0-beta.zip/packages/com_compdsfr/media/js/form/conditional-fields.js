import { getFormValues } from './values.js';

export function bindConditionalFields(component) {

    const form = document.getElementById(
        'dynamic-component-form'
    );

    if (!form) {
        return;
    }

    form.addEventListener('change', () => {
        updateConditionalFields(component);
    });

    updateConditionalFields(component);
}

export function updateConditionalFields(component) {

    const values = getFormValues();

    document.querySelectorAll('[data-visible-if]')
        .forEach(el => {

            const raw = el.dataset.visibleIf;

            if (!raw || raw === '""') {
                el.style.display = '';
                return;
            }

            try {

                const condition = JSON.parse(raw);

                const fieldValue = values[condition.field];

                let visible = false;

                switch (condition.operator) {

                    case '===':
                        visible = fieldValue === condition.value;
                        break;

                    case '!==':
                        visible = fieldValue !== condition.value;
                        break;
                }

                el.style.display = visible ? '' : 'none';

            } catch (e) {

                console.error('visibleIf error', e);
            }
        });
}