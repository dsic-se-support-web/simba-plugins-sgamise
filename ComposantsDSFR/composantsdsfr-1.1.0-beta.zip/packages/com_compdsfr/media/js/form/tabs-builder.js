let counter = 0;

export function initTabsBuilder(existingTabs = []) {

    const container = document.getElementById('tabs-builder');
    const addBtn = document.getElementById('add-tab');

    counter = 0;

    if (!container || !addBtn) {
        return;
    }

    destroyTabsEditors();

    addBtn.replaceWith(addBtn.cloneNode(true));

    const newAddBtn = document.getElementById('add-tab');

    newAddBtn.addEventListener('click', () => {
        addTab(container);
    });

    if (existingTabs.length) {
        existingTabs.forEach(tab => addTab(container, tab));
    } else {
        addTab(container);
    }
}

export function addTab(
    container,
    data = {}
) {

    const index = counter++;

    const wrapper =
        document.createElement('div');

    const label =
        data.label || '';

    const content =
        data.content || '';

    wrapper.className =
        'card p-3 mb-3';

    wrapper.innerHTML = `
        <input
            type="text"
            class="form-control mb-2 tab-label"
            value="${escapeHtml(label)}"
            placeholder="Libellé">

        <textarea
            id="tab-content-${index}"
            class="form-control tab-content"
            rows="8"></textarea>

        <button
            type="button"
            class="btn btn-danger btn-sm mt-2 remove-tab">

            Supprimer
        </button>
    `;

    const textarea =
        wrapper.querySelector(
            '.tab-content'
        );

    textarea.value = content;

    wrapper
        .querySelector('.remove-tab')
        .addEventListener('click', () => {

            destroyEditor(
                textarea.id
            );

            wrapper.remove();
        });

    container.appendChild(wrapper);

    requestAnimationFrame(() => {
        initTinyMce(textarea);
    });
}

function initTinyMce(textarea) {

    const tiny =
        window.tinymce ||
        window.parent?.tinymce;

    if (!tiny) {
        return;
    }

    if (tiny.get(textarea.id)) {
        tiny.get(textarea.id).remove();
    }

    setTimeout(() => {
        tiny.init({
            target: textarea,
            height: 300,
            menubar: false,
            branding: false,
            promotion: false,
            plugins: ['lists', 'link', 'table', 'code'],
            toolbar:
                'undo redo | bold italic underline | bullist numlist | link table | code'
        });
    }, 100);
}

function destroyEditor(editorId) {

    const tiny =
        window.tinymce
        || window.parent?.tinymce;

    if (!tiny) {
        return;
    }

    const editor =
        tiny.get(editorId);

    if (editor) {
        editor.remove();
    }
}

function destroyTabsEditors() {

    const tiny =
        window.tinymce
        || window.parent?.tinymce;

    if (!tiny) {
        return;
    }

    const editors = tiny.editors;

    if (!editors) {
        return;
    }

    Object.values(editors).forEach(editor => {
        if (
            editor?.id &&
            editor.id.startsWith('tab-content-')
        ) {
            editor.remove();
        }
    });
}

function escapeHtml(str = '') {

    const div =
        document.createElement('div');

    div.textContent = str;

    return div.innerHTML;
}