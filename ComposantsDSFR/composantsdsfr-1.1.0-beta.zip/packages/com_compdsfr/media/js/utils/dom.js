export function parseHtml(html) {
    return new DOMParser().parseFromString(html, 'text/html');
}

export function getFirstElement(html) {
    return parseHtml(html).body.firstElementChild;
}