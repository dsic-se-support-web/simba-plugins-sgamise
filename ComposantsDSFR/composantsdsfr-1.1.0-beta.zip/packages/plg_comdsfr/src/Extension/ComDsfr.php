<?php

declare(strict_types=1);
namespace Joomla\Plugin\EditorsXtd\ComDsfr\Extension;

use Joomla\CMS\Editor\Button\Button;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\SubscriberInterface;
use Joomla\CMS\Event\Editor\EditorButtonsSetupEvent;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

class ComDsfr extends CMSPlugin implements SubscriberInterface
{   

    public static function getSubscribedEvents(): array
    {
        return [
            'onEditorButtonsSetup' => 'onEditorButtonsSetup',
        ];
    }

    public function onEditorButtonsSetup(EditorButtonsSetupEvent $event)
    {
        $subject  = $event->getButtonsRegistry();
        $editorId = $event->getEditorId();
    
        // URL de base
        $link = 'index.php?option=com_compdsfr&view=modal&tmpl=component&editor_id=' . $editorId;
    
        // Ajout du bouton
        $button = new Button('comdsfr', [
            'action'  => 'modal',
            'link'    => $link,
            'text'    => 'Composants DSFR',
            'icon'    => 'cube',
            'name'    => 'comdsfr',
            'options' => [
                'height' => '600px',
                'width'  => '900px',
            ]
        ]);
    
        $subject->add($button);
    }
}