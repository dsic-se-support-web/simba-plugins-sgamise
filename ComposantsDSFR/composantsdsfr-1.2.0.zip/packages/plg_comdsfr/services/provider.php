<?php
declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Event\DispatcherInterface;
use Joomla\Plugin\EditorsXtd\ComDsfr\Extension\ComDsfr;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(PluginInterface::class, function (Container $container) {
            $dispatcher = $container->get(DispatcherInterface::class);
            $plugin = new ComDsfr(
                $dispatcher,
                (array) PluginHelper::getPlugin('editors-xtd', 'comdsfr')
            );
            $plugin->setApplication(Factory::getApplication());

            return $plugin;
        });
    }
};
