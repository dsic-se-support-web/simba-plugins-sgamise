<?php

namespace Joomla\Component\CompDsfr\Administrator\Controller;

defined('_JEXEC') or die;

// Nécessaire pour appeler le parser à l'ouverture de la fenêtre modale
require_once JPATH_COMPONENT_ADMINISTRATOR . '/src/Helper/DsfrParser.php';

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;
use Joomla\CMS\Response\JsonResponse;
use Joomla\Component\CompDsfr\Administrator\Helper\DsfrParser;
use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;
use Joomla\Database\DatabaseInterface;

class DisplayController extends BaseController {
    protected $default_view = 'modal';

    /**
     * Génère le HTML à partir d'un shortcode
     * 
     * @return void
     */
    public function render()
    {
        $this->checkToken('post');

        $app   = Factory::getApplication();
        $input = $app->getInput();
        $shortcode = $input->post->get('shortcode', '', 'RAW');

        if (empty($shortcode)) {
            echo new JsonResponse(new \Exception('Shortcode vide'));
            $app->close();
        }
        
        $textFinal = \Joomla\CMS\HTML\HTMLHelper::_('content.prepare', $shortcode);
        echo new JsonResponse(['html' => $textFinal]);
        $app->close();
    }

    /**
     * Récupère la liste des composants DSFR disponibles
     * 
     * @return void
     */
    public function getComponents()
    {
        $app = Factory::getApplication();
        $path = JPATH_ROOT . '/media/com_compdsfr/templates';
        $files = glob($path . '/*.json');
        $components = [];
    
        foreach ($files as $file) {
            // Ignore index.json
            if (basename($file) === 'index.json') {
                continue;
            }
        
            $json = json_decode(file_get_contents($file), true);
        
            // Ignore fichiers invalides
            if (!$json || empty($json['name']) || empty($json['label'])) {
                continue;
            }
        
            $components[] = [
                'name'        => $json['name'],
                'label'       => $json['label'],
                'description' => $json['description'] ?? '',
                'fields'      => $json['fields'] ?? [],
                'computed'    => $json['computed'] ?? [],
                'template'    => $json['template'] ?? ''
            ];
        }

        $collator = new \Collator('fr_FR');

        usort(
            $components,
            static function ($a, $b) use ($collator) {
                return $collator->compare(
                    $a['label'],
                    $b['label']
                );
            }
        );

        echo new JsonResponse($components);
    
        $app->close();
    }

    /**
     * Analyse un composant existant dans l'article
     * 
     * @return void
     */
    public function getSelectedComponent()
    {
        $app = Factory::getApplication();
        $input = $app->getInput();
        $html = $input->post->get('html', '', 'RAW');
    
        if (empty($html)) {
            echo new JsonResponse(new \Exception('Aucun contenu sélectionné'));
            $app->close();
        }
    
        $data = DsfrParser::parseComponent($html);
    
        if ($data) {
            echo new JsonResponse($data);
            $app->close();
        }
    
        echo new JsonResponse(new \Exception('Composant non reconnu'));
        $app->close();
    }

    /**
     * Récupère les informations d'un article
     * 
     * @return void
     */
    public function getArticle()
    {
        $app = Factory::getApplication();
        $id = $app->input->getInt('id');
        $db = Factory::getContainer()
            ->get(DatabaseInterface::class);
        $query = $db->getQuery(true)
            ->select([
                'a.id',
                'a.title',
                'a.catid',
                'a.language'
            ])
            ->from('#__content AS a')
            ->where('a.id = ' . (int) $id);
    
        $db->setQuery($query);
    
        $article = $db->loadAssoc();
    
        if (!$article) {
            echo new JsonResponse(new \Exception('Article introuvable'));
    
            $app->close();
        }
    
        $article['sef_url'] = Route::_(RouteHelper::getArticleRoute($article['id'], $article['catid'], $article['language']));
    
        echo new JsonResponse($article);
    
        $app->close();
    }
}
