<?php
namespace Joomla\Component\CompDsfr\Administrator\View\Modal;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Factory;

class HtmlView extends BaseHtmlView
{
    public $editorId;

    /**
     * Affiche la vue modale
     *
     * @param string|null $tpl Le template à utiliser
     * @return void
     */
    public function display($tpl = null)
    {
        $app = Factory::getApplication();
     
        $this->editorId = $app->getInput()->get('editor_id', '', 'cmd');

        $this->document->addScriptOptions('compdsfr_data', [
            'editorId' => $this->editorId
        ]);

        return parent::display($tpl);
    }
}
