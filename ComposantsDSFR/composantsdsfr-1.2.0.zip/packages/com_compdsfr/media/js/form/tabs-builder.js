let counter = 0;

/**
 * Initialise le constructeur d'onglets
 *
 * @param {Array} existingTabs Onglets existants
 * @return void
 */
export function initTabsBuilder(existingTabs = []) {

    const container = document.getElementById('tabs-builder');
    const addBtn = document.getElementById('add-tab');

    counter = 0;

    if (!container || !addBtn) {
        return;
    }

    destroyTabsEditors();

    addBtn.replaceWith(addBtn.cloneNode(true));

    const newAddBtn = document.getElementById('add-tab');

    newAddBtn.addEventListener('click', () => {
        addTab(container);
    });

    if (existingTabs.length) {
        existingTabs.forEach(tab => addTab(container, tab));
    } else {
        addTab(container);
    }
}

/**
 * Ajoute un onglet au builder
 *
 * @param {HTMLElement} container Conteneur du builder
 * @param {object} data Données de l'onglet
 * @return void
 */
export function addTab(
    container,
    data = {}
) {

    const index = counter++;

    const wrapper =
        document.createElement('div');

    const label =
        data.label || '';

    const content =
        data.content || '';

    wrapper.className =
        'card p-3 mb-3';

    wrapper.innerHTML = `
        <input
            type="text"
            class="form-control mb-2 tab-label"
            value="${escapeHtml(label)}"
            placeholder="Libellé">

        <textarea
            id="tab-content-${index}"
            class="form-control tab-content"
            rows="8"></textarea>

        <button
            type="button"
            class="btn btn-danger btn-sm mt-2 remove-tab">

            Supprimer
        </button>
    `;

    const textarea =
        wrapper.querySelector(
            '.tab-content'
        );

    textarea.value = content;

    wrapper
        .querySelector('.remove-tab')
        .addEventListener('click', () => {

            destroyEditor(
                textarea.id
            );

            wrapper.remove();
        });

    container.appendChild(wrapper);

    requestAnimationFrame(() => {
        initTinyMce(textarea);
    });
}

/**
 * Initialise TinyMCE pour un textarea
 *
 * @param {HTMLElement} textarea Zone de texte
 * @return void
 */
function initTinyMce(textarea) {

    const tiny =
        window.tinymce ||
        window.parent?.tinymce;

    if (!tiny) {
        return;
    }

    if (tiny.get(textarea.id)) {
        tiny.get(textarea.id).remove();
    }

    setTimeout(() => {
        tiny.init({
            target: textarea,
            height: 300,
            menubar: false,
            branding: false,
            promotion: false,
            plugins: ['lists', 'link', 'table', 'code'],
            toolbar:
                'undo redo | bold italic underline | bullist numlist | link table | code'
        });
    }, 100);
}

/**
 * Détruit un éditeur TinyMCE
 *
 * @param {string} editorId ID de l'éditeur
 * @return void
 */
function destroyEditor(editorId) {

    const tiny =
        window.tinymce
        || window.parent?.tinymce;

    if (!tiny) {
        return;
    }

    const editor =
        tiny.get(editorId);

    if (editor) {
        editor.remove();
    }
}

/**
 * Détruit tous les éditeurs TinyMCE
 *
 * @return void
 */
function destroyTabsEditors() {

    const tiny =
        window.tinymce
        || window.parent?.tinymce;

    if (!tiny) {
        return;
    }

    const editors = tiny.editors;

    if (!editors) {
        return;
    }

    Object.values(editors).forEach(editor => {
        if (
            editor?.id &&
            editor.id.startsWith('tab-content-')
        ) {
            editor.remove();
        }
    });
}

/**
 * Échappe les caractères HTML
 *
 * @param {string} str Chaîne à échapper
 * @return {string} Chaîne échappée
 */
function escapeHtml(str = '') {

    const div = document.createElement('div');
    div.textContent = str;

    return div.innerHTML;
}