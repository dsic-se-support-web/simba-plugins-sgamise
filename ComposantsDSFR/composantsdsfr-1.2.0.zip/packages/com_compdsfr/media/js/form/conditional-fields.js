import { getFormValues } from './values.js';

/**
 * Lie les champs conditionnels au composant
 *
 * @param {object} component Configuration du composant
 * @return void
 */
export function bindConditionalFields(component) {

    const form = document.getElementById('dynamic-component-form');

    if (!form) {
        return;
    }

    form.addEventListener('change', () => {
        updateConditionalFields(component);
    });

    updateConditionalFields(component);
}

/**
 * Met à jour les champs conditionnels selon les valeurs actuelles
 *
 * @param {object} component Configuration du composant
 * @return void
 */
export function updateConditionalFields(component) {

    const values = getFormValues();

    document.querySelectorAll('[data-visible-if]')
        .forEach(el => {

            const raw = el.dataset.visibleIf;

            if (!raw || raw === '""') {
                el.style.display = '';
                return;
            }

            try {

                const condition = JSON.parse(raw);
                const fieldValue = values[condition.field];
                let visible = false;

                switch (condition.operator) {

                    case '===':
                        visible = fieldValue === condition.value;
                        break;

                    case '!==':
                        visible = fieldValue !== condition.value;
                        break;
                }

                el.style.display = visible ? '' : 'none';

            } catch (e) {

                console.error('visibleIf error', e);
            }
        });
}