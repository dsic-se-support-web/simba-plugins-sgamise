let counter = 0;

window.addEventListener('message', event => {

    if (!event.data || event.data.messageType !== 'comdsfr:article-select') {
        return;
    }

    if (!window.dsfrCurrentArticlePicker) {
        return;
    }

    const {idField, titleField} = window.dsfrCurrentArticlePicker;
    idField.value = event.data.id;
    titleField.value = event.data.title;
    const card = idField.closest('.dsfr-card-item');

    if (card) {

        let articleUrl =
            card.querySelector('.card-article-url');

        if (!articleUrl) {
            articleUrl = document.createElement('input');
            articleUrl.type = 'hidden';
            articleUrl.className = 'card-article-url';

            card.appendChild(articleUrl);
        }

        articleUrl.value = event.data.url;
    }

    window.dsfrCurrentArticlePicker = null;

    if (window.ArticleManager) {
        window.ArticleManager.close();
    }
});

/**
 * Initialise le constructeur de cartes
 *
 * @param {Array} existingCards Cartes existantes
 * @return void
 */
export function initCardBuilder(existingCards = []) {

    const container = document.getElementById('card-builder');

    if (!container) {
        return;
    }

    container.innerHTML = '';
    counter = 0;
    const addButton = document.getElementById('add-card');

    if (addButton) {

        addButton.onclick = () => {

            const currentCount = container.querySelectorAll('.dsfr-card-item').length;

            if (currentCount >= 4) {

                Joomla.renderMessages({
                    warning: ['Le composant Carte est limité à 4 cartes.']
                });

                return;
            }

            addCard(container);

            const countField = document.querySelector('[name="cards_count"]');

            if (countField) {
                countField.value = currentCount + 1;
            }
        };
    }

    const count = Math.max(parseInt(document.querySelector('[name="cards_count"]')?.value || 1), existingCards.length);

    for (let i = 0; i < count; i++) {

        const data = existingCards[i] || {};

        addCard(container, data);

        if (data.article_id && !data.article_title) {
        
            fetch(`index.php?option=com_compdsfr&task=display.getArticle&id=${data.article_id}`)
            .then(r => r.json())
            .then(r => {
        
                if (!r.success) {
                    return;
                }
        
                const card = container.lastElementChild;
        
                card.querySelector('.card-article-title').value = r.data.title;
            });
        }
    }

    document.querySelector('[name="cards_count"]')?.addEventListener('change', event => {
    
            const wanted = parseInt(event.target.value);
            const current = container.querySelectorAll('.dsfr-card-item').length;
    
            if (wanted > current) {
    
                for (let i = current; i < wanted; i++) {
                    addCard(container);
                }
    
                return;
            }
    
            if (wanted < current) {
    
                const cards = container.querySelectorAll('.dsfr-card-item');
    
                for (let i = current; i > wanted; i--) {
                    cards[i - 1].remove();
                }
            }
        }
    );
}

/**
 * Lie les champs de médias à une carte
 *
 * @param {HTMLElement} wrapper Wrapper de la carte
 * @return void
 */
function bindCardMedia(wrapper)
{
    const button = wrapper.querySelector('.card-media-picker');
    const input = wrapper.querySelector('.card-image');
    const preview = wrapper.querySelector('.card-image-preview');

    if (!button || !input) {
        return;
    }

    const updatePreview = (url) => {

        if (!preview) {
            return;
        }

        if (!url) {
            preview.innerHTML = '';
            return;
        }

        let finalUrl = url;

        if (finalUrl.startsWith('local-images:/')) {
            finalUrl = finalUrl.replace('local-images:/', `${window.location.origin}/images/`);
        }
        else if (!finalUrl.startsWith('http') && !finalUrl.startsWith('/')) {
            finalUrl = `${window.location.origin}/${finalUrl}`;
        }

        preview.innerHTML = `
            <img src="${finalUrl}" style="max-width:200px;height:auto;border-radius:6px;">
        `;
    };

    // preview initiale
    updatePreview(input.value);

    input.addEventListener('input', () => {
        updatePreview(input.value);
    });

    button.addEventListener('click', () => {

        const fieldId = `card-media-${Date.now()}`;
        const handler = (event) => {

            if (!event.data) return;

            if (event.data.messageType === 'joomla:media-select' && event.data.fieldid === fieldId) {
                let imageUrl = event.data.url || event.data.path || event.data.uri || '';

                if (!imageUrl) return;

                input.value = imageUrl;
                updatePreview(imageUrl);

                window.removeEventListener('message', handler);
            }
        };

        window.addEventListener('message', handler);

        const url = `index.php?option=com_media&view=media&tmpl=component` + `&asset=com_compdsfr&fieldid=${fieldId}`;

        window.open(url, 'MediaManager', 'width=1200,height=700,resizable=yes');
    });
}

/**
 * Ajoute une carte au builder
 *
 * @param {HTMLElement} container Conteneur du builder
 * @param {object} data Données de la carte
 * @return void
 */
function addCard(container, data = {}) {

    const wrapper = document.createElement('div');
    const linkType = data.link_type || 'article';

    wrapper.className = 'carte p-3 mb-3 dsfr-card-item';

        wrapper.innerHTML = `
        <h4>Carte ${++counter}</h4>

        <button type="button" class="btn btn-danger btn-sm remove-card fr-mb-2v">
            Supprimer la carte
        </button>

        <input class="form-control card-title mb-2" placeholder="Titre" value="${data.title || ''}">
    
        <textarea class="form-control card-description mb-2" placeholder="Description">${data.description || ''}</textarea>
    
        <label class="form-label fr-mt-5v">
            Type de lien
        </label>
    
        <select class="form-select card-link-type mb-3">
            <option value="article" ${linkType === 'article' ? 'selected' : ''}>
                Article Joomla
            </option>
    
            <option value="url" ${linkType === 'url' ? 'selected' : ''}>
                URL externe
            </option>
        </select>
    
        <div class="card-link-article">
    
            <input type="hidden" class="card-article-id" value="${data.article_id || ''}">

            <input type="hidden" class="card-article-url" value="${data.article_url || ''}">
    
            <div class="input-group mb-3">
                <input type="text" class="form-control card-article-title" readonly value="${data.article_title || ''}">
    
                <button type="button" class="fr-btn fr-btn--secondary card-select-article">
                    Sélectionner
                </button>
            </div>
        </div>
    
        <div class="card-link-url">
            <input type="url" class="form-control card-url mb-3" placeholder="https://..." value="${data.url || ''}">
        </div>

        <label class="form-label fr-mt-5v">
            Image d'illustration de la carte
        </label>

        <div class="alert alert-info dsfr-form-notice fr-mb-3v">
            Utilisez la fonctionnalité "obtenir un lien" dans l'explorateur de médias puis collez-le dans ce champ
        </div>

        <div class="input-group fr-mb-3v">
            <input type="text" class="form-control card-image" placeholder="Image" value="${data.image_url || ''}">
        
            <button type="button" class="fr-btn fr-btn--secondary card-media-picker">
                Sélectionner
            </button>
        </div>

        <div class="card-image-preview fr-mb-3v"></div>
    
        <input class="form-control card-alt" placeholder="Texte alternatif" value="${data.image_alt || ''}">
    `;

    container.appendChild(wrapper);

    bindCardMedia(wrapper);

    wrapper.querySelector('.remove-card')
    ?.addEventListener('click', () => {
    
        wrapper.remove();
    
        const count = container.querySelectorAll('.dsfr-card-item').length;
        const countField = document.querySelector('[name="cards_count"]');
    
        if (countField) {
            countField.value = count;
        }
    });

    const linkTypeSelect = wrapper.querySelector('.card-link-type');
    const articleBlock = wrapper.querySelector('.card-link-article');
    const urlBlock = wrapper.querySelector('.card-link-url');

    function refreshLinkMode()
    {
        const type = linkTypeSelect.value;

        articleBlock.style.display =
            type === 'article'
                ? ''
                : 'none';

        urlBlock.style.display =
            type === 'url'
                ? ''
                : 'none';
    }

    refreshLinkMode();

    linkTypeSelect.addEventListener('change', refreshLinkMode);
  
    wrapper.querySelector('.card-select-article')
    ?.addEventListener('click', () => {
    
        const titleField = wrapper.querySelector('.card-article-title');
        const idField = wrapper.querySelector('.card-article-id');
    
        window.dsfrCurrentArticlePicker = {
            idField,
            titleField
        };
  
        const fieldId = 'card_article_' + Date.now();
        idField.dataset.fieldid = fieldId;
        const url = 'index.php?option=com_compdsfr' + '&view=modalarticles' + '&tmpl=component';
    
        window.ArticleManager = window.open(url, 'ArticleManager', 'width=1200,height=700,resizable=yes');
    });
}