import { renderTemplate } from '../template-engine.js';
import { getFormValues, computeValues } from '../form/values.js';
import { generateDsfrId } from '../utils/uid.js';
import { injectDsfrAttributes, injectDsfrProps } from './attributes.js';

/**
 * Génère le code HTML pour un composant
 * 
 * @param {Object} component - Configuration du composant
 * @returns {Promise<string>} - Code HTML généré
 */
export async function generate(component) {

    if (!component) {
        return '';
    }

    let values = getFormValues();

    if (!values.dsfr_id) {
        values.dsfr_id = generateDsfrId();
    }

    values = computeValues(component, values);
    let html = renderTemplate(component.template, values);
    html = injectDsfrAttributes(html, component.name, values.dsfr_id);
    html = injectDsfrProps(html, component.name, values);

    return html.replace(/\s+/g, ' ').trim();
}