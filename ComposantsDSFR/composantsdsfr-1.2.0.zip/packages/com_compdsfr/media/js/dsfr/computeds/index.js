import { computeAccordionValues }
    from './accordion.js';

import { computeAlertValues }
    from './alert.js';

import { computeButtonValues }
    from './button.js';

import { computeCalloutValues }
    from './callout.js';

import { computeCardValues }
    from './card.js';

import { computeDownloadValues }
    from './download.js';

import { computeHighlightValues }
    from './highlight.js';

import { computeCitationValues }
    from './citation.js';

import { computeNoticeValues }
    from './notice.js';

import { computeTableValues }
    from './table.js';

import { computeTabsValues }
    from './tabs.js';

import { computeTileValues }
    from './tile.js';

import { computeTooltipValues }
    from './tooltip.js';

import { computeVideoValues }
    from './video.js';

const COMPUTEDS = {
    accordion: computeAccordionValues,  // Accordéons
    alert: computeAlertValues,          // Alerte
    notice: computeNoticeValues,        // Bandeau d'information
    bouton: computeButtonValues,        // Bouton
    card: computeCardValues,            // Cartes
    citation: computeCitationValues,    // Citation
    tooltip: computeTooltipValues,      // Infobulle
    callout: computeCalloutValues,      // Mise en avant
    highlight: computeHighlightValues,  // Mise en exergue
    table: computeTableValues,          // Tableau
    tabs: computeTabsValues,            // Onglets
    tile: computeTileValues,            // Tuiles
    download: computeDownloadValues,    // Téléchargement
    video: computeVideoValues           // Video
};

/**
 * Calcule les valeurs spécifiques à un composant
 *
 * @param {object} component Configuration du composant
 * @param {object} values Valeurs saisies
 * @return {object} Valeurs calculées
 */
export function computeComponentValues(component, values) {
    if (!component?.name) {
        return values;
    }

    const handler = COMPUTEDS[component.name];

    if (!handler) {
        return values;
    }

    return handler(values);
}