import {escapeHtml, escapeAttribute} from '../../utils/html.js';

/**
 * Calcule les valeurs pour le composant Tabs
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeTabsValues(values) {

    const tabs = values.tabs || [];

    const uid = escapeAttribute(values.dsfr_id || `tabs-${Date.now()}`);

    const iconClass = values.has_icon === '1'
            ? `${escapeAttribute(values.icon || 'fr-icon-checkbox-circle-line')} fr-tabs__tab--icon-left`
            : '';

    const buttons = tabs.map((tab, index) => {

            const selected = index === 0;

            return `
                <li role="presentation">
                    <button type="button"
                        id="${uid}-tab-${index}"
                        class="fr-tabs__tab${iconClass ? ` ${iconClass}` : ''}"
                        tabindex="${selected ? '0' : '-1'}"
                        role="tab"
                        aria-selected="${selected}"
                        aria-controls="${uid}-panel-${index}">

                        ${escapeHtml(tab.label || '')}
                    </button>
                </li>
            `;
        })
        .join('');

    const panels = tabs.map((tab, index) => {

            const selected = index === 0
                    ? ' fr-tabs__panel--selected'
                    : '';

            return `
                <div id="${uid}-panel-${index}" class="fr-tabs__panel${selected}" role="tabpanel" aria-labelledby="${uid}-tab-${index}" tabindex="0">
                    ${tab.content || ''}
                </div>
            `;
        })
        .join('');

    values.tabs_html = `
        <div class="fr-tabs">
            <ul class="fr-tabs__list" role="tablist" aria-label="Système d'onglets">
                ${buttons}
            </ul>

            ${panels}
        </div>
    `;

    return values;
}