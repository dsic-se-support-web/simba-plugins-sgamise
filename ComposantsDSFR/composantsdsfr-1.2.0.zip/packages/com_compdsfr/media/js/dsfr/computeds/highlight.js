import { escapeHtml } from '../../utils/html.js';

/**
 * Calcule les valeurs pour le composant Highlight
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeHighlightValues(values) {

    const classes = ['fr-highlight'];

    if (values.accent) {
        classes.push(`fr-highlight--${values.accent}`);
    }

    let textClass = '';

    switch (values.size) {

        case 'sm':
            textClass = 'fr-text--sm';
            break;

        case 'lg':
            textClass = 'fr-text--lg';
            break;

        default:
            textClass = '';
            break;
    }

    values.highlight_html = `
        <div class="${classes.join(' ')}">
            <p${textClass ? ` class="${textClass}"` : ''}>
                ${escapeHtml(values.content || '')}
            </p>
        </div>
    `;

    return values;
}