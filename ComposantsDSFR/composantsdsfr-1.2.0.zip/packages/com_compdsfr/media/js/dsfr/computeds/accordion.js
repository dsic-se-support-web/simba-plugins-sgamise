/**
 * Calcule les valeurs pour le composant Accordion
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeAccordionValues(values) {

    const accordions = values.accordions || [];
    const html = accordions.map(item => {
        const expanded = item.isExpanded === '1';

        return `
<section class="fr-accordion">
    <h3 class="fr-accordion__title">
        <button type="button" class="fr-accordion__btn" aria-expanded="${expanded}" aria-controls="${item.id}">
            ${item.label}
        </button>
    </h3>

    <div class="fr-collapse${expanded ? ' fr-collapse--expanded' : ''}" id="${item.id}">
        ${item.content}
    </div>
</section>
        `;
    }).join('');

    values.accordions_html = `
    <div class="dsfr-accordion-wrapper">
        ${
            values.grouped === '1'
                ? `
                <div data-fr-group="true" class="fr-accordions-group">
                    ${html}
                </div>
                `
                : html
        }
    </div>
    `;

    return values;
}