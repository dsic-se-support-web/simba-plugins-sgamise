import {escapeHtml, escapeAttribute} from '../../utils/html.js';

/**
 * Calcule les valeurs pour le composant Download
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeDownloadValues(values) {

    const classes = [
        'fr-link',
        'fr-link--download'
    ];

    if (values.size === 'sm') {
        classes.push('fr-link--sm');
    }

    if (values.size === 'lg') {
        classes.push('fr-link--lg');
    }

    const disabled = values.disabled === '1';

    const disabledAttr = disabled
        ? 'aria-disabled="true" tabindex="-1"'
        : '';

    const href = disabled
        ? '#'
        : escapeAttribute(values.href || '');

    values.download_html = `
        <a
            id="${escapeAttribute(values.dsfr_id || '')}"
            class="${classes.join(' ')}"
            href="${href}"
            target="_self"
            download
            data-fr-assess-file
            ${disabledAttr}>
            ${escapeHtml(values.label || '')}
            <span class="fr-link__detail">bytes</span>
        </a>
    `;

    return values;
}