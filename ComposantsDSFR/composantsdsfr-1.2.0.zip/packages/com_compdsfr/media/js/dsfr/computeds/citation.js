import {escapeHtml, escapeAttribute} from '../../utils/html.js';

/**
 * Calcule les valeurs pour le composant Citation
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeCitationValues(values) {

    values.image_url = normalizeImageUrl(values.image_url);

    const classes = ['fr-quote'];

    if (values.size === 'lg') {
        classes.push('fr-quote--lg');
    }

    if (values.accent) {
        classes.push(`fr-quote--${values.accent}`);
    }

    const source = values.source?.trim() || '';
    const isUrl = /^https?:\/\/[^\s]+$/i.test(source);

    let sourceHtml = '';

    if (source) {

        sourceHtml = isUrl
            ? `
                <ul class="fr-quote__source">
                    <li>
                        <a href="${escapeAttribute(source)}" target="_blank" rel="noopener noreferrer" class="fr-link">
                            ${escapeHtml(source)}
                        </a>
                    </li>
                </ul>
            `
            : `
                <ul class="fr-quote__source">
                    <li>${escapeHtml(source)}</li>
                </ul>
            `;
    }

    let imageHtml = '';

    if (values.hasImage === '1' && values.image_url) {

        imageHtml = `
            <div class="fr-quote__image">
                <img
                    src="${escapeAttribute(values.image_url)}"
                    alt="${escapeAttribute(values.image_alt || '')}"
                    class="fr-responsive-img">
            </div>
        `;
    }

    const authorHtml = values.author
        ? `
            <p class="fr-quote__author">
                ${escapeHtml(values.author)}
            </p>
        `
        : '';

    values.citation_html = `
        <figure class="${classes.join(' ')}">

            <blockquote>
                <p class="fr-text--md">
                    ${escapeHtml(values.content || '')}
                </p>
            </blockquote>

            <figcaption>

                ${authorHtml}

                ${sourceHtml}

                ${imageHtml}

            </figcaption>

        </figure>
    `;

    return values;
}

/**
 * Normalise l'URL d'une image pour l'affichage
 *
 * @param {string} url URL de l'image
 * @return {string} URL normalisée
 */
function normalizeImageUrl(url) {

    if (!url) {
        return '';
    }

    const options = Joomla.getOptions('com_dsfr') || {};
    const root = options.root || window.location.origin + '/';

    // local-images:/foo.jpg
    if (url.startsWith('local-images:/')) {

        return root.replace(/\/$/, '') +
            '/images/' +
            url.replace('local-images:/', '');
    }

    // déjà absolue
    if (url.startsWith('http://') || url.startsWith('https://')) {
        return url;
    }

    // /images/foo.jpg
    if (url.startsWith('/')) {
        return root.replace(/\/$/, '') + url;
    }

    // images/foo.jpg
    return root + url.replace(/^\/+/, '');
}