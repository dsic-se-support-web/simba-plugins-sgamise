import {escapeHtml, escapeAttribute} from '../../utils/html.js';

/**
 * Calcule les valeurs pour le composant Bouton
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeButtonValues(values) {

    const classes = ['fr-btn'];

    if (values.style) {
        classes.push(`fr-btn--${values.style}`);
    }

    if (values.size) {
        classes.push(`fr-btn--${values.size}`);
    }

    if (values.fullwidth === '1') {
        classes.push('fr-btn--full-width');
    }

    if (values.has_icon === '1' && values.icon) {

        classes.push(values.icon);

        switch (values.icon_position) {

            case 'right': classes.push('fr-btn--icon-right');
                break;

            case 'icon_only': classes.push('fr-btn--icon');
                break;

            default: classes.push('fr-btn--icon-left');
                break;
        }
    }

    const classAttr = classes.join(' ');
    const ariaLabel = values.icon_position === 'icon_only'
        ? (values.aria_label || values.label || '')
        : '';
    const ariaLabelAttr = ariaLabel
            ? ` aria-label="${escapeHtml(ariaLabel)}"`
            : '';
    const disabledAttr = computeDisabled(values);

    switch (values.button_type) {

        case 'a':

            values.button_html = `
                <a class="${classAttr}" href="${escapeAttribute(values.url || '#')}"
                    ${values.target_blank === '1'
                        ? 'target="_blank" rel="noopener"'
                        : ''}
                    ${disabledAttr}
                    ${ariaLabelAttr}>
                    ${values.icon_position === 'icon_only'
                        ? '&nbsp;'
                        : escapeHtml(values.label || '')}
                </a>`;

            break;

        case 'input':

            values.button_html = `
                <input type="button" class="${classAttr}" value="${escapeAttribute(values.label || '')}"
                    ${disabledAttr}
                    ${ariaLabelAttr}>`;

            break;

        case 'button':
        default:

            values.button_html = `
                <button type="button" class="${classAttr}"
                    ${disabledAttr}
                    ${ariaLabelAttr}>
                    ${values.icon_position === 'icon_only'
                        ? '&nbsp;'
                        : escapeHtml(values.label || '')}
                </button>`;

            break;
    }

    return values;
}

/**
 * Détermine l'attribut disabled du bouton
 *
 * @param {object} values Les valeurs du bouton
 * @return {string} Attribut HTML
 */
function computeDisabled(values) {

    if (values.disabled !== '1') {
        return '';
    }

    if (values.button_type === 'a') {
        return 'aria-disabled="true" tabindex="-1"';
    }

    return 'disabled';
}