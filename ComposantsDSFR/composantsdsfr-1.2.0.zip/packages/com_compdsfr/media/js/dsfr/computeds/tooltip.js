import {escapeHtml, escapeAttribute} from '../../utils/html.js';

/**
 * Calcule les valeurs pour le composant Tooltip
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeTooltipValues(values) {

    const tooltipId = `${values.dsfr_id}-tooltip`;

    const trigger = values.trigger || 'hover';
    const support = values.support || 'button';
    const label = (values.label || '').trim();
    const content = escapeHtml(values.content || '');

    let triggerHtml = '';

    /**
     * MODE LIEN
     */
    if (support === 'link') {

        triggerHtml = `
            <a aria-describedby="${tooltipId}" href="${escapeAttribute(values.url || '#')}" class="fr-link">
                ${escapeHtml(label)}
            </a>
        `;
    }

    /**
     * MODE BOUTON SURVOL
     */
    else if (trigger === 'hover') {

        triggerHtml = `
            <button aria-describedby="${tooltipId}" type="button" class="fr-btn">
                ${escapeHtml(label)}
            </button>
        `;
    }

    /**
     * MODE BOUTON CLIC
     */
    else {

        triggerHtml = `
            <button aria-describedby="${tooltipId}" type="button" class="fr-btn fr-btn--tooltip">
                ${escapeHtml(label || 'Infobulle')}
            </button>
        `;
    }

    values.tooltip_html = `
        <div class="fr-tooltip-wrapper">

            ${triggerHtml}

            <span class="fr-tooltip fr-placement" id="${tooltipId}" role="tooltip">
                ${content}
            </span>

        </div>
    `;

    return values;
}