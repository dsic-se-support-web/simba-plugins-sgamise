import { escapeHtml, escapeAttribute } from '../../utils/html.js';

/**
 * Calcule les valeurs pour le composant Tile
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeTileValues(values) {
    const tilesList = values.tiles || [];
    const count = tilesList.length;

    // Si aucune tuile n'est configurée, on retourne un contenu vide
    if (count === 0) {
        values.tiles_html = '';
        return values;
    }

    let colClass = 'fr-col-12';
    if (count === 2) colClass = 'fr-col-md-6';
    if (count === 3) colClass = 'fr-col-md-4';
    if (count === 4) colClass = 'fr-col-md-3';

    const tileClasses = [];

    if (values.enlarge === '1') {
        tileClasses.push('fr-enlarge-link');
    }

    if (values.horizontal === '1') {
        tileClasses.push('fr-tile--horizontal');
    }

    if (values.size && values.size !== 'md') {
        tileClasses.push(`fr-tile--${values.size}`);
    }
    
    // Note : La variation globale est appliquée ici et sera combinée 
    // avec les variations spécifiques à chaque tuile dans buildTile
    if (values.variation) {
        tileClasses.push(`fr-tile--${values.variation}`);
    }

    const innerHtml = tilesList
        .map(tile => buildTile(tile, values, tileClasses.join(' '), colClass))
        .join('');

    // On encapsule la rangée directement dans le JS calculé pour reproduire le comportement de callout
    values.tiles_html = `<div class="fr-grid-row fr-grid-row--gutters">${innerHtml}</div>`;

    return values;
}

/**
 * Construit le HTML d'une tuile
 *
 * @param {object} tile Données de la tuile
 * @param {object} global Données globales
 * @param {string} baseClasses Classes CSS héritées du parent
 * @param {string} colClass Classe de colonne
 * @return {string} HTML de la tuile
 */
function buildTile(tile, global, baseClasses, colClass) {
    const allowedTags = ['h2', 'h3', 'h4', 'h5'];
    const titleTag = allowedTags.includes(global.title_level) ? global.title_level : 'h3';

    // On crée un Set pour éviter toute duplication de classes (ex: variation globale + locale identique)
    const uniqueClasses = new Set(baseClasses.split(' ').filter(Boolean));

    if (tile.download === '1') {
        uniqueClasses.add('fr-tile--download');
    }
    
    if (tile.variation) {
        uniqueClasses.add(`fr-tile--${tile.variation}`);
    }

    const currentClasses = Array.from(uniqueClasses).join(' ');

    let href = '#';
    let extraAttributes = '';

    if (tile.link_type === 'article' && tile.article_url) {
        href = tile.article_url;
    } else if (tile.link_type === 'url') {
        href = tile.url || '#';
    }

    if (tile.download === '1') {
        href = tile.download_url || '#';
        extraAttributes = ' download="" data-fr-assess-file=""';
    }

    const downloadDetail = tile.download === '1'
        ? '<span class="fr-link__detail">bytes</span>'
        : '';

    let descriptionHtml = '';
    if (tile.description) {
        descriptionHtml = `<p class="fr-tile__desc">${escapeHtml(tile.description)}</p>`;
    }

    let detailHtml = '';
    if (tile.detail) {
        detailHtml = `<p class="fr-tile__detail">${escapeHtml(tile.detail)}</p>`;
    }

    let headerHtml = '';
    if (tile.pictogram) {
        headerHtml = `
        <div class="fr-tile__header">
            <div class="fr-tile__pictogram">
                <img src="${escapeAttribute(tile.pictogram)}" class="fr-responsive-img" alt="">
            </div>
        </div>
        `;
    }

    return `
    <div class="${escapeAttribute(colClass)}">
        <div class="fr-tile ${escapeAttribute(currentClasses)}">
            <div class="fr-tile__body">
                <div class="fr-tile__content">
                    <${titleTag} class="fr-tile__title">
                        <a href="${escapeAttribute(href)}"${extraAttributes}>
                            ${escapeHtml(tile.title || '')}
                            ${downloadDetail}
                        </a>
                    </${titleTag}>
                    ${descriptionHtml}
                    ${detailHtml}
                </div>
            </div>
            ${headerHtml}
        </div>
    </div>
    `;
}