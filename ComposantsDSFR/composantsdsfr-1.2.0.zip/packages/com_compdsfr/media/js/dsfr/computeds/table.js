import { escapeHtml } from '../../utils/html.js';

/**
 * Calcule les valeurs pour le composant Table
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeTableValues(values) {

    const cols = parseInt(values.cols || 5, 10);
    const rows = parseInt(values.rows || 5, 10);
    const tableId = values.dsfr_id || `table-${Date.now()}`;
    const classes = ['fr-table'];

    if (values.bordered === '1') {
        classes.push('fr-table--bordered');
    }

    if (values.noScroll === '1') {
        classes.push('fr-table--no-scroll');
    }

    if (values.multiline === '1') {
        classes.push('fr-table--multiline');
    }

    if (values.captionBottom === '1') {
        classes.push('fr-table--caption-bottom');
    }

    if (values.noCaption === '1') {
        classes.push('fr-table--no-caption');
    }

    if (values.size && values.size !== 'md') {
        classes.push(`fr-table--${values.size}`);
    }

    const headHtml = Array.from(
        { length: cols },
        (_, i) => `
            <th scope="col">
                ${escapeHtml(`th${i}`)}
            </th>
        `
    ).join('');

    const bodyHtml = Array.from(
        { length: rows },
        (_, rowIndex) => {

            const cellsHtml = Array.from(
                { length: cols },
                (_, colIndex) => `
                    <td>
                        ${escapeHtml(`Cellule ${rowIndex}-${colIndex}`)}
                    </td>
                `
            ).join('');

            return `
                <tr id="${tableId}-row-${rowIndex + 1}" data-row-key="${rowIndex + 1}">
                    ${cellsHtml}
                </tr>
            `;
        }
    ).join('');

    let captionHtml = '';

    if (values.caption) {

        captionHtml = `
            <caption>
                ${escapeHtml(values.caption)}
        `;

        if (values.captionDetail) {

            captionHtml += `
                <br>
                <span class="fr-text--regular">
                    ${escapeHtml(values.captionDetail)}
                </span>
            `;
        }

        captionHtml += `
            </caption>
        `;
    }

    values.table_html = `
        <div class="${classes.join(' ')}">
            <div class="fr-table__wrapper">
                <div class="fr-table__container">
                    <div class="fr-table__content">

                        <table id="${tableId}">

                            ${captionHtml}

                            <thead>
                                <tr>
                                    ${headHtml}
                                </tr>
                            </thead>

                            <tbody>
                                ${bodyHtml}
                            </tbody>

                        </table>

                    </div>
                </div>
            </div>
        </div>
    `;

    return values;
}