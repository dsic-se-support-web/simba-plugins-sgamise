/**
 * Récupère l'instance TinyMCE associée à un éditeur
 *
 * @param {string} editorId ID de l'éditeur
 * @return {Object|null} Instance TinyMCE ou null
 */
export function getEditor(editorId) {

    return window.parent.tinymce?.get(editorId);
}

/**
 * Récupère le HTML sélectionné dans l'éditeur TinyMCE
 *
 * @param {string} editorId ID de l'éditeur
 * @return {string} HTML sélectionné
 */
export function getSelectedComponentHtml(editorId) {

    try {

        const editor = getEditor(editorId);

        if (!editor) {
            return '';
        }

        let node = editor.selection.getNode();

        if (!node) {
            return '';
        }

        if (node.nodeType === Node.TEXT_NODE) {
            node = node.parentElement;
        }

        let component = null;
        let current = node;

        while (current) {

            if (current.nodeType === 1 && current.hasAttribute('data-dsfr-component')) {
                component = current;
                break;
            }

            current = current.parentElement;
        }

        if (component && component.getAttribute('data-dsfr-component') === 'card') {

            const dsfrId = component.getAttribute('data-dsfr-id');

            if (dsfrId) {

                const root = editor.getBody().querySelector(`[data-dsfr-id="${dsfrId}"]`);

                if (root) {
                    component = root;
                }
            }
        }

        return component?.outerHTML || '';

    } catch (e) {

        console.warn('Erreur TinyMCE', e);

        return '';
    }
}

/**
 * Insère ou remplace un composant dans l'éditeur TinyMCE
 *
 * @param {string} editorId ID de l'éditeur
 * @param {string} html HTML du composant à insérer
 * @return void
 */
export function insertOrReplaceComponent(editorId, html) {

    const editor = getEditor(editorId);

    if (!editor) {
        return;
    }

    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const first = doc.body.firstElementChild;
    const dsfrId = first?.getAttribute('data-dsfr-id');

    if (dsfrId) {

        const existingNode = editor.dom.select(`[data-dsfr-id="${dsfrId}"]`)[0];

        if (existingNode) {

            editor.dom.setOuterHTML(existingNode, html);

            return;
        }
    }

    editor.insertContent(html);
}