/**
 * Effectue une requête HTTP avec parsing JSON
 *
 * @param {string} url URL de la requête
 * @param {Object} options Options supplémentaires
 * @return {Promise<Object>} Réponse JSON
 */
export async function fetchJson(url, options = {}) {

    const response = await fetch(url, options);

    if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
    }

    return response.json();
}