/**
 * Génère un identifiant unique pour les composants DSFR
 *
 * @return {string} ID unique
 */
export function generateDsfrId() {
    return 'dsfr-' + crypto.randomUUID().slice(0, 8);
}