/**
 * Parse des éléments DOM
 *
 * @param {html} Code HTML
 * @return le HTML parsé
 */
export function parseHtml(html) {
    return new DOMParser().parseFromString(html, 'text/html');
}

/**
 * Extrait le premier élément DOM d’un code HTML
 *
 * @param {html} Code HTML
 * @return premier élément DOM
 */
export function getFirstElement(html) {
    return parseHtml(html).body.firstElementChild;
}