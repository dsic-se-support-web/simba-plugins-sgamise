/**
 * Échappe une chaîne pour une insertion dans le HTML
 *
 * @param {string} value
 * @return {string}
 */
export function escapeHtml(value = '') {

    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

/**
 * Échappe une chaîne pour une insertion dans un attribut HTML
 *
 * @param {string} value
 * @return {string}
 */
export function escapeAttribute(value = '') {

    return escapeHtml(value);
}