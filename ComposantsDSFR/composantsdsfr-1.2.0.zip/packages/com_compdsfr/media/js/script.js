import { fetchComponents, parseSelectedComponent }
    from './api/component-api.js';

import { getSelectedComponentHtml, insertOrReplaceComponent }
    from './editor/tinymce-bridge.js';

import { renderForm }
    from './form/renderer.js';

import { updateConditionalFields }
    from './form/conditional-fields.js';

import { generate }
    from './dsfr/generator.js';

import { preview }
    from './dsfr/preview.js';

const editorId = Joomla.getOptions('compdsfr_data').editorId;
let currentComponent = null;
let components = [];


/**
 * Initialisation de l'interface
 */
document.addEventListener('DOMContentLoaded',init);

/**
 * Gestion des événements de clique sur les règles
 */
document.addEventListener('click', event => {
        const toggle = event.target.closest('#guidelines-toggle');

        if (!toggle) {
            return;
        }

        const wrapper = document.getElementById('form-guidelines');

        wrapper.classList.toggle('is-open');
    }
);

/**
 * Initialisation du composant
 *
 * @return void
 */
async function init() {

    components = await fetchComponents();

    buildMenu();

    const selectedHtml = getSelectedHtmlFromUrl() || getSelectedComponentHtml(editorId);

    if (selectedHtml) {
        await loadSelectedComponent(selectedHtml);
    }
}

/**
 * Récupère le HTML sélectionné depuis l'URL
 *
 * @return string Le HTML sélectionné ou une chaîne vide
 */
function getSelectedHtmlFromUrl() {

    const params = new URLSearchParams(window.location.search);
    const encoded = params.get('selected_html');

    if (!encoded) {
        return '';
    }

    const binary = atob(encoded);

    const bytes = Uint8Array.from(
        binary,
        char => char.charCodeAt(0)
    );

    return new TextDecoder().decode(bytes);
}

/**
 * Construction du menu des composants
 * 
 * @return void
 */
function buildMenu() {

    const menu = document.getElementById('component-menu');

    menu.innerHTML = '';

    components.forEach((component, index) => {

        if (!component.label) {
            return;
        }
    
        const btn = document.createElement('button');
    
        btn.type = 'button';
    
        btn.className ='list-group-item list-group-item-action py-3';
        btn.innerText = component.label;
        btn.onclick = () => loadComponent(index);
    
        menu.appendChild(btn);
    });
}

/**
 * Affichage de la description du composant
 *
 * @param {object} description Les données de description
 * @return void
 */
function renderDescription(description = {}) {

    const summaryContainer = document.getElementById('form-summary');
    const guidelines = document.getElementById('form-guidelines');
    const content = document.getElementById('form-description');

    if (!summaryContainer || !guidelines || !content) {
        return;
    }

    // SUMMARY
    summaryContainer.innerText = description.summary || '';

    let html = '';

    if (description.usage) {
        html += `
            <div class="dsfr-desc-block">
                <strong>Bon usage</strong>
                <p>${description.usage}</p>
            </div>
        `;
    }

    if (
        description.reference
        && description.reference.url
    )
    {
        html += `
            <div class="dsfr-desc-block">
                <strong>Références officielles</strong>
                <p>
                    <a href="${description.reference.url}" target="_blank" rel="noopener noreferrer">
                        ${description.reference.label || description.reference.url}
                    </a>
                </p>
            </div>
        `;
    }

    if (description.accessibility) {
        html += `
            <div class="dsfr-desc-block">
                <strong>Accessibilité</strong>
                <p>${description.accessibility}</p>
            </div>
        `;
    }

    if (description.warning) {

        html += `
            <div class="dsfr-desc-block dsfr-desc-warning">
                <strong>Attention</strong>
                <p>${description.warning}</p>
            </div>
        `;
    }

    if (Array.isArray(description.dos) && description.dos.length) {
        html += `
            <div class="dsfr-desc-block">
                <strong>À faire</strong>

                <ul>
                    ${description.dos.map(item => `
                        <li>${item}</li>
                    `).join('')}
                </ul>
            </div>
        `;
    }

    if (Array.isArray(description.donts) && description.donts.length) {
        html += `
            <div class="dsfr-desc-block">
                <strong>À éviter</strong>

                <ul>
                    ${description.donts.map(item => `
                        <li>${item}</li>
                    `).join('')}
                </ul>
            </div>
        `;
    }

    content.innerHTML = html;

    // Affichage du panneau seulement si contenu
    guidelines.classList.toggle('d-none', html.trim() === '');
}

/**
 * Chargement d'un composant spécifique
 *
 * @param {number} index L'index du composant
 * @return void
 */
function loadComponent(index) {

    currentComponent = components[index];

    document.getElementById('form-title').innerText = currentComponent.label;

    renderDescription(currentComponent.description || {});

    document.getElementById('form-actions').classList.remove('d-none');
    document.getElementById('empty-state') ?.classList.add('d-none');
    document.getElementById('form-wrapper') ?.classList.remove('d-none');

    renderForm(currentComponent);
    prefillTooltipLabel();
}

/**
 * Pré-remplissage du libellé pour les infobulles
 *
 * @return void
 */
function prefillTooltipLabel() {

    if (!currentComponent || currentComponent.name !== 'tooltip') {
        return;
    }

    const form = document.getElementById('dynamic-component-form');

    if (!form) {
        return;
    }

    const labelField = form.querySelector('[name="label"]');

    if (!labelField) {
        return;
    }

    // Ne pas écraser une édition existante
    if (labelField.value.trim() !== '') {
        return;
    }

    const selectedText = getPlainSelectedText();

    if (!selectedText) {
        return;
    }

    labelField.value = selectedText;
}

/**
 * Chargement d'un composant sélectionné
 *
 * @param {string} html Le HTML du composant sélectionné
 * @return void
 */
async function loadSelectedComponent(html) {

    const result = await parseSelectedComponent(html);

    if (!result.data) {
        return;
    }

    const parsedData = result.data;

    const componentIndex = components.findIndex(c => c.name === parsedData.component);

    if (componentIndex === -1) {
        return;
    }

    components[componentIndex].values = parsedData;

    loadComponent(componentIndex);

    hydrateForm(parsedData);

    updateConditionalFields(currentComponent);
}

/**
 * Hydratation du formulaire avec les données existantes
 *
 * @param {object} data Les données à utiliser pour remplir le formulaire
 * @return void
 */
function hydrateForm(data) {

    const form = document.getElementById('dynamic-component-form');

    if (!form) {
        return;
    }

    for (const [key, value] of Object.entries(data)) {

        const fields = form.querySelectorAll(`[name="${key}"]`);

        fields.forEach(field => {

            if (field.type === 'radio') {
                field.checked = String(field.value) === String(value);
            } else {
                field.value = value ?? '';
            }
        });
    }
}

/**
 * Génération et insertion du composant
 *
 * @return void
 */
async function genererEtInserer() {

    const html = await generate(currentComponent);

    if (!html) {
        return;
    }

    insertOrReplaceComponent(editorId, html);

    window.parent.Joomla
        ?.Modal
        ?.getCurrent()
        ?.close();
}

/**
 * Extraction du texte sélectionné
 *
 * @return string Le texte sélectionné
 */
function getPlainSelectedText() {

    const selectedHtml = getSelectedComponentHtml(editorId);

    if (!selectedHtml) {
        return '';
    }

    const div = document.createElement('div');

    div.innerHTML = selectedHtml;

    return div.textContent.trim();
}

window.genererEtInserer = genererEtInserer;

window.preview = () => preview(() => generate(currentComponent));