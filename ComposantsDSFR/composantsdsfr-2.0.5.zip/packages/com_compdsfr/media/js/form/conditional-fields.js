import { getFormValues } from './values.js';

/**
 * Lie les champs conditionnels au composant
 *
 * @param {object} component Configuration du composant
 * @return void
 */
export function bindConditionalFields(component) {

    const form = document.getElementById('dynamic-component-form');

    if (!form) {
        return;
    }

    form.addEventListener('change', () => {
        updateConditionalFields(component);
    });

    updateConditionalFields(component);
}

/**
 * Évalue une condition visibleIf
 *
 * @param {object} condition Condition à évaluer
 * @param {object} values Valeurs actuelles du formulaire
 * @return {boolean}
 */
function evaluateCondition(condition, values) {

    if (!condition) {
        return true;
    }

    const fieldValue = values[condition.field];

    switch (condition.operator) {

        case '===':
            return fieldValue === condition.value;

        case '!==':
            return fieldValue !== condition.value;

        default:
            return true;
    }
}

/**
 * Met à jour les champs et options conditionnels selon les valeurs actuelles
 *
 * @param {object} component Configuration du composant
 * @return void
 */
export function updateConditionalFields(component) {

    const form = document.getElementById('dynamic-component-form');

    if (!form) {
        return;
    }

    let values = getFormValues();

    /*
     * INFOBULLE
     * Le lien ne peut être utilisé qu'avec une
     * information contextuelle.
     *
     * Si l'option était précédemment en mode
     * "clic" et sélectionne "Lien", on repasse
     * automatiquement en mode "hover".
     */
    if (values.support === 'link' && values.trigger === 'click') {

        const hoverRadio = form.querySelector('input[name="trigger"][value="hover"]');

        if (hoverRadio) {
            hoverRadio.checked = true;
        }

        values = getFormValues();
    }

    /**
     * Champs conditionnels
     */
    form.querySelectorAll('[data-visible-if]')
        .forEach(el => {

            const raw = el.dataset.visibleIf;

            if (!raw || raw === '""') {
                el.style.display = '';
                return;
            }

            try {

                const condition = JSON.parse(raw);
                const visible = evaluateCondition(condition, values);

                el.style.display = visible ? '' : 'none';

            } catch (e) {

                console.error('visibleIf error', e);
            }
        });

    /**
     * Options conditionnelles
     */
    form.querySelectorAll('[data-option-visible-if]')
        .forEach(el => {

            const raw = el.dataset.optionVisibleIf;

            if (!raw || raw === '""') {
                el.style.display = '';
                return;
            }

            try {

                const condition = JSON.parse(raw);
                const visible = evaluateCondition(condition, values);

                el.style.display = visible ? '' : 'none';

                /**
                 * Une option masquée ne doit pas
                 * rester sélectionnée.
                 */
                const input = el.querySelector('input[type="radio"]');

                if (input) {
                    input.disabled = !visible;

                    if (!visible && input.checked) {
                        input.checked = false;
                    }
                }

            } catch (e) {

                console.error('option visibleIf error', e);
            }
        });
}
