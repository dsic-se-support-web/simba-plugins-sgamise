<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;

class pkg_comdsfrInstallerScript
{
    /**
     * Exécuté après l'installation du package.
     */
    public function postflight(
        string $type,
        InstallerAdapter $adapter
    ): bool {
        if ($type !== 'install') {
            return true;
        }

        $this->enablePlugin('comdsfr', 'editors-xtd');
        $this->enablePlugin('syscomdsfr', 'system');

        return true;
    }

    /**
     * Active une extension de type plugin.
     */
    private function enablePlugin(
        string $element,
        string $folder
    ): void {
        $db = Factory::getContainer()
            ->get(\Joomla\Database\DatabaseInterface::class);

        $query = $db->getQuery(true)
            ->update($db->quoteName('#__extensions'))
            ->set($db->quoteName('enabled') . ' = 1')
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('element') . ' = ' . $db->quote($element))
            ->where($db->quoteName('folder') . ' = ' . $db->quote($folder));

        $db->setQuery($query);
        $db->execute();
    }
}
