import { escapeHtml, escapeAttribute } from '../../utils/html.js';

/**
 * Calcule les valeurs pour le composant Card
 *
 * @param {object} values Les valeurs à calculer
 * @return {object} Les valeurs calculées
 */
export function computeCardValues(values) {

    const cardsList = values.cards || [];
    const count = cardsList.length;

    if (count === 0) {
        values.cards_html = '';

        return values;
    }

    let colClass = 'fr-col-12';

    if (count === 1) colClass = 'fr-col-md-3';
    if (count === 2) colClass = 'fr-col-md-6';
    if (count === 3) colClass = 'fr-col-md-4';
    if (count === 4) colClass = 'fr-col-md-3';

    const cardClasses = [];

    if (values.enlarge === '1') {
        cardClasses.push('fr-enlarge-link');
    }

    if (values.size && values.size !== 'md') {
        cardClasses.push(`fr-card--${values.size}`);
    }

    if (values.horizontal === '1') {
        cardClasses.push('fr-card--horizontal');
    }

    if (values.variant) {
        cardClasses.push(`fr-card--${values.variant}`);
    }

    const innerHtml = cardsList
        .map(card => buildCard(card, values, cardClasses.join(' '), colClass))
        .join('');

    values.cards_html = `<div class="fr-grid-row fr-grid-row--gutters">${innerHtml}</div>`;

    return values;
}

/**
 * Construit le HTML d'une carte
 *
 * @param {object} card Données de la carte
 * @param {object} global Données globales
 * @param {string} baseClasses Classes héritées
 * @param {string} colClass Classe de colonne
 * @return {string} HTML de la carte
 */
function buildCard(card, global, baseClasses, colClass) {

    const allowedTags = ['h2', 'h3', 'h4', 'h5'];
    const titleTag = allowedTags.includes(global.title_level)
        ? global.title_level
        : 'h3';
    const uniqueClasses = new Set(baseClasses.split(' ').filter(Boolean));
    const currentClasses = Array.from(uniqueClasses).join(' ');

    let href = '#';

    if (card.link_type === 'article' && card.article_url) {
        href = card.article_url;
    } else if (card.link_type === 'url') {
        href = card.url || '#';
    } else if (card.link_type === 'download') {
        href = card.download_url || '#';
    }

    let targetAttr = '';

    if (card.target_blank === '1') {
        targetAttr = ' target="_blank" rel="noopener"';
    }

    let imageHtml = '';

    if (card.image_url) {
        imageHtml = `
            <div class="fr-card__header">
                <div class="fr-card__img">
                    <img class="fr-responsive-img" src="${escapeAttribute(card.image_url)}" alt="${escapeAttribute(card.image_alt || '')}">
                </div>
            </div>
        `;
    }

    let descriptionHtml = '';

    if (card.description) {
        descriptionHtml = `
            <p class="fr-card__desc">
                ${escapeHtml(card.description)}
            </p>
        `;
    }

    let detailHtml = '';

    if (card.detail) {
        detailHtml = `
            <div class="fr-card__end">
                <ul class="fr-card__detail">
                    <li>${escapeHtml(card.detail)}</li>
                </ul>
            </div>
        `;
    }

    return `
        <div class="${escapeAttribute(colClass)}">
            <div class="fr-card ${escapeAttribute(currentClasses)}">
                <div class="fr-card__body">
                    <div class="fr-card__content">

                        <${titleTag} class="fr-card__title">

                            <a href="${escapeAttribute(href)}"${targetAttr}>
                                ${escapeHtml(card.title || '')}
                            </a>

                        </${titleTag}>

                        ${descriptionHtml}

                        ${detailHtml}

                    </div>
                </div>

                ${imageHtml}

            </div>
        </div>
    `;
}