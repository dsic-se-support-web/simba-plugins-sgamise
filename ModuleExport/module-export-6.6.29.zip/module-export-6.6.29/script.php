<?php
// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Version;


/**
 * Script file for the ModuleExport plugin.
 * This class handles actions during installation, update, and uninstallation.
 */
class plg_system_moduleexportInstallerScript
{
    /**
     * Vérifie la compatibilité avant installation/upgrade.
     */
    public function preflight($type, $parent)
    {
        $version = new Version();
        // Le plugin 6.5.x est annoncé comme compatible Joomla 5 uniquement
        if (version_compare($version->getShortVersion(), '5.0', '<')) {
            Factory::getApplication()->enqueueMessage(
                'Le plugin SIMBA Module-Export 6.5 requiert Joomla 5.x. Installation annulée.',
                'error'
            );
            return false;
        }
        return true;
    }

    /**
     * Method to run after an install or update action.
     * It adds a confirmation message to the Joomla message queue.
     *
     * @param   string            $type    The type of change (install, update, or discover_install).
     * @param   InstallerAdapter  $parent  The class calling this method, which gives access to the manifest.
     *
     * @return  void
     */
    public function postflight($type, $parent)
    {
        if ($type === 'install') {
            $version = $parent->get('manifest')->version;
            Factory::getApplication()->enqueueMessage(
                "Le plugin SIMBA Module-Export (v{$version}) a été installé avec succès. Les boutons 'Exporter' et 'Importer' sont maintenant disponibles dans le gestionnaire de modules.",
                'message'
            );
        } elseif ($type === 'update') {
            $version = $parent->get('manifest')->version;
            Factory::getApplication()->enqueueMessage("Le plugin SIMBA Module-Export a été mis à jour avec succès vers la version {$version}.", 'message');
        }
    }
}
