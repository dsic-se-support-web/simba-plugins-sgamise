# Plugin d'export et d'import — Assistant de migration DSFR

Ce plugin est un assistant de migration autonome. Il permet d'exporter et d'importer le contenu de modules Joomla afin de simplifier la transition du thème **DSFR partiellement intégré** (thème enfant DSFR 1.0) vers le **DSFR complet**.

---

## Prérequis et compatibilité

Avant de commencer la migration, assurez-vous que votre environnement répond aux conditions suivantes :

| Élément | Version requise |
|---|---|
| Joomla | 4.x ou supérieur |
| PHP | 8.1 ou supérieur |
| Plugin SIMBA_Module-Export | v6.30 |
| Thème source | DSFR enfant 1.0 |
| Thème cible | DSFR complet |

> ⚠️ **Important :** Effectuez toujours une sauvegarde complète de votre site avant de démarrer la migration.

---

## Problèmes connus du thème enfant DSFR 1.0

Le thème enfant DSFR 1.0 présente plusieurs limitations que ce plugin a pour objectif de corriger lors de la migration vers le DSFR complet :

- **Menu principal** : le menu reste affiché en position dépliée par défaut.
- **Sous-menu de niveau 3** : le sous-menu ne reste pas ouvert dans la navigation latérale.
- **Fil d'Ariane** : la structure HTML du fil d'Ariane ne respecte pas les spécifications DSFR.
- **Thème sombre** : le mode sombre n'est pas intégré au thème enfant.
- **Moteur de recherche** : les filtres de recherche sont absents de l'affichage.
- **Accessibilité** : le thème n'est pas conforme aux référentiels RGAA / WCAG.

---



## Suivi des évolutions

- v6.6.16 Application automatique classe Twitter entièrement fonctionnelle
- v6.6.17 Intermédiaire — fixes session Mars 2026
- v6.6.18 Intermédiaire — fixes session Mars 2026
- v6.6.19 Badge SIMBA masqué si état ok ou idle
- v6.6.20 Renommage checklist étape 1 — IDs et libellés courts cohérents, ordre logique
- v6.6.21 Fix PHP E_ALL (ini_set display_errors), SIMBA auto-apply déclenché automatiquement
- v6.6.22 Recherche module Titre en 3 niveaux (exact → LIKE → signature DSFR)
- v6.6.23 Intermédiaire — fixes session Avril 2026
- v6.6.24 Intermédiaire — fixes session Avril 2026
- v6.6.25 Fallback ZIP natif → API Joomla, indicateur méthode, paramètre show_theme_dropzone
- v6.6.26 Bump de version (pas de modification fonctionnelle)
- v6.6.27 Tuile "Alertes Bootstrap" étape 2 — détection alert alert-* avec badges colorés DSFR
- v6.6.28 Renommage tuile "Alertes Bootstrap" → "Alertes (fr-alerte)"
- v6.6.29 Correction orthographe : "fr-alerte" → "fr-alert" (classe CSS DSFR exacte)
- v6.6.30 Migration auto alertes Bootstrap→DSFR + migration fr-card (3 passes DOMDocument), lazy loading inventaire, correction XPath, gestion images, suppression commentaires, export CSV corrigé


- **Thème cible :** DSFR complet
- **Documentation DSFR :** [https://www.systeme-de-design.gouv.fr](https://www.systeme-de-design.gouv.fr)