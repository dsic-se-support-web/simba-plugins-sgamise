<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.ModuleExport
 * @version     (see moduleexport.xml)
 */
defined('_JEXEC') or die;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Response\JsonResponse;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Filter\InputFilter;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Installer\Installer;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\Archive\Archive as JoomlaArchive;

require_once __DIR__ . '/src/Utility/TableFactory.php';

class PlgSystemModuleExport extends CMSPlugin
{
    protected $app;

    /** @var string|null Version mise en cache */
    private static ?string $cachedVersion = null;
    /** @var ModuleExportLogger|null */
    private $logger = null;

    /**
     * Retourne un logger réutilisable (paresseux) pour tout le plugin.
     */
    private function getLogger()
    {
        if ($this->logger === null) {
            require_once __DIR__ . '/src/Utility/Logger.php';
            $debug = (int) $this->params->get('debug', 0) === 1;
            $this->logger = new ModuleExportLogger($debug);
        }
        return $this->logger;
    }

    /**
     * Récupère la version du plugin avec mise en cache
     * @return string
     */
    private function getPluginVersion(): string
    {
        if (self::$cachedVersion === null) {
            $xmlFile = JPATH_PLUGINS . '/system/moduleexport/moduleexport.xml';
            if (file_exists($xmlFile)) {
                $xml = @simplexml_load_file($xmlFile);
                self::$cachedVersion = ($xml && $xml->version) ? (string) $xml->version : 'N/A';
            } else {
                self::$cachedVersion = 'N/A';
            }
        }
        return self::$cachedVersion;
    }

    /**
     * Ajoute les boutons Export et Import dans la toolbar
     */
    public function onAfterRender()
    {
        // Empêcher toute notice/warning PHP de s'insérer dans le HTML/JS injecté
        $prevDisplayErrors = ini_get('display_errors');
        ini_set('display_errors', '0');

        // Initialisation du log de débogage pour onAfterRender
        $this->ensureLogDirExists();
        // Utilise le répertoire de logs Joomla (/logs/moduleexport)
        $logDir = JPATH_ROOT . '/logs/moduleexport';
        $renderLogFile = $logDir . '/render_debug.log';

        // Helper pour logger
        // Initialisation de la vérification du debug tôt pour éviter les IO inutiles
        $app = Factory::getApplication();
        $input = $app->input;
        // Debug activé soit par le paramètre plugin, soit par ?debug=1
        $debugParam = (int) $this->params->get('debug', 0);
        $debugRequest = $input->getInt('debug', 0);
        $debug = ($debugParam === 1) || ($debugRequest === 1);

        // Helper pour logger (conditionné au debug)
        $log = function ($msg) use ($renderLogFile, $debug) {
            if ($debug) {
                file_put_contents($renderLogFile, date('Y-m-d H:i:s') . " | " . $msg . "\n", FILE_APPEND);
            }
        };

        try {
            $log("=== onAfterRender Start ===");
            $app = Factory::getApplication();
            $appName = method_exists($app, 'getName') ? $app->getName() : 'unknown';
            $isAdm = method_exists($app, 'isClient') ? ($app->isClient('administrator') ? 'YES' : 'NO') : 'N/A';
            $log("Application: Name=[$appName], isClient('administrator')=[$isAdm]");

            if ($isAdm === 'NO' || ($isAdm === 'N/A' && method_exists($app, 'isAdmin') && !$app->isAdmin())) {
                $log("Not administrator client. Option check aborted.");
                // Debug front léger si ?debug=1 est présent dans l'URL
                $input = $app->input;
                $this->injectFrontSearchFallback($app, $input->getInt('debug', 0) === 1);
                return;
            }
            $log("Is administrator client");
            $input = $app->input;
            $option = $input->getCmd('option');
            $view = $input->getCmd('view');
            $task = $input->getCmd('task');
            $method = $input->getMethod();

            $log("Context: Option=[$option] View=[$view] Task=[$task] Method=[$method]");

            // Vérification stricte du type de document
            $doc = $this->app->getDocument();
            $log("Document retrieved");
            $docType = $doc->getType();
            $log("Document Type: [$docType]");

            if ($docType !== 'html') {
                $log("Aborting: Document type is not html.");
                return;
            }

            // Vérification AJAX supplémentaire
            $isAjax = $input->server->get('HTTP_X_REQUESTED_WITH') === 'XMLHttpRequest';
            $log("Is AJAX: " . ($isAjax ? 'YES' : 'NO'));

            if ($isAjax) {
                $log("Aborting: AJAX request detected.");
                return;
            }
            $format = $input->getCmd('format', 'html');
            $log("Format: [$format]");

            if ($format !== 'html') {
                $log("Aborting: Format is not html.");
                return;
            }

            // Log de début d'exécution si le debug est activé
            if ($this->params->get('debug', 0)) {
                file_put_contents($renderLogFile, date('Y-m-d H:i:s') . " [INFO] onAfterRender start. Option: $option, View: " . $input->getCmd('view') . "\n", FILE_APPEND);
            }

            $isConditionsInstalled = \Joomla\CMS\Component\ComponentHelper::isEnabled('com_conditions');

            // Protection accès params
            $log("Reading params...");
            $handleRlConditions = $this->params->get('handle_rl_conditions', 1);
            $showThemeDropzone = (int) $this->params->get('show_theme_dropzone', 1);
            // Debug activé soit par le paramètre plugin, soit par ?debug=1
            $debugParam = (int) $this->params->get('debug', 0);
            $debugRequest = $input->getInt('debug', 0);
            $debug = ($debugParam === 1) || ($debugRequest === 1);
            $log("Params read. Debug param: $debugParam | debug query: $debugRequest | Effective debug: " . ($debug ? 'YES' : 'NO'));

            // Autoriser le plugin à s'exécuter sur les deux gestionnaires de modules
            $allowedOptions = ['com_modules', 'com_advancedmodules'];

            if (!in_array($option, $allowedOptions)) {
                $log("Aborting: Option not allowed.");
                return;
            }

            $log("Getting Body...");
            $body = $app->getBody();
            $log("Body retrieved. Length: " . strlen($body));

            // Utiliser la version mise en cache
            $version = $this->getPluginVersion();

            $conditionsStr = $isConditionsInstalled ? 'true' : 'false';
            $handleRlConditionsStr = $handleRlConditions ? 'true' : 'false';
            $showThemeDropzoneStr = $showThemeDropzone ? 'true' : 'false';

            $debugStr = $debug ? 'true' : 'false';
            // --- MARQUEUR DE DÉBOGAGE (VÉRIFIE L'EXÉCUTION DU PHP) ---

            // Récupérer les mots-clés pour l'auto-détection
            $autodetectKeywords = $this->params->get('autodetect_keywords', '');

            // Récupérer la hauteur de la modale
            $modalHeight = (int) $this->params->get('modal_height', 400);

            $debugMarker = "<!-- ModuleExport Plugin v{$version} Loaded -->\n";
            $debugBanner = $debug ? "<div id='me-debug-banner' style='position:fixed;bottom:10px;right:10px;background:rgba(0,0,0,0.8);color:white;padding:5px 10px;font-size:10px;border-radius:5px;z-index:9999;pointer-events:none;'>ME v{$version} Active</div>" : "";
            // -----------------------------------------------------------
            $log("Preparing script injection...");
            // Récupération des templates et du chemin user.css
            try {
                $db = Factory::getDbo();
                // Inclure la colonne "parent" si disponible (Joomla 4+/5) pour l'état du thème parent
                $columns = $db->getTableColumns('#__template_styles');
                $selects = ['id', 'title', 'template', 'home'];
                if (isset($columns['parent'])) {
                    $selects[] = 'parent';
                }

                $query = $db->getQuery(true)
                    ->select($db->quoteName($selects))
                    ->from($db->quoteName('#__template_styles'))
                    ->where($db->quoteName('client_id') . ' = 0')
                    ->order($db->quoteName('title'));
                $allTemplates = $db->setQuery($query)->loadObjectList();

                $activeTemplatePath = 'Erreur: Template actif non trouvé.';
                foreach ($allTemplates as $template) {
                    if ($template->home == 1) {
                        $activeTemplatePath = 'templates/' . $template->template . '/css/user.css';
                        break;
                    }
                }

            } catch (Throwable $t) {
                file_put_contents(JPATH_ROOT . '/logs/moduleexport/render_debug.log', date('Y-m-d H:i:s') . " | ❌ FATAL ERROR: " . $t->getMessage() . " in " . $t->getFile() . ":" . $t->getLine() . "\n", FILE_APPEND);
                $allTemplates = [];
                $activeTemplatePath = 'Erreur : ' . $t->getMessage();
            }

            // Chemins des assets
            $pluginPath = 'plugins/system/moduleexport/';
            $cssUrl = Uri::root() . $pluginPath . 'assets/css/moduleexport.css';
            $cssPathAbsolute = JPATH_ROOT . '/' . $pluginPath . 'assets/css/moduleexport.css';
            $utilsUrl = Uri::root() . $pluginPath . 'assets/js/utils.js';

            // Choisir le JS minifié si disponible et si le debug est désactivé
            $jsRelativePath = (!$debug && file_exists(JPATH_ROOT . '/' . $pluginPath . 'assets/js/moduleexport.min.js'))
                ? 'assets/js/moduleexport.min.js'
                : 'assets/js/moduleexport.js';
            $jsPathAbsolute = JPATH_ROOT . '/' . $pluginPath . $jsRelativePath;
            $log("JS selected: $jsRelativePath (debug=" . ($debug ? 'on' : 'off') . ")");

            $log("=== ASSETS LOADING DEBUG ===");
            $log("Plugin path: $pluginPath");
            $log("JPATH_ROOT: " . JPATH_ROOT);
            $log("Uri::root(): " . Uri::root());
            $log("CSS URL: $cssUrl");
            $log("CSS Path: $cssPathAbsolute");
            $log("CSS file exists: " . (file_exists($cssPathAbsolute) ? 'YES ✅' : 'NO ❌'));
            if (file_exists($cssPathAbsolute)) {
                $log("CSS file size: " . filesize($cssPathAbsolute) . " bytes");
            }
            $log("JS Path: $jsPathAbsolute");
            $log("JS file exists: " . (file_exists($jsPathAbsolute) ? 'YES ✅' : 'NO ❌'));
            if (file_exists($jsPathAbsolute)) {
                $log("JS file size: " . filesize($jsPathAbsolute) . " bytes");
            }

            // NOTE: Dans onAfterRender, le <head> est déjà fermé
            // On injecte donc la balise <link> directement dans le body
            $log("CSS will be injected as <link> tag in body (head already closed in onAfterRender)");

            // Charger le contenu du fichier JavaScript
            if (!file_exists($jsPathAbsolute)) {
                $log("❌ ERROR: JavaScript file not found at: $jsPathAbsolute");
                return;
            }

            $jsContent = file_get_contents($jsPathAbsolute);
            $log("✅ JavaScript loaded successfully (" . strlen($jsContent) . " characters)");

            // Remplacement des placeholders dans le JavaScript
            $log("=== PLACEHOLDER REPLACEMENT ===");
            $placeholders = [
                '__DEBUG_VALUE__' => $debugStr,
                '__VERSION_VALUE__' => json_encode($version),
                '__JOOMLA_VERSION__' => json_encode(JVERSION),
                '__CONDITIONS_INSTALLED__' => $conditionsStr,
                '__HANDLE_RL_CONDITIONS__' => $handleRlConditionsStr,
                '__SHOW_THEME_DROPZONE__' => $showThemeDropzoneStr,
                '__MODAL_HEIGHT__' => $modalHeight
            ];

            foreach ($placeholders as $placeholder => $value) {
                $before = substr_count($jsContent, $placeholder);
                $jsContent = str_replace($placeholder, $value, $jsContent);
                $after = substr_count($jsContent, $placeholder);
                $log("$placeholder: found=$before, replaced=" . ($before - $after));
            }

            $jsContent = str_replace('__USER_CSS_PATH__', json_encode($activeTemplatePath), $jsContent);
            $jsContent = str_replace('__ALL_TEMPLATES__', json_encode($allTemplates), $jsContent);
            // Injecter les variables PHP dans le JS
            $defaultJsonUrl = Uri::root() . 'plugins/system/moduleexport/assets/json/export_modules_dsfr.json';
            $menuMappingDefaultUrl = Uri::root() . 'plugins/system/moduleexport/assets/json/menu_mapping_simba.json';
            $menuMappingEmbedded = '""';
            $embeddedPath = __DIR__ . '/assets/json/menu_mapping_simba.json';
            if (is_file($embeddedPath)) {
                $raw = file_get_contents($embeddedPath);
                // json_encode pour sérialiser proprement en JS (gère guillemets et sauts de ligne)
                $menuMappingEmbedded = json_encode($raw, JSON_UNESCAPED_SLASHES);
            }
            $jsContent = "const DEFAULT_JSON_URL = " . json_encode($defaultJsonUrl) . ";\nconst MENU_MAPPING_DEFAULT_URL = " . json_encode($menuMappingDefaultUrl) . ";\nconst MENU_MAPPING_EMBEDDED = $menuMappingEmbedded;\n" . $jsContent;

            $jsContent = str_replace('__AUTODETECT_MODULE_ID__', json_encode($this->params->get('autodetect_module_id', '')), $jsContent);

            // Transformer la chaîne de mots-clés en un tableau JS
            $keywordsArray = array_filter(array_map('trim', explode("\n", $autodetectKeywords)));
            $jsContent = str_replace('__AUTODETECT_KEYWORDS__', json_encode($keywordsArray), $jsContent);

            $log("✅ All placeholders replaced");

            // Construire le code à injecter : CSS externe + JavaScript inline
            $injection = <<<HTML
    <!-- ModuleExport CSS (fichier externe) -->
    <link rel="stylesheet" href="$cssUrl">
    <!-- ModuleExport utilitaires JS -->
    <script src="$utilsUrl"></script>
    <!-- ModuleExport JavaScript (inline avec placeholders remplacés) -->
    <script>
$jsContent
    </script>
HTML;

            $log("Injecting CSS link and JavaScript into body...");
            $log("CSS URL to inject: $cssUrl");
            $pos = strpos($body, '</body>');
            if ($pos === false) {
                $log("❌ ERROR: </body> tag NOT found in body output! Injection aborted.");
                // Tentative d'injection forcée à la fin si nécessaire ? Non, log d'abord.
            } else {
                $log("✅ </body> tag found at position $pos. Proceeding with replacement.");
            }
            $body = str_replace('</body>', $debugMarker . $debugBanner . $injection . "\n</body>", $body);
            $app->setBody($body);
            $log("✅ Body updated successfully (Length: " . strlen($body) . ")");

            // ═══════════════════════════════════════════════════════════════
            // INJECTION DU PANNEAU DE DÉBOGAGE SUR LA PAGE D'ÉDITION DU MODULE
            // ═══════════════════════════════════════════════════════════════
            $view = $input->getCmd('view');
            $layout = $input->getCmd('layout');
            $id = $input->getInt('id');

            if ($debug && $option === 'com_modules' && $view === 'module' && $layout === 'edit' && $id > 0) {
                try {
                    $db = Factory::getDbo();

                    // 1. Données du module et paramètres
                    $query = $db->getQuery(true)->select('*')->from($db->quoteName('#__modules'))->where($db->quoteName('id') . ' = ' . (int) $id);
                    $module = $db->setQuery($query)->loadObject();
                    if (!$module) {
                        throw new \RuntimeException("Module ID {$id} introuvable en base.");
                    }
                    $moduleParams = json_decode($module->params, true) ?: [];
                    $jsonError = json_last_error();
                    $jsonMsg = json_last_error_msg();

                    // 2. Assignations de menu
                    $query = $db->getQuery(true)->select('*')->from($db->quoteName('#__modules_menu'))->where($db->quoteName('moduleid') . ' = ' . (int) $id);
                    $menuAssignments = $db->setQuery($query)->loadObjectList();

                    // 4. Données Regular Labs (RL)
                    $rlData = null;
                    if ($isConditionsInstalled && isset($moduleParams['conditions_assignment_id']) && (int) $moduleParams['conditions_assignment_id'] > 0) {
                        $conditionGroupId = (int) $moduleParams['conditions_assignment_id'];
                        $query = $db->getQuery(true)->select('*')->from($db->quoteName('#__conditions'))->where($db->quoteName('id') . ' = ' . $conditionGroupId);
                        $rlGroup = $db->setQuery($query)->loadObject();

                        $query = $db->getQuery(true)->select('*')->from($db->quoteName('#__conditions_rules'))->where($db->quoteName('group_id') . ' = ' . $conditionGroupId);
                        $rlRules = $db->setQuery($query)->loadObjectList();
                        $rlData = ['group' => $rlGroup, 'rules' => $rlRules];
                    }

                    // Fonction pour formater le dump
                    $formatDump = function ($title, $data) {
                        if ($data === null) {
                            return "<h4>{$title}</h4><div class='alert alert-warning'>Non applicable ou non trouvé.</div>";
                        }
                        $dump = htmlspecialchars(print_r($data, true), ENT_QUOTES, 'UTF-8');
                        return "<h4>{$title}</h4><pre style='white-space: pre-wrap; word-break: break-all; background-color: #f8f9fa; border: 1px solid #dee2e6; padding: 1rem; border-radius: .25rem; max-height: 400px; overflow-y: auto;'>{$dump}</pre>";
                    };

                    $paramsStatus = ($jsonError === JSON_ERROR_NONE)
                        ? '<span class="badge bg-success">JSON Valide</span>'
                        : '<span class="badge bg-danger">JSON Invalide : ' . $jsonMsg . '</span>';

                    // Construction du HTML
                    $debugPanel = "
                        <div class='alert alert-primary mt-3' id='module-export-debug-panel'>
                            <h3 class='alert-heading'>[ModuleExport] Panneau de débogage (Module ID: {$id})</h3>
                            <p>Ces informations sont visibles car le mode débogage du plugin est activé.</p>
                            <hr>
                            <div class='row'>
                                <div class='col-md-6'>{$formatDump('Assignations de Menu (#__modules_menu)', $menuAssignments)}</div>
                                <div class='col-md-6'>
                                    {$formatDump('Paramètres du module (décodés)', $moduleParams)}
                                    <div class='mt-2'><strong>Statut JSON params :</strong> {$paramsStatus}</div>
                                    <details class='mt-2'>
                                        <summary class='text-muted' style='cursor:pointer;'>Voir le JSON brut en base</summary>
                                        <pre class='mt-2 p-2 bg-light border' style='font-size: 0.85rem; white-space: pre-wrap; word-break: break-all;'>" . htmlspecialchars($module->params) . "</pre>
                                    </details>
                                </div>
                            </div>
                            <hr>
                            <div class='row'>
                                <div class='col-md-6'>{$formatDump('Données Regular Labs Conditions (#__conditions & #__conditions_rules)', $rlData)}</div>
                            </div>
                            <hr>
                            <div class='row'>
                                <div class='col-12'>{$formatDump('Données brutes du module (#__modules)', $module)}</div>
                            </div>
                        </div>
                    ";

                    // Injection du panneau juste après le header de la page
                    $body = $app->getBody();
                    $body = preg_replace('/(<div class="page-header">.*?<\/div>)/s', '$1' . $debugPanel, $body, 1);
                    $app->setBody($body);

                } catch (Exception $e) {
                    // En cas d'erreur, on ne bloque pas la page
                    $app->enqueueMessage('Erreur lors de la génération du panneau de débogage ModuleExport : ' . $e->getMessage(), 'error');
                }
            }
        } catch (\Throwable $e) {
            // Capture globale des erreurs dans onAfterRender pour éviter de casser le site
            file_put_contents($renderLogFile, date('Y-m-d H:i:s') . " [CRITICAL ERROR in onAfterRender] " . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n", FILE_APPEND);
            $log("!!! CRITICAL ERROR !!! " . $e->getMessage());
            $log($e->getTraceAsString());
        }

        ini_set('display_errors', $prevDisplayErrors);
    }

    /**
     * Gestion des tâches d'export/import
     */
    public function onAfterRoute()
    {
        // Vérification de sécurité : Détecter une sortie prématurée (ex: espaces avant <?php)
        if (headers_sent($file, $line)) {
            $this->ensureLogDirExists();
            $logDir = JPATH_ROOT . '/logs/moduleexport';
            file_put_contents($logDir . '/headers_error.log', date('Y-m-d H:i:s') . " [CRITICAL] En-têtes déjà envoyés depuis $file:$line. Vérifiez l'absence d'espaces avant <?php.\n", FILE_APPEND);
        }

        $app = Factory::getApplication();
        if (!$app->isClient('administrator')) {
            return;
        }
        $input = $app->input;
        $task = $input->getCmd('task');

        // Définir le fichier de débogage
        // Dossier de logs centralisé
        $logDir = JPATH_ROOT . '/logs/moduleexport';
        // Debug activé soit par le paramètre plugin, soit par ?debug=1
        $debug = ((int) $this->params->get('debug', 0) === 1) || ($input->getInt('debug', 0) === 1);
        $debugFile = '';

        // ✅ NOUVELLE LOGIQUE D'ARCHIVAGE : Crée un fichier de log unique par session d'import
        $logTimestamp = $input->getString('log_timestamp', '');
        if ($debug) {
            $this->ensureLogDirExists();
            if ($task === 'module.importmodule' && !empty($logTimestamp)) {
                $debugFile = $logDir . '/import_' . $logTimestamp . '.log';
            } else {
                $debugFile = $logDir . '/moduleexport_other_tasks.log';
            }
        }


        $option = $input->getCmd('option');
        $format = $input->getCmd('format');
        if ($format !== 'json' || !in_array($task, ['module.exportmodule', 'module.importmodule', 'module.importchunk', 'module.getcontent', 'module.checkids', 'module.getmaxid', 'module.searchbytitle', 'module.toggleUserCss', 'module.clearJoomlaCache', 'module.clearModuleTrash', 'module.getUserCssStatus', 'module.deployThemeZip', 'module.getInventory', 'module.getTemplateStatus', 'module.getTemplateParams', 'module.getTinyMceParams', 'module.saveTinyMceParams', 'module.uninstallTemplate', 'module.checkandfixdb', 'module.saveParentThemeZip', 'module.saveDynamicReplaceConfig', 'module.applymenumapping', 'module.applyLateralModel', 'module.applyAlertMigration', 'module.applyFrcardMigration', 'module.getInventoryHeavy', 'module.getTwitterMenuClass', 'module.setTwitterMenuClass', 'module.renamemodule', 'module.checkZipMethod'])) {
            return;
        }

        try {
            // Log de la tâche exécutée
            if ($debug && !empty($debugFile)) {
                file_put_contents($debugFile, "--- [START TASK] ---\n" . date('Y-m-d H:i:s') . " | Tâche: {$task} | Option: {$option}\n", FILE_APPEND);
                file_put_contents($debugFile, "Log file location: {$debugFile}\n", FILE_APPEND);
            }

            $isConditionsInstalled = \Joomla\CMS\Component\ComponentHelper::isEnabled('com_conditions');
            $handleRlConditions = $this->params->get('handle_rl_conditions', 1);

            // Nouvelle tâche pour récupérer le contenu d'un module
            if ($task === 'module.getcontent') {
                if (!$this->validateCsrfToken(false, $debug, $debugFile))
                    return;

                $id = $input->getInt('id');
                $idsRaw = $input->getString('ids', '');

                if (!$id && empty($idsRaw)) {
                    $this->sendCleanJsonResponse(['message' => 'ID(s) manquant(s).'], true);
                    return;
                }
                try {
                    $db = Factory::getDbo();

                    if (!empty($idsRaw)) {
                        // Mode Batch (plusieurs IDs)
                        $ids = json_decode($idsRaw, true);
                        if (!is_array($ids))
                            $ids = [];
                        $ids = array_map('intval', $ids);
                        $ids = array_filter($ids); // Enlever les 0

                        if (empty($ids)) {
                            $this->sendCleanJsonResponse(['success' => true, 'data' => []]);
                            return;
                        }

                        $query = $db->getQuery(true)
                            ->select($db->quoteName(['id', 'content', 'title']))
                            ->from($db->quoteName('#__modules'))
                            ->where($db->quoteName('id') . ' IN (' . implode(',', $ids) . ')');
                        $modules = $db->setQuery($query)->loadObjectList('id');

                        $this->sendCleanJsonResponse(['success' => true, 'data' => $modules]);
                    } else {
                        // Mode Single (comportement original)
                        $query = $db->getQuery(true)
                            ->select($db->quoteName(['content', 'title']))
                            ->from($db->quoteName('#__modules'))
                            ->where($db->quoteName('id') . ' = ' . (int) $id);
                        $module = $db->setQuery($query)->loadObject();
                        $this->sendCleanJsonResponse(['success' => true, 'data' => $module]);
                    }
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur: ' . $e->getMessage()], true);
                }
            }

            // Tâche légère : détecte le moteur de décompression ZIP disponible
            if ($task === 'module.checkZipMethod') {
                if (!$this->validateCsrfToken(false, $debug, $debugFile))
                    return;
                $method  = class_exists('ZipArchive') ? 'ZipArchive' : 'Joomla\\Archive';
                $label   = class_exists('ZipArchive') ? 'ZipArchive (natif PHP)' : 'API Joomla (pur PHP)';
                $this->sendCleanJsonResponse(['success' => true, 'data' => ['method' => $method, 'label' => $label]]);
                return;
            }

            // Nouvelle tâche pour vérifier l'existence d'IDs de modules en base
            if ($task === 'module.checkids') {
                if (!$this->validateCsrfToken(false, $debug, $debugFile))
                    return;

                $idsRaw = $input->getString('ids', '');
                $ids = [];
                if (!empty($idsRaw)) {
                    $decoded = json_decode($idsRaw, true);
                    if (is_array($decoded)) {
                        $ids = $decoded;
                    } else {
                        $ids = preg_split('/[,\s]+/', $idsRaw);
                    }
                }

                $ids = array_unique(array_filter(array_map(function ($v) {
                    return (int) $v;
                }, $ids), function ($v) {
                    return $v > 0;
                }));

                if (empty($ids)) {
                    $this->sendCleanJsonResponse(['success' => true, 'data' => ['found' => []]]);
                    return;
                }

                try {
                    $db = Factory::getDbo();
                    $query = $db->getQuery(true)
                        ->select($db->quoteName(['id', 'title', 'module', 'client_id']))
                        ->from($db->quoteName('#__modules'))
                        ->where($db->quoteName('id') . ' IN (' . implode(',', $ids) . ')');

                    $rows = $db->setQuery($query)->loadObjectList();
                    $found = [];
                    foreach ($rows as $row) {
                        $found[(string) $row->id] = [
                            'title' => $row->title,
                            'module' => $row->module,
                            'client_id' => (int) $row->client_id
                        ];
                    }

                    $this->sendCleanJsonResponse(['success' => true, 'data' => ['found' => $found]]);
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur: ' . $e->getMessage()], true);
                }
            }

            // Nouvelle tâche pour récupérer le max ID en base
            if ($task === 'module.getmaxid') {
                if (!$this->validateCsrfToken(false, $debug, $debugFile))
                    return;

                try {
                    $db = Factory::getDbo();
                    $query = $db->getQuery(true)
                        ->select('MAX(' . $db->quoteName('id') . ')')
                        ->from($db->quoteName('#__modules'));
                    $maxId = (int) $db->setQuery($query)->loadResult();
                    $this->sendCleanJsonResponse(['success' => true, 'data' => ['max_id' => $maxId]]);
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur: ' . $e->getMessage()], true);
                }
            }

            // Nouvelle tâche pour rechercher un module par son titre
            if ($task === 'module.searchbytitle') {
                if (!$this->validateCsrfToken(false, $debug, $debugFile))
                    return;

                $title = $input->getString('title');
                if (!$title) {
                    $this->sendCleanJsonResponse(['message' => 'Titre du module manquant.'], true);
                    return;
                }

                try {
                    $db = Factory::getDbo();

                    // 1. Match exact (exclut mod_title qui n'a pas de contenu HTML utile)
                    $query = $db->getQuery(true)
                        ->select($db->quoteName(['id', 'title', 'content', 'module']))
                        ->from($db->quoteName('#__modules'))
                        ->where($db->quoteName('title') . ' = ' . $db->quote($title))
                        ->where($db->quoteName('client_id') . ' = 0')
                        ->where($db->quoteName('module') . ' != ' . $db->quote('mod_title'))
                        ->order($db->quoteName('id') . ' DESC');
                    $module = $db->setQuery($query, 0, 1)->loadObject();

                    // 2. Fallback LIKE (inclut les modules non publiés, exclut mod_title)
                    if (!$module) {
                        $query = $db->getQuery(true)
                            ->select($db->quoteName(['id', 'title', 'content', 'module']))
                            ->from($db->quoteName('#__modules'))
                            ->where('LOWER(' . $db->quoteName('title') . ') LIKE ' . $db->quote('%' . strtolower($title) . '%'))
                            ->where($db->quoteName('client_id') . ' = 0')
                            ->where($db->quoteName('module') . ' != ' . $db->quote('mod_title'))
                            ->order($db->quoteName('id') . ' DESC');
                        $module = $db->setQuery($query, 0, 1)->loadObject();
                    }

                    // 3. Fallback signature contenu DSFR (pour le module "Titre")
                    // Exclut les modules de structure complexe (fr-logo, fr-header__brand)
                    if (!$module && stripos($title, 'titre') !== false) {
                        $query = $db->getQuery(true)
                            ->select($db->quoteName(['id', 'title', 'content', 'module']))
                            ->from($db->quoteName('#__modules'))
                            ->where($db->quoteName('module') . ' = ' . $db->quote('mod_custom'))
                            ->where($db->quoteName('content') . ' LIKE ' . $db->quote('%fr-header__service-title%'))
                            ->where($db->quoteName('content') . ' NOT LIKE ' . $db->quote('%fr-logo%'))
                            ->where($db->quoteName('content') . ' NOT LIKE ' . $db->quote('%fr-header__brand%'))
                            ->where($db->quoteName('client_id') . ' = 0')
                            ->order('LENGTH(' . $db->quoteName('content') . ') ASC');
                        $module = $db->setQuery($query, 0, 1)->loadObject();
                    }

                    if ($module) {
                        $this->sendCleanJsonResponse(['success' => true, 'data' => $module]);
                    } else {
                        $this->sendCleanJsonResponse(['success' => false, 'message' => 'Module non trouvé'], false);
                    }
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur: ' . $e->getMessage()], true);
                }
            }

            // Nouvelle tâche pour récupérer les paramètres TinyMCE
            if ($task === 'module.getTinyMceParams') {
                if (!$this->validateCsrfToken(false, $debug, $debugFile))
                    return;

                try {
                    $db = Factory::getDbo();
                    $query = $db->getQuery(true)
                        ->select($db->quoteName('params'))
                        ->from($db->quoteName('#__extensions'))
                        ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                        ->where($db->quoteName('element') . ' = ' . $db->quote('tinymce'))
                        ->where($db->quoteName('folder') . ' = ' . $db->quote('editors'));

                    $paramsJson = $db->setQuery($query)->loadResult();

                    $fileList = [];
                    $templatePath = '';
                    if ($paramsJson) {
                        $params = json_decode($paramsJson, true);

                        // Chercher le répertoire de modèles et les CSS personnalisés
                        foreach ($params as $key => $value) {
                            if (empty($templatePath) && (strpos($key, 'template_list_path') !== false || strpos($key, 'template_directory') !== false || strpos($key, 'content_template_path') !== false)) {
                                $templatePath = $value;
                            }
                        }

                        // Structure Joomla 4/5 configuration -> setoptions
                        if (isset($params['configuration']['setoptions']) && is_array($params['configuration']['setoptions'])) {
                            foreach ($params['configuration']['setoptions'] as $set) {
                                if (empty($templatePath)) {
                                    $templatePath = $set['content_template_path'] ?? $set['template_list_path'] ?? $set['template_directory'] ?? '';
                                }
                                if ($templatePath)
                                    break;
                            }
                        }

                        $allTemplatePaths = [];
                        if ($templatePath) {
                            $allTemplatePaths[] = $templatePath;
                        }

                        // Scanner tous les templates pour trouver tous les dossiers de modèles possibles
                        $templatesDir = JPATH_SITE . '/templates';
                        if (is_dir($templatesDir)) {
                            $tplFolders = scandir($templatesDir);
                            foreach ($tplFolders as $tpl) {
                                if ($tpl !== '.' && $tpl !== '..' && is_dir($templatesDir . '/' . $tpl)) {
                                    $candidates = [
                                        $tpl . '/html/tinymce',
                                        $tpl . '/html/layouts/plugins/editors/tinymce',
                                        $tpl . '/tinymce'
                                    ];
                                    foreach ($candidates as $cand) {
                                        if (is_dir($templatesDir . '/' . $cand)) {
                                            $allTemplatePaths[] = $cand;
                                        }
                                    }
                                }
                            }
                        }
                        $allTemplatePaths = array_unique($allTemplatePaths);

                        if ($templatePath) {
                            $possiblePaths = [
                                JPATH_ROOT . '/templates/' . ltrim($templatePath, '/'),
                                JPATH_SITE . '/templates/' . ltrim($templatePath, '/'),
                                JPATH_ROOT . '/' . ltrim($templatePath, '/'),
                                JPATH_SITE . '/' . ltrim($templatePath, '/')
                            ];

                            $actualPathUsed = '';
                            foreach ($possiblePaths as $path) {
                                if (is_dir($path)) {
                                    $actualPathUsed = $path;
                                    $files = scandir($path);
                                    if ($files !== false) {
                                        foreach ($files as $file) {
                                            if ($file !== '.' && $file !== '..' && (strpos($file, '.html') !== false || strpos($file, '.txt') !== false || strpos($file, '.php') !== false)) {
                                                $fileList[] = $file;
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                        }

                        $this->sendCleanJsonResponse([
                            'success' => true,
                            'data' => $params,
                            'template_files' => $fileList,
                            'all_template_paths' => array_values($allTemplatePaths),
                            'detected_path' => $templatePath,
                            'actual_path' => $actualPathUsed,
                            'debug_msg' => empty($fileList) ? 'Dossier ' . ($actualPathUsed ?: 'introuvable') : 'Modèles trouvés'
                        ]);
                    } else {
                        $this->sendCleanJsonResponse(['message' => 'Paramètres TinyMCE non trouvés.'], true);
                    }
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur: ' . $e->getMessage()], true);
                }
                return; // FIX: Missing Return
            }

            // Nouvelle tâche pour sauvegarder les paramètres TinyMCE
            if ($task === 'module.saveTinyMceParams') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                try {
                    $templatePathInput = $input->getString('template_path', '');
                    if (empty($templatePathInput)) {
                        $this->sendCleanJsonResponse(['message' => 'Chemin du modèle manquant.'], true);
                        return;
                    }

                    $db = Factory::getDbo();
                    $query = $db->getQuery(true)
                        ->select($db->quoteName('params'))
                        ->from($db->quoteName('#__extensions'))
                        ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                        ->where($db->quoteName('element') . ' = ' . $db->quote('tinymce'))
                        ->where($db->quoteName('folder') . ' = ' . $db->quote('editors'));

                    $paramsJson = $db->setQuery($query)->loadResult();

                    if ($paramsJson) {
                        $params = json_decode($paramsJson, true);

                        // Mise à jour des paramètres à la racine
                        $params['template_list_path'] = $templatePathInput;
                        $params['template_directory'] = $templatePathInput;
                        $params['content_template_path'] = $templatePathInput;

                        // Mise à jour dans configuration -> setoptions (Joomla 4/5)
                        if (isset($params['configuration']['setoptions']) && is_array($params['configuration']['setoptions'])) {
                            foreach ($params['configuration']['setoptions'] as &$set) {
                                $set['content_template_path'] = $templatePathInput;
                                $set['template_list_path'] = $templatePathInput;
                                $set['template_directory'] = $templatePathInput;
                            }
                        }

                        // Sauvegarde
                        $query = $db->getQuery(true)
                            ->update($db->quoteName('#__extensions'))
                            ->set($db->quoteName('params') . ' = ' . $db->quote(json_encode($params)))
                            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                            ->where($db->quoteName('element') . ' = ' . $db->quote('tinymce'))
                            ->where($db->quoteName('folder') . ' = ' . $db->quote('editors'));

                        $db->setQuery($query)->execute();

                        $this->sendCleanJsonResponse(['success' => true, 'message' => 'Configuration TinyMCE mise à jour.']);
                    } else {
                        $this->sendCleanJsonResponse(['message' => 'Plugin TinyMCE introuvable.'], true);
                    }
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur: ' . $e->getMessage()], true);
                }
            }

            // Tâche pour récupérer le statut complet des templates (Liste fraîche pour le wizard)
            if ($task === 'module.getTemplateStatus') {
                if (!$this->validateCsrfToken(false, $debug, $debugFile))
                    return;

                try {
                    $db = Factory::getDbo();

                    // On vérifie d'abord si la colonne 'parent' existe pour éviter une erreur 500 sur de vieux Joomla 4.0/3.x (si plugin compatible)
                    // Ou on assume Joomla 4+ comme pré-requis.
                    // Par sécurité, on liste les colonnes.
                    $columns = $db->getTableColumns('#__template_styles');
                    $hasParent = isset($columns['parent']);

                    $selects = ['id', 'title', 'template', 'home'];
                    if ($hasParent) {
                        $selects[] = 'parent';
                    }

                    $query = $db->getQuery(true)
                        ->select($db->quoteName($selects))
                        ->from($db->quoteName('#__template_styles'))
                        ->where($db->quoteName('client_id') . ' = 0')
                        ->order($db->quoteName('title'));
                    $allTemplates = $db->setQuery($query)->loadObjectList();

                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | getTemplateStatus: Found " . count($allTemplates) . " templates. HasParent: " . ($hasParent ? 'Yes' : 'No') . "\n", FILE_APPEND);
                        file_put_contents($debugFile, print_r($allTemplates, true), FILE_APPEND);
                    }

                    $this->sendCleanJsonResponse(['success' => true, 'data' => $allTemplates]);
                } catch (\Throwable $e) {
                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | ERROR getTemplateStatus: " . $e->getMessage() . "\n", FILE_APPEND);
                    }
                    $this->sendCleanJsonResponse(['message' => 'Erreur récupération templates: ' . $e->getMessage()], true);
                }
                return;
            }

            // Tâche pour récupérer les paramètres d'un template spécifique
            if ($task === 'module.getTemplateParams') {
                if (!$this->validateCsrfToken(false, $debug, $debugFile))
                    return;

                $templateName = $input->getString('template_name');

                if (empty($templateName)) {
                    $this->sendCleanJsonResponse(['message' => 'Nom du template manquant.'], true);
                    return;
                }

                try {
                    $db = Factory::getDbo();

                    // Récupérer les params du template style
                    $query = $db->getQuery(true)
                        ->select($db->quoteName('params'))
                        ->from($db->quoteName('#__template_styles'))
                        ->where($db->quoteName('template') . ' = ' . $db->quote($templateName))
                        ->where($db->quoteName('client_id') . ' = 0')
                        ->order($db->quoteName('home') . ' DESC');  // Template par défaut en premier
                    $paramsJson = $db->setQuery($query, 0, 1)->loadResult();

                    if ($paramsJson) {
                        $paramsArray = json_decode($paramsJson, true) ?: [];
                        $this->sendCleanJsonResponse([
                            'success' => true,
                            'data' => [
                                'template_name' => $templateName,
                                'params' => $paramsArray
                            ]
                        ]);
                    } else {
                        $this->sendCleanJsonResponse(['message' => 'Template non trouvé ou sans paramètres.'], true);
                    }
                } catch (\Throwable $e) {
                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | ERROR getTemplateParams: " . $e->getMessage() . "\n", FILE_APPEND);
                    }
                    $this->sendCleanJsonResponse(['message' => 'Erreur récupération params: ' . $e->getMessage()], true);
                }
                return;
            }

            // Tâche pour récupérer la classe CSS du lien de menu "twitter"
            if ($task === 'module.getTwitterMenuClass') {
                if (!$this->validateCsrfToken(false, $debug, $debugFile))
                    return;

                try {
                    $db = Factory::getDbo();
                    $query = $db->getQuery(true)
                        ->select($db->quoteName(['id', 'title', 'params']))
                        ->from($db->quoteName('#__menu'))
                        ->where('LOWER(' . $db->quoteName('title') . ') = ' . $db->quote('twitter'))
                        ->where($db->quoteName('published') . ' >= 0');
                    $row = $db->setQuery($query, 0, 1)->loadObject();

                    if (!$row) {
                        $this->sendCleanJsonResponse(['message' => 'Lien de menu "twitter" introuvable.'], true);
                        return;
                    }

                    $params = json_decode($row->params, true) ?: [];
                    $currentClass = trim(preg_replace('/\s+/', ' ', $params['menu-anchor_css'] ?? ''));

                    $this->sendCleanJsonResponse([
                        'success' => true,
                        'data' => [
                            'id'            => (int) $row->id,
                            'title'         => $row->title,
                            'anchor_css'    => $currentClass,
                            'already_done'  => (strpos($currentClass, 'fr-btn--twitter-x') !== false),
                        ]
                    ]);
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur getTwitterMenuClass: ' . $e->getMessage()], true);
                }
                return;
            }

            // Tâche pour appliquer la classe CSS fr-btn--twitter-x fr-btn sur le lien "twitter"
            if ($task === 'module.setTwitterMenuClass') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                try {
                    $db = Factory::getDbo();
                    $query = $db->getQuery(true)
                        ->select($db->quoteName(['id', 'params']))
                        ->from($db->quoteName('#__menu'))
                        ->where('LOWER(' . $db->quoteName('title') . ') = ' . $db->quote('twitter'))
                        ->where($db->quoteName('published') . ' >= 0');
                    $row = $db->setQuery($query, 0, 1)->loadObject();

                    if (!$row) {
                        $this->sendCleanJsonResponse(['message' => 'Lien de menu "twitter" introuvable.'], true);
                        return;
                    }

                    $params = json_decode($row->params, true) ?: [];
                    $params['menu-anchor_css'] = 'fr-btn--twitter-x fr-btn';

                    $updateQuery = $db->getQuery(true)
                        ->update($db->quoteName('#__menu'))
                        ->set($db->quoteName('params') . ' = ' . $db->quote(json_encode($params)))
                        ->where($db->quoteName('id') . ' = ' . (int) $row->id);
                    $db->setQuery($updateQuery)->execute();

                    $this->sendCleanJsonResponse([
                        'success' => true,
                        'data'    => ['id' => (int) $row->id, 'anchor_css' => 'fr-btn--twitter-x fr-btn']
                    ]);
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur setTwitterMenuClass: ' . $e->getMessage()], true);
                }
                return;
            }

            // Tâche pour renommer un module par son ID
            if ($task === 'module.renamemodule') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                $id = $input->getInt('id');
                $newTitle = trim($input->getString('newtitle', 'Titre'));
                if (!$id || !$newTitle) {
                    $this->sendCleanJsonResponse(['message' => 'ID ou titre manquant.'], true);
                    return;
                }

                try {
                    $db = Factory::getDbo();
                    $query = $db->getQuery(true)
                        ->update($db->quoteName('#__modules'))
                        ->set($db->quoteName('title') . ' = ' . $db->quote($newTitle))
                        ->where($db->quoteName('id') . ' = ' . (int) $id)
                        ->where($db->quoteName('client_id') . ' = 0');
                    $db->setQuery($query)->execute();
                    $this->sendCleanJsonResponse(['success' => true, 'data' => ['id' => $id, 'title' => $newTitle]]);
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur renamemodule: ' . $e->getMessage()], true);
                }
                return;
            }

            // Tâche pour désinstaller un template (thème enfant)
            if ($task === 'module.uninstallTemplate') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                $templateName = $input->getString('template_name');

                if (empty($templateName)) {
                    $this->sendCleanJsonResponse(['message' => 'Nom du template manquant.'], true);
                    return;
                }

                // Sécurité : nettoyage du nom de template
                $filter = InputFilter::getInstance();
                $templateName = $filter->clean($templateName, 'CMD');

                if (empty($templateName)) {
                    $this->sendCleanJsonResponse(['message' => 'Nom de template invalide après nettoyage.'], true);
                    return;
                }

                try {
                    $db = Factory::getDbo();

                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | uninstallTemplate: Starting uninstallation of template '{$templateName}'\n", FILE_APPEND);
                    }

                    // 1. Vérifier que le template existe dans #__template_styles
                    // Vérifier si la colonne 'parent' existe
                    $columns = $db->getTableColumns('#__template_styles');
                    $hasParentColumn = isset($columns['parent']);

                    $selects = ['id', 'template', 'title', 'home'];
                    if ($hasParentColumn) {
                        $selects[] = 'parent';
                    }

                    $query = $db->getQuery(true)
                        ->select($db->quoteName($selects))
                        ->from($db->quoteName('#__template_styles'))
                        ->where($db->quoteName('template') . ' = ' . $db->quote($templateName))
                        ->where($db->quoteName('client_id') . ' = 0');
                    $templateStyle = $db->setQuery($query)->loadObject();

                    // 2. Si c'est le template par défaut, basculer automatiquement sur le thème parent
                    $parentTemplateName = null;
                    $parentTemplateId = null;

                    if ($templateStyle && ($templateStyle->home == 1 || $templateStyle->home == '1')) {
                        if ($debug && !empty($debugFile)) {
                            file_put_contents($debugFile, date('Y-m-d H:i:s') . " | uninstallTemplate: Template is default, searching for parent template\n", FILE_APPEND);
                        }

                        // Stratégie 1 : Chercher un autre thème enfant DSFR (ex: cassiopeia_dsfr)
                        if ($hasParentColumn) {
                            $query = $db->getQuery(true)
                                ->select($db->quoteName(['id', 'template', 'title']))
                                ->from($db->quoteName('#__template_styles'))
                                ->where($db->quoteName('client_id') . ' = 0')
                                ->where($db->quoteName('template') . ' != ' . $db->quote($templateName))
                                ->where($db->quoteName('parent') . ' != ' . $db->quote(''));
                            $otherChildTemplates = $db->setQuery($query)->loadObjectList();

                            foreach ($otherChildTemplates as $candidate) {
                                if (stripos($candidate->template, 'dsfr') !== false || stripos($candidate->title, 'dsfr') !== false) {
                                    $parentTemplateName = $candidate->template;
                                    $parentTemplateId = $candidate->id;
                                    if ($debug && !empty($debugFile)) {
                                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | uninstallTemplate: Found other DSFR child template: '{$parentTemplateName}'\n", FILE_APPEND);
                                    }
                                    break;
                                }
                            }
                        }

                        // Stratégie 2 : Utiliser la colonne 'parent' pour remonter au thème parent direct
                        if (!$parentTemplateName && $hasParentColumn && !empty($templateStyle->parent)) {
                            $query = $db->getQuery(true)
                                ->select($db->quoteName(['id', 'template', 'title']))
                                ->from($db->quoteName('#__template_styles'))
                                ->where($db->quoteName('template') . ' = ' . $db->quote($templateStyle->parent))
                                ->where($db->quoteName('client_id') . ' = 0');
                            $parentTemplate = $db->setQuery($query)->loadObject();

                            if ($parentTemplate) {
                                $parentTemplateName = $parentTemplate->template;
                                $parentTemplateId = $parentTemplate->id;
                                if ($debug && !empty($debugFile)) {
                                    file_put_contents($debugFile, date('Y-m-d H:i:s') . " | uninstallTemplate: Found parent from 'parent' column: '{$parentTemplateName}'\n", FILE_APPEND);
                                }
                            }
                        }

                        // Stratégie 3 : Chercher cassiopeia (thème Joomla par défaut)
                        if (!$parentTemplateName) {
                            $query = $db->getQuery(true)
                                ->select($db->quoteName(['id', 'template', 'title']))
                                ->from($db->quoteName('#__template_styles'))
                                ->where($db->quoteName('template') . ' = ' . $db->quote('cassiopeia'))
                                ->where($db->quoteName('client_id') . ' = 0');
                            $parentTemplate = $db->setQuery($query)->loadObject();

                            if ($parentTemplate) {
                                $parentTemplateName = $parentTemplate->template;
                                $parentTemplateId = $parentTemplate->id;
                                if ($debug && !empty($debugFile)) {
                                    file_put_contents($debugFile, date('Y-m-d H:i:s') . " | uninstallTemplate: Using cassiopeia as parent\n", FILE_APPEND);
                                }
                            }
                        }

                        // Stratégie 4 : Prendre le premier template disponible (qui n'est pas le template actuel)
                        if (!$parentTemplateName) {
                            $query = $db->getQuery(true)
                                ->select($db->quoteName(['id', 'template', 'title']))
                                ->from($db->quoteName('#__template_styles'))
                                ->where($db->quoteName('client_id') . ' = 0')
                                ->where($db->quoteName('template') . ' != ' . $db->quote($templateName))
                                ->order($db->quoteName('id') . ' ASC');
                            $parentTemplate = $db->setQuery($query, 0, 1)->loadObject();

                            if ($parentTemplate) {
                                $parentTemplateName = $parentTemplate->template;
                                $parentTemplateId = $parentTemplate->id;
                                if ($debug && !empty($debugFile)) {
                                    file_put_contents($debugFile, date('Y-m-d H:i:s') . " | uninstallTemplate: Using first available template: '{$parentTemplateName}'\n", FILE_APPEND);
                                }
                            }
                        }

                        if ($parentTemplateName && $parentTemplateId) {
                            if ($debug && !empty($debugFile)) {
                                file_put_contents($debugFile, date('Y-m-d H:i:s') . " | uninstallTemplate: Found parent template '{$parentTemplateName}', switching default\n", FILE_APPEND);
                            }

                            // Désactiver tous les templates
                            $query = $db->getQuery(true)
                                ->update($db->quoteName('#__template_styles'))
                                ->set($db->quoteName('home') . ' = ' . $db->quote('0'))
                                ->where($db->quoteName('client_id') . ' = 0');
                            $db->setQuery($query)->execute();

                            // Activer le thème parent comme par défaut
                            $query = $db->getQuery(true)
                                ->update($db->quoteName('#__template_styles'))
                                ->set($db->quoteName('home') . ' = ' . $db->quote('1'))
                                ->where($db->quoteName('id') . ' = ' . (int) $parentTemplateId);
                            $db->setQuery($query)->execute();

                            if ($debug && !empty($debugFile)) {
                                file_put_contents($debugFile, date('Y-m-d H:i:s') . " | uninstallTemplate: Parent template '{$parentTemplateName}' is now default\n", FILE_APPEND);
                            }
                        } else {
                            $this->sendCleanJsonResponse(['message' => 'Impossible de supprimer le template par défaut. Aucun autre thème disponible pour basculer.'], true);
                            return;
                        }
                    }

                    // 3. Trouver l'extension_id dans #__extensions
                    $query = $db->getQuery(true)
                        ->select($db->quoteName('extension_id'))
                        ->from($db->quoteName('#__extensions'))
                        ->where($db->quoteName('type') . ' = ' . $db->quote('template'))
                        ->where($db->quoteName('element') . ' = ' . $db->quote($templateName))
                        ->where($db->quoteName('client_id') . ' = 0');
                    $extensionId = $db->setQuery($query)->loadResult();

                    if (!$extensionId && !$templateStyle) {
                        $this->sendCleanJsonResponse(['message' => 'Template introuvable dans le système.'], true);
                        return;
                    }

                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | uninstallTemplate: Extension ID: " . ($extensionId ?: 'Not found') . ", Style ID: " . ($templateStyle ? $templateStyle->id : 'Not found') . "\n", FILE_APPEND);
                    }

                    // 4. Utiliser l'API Installer de Joomla pour désinstaller proprement
                    if ($extensionId) {
                        $installer = \Joomla\CMS\Installer\Installer::getInstance();
                        $result = $installer->uninstall('template', $extensionId);

                        if ($debug && !empty($debugFile)) {
                            file_put_contents($debugFile, date('Y-m-d H:i:s') . " | uninstallTemplate: Installer result: " . ($result ? 'SUCCESS' : 'FAILED') . "\n", FILE_APPEND);
                        }

                        if (!$result) {
                            // Si l'API Installer échoue, on fait un nettoyage manuel
                            if ($debug && !empty($debugFile)) {
                                file_put_contents($debugFile, date('Y-m-d H:i:s') . " | uninstallTemplate: Installer failed, attempting manual cleanup\n", FILE_APPEND);
                            }

                            // Supprimer manuellement les entrées de base de données
                            if ($templateStyle) {
                                $query = $db->getQuery(true)
                                    ->delete($db->quoteName('#__template_styles'))
                                    ->where($db->quoteName('id') . ' = ' . (int) $templateStyle->id);
                                $db->setQuery($query)->execute();
                            }

                            $query = $db->getQuery(true)
                                ->delete($db->quoteName('#__extensions'))
                                ->where($db->quoteName('extension_id') . ' = ' . (int) $extensionId);
                            $db->setQuery($query)->execute();

                            // Supprimer les fichiers si possible
                            $templatePath = JPATH_ROOT . '/templates/' . $templateName;
                            if (is_dir($templatePath) && is_writable($templatePath)) {
                                \Joomla\CMS\Filesystem\Folder::delete($templatePath);
                            }
                        }
                    } else {
                        // Pas d'extension, mais un style existe : nettoyage manuel
                        if ($templateStyle) {
                            $query = $db->getQuery(true)
                                ->delete($db->quoteName('#__template_styles'))
                                ->where($db->quoteName('id') . ' = ' . (int) $templateStyle->id);
                            $db->setQuery($query)->execute();
                        }

                        // Supprimer les fichiers si possible
                        $templatePath = JPATH_ROOT . '/templates/' . $templateName;
                        if (is_dir($templatePath) && is_writable($templatePath)) {
                            \Joomla\CMS\Filesystem\Folder::delete($templatePath);
                        }
                    }

                    // 5. Nettoyer le cache Joomla
                    try {
                        $cache = \Joomla\CMS\Cache\CacheControllerFactoryInterface::class;
                        if (class_exists($cache)) {
                            $cacheController = Factory::getContainer()->get(\Joomla\CMS\Cache\CacheControllerFactoryInterface::class);
                            $cacheController->createCacheController('page')->gc();
                        }
                    } catch (\Exception $e) {
                        // Cache cleaning failed, continue anyway
                        if ($debug && !empty($debugFile)) {
                            file_put_contents($debugFile, date('Y-m-d H:i:s') . " | uninstallTemplate: Cache cleaning failed (non-critical): " . $e->getMessage() . "\n", FILE_APPEND);
                        }
                    }

                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | uninstallTemplate: Uninstallation completed successfully.\n", FILE_APPEND);
                    }

                    $responseData = [
                        'success' => true,
                        'message' => 'Template désinstallé avec succès.',
                        'data' => [
                            'template_name' => $templateName,
                            'parent_template' => $parentTemplateName
                        ]
                    ];

                    $this->sendCleanJsonResponse($responseData);
                } catch (\Throwable $e) {
                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | ERROR uninstallTemplate: " . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n", FILE_APPEND);
                    }
                    $this->sendCleanJsonResponse(['message' => 'Erreur lors de la désinstallation: ' . $e->getMessage()], true);
                }
                return;
            }

            // Tâche pour sauvegarder la config de remplacement dynamique (front)
            if ($task === 'module.saveDynamicReplaceConfig') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                // Utiliser getRaw pour préserver les balises HTML (ex: <br>)
                $configJson = $input->getRaw('config', '');

                if (empty($configJson)) {
                    $this->sendCleanJsonResponse(['message' => 'Config manquante.'], true);
                    return;
                }

                $config = json_decode($configJson, true);
                if (!is_array($config)) {
                    $this->sendCleanJsonResponse(['message' => 'Config invalide.'], true);
                    return;
                }

                try {
                    $db = Factory::getDbo();

                    // Charger params actuels du plugin
                    $query = $db->getQuery(true)
                        ->select($db->quoteName('params'))
                        ->from($db->quoteName('#__extensions'))
                        ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                        ->where($db->quoteName('element') . ' = ' . $db->quote('moduleexport'))
                        ->where($db->quoteName('folder') . ' = ' . $db->quote('system'));
                    $paramsJson = $db->setQuery($query)->loadResult();
                    $params = $paramsJson ? json_decode($paramsJson, true) : [];
                    if (!is_array($params))
                        $params = [];

                    $params['dynamic_replace_config'] = json_encode($config);

                    $query = $db->getQuery(true)
                        ->update($db->quoteName('#__extensions'))
                        ->set($db->quoteName('params') . ' = ' . $db->quote(json_encode($params)))
                        ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                        ->where($db->quoteName('element') . ' = ' . $db->quote('moduleexport'))
                        ->where($db->quoteName('folder') . ' = ' . $db->quote('system'));
                    $db->setQuery($query)->execute();

                    $this->sendCleanJsonResponse(['success' => true, 'message' => 'Config dynamique sauvegardée.']);
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur sauvegarde config: ' . $e->getMessage()], true);
                }
                return;
            }
            // Nouvelle tâche pour vérifier et réparer la base de données (Database Health Check)
            if ($task === 'module.checkandfixdb') {
                if (!$this->validateCsrfToken(false, $debug, $debugFile))
                    return;

                $logFilePath = JPATH_PLUGINS . '/system/moduleexport/logs/moduleexport_other_tasks.log';
                $logDir = dirname($logFilePath);
                if (!is_dir($logDir)) {
                    @mkdir($logDir, 0755, true);
                }

                $log = function ($msg) use ($logFilePath) {
                    if (is_writable(dirname($logFilePath))) {
                        file_put_contents($logFilePath, date('Y-m-d H:i:s') . ' | [DB_CHECK] ' . $msg . "\n", FILE_APPEND);
                    }
                };

                $log("--- DÉBUT VÉRIFICATION BASE DE DONNÉES ---");

                try {
                    $db = Factory::getDbo();
                    $report = [];

                    // 1. Vérification de la connexion et des tables de base
                    $tables = ['modules', 'extensions', 'menu'];
                    foreach ($tables as $table) {
                        $query = "SHOW TABLES LIKE " . $db->quote($db->getPrefix() . $table);
                        if ($db->setQuery($query)->loadResult()) {
                            $report[] = "V Table #__$table est opérationnelle.";
                        } else {
                            $report[] = "X Table #__$table introuvable !";
                        }
                    }

                    // 2. Vérification spécifique com_conditions si installé
                    if ($isConditionsInstalled) {
                        $query = "SHOW TABLES LIKE " . $db->quote($db->getPrefix() . 'conditions');
                        if ($db->setQuery($query)->loadResult()) {
                            $report[] = "V Table #__conditions détectée.";
                        } else {
                            $report[] = "! Com_conditions activé mais table #__conditions absente.";
                        }
                    }

                    $log("Vérification terminée. " . count($report) . " points contrôlés.");

                    $this->sendCleanJsonResponse([
                        'success' => true,
                        'data' => [
                            'message' => implode("\n", $report),
                            'reloaded' => false
                        ]
                    ]);
                } catch (\Throwable $e) {
                    $log("ERREUR : " . $e->getMessage());
                    $this->sendCleanJsonResponse(['success' => false, 'message' => 'Erreur lors de la vérification : ' . $e->getMessage()], true);
                }
                return;
            }


            // Tâche pour appliquer un mapping de menu (renommer + réordonner)
            if ($task === 'module.applymenumapping') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                $mappingRaw = $input->getRaw('mapping', '');
                $dryRun = (int) $input->getInt('dry_run', 0) === 1;

                if (empty($mappingRaw)) {
                    $this->sendCleanJsonResponse(['message' => 'Mapping JSON manquant.'], true);
                    return;
                }

                $mapping = json_decode($mappingRaw, true);
                if (!is_array($mapping)) {
                    $this->sendCleanJsonResponse(['message' => 'Mapping JSON invalide.'], true);
                    return;
                }

                $menutype = $mapping['menutype'] ?? '';
                $items = $mapping['items'] ?? [];

                if (!$menutype || !is_array($items) || count($items) === 0) {
                    $this->sendCleanJsonResponse(['message' => 'Mapping incomplet (menutype/items).'], true);
                    return;
                }

                $normalizeTitle = function ($value) {
                    $value = is_string($value) ? $value : '';
                    $value = trim($value);
                    if ($value === '')
                        return '';
                    return mb_strtolower($value);
                };

                $normalizeUrl = function ($value) {
                    $value = is_string($value) ? $value : '';
                    $value = trim($value);
                    if ($value === '')
                        return '';
                    $value = mb_strtolower($value);
                    $value = preg_replace('#^https?://#', '', $value);
                    $value = preg_replace('#^www\.#', '', $value);
                    $value = rtrim($value, '/');
                    return $value;
                };

                $urlMatches = function ($needle, $haystack) {
                    if ($needle === '' || $haystack === '')
                        return false;
                    if ($needle === $haystack)
                        return true;
                    // Correspondance partielle pour tolérer les proxys / nouveaux domaines intranet
                    return str_contains($haystack, $needle) || str_contains($needle, $haystack);
                };

                try {
                    $db = Factory::getDbo();

                    $selectMenuQuery = $db->getQuery(true)
                        ->select($db->quoteName(['id', 'title', 'link', 'params', 'menutype', 'parent_id', 'lft', 'type']))
                        ->from($db->quoteName('#__menu'))
                        ->where($db->quoteName('client_id') . ' = 0');

                    $selectByMenutype = clone $selectMenuQuery;
                    $selectByMenutype->where($db->quoteName('menutype') . ' = ' . $db->quote($menutype));

                    $menuItems = $db->setQuery($selectByMenutype)->loadObjectList();
                    $usedFallbackMenutype = false;

                    if (!$menuItems) {
                        // Fallback : parcourir tous les menus publics si le menutype n'existe plus (nouvel intranet)
                        $menuItems = $db->setQuery($selectMenuQuery)->loadObjectList();
                        $usedFallbackMenutype = true;
                    }

                    $byId = [];
                    $byTitle = [];
                    $byUrl = [];

                    $getItemUrl = function ($item) use ($normalizeUrl) {
                        $url = '';
                        if (!empty($item->link)) {
                            $url = $item->link;
                        }
                        if (!empty($item->params)) {
                            $params = json_decode($item->params, true);
                            if (is_array($params) && !empty($params['url'])) {
                                $url = $params['url'];
                            }
                        }
                        return $normalizeUrl($url);
                    };

                    foreach ($menuItems as $item) {
                        $byId[(string) $item->id] = $item;

                        $titleKey = $normalizeTitle($item->title ?? '');
                        if ($titleKey !== '') {
                            if (!isset($byTitle[$titleKey]))
                                $byTitle[$titleKey] = [];
                            $byTitle[$titleKey][] = $item;
                        }

                        $urlKey = $getItemUrl($item);
                        if ($urlKey !== '') {
                            if (!isset($byUrl[$urlKey]))
                                $byUrl[$urlKey] = [];
                            $byUrl[$urlKey][] = $item;
                        }
                    }

                    $matchedIds = [];
                    $notFound = [];
                    $updated = [];
                    $targetParentId = null;
                    $desiredById = [];

                    foreach ($items as $entry) {
                        if (!is_array($entry))
                            continue;
                        $match = $entry['match'] ?? [];
                        $update = $entry['update'] ?? [];
                        if (!is_array($match))
                            $match = [];
                        if (!is_array($update))
                            $update = [];

                        $found = null;

                        if (isset($match['id'])) {
                            $ids = is_array($match['id']) ? $match['id'] : [$match['id']];
                            foreach ($ids as $idVal) {
                                $idKey = (string) (int) $idVal;
                                if (isset($byId[$idKey])) {
                                    $found = $byId[$idKey];
                                    break;
                                }
                            }
                        }

                        if (!$found && isset($match['url'])) {
                            $urls = is_array($match['url']) ? $match['url'] : [$match['url']];
                            foreach ($urls as $urlVal) {
                                $urlKey = $normalizeUrl($urlVal);
                                if ($urlKey === '')
                                    continue;
                                // Correspondance directe
                                if (!empty($byUrl[$urlKey])) {
                                    $found = $byUrl[$urlKey][0];
                                    break;
                                }
                                // Correspondance partielle
                                foreach ($byUrl as $key => $itemsWithUrl) {
                                    if ($urlMatches($urlKey, $key)) {
                                        $found = $itemsWithUrl[0];
                                        break 2;
                                    }
                                }
                            }
                        }

                        if (!$found && isset($match['title'])) {
                            $titles = is_array($match['title']) ? $match['title'] : [$match['title']];
                            foreach ($titles as $titleVal) {
                                $titleKey = $normalizeTitle($titleVal);
                                if ($titleKey !== '' && !empty($byTitle[$titleKey])) {
                                    $found = $byTitle[$titleKey][0];
                                    break;
                                }
                            }
                        }

                        if (!$found) {
                            $notFound[] = $match;
                            continue;
                        }

                        $idStr = (string) $found->id;
                        if (in_array($idStr, $matchedIds, true)) {
                            continue;
                        }

                        if ($targetParentId === null) {
                            $targetParentId = (int) $found->parent_id;
                        }

                        $desiredById[$idStr] = [
                            'title' => $update['title'] ?? null,
                            'url' => $update['url'] ?? ($update['link'] ?? null)
                        ];

                        $matchedIds[] = $idStr;

                        if (!$dryRun) {
                            $newTitle = $update['title'] ?? null;
                            $newUrl = $update['url'] ?? ($update['link'] ?? null);

                            if ($newTitle !== null || $newUrl !== null) {
                                $fields = [];
                                if ($newTitle !== null) {
                                    $fields[] = $db->quoteName('title') . ' = ' . $db->quote($newTitle);
                                }

                                $paramsJson = $found->params;
                                if ($newUrl !== null) {
                                    $fields[] = $db->quoteName('link') . ' = ' . $db->quote($newUrl);
                                    if (!empty($paramsJson)) {
                                        $params = json_decode($paramsJson, true);
                                        if (is_array($params) && array_key_exists('url', $params)) {
                                            $params['url'] = $newUrl;
                                            $paramsJson = json_encode($params);
                                        }
                                    }
                                }

                                if ($paramsJson !== $found->params) {
                                    $fields[] = $db->quoteName('params') . ' = ' . $db->quote($paramsJson);
                                }

                                if (!empty($fields)) {
                                    $updateQuery = $db->getQuery(true)
                                        ->update($db->quoteName('#__menu'))
                                        ->set($fields)
                                        ->where($db->quoteName('id') . ' = ' . (int) $found->id);
                                    $db->setQuery($updateQuery)->execute();
                                }

                                $updated[] = $found->id;
                            }
                        }
                    }

                    if (empty($matchedIds)) {
                        $this->sendCleanJsonResponse(['message' => 'Aucun lien de menu correspondant trouvé.', 'data' => ['not_found' => $notFound]], true);
                        return;
                    }

                    $computeStatus = function ($menuItems, $matchedIds, $desiredById) use ($normalizeTitle, $normalizeUrl, $getItemUrl) {
                        $byIdLocal = [];
                        foreach ($menuItems as $item) {
                            $byIdLocal[(string) $item->id] = $item;
                        }

                        $itemsStatus = [];
                        $itemsOkCount = 0;

                        foreach ($matchedIds as $idStr) {
                            if (!isset($byIdLocal[$idStr]))
                                continue;
                            $item = $byIdLocal[$idStr];
                            $desired = $desiredById[$idStr] ?? ['title' => null, 'url' => null];

                            $currentTitle = (string) ($item->title ?? '');
                            $currentUrl = $getItemUrl($item);

                            $desiredTitle = is_string($desired['title'] ?? null) ? $desired['title'] : null;
                            $desiredUrl = is_string($desired['url'] ?? null) ? $desired['url'] : null;

                            $titleOk = $desiredTitle === null ? true : ($normalizeTitle($currentTitle) === $normalizeTitle($desiredTitle));
                            $urlOk = $desiredUrl === null ? true : ($normalizeUrl($currentUrl) === $normalizeUrl($desiredUrl));

                            if ($titleOk && $urlOk)
                                $itemsOkCount++;

                            $itemsStatus[] = [
                                'id' => (int) $item->id,
                                'title_ok' => $titleOk,
                                'url_ok' => $urlOk
                            ];
                        }

                        $orderPairs = [];
                        foreach ($matchedIds as $idStr) {
                            if (!isset($byIdLocal[$idStr]))
                                continue;
                            $item = $byIdLocal[$idStr];
                            $orderKey = isset($item->lft) ? (int) $item->lft : (int) $item->id;
                            $orderPairs[] = ['id' => $idStr, 'key' => $orderKey];
                        }

                        usort($orderPairs, function ($a, $b) {
                            return $a['key'] <=> $b['key'];
                        });
                        $currentOrder = array_map(function ($pair) {
                            return $pair['id'];
                        }, $orderPairs);

                        $orderOk = $currentOrder === $matchedIds;

                        $itemsTotal = count($itemsStatus);
                        $upToDate = ($itemsOkCount === $itemsTotal) && $orderOk;

                        return [
                            'up_to_date' => $upToDate,
                            'order_ok' => $orderOk,
                            'items_total' => $itemsTotal,
                            'items_ok' => $itemsOkCount,
                            'items' => $itemsStatus
                        ];
                    };

                    $statusBefore = $computeStatus($menuItems, $matchedIds, $desiredById);

                    $orderingScope = $menuItems;
                    if ($targetParentId !== null) {
                        $orderingScope = array_values(array_filter($menuItems, function ($item) use ($targetParentId) {
                            return (int) $item->parent_id === (int) $targetParentId;
                        }));
                    }

                    usort($orderingScope, function ($a, $b) {
                        $aKey = isset($a->lft) ? (int) $a->lft : (int) $a->id;
                        $bKey = isset($b->lft) ? (int) $b->lft : (int) $b->id;
                        return $aKey <=> $bKey;
                    });

                    $remaining = array_filter($orderingScope, function ($item) use ($matchedIds) {
                        return !in_array((string) $item->id, $matchedIds, true);
                    });

                    $finalOrder = array_merge($matchedIds, array_map(function ($item) {
                        return (string) $item->id;
                    }, $remaining));

                    if (!$dryRun) {
                        $columns = $db->getTableColumns('#__menu');
                        $hasOrdering = isset($columns['ordering']);
                        $orderingCheckError = null;

                        if ($hasOrdering) {
                            try {
                                $db->setQuery('SELECT ' . $db->quoteName('ordering') . ' FROM ' . $db->quoteName('#__menu') . ' LIMIT 1');
                                $db->loadResult();
                            } catch (\Throwable $e) {
                                $hasOrdering = false;
                                $orderingCheckError = $e->getMessage();
                            }
                        }

                        if ($hasOrdering) {
                            try {
                                $position = 1;
                                foreach ($finalOrder as $menuId) {
                                    $query = $db->getQuery(true)
                                        ->update($db->quoteName('#__menu'))
                                        ->set($db->quoteName('ordering') . ' = ' . (int) $position)
                                        ->where($db->quoteName('id') . ' = ' . (int) $menuId);
                                    $db->setQuery($query)->execute();
                                    $position++;
                                }
                            } catch (\Throwable $e) {
                                $hasOrdering = false;
                                $orderingCheckError = $e->getMessage();
                            }
                        }

                        if (!$hasOrdering) {
                            try {
                                $menuTable = TableFactory::getMenuTable();
                                foreach ($finalOrder as $menuId) {
                                    if (!$menuTable->load((int) $menuId)) {
                                        continue;
                                    }
                                    $parentId = $targetParentId !== null ? (int) $targetParentId : (int) $menuTable->parent_id;
                                    $menuTable->setLocation($parentId, 'last-child');
                                    $menuTable->store();
                                }
                            } catch (\Throwable $e) {
                                $orderingCheckError = $orderingCheckError ?: $e->getMessage();
                            }
                        }

                        try {
                            $table = TableFactory::getMenuTable();
                            if ($table && method_exists($table, 'rebuild')) {
                                $table->rebuild();
                            }
                        } catch (\Throwable $e) {
                            // Rebuild échoué, non bloquant
                        }
                    }

                    $statusAfter = null;
                    if (!$dryRun) {
                        // Recharger pour calculer l'état final
                        $menuItemsAfter = $db->setQuery($usedFallbackMenutype ? $selectMenuQuery : $selectByMenutype)->loadObjectList();
                        if ($menuItemsAfter) {
                            $statusAfter = $computeStatus($menuItemsAfter, $matchedIds, $desiredById);
                        }
                    }

                    $responsePayload = [
                        'success' => true,
                        'message' => $dryRun ? 'Aperçu OK (dry-run).' : 'Mapping de menu appliqué.',
                        'data' => [
                            'menutype' => $menutype,
                            'menutype_fallback' => $usedFallbackMenutype,
                            'matched' => $matchedIds,
                            'updated' => $updated,
                            'not_found' => $notFound,
                            'final_order' => $finalOrder,
                            'ordering_method' => $hasOrdering ? 'ordering_column' : 'nested_set',
                            'ordering_warning' => $orderingCheckError,
                            'status' => $statusBefore,
                            'status_after' => $statusAfter
                        ]
                    ];

                    if ($debug && !empty($debugFile)) {
                        $responsePayload['debug'] = [
                            'has_ordering_column' => isset($columns['ordering']),
                            'ordering_check_error' => $orderingCheckError,
                            'final_order_count' => count($finalOrder)
                        ];
                    }

                    $this->sendCleanJsonResponse($responsePayload);
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur mapping menu: ' . $e->getMessage()], true);
                }
                return;
            }


            // Tâche pour sauvegarder le thème parent au format ZIP
            if ($task === 'module.saveParentThemeZip') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                $templateName = $input->getString('template_name');

                if (empty($templateName)) {
                    $this->sendCleanJsonResponse(['message' => 'Nom du template manquant.'], true);
                    return;
                }

                // Sécurité : nettoyage du nom de template
                $filter = InputFilter::getInstance();
                $templateName = $filter->clean($templateName, 'CMD');

                if (empty($templateName)) {
                    $this->sendCleanJsonResponse(['message' => 'Nom de template invalide après nettoyage.'], true);
                    return;
                }

                try {
                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | saveParentThemeZip: Starting ZIP creation for template '{$templateName}'\n", FILE_APPEND);
                    }

                    // Vérifier que le template existe
                    $templatePath = JPATH_ROOT . '/templates/' . $templateName;
                    if (!is_dir($templatePath)) {
                        $this->sendCleanJsonResponse(['message' => 'Le répertoire du template est introuvable.'], true);
                        return;
                    }

                    // Créer le dossier tmp s'il n'existe pas
                    $tmpDir = JPATH_ROOT . '/tmp/theme_backups';
                    if (!is_dir($tmpDir)) {
                        \Joomla\CMS\Filesystem\Folder::create($tmpDir);
                    }

                    // Nom du fichier ZIP avec timestamp
                    $timestamp = date('Y-m-d_H-i-s');
                    $zipFilename = $templateName . '_backup_' . $timestamp . '.zip';
                    $zipPath = $tmpDir . '/' . $zipFilename;

                    // Supprimer l'ancien fichier ZIP s'il existe
                    if (file_exists($zipPath)) {
                        \Joomla\CMS\Filesystem\File::delete($zipPath);
                    }

                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | saveParentThemeZip: Creating ZIP at '{$zipPath}'\n", FILE_APPEND);
                    }

                    // Sécuriser le dossier de destination
                    if (!file_exists($zipPathDir . '/.htaccess')) {
                        file_put_contents($zipPathDir . '/.htaccess', "Order Deny,Allow\nDeny from all\n");
                    }
                    // create empty index.html
                    if (!file_exists($zipPathDir . '/index.html')) {
                        file_put_contents($zipPathDir . '/index.html', '');
                    }

                    // Créer le fichier ZIP
                    $zip = new \ZipArchive();
                    if ($zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
                        $this->sendCleanJsonResponse(['message' => 'Impossible de créer le fichier ZIP.'], true);
                        return;
                    }

                    // Ajouter tous les fichiers du template au ZIP
                    $files = new \RecursiveIteratorIterator(
                        new \RecursiveDirectoryIterator($templatePath, \RecursiveDirectoryIterator::SKIP_DOTS),
                        \RecursiveIteratorIterator::LEAVES_ONLY
                    );

                    $fileCount = 0;
                    foreach ($files as $file) {
                        if (!$file->isDir()) {
                            $filePath = $file->getRealPath();
                            $relativePath = substr($filePath, strlen(JPATH_ROOT . '/templates/'));
                            $zip->addFile($filePath, $relativePath);
                            $fileCount++;
                        }
                    }

                    $zip->close();

                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | saveParentThemeZip: ZIP created successfully with {$fileCount} files\n", FILE_APPEND);
                    }

                    // Générer l'URL de téléchargement
                    $downloadUrl = \Joomla\CMS\Uri\Uri::root() . 'tmp/theme_backups/' . $zipFilename;

                    $this->sendCleanJsonResponse([
                        'success' => true,
                        'message' => 'Thème sauvegardé avec succès.',
                        'data' => [
                            'filename' => $zipFilename,
                            'download_url' => $downloadUrl,
                            'file_count' => $fileCount
                        ]
                    ]);
                } catch (\Throwable $e) {
                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | ERROR saveParentThemeZip: " . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n", FILE_APPEND);
                    }
                    $this->sendCleanJsonResponse(['message' => 'Erreur lors de la création du ZIP: ' . $e->getMessage()], true);
                }
                return;
            }

            // Tâche pour récupérer le statut du fichier user.css

            if ($task === 'module.getUserCssStatus') {
                if (!$this->validateCsrfToken(false, $debug, $debugFile))
                    return;

                $template = $input->getString('template');

                if (empty($template)) {

                    $this->sendCleanJsonResponse(['message' => 'Nom du template manquant.'], true);

                    return;

                }

                $filter = InputFilter::getInstance();

                $template = $filter->clean($template, 'CMD');

                if (empty($template)) {

                    $this->sendCleanJsonResponse(['message' => 'Nom de template invalide après nettoyage.'], true);

                    return;

                }



                $userCssPath = JPATH_ROOT . '/media/templates/site/' . $template . '/css/user.css';

                $disabledUserCssPath = $userCssPath . '.disabled';



                if (file_exists($userCssPath)) {

                    $this->sendCleanJsonResponse(['success' => true, 'status' => 'enabled', 'path' => 'media/templates/site/' . $template . '/css/user.css']);

                } elseif (file_exists($disabledUserCssPath)) {

                    $this->sendCleanJsonResponse(['success' => true, 'status' => 'disabled', 'path' => 'media/templates/site/' . $template . '/css/user.css.disabled']);

                } else {

                    $this->sendCleanJsonResponse(['success' => true, 'status' => 'missing', 'path' => 'media/templates/site/' . $template . '/css/user.css']);

                }

                return;

            }



            // Tâche pour activer/désactiver le fichier user.css

            if ($task === 'module.toggleUserCss') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                $template = $input->getString('template');

                if (empty($template)) {

                    $this->sendCleanJsonResponse(['message' => 'Nom du template manquant.'], true, $debug, $debugFile);

                    return;

                }



                $filter = InputFilter::getInstance();

                $template = $filter->clean($template, 'CMD');



                if (empty($template)) {

                    $this->sendCleanJsonResponse(['message' => 'Nom de template invalide après nettoyage.'], true, $debug, $debugFile);

                    return;

                }



                $userCssPath = JPATH_ROOT . '/media/templates/site/' . $template . '/css/user.css';

                $disabledUserCssPath = $userCssPath . '.disabled';



                if (file_exists($userCssPath)) {
                    // Désactiver : renommer user.css en user.css.disabled
                    if (is_writable(dirname($userCssPath)) && rename($userCssPath, $disabledUserCssPath)) {
                        $this->clearCache($debug, $debugFile);
                        $this->sendCleanJsonResponse(['success' => true, 'message' => 'Le fichier user.css a été désactivé et le cache a été vidé.', 'status' => 'disabled']);
                    } else {
                        $this->sendCleanJsonResponse(['message' => 'Impossible de renommer le fichier user.css. Vérifiez les permissions d\'écriture.'], true);
                    }
                } elseif (file_exists($disabledUserCssPath)) {
                    // Activer : renommer user.css.disabled en user.css
                    if (is_writable(dirname($disabledUserCssPath)) && rename($disabledUserCssPath, $userCssPath)) {
                        $this->clearCache($debug, $debugFile);
                        $this->sendCleanJsonResponse(['success' => true, 'message' => 'Le fichier user.css a été activé et le cache a été vidé.', 'status' => 'enabled']);
                    } else {
                        $this->sendCleanJsonResponse(['message' => 'Impossible de renommer le fichier user.css.disabled. Vérifiez les permissions d\'écriture.'], true);
                    }
                } else {
                    $this->sendCleanJsonResponse(['message' => 'Le fichier user.css ou user.css.disabled n\'existe pas pour ce template.'], true);
                }
                return;
            }

            // Tâche pour déployer l'archive ZIP du thème enfant via Installer Joomla
            if ($task === 'module.deployThemeZip') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                $file = $_FILES['theme_zip'] ?? null;
                if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur lors du téléchargement du fichier ZIP.'], true);
                    return;
                }

                // Nouvelle Stratégie Robuste : Extraction Manuelle -> Validation -> Installation depuis Répertoire
                $tempExtractDir = JPATH_CACHE . '/theme_install_' . microtime(true);

                try {
                    // 1. Extraction manuelle
                    // Cela évite les problèmes de détection de type d'archive par l'installateur
                    if (!Folder::create($tempExtractDir)) {
                        throw new Exception("Impossible de créer le répertoire temporaire d'extraction.");
                    }

                    if (class_exists('ZipArchive')) {
                        // Méthode native PHP (plus rapide)
                        $zip = new \ZipArchive;
                        if ($zip->open($file['tmp_name']) !== TRUE) {
                            throw new Exception("Impossible d'ouvrir l'archive ZIP.");
                        }
                        if (!$zip->extractTo($tempExtractDir)) {
                            $zip->close();
                            throw new Exception("L'extraction de l'archive a échoué.");
                        }
                        $zip->close();
                        $extractMethod = 'ZipArchive';
                    } else {
                        // Fallback : API Joomla (pure PHP, toujours disponible)
                        $archive = new JoomlaArchive();
                        if (!$archive->extract($file['tmp_name'], $tempExtractDir)) {
                            throw new Exception("L'extraction de l'archive a échoué (API Joomla).");
                        }
                        $extractMethod = 'Joomla\\Archive';
                    }

                    // 2. Validation du contenu (templateDetails.xml)
                    // On cherche le XML à la racine ou dans un sous-dossier direct
                    $xmlFiles = glob($tempExtractDir . '/*/templateDetails.xml');
                    if (empty($xmlFiles)) {
                        $xmlFiles = glob($tempExtractDir . '/templateDetails.xml');
                    }

                    if (empty($xmlFiles)) {
                        throw new Exception("Fichier templateDetails.xml introuvable dans l'archive.");
                    }

                    $xmlPath = $xmlFiles[0];
                    // Le dossier racine d'installation est celui qui contient le XML
                    $installSourceDir = dirname($xmlPath);

                    libxml_use_internal_errors(true);
                    $xml = simplexml_load_file($xmlPath);
                    if (!$xml) {
                        throw new Exception("Impossible de lire le manifest XML.");
                    }

                    $templateName = (string) $xml->name;
                    $templateParent = (string) ($xml->parent ?? '');

                    // Vérification stricte Child Theme
                    if (empty($templateParent)) {
                        throw new Exception("Le package '$templateName' n'est pas un thème enfant (balise <parent> manquante).");
                    }

                    // Vérification présence Parent
                    if (!is_dir(JPATH_ROOT . '/templates/' . $templateParent)) {
                        throw new Exception("Le thème parent '$templateParent' est absent du site. Installation annulée.");
                    }

                    // 3. Installation via Joomla Installer depuis le répertoire
                    $installer = Installer::getInstance();

                    // On passe le chemin du répertoire décompressé
                    if (!$installer->install($installSourceDir)) {
                        throw new Exception("L'installation Joomla a échoué : " . ($installer->getError() ?: 'Erreur inconnue lors de l\'enregistrement.'));
                    }

                    // 4. Activation du style
                    $db = Factory::getDbo();
                    // Trouver le style fraîchement créé
                    $query = $db->getQuery(true)
                        ->select('id')
                        ->from($db->quoteName('#__template_styles'))
                        ->where($db->quoteName('template') . ' = ' . $db->quote($templateName))
                        ->where($db->quoteName('client_id') . ' = 0')
                        ->order($db->quoteName('id') . ' DESC');

                    $styleId = $db->setQuery($query, 0, 1)->loadResult();

                    if ($styleId) {
                        // Désactiver home actuel
                        $query = $db->getQuery(true)
                            ->update($db->quoteName('#__template_styles'))
                            ->set($db->quoteName('home') . ' = ' . $db->quote('0'))
                            ->where($db->quoteName('client_id') . ' = 0');
                        $db->setQuery($query)->execute();

                        // Activer nouveau style
                        $query = $db->getQuery(true)
                            ->update($db->quoteName('#__template_styles'))
                            ->set($db->quoteName('home') . ' = ' . $db->quote('1'))
                            ->where($db->quoteName('id') . ' = ' . (int) $styleId);
                        $db->setQuery($query)->execute();

                        // Désactiver l'en-tête du site (brand) automatiquement
                        $brandDebugInfo = [];
                        try {
                            // Récupérer les params actuels du style
                            $query = $db->getQuery(true)
                                ->select($db->quoteName('params'))
                                ->from($db->quoteName('#__template_styles'))
                                ->where($db->quoteName('id') . ' = ' . (int) $styleId);
                            $currentParams = $db->setQuery($query)->loadResult();

                            // Décoder les params JSON
                            $paramsArray = json_decode($currentParams, true) ?: [];

                            // Debug : Capturer les infos AVANT modification
                            $brandDebugInfo['params_avant'] = $paramsArray;
                            $brandDebugInfo['cles_disponibles'] = array_keys($paramsArray);
                            $brandDebugInfo['brand_avant'] = $paramsArray['brand'] ?? 'NON_DÉFINI';

                            // Désactiver le paramètre 'brand' (En-tête du site)
                            $paramsArray['brand'] = '0';

                            // Réencoder en JSON
                            $newParams = json_encode($paramsArray);

                            // Mettre à jour les params en base de données
                            $query = $db->getQuery(true)
                                ->update($db->quoteName('#__template_styles'))
                                ->set($db->quoteName('params') . ' = ' . $db->quote($newParams))
                                ->where($db->quoteName('id') . ' = ' . (int) $styleId);
                            $db->setQuery($query)->execute();

                            // Debug : Capturer les infos APRÈS modification
                            $brandDebugInfo['brand_apres'] = '0';
                            $brandDebugInfo['params_apres'] = $paramsArray;
                            $brandDebugInfo['statut'] = 'SUCCÈS';

                            if ($debug && !empty($debugFile)) {
                                file_put_contents($debugFile, date('Y-m-d H:i:s') . " | deployThemeZip: En-tête du site (brand) désactivé automatiquement\n", FILE_APPEND);
                                file_put_contents($debugFile, print_r($brandDebugInfo, true), FILE_APPEND);
                            }
                        } catch (\Exception $e) {
                            // Si la désactivation de brand échoue, on continue quand même
                            $brandDebugInfo['statut'] = 'ERREUR';
                            $brandDebugInfo['message_erreur'] = $e->getMessage();
                            if ($debug && !empty($debugFile)) {
                                file_put_contents($debugFile, date('Y-m-d H:i:s') . " | deployThemeZip: Erreur lors de la désactivation du brand (non-critique): " . $e->getMessage() . "\n", FILE_APPEND);
                            }
                        }
                    } else {
                        // Fallback si pas de style (peu probable avec un bon installer)
                        if ($debug)
                            file_put_contents($debugFile, "⚠ Style non trouvé pour activation après install.\n", FILE_APPEND);
                    }

                    // 5. Assurer la présence du user.css dans /media/templates/site/cassiopeia_dsfr/css
                    $mediaUserCssInfo = $this->ensureMediaUserCss('cassiopeia_dsfr', $debug, $debugFile);

                    // Nettoyage
                    Folder::delete($tempExtractDir);

                    $this->clearCache($debug, $debugFile);
                    $this->sendCleanJsonResponse([
                        'success' => true,
                        'message' => "Thème enfant '$templateName' installé et activé.",
                        'data' => [
                            'template_name' => $templateName,
                            'template_parent' => $templateParent,
                            'style_id' => $styleId,
                            'brand_debug' => $brandDebugInfo,  // Infos de debug pour l'en-tête
                            'media_user_css' => $mediaUserCssInfo,
                            'extract_method' => $extractMethod
                        ]
                    ]);

                } catch (\Throwable $e) {
                    // Nettoyage en cas d'erreur
                    if (is_dir($tempExtractDir)) {
                        Folder::delete($tempExtractDir);
                    }
                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | ERROR deployThemeZip: " . $e->getMessage() . "\n", FILE_APPEND);
                    }
                    $this->sendCleanJsonResponse(['message' => 'Erreur : ' . $e->getMessage()], true);
                }
                return;
            }

            // Tâche pour récupérer l'inventaire des modules du site et statistiques globales
            if ($task === 'module.getInventory') {
                if (!$this->validateCsrfToken(false, $debug, $debugFile))
                    return;

                try {
                    $db = Factory::getDbo();

                    // Tous les modules du site (client_id = 0), peu importe le statut
                    $query = $db->getQuery(true)
                        ->select($db->quoteName(['m.id', 'm.title', 'm.module', 'm.position', 'm.published']))
                        ->from($db->quoteName('#__modules', 'm'))
                        ->where($db->quoteName('m.client_id') . ' = 0')
                        ->order($db->quoteName('m.position') . ' ASC');
                    $modules = $db->setQuery($query)->loadObjectList();

                    // Statistiques Articles
                    $stats = [
                        'modules_total' => 0,
                        'articles_total' => 0,
                        'articles_trash' => 0,
                        'articles_test' => 0,
                        'articles_table' => 0,
                        'site_size' => 0,
                        'base_path' => JPATH_SITE
                    ];

                    $stats['modules_total'] = count($modules);

                    // Modules mod_menu déjà migrés en position dsfrMenuLateral
                    $query = $db->getQuery(true)
                        ->select($db->quoteName(['id', 'title']))
                        ->from($db->quoteName('#__modules'))
                        ->where($db->quoteName('client_id') . ' = 0')
                        ->where($db->quoteName('module') . ' = ' . $db->quote('mod_menu'))
                        ->where($db->quoteName('position') . ' = ' . $db->quote('dsfrMenuLateral'));
                    $stats['dsfrlateral_list']  = $db->setQuery($query)->loadObjectList();
                    $stats['dsfrlateral_total'] = count($stats['dsfrlateral_list']);

                    // Total articles
                    $query = $db->getQuery(true)
                        ->select([$db->quoteName('c.id'), $db->quoteName('c.title'), $db->quoteName('c.created'), $db->quoteName('c.modified'), $db->quoteName('cat.title', 'category')])
                        ->from($db->quoteName('#__content', 'c'))
                        ->join('LEFT', $db->quoteName('#__categories', 'cat') . ' ON ' . $db->quoteName('cat.id') . ' = ' . $db->quoteName('c.catid'));
                    $stats['articles_total_list'] = $db->setQuery($query)->loadObjectList();
                    $stats['articles_total'] = count($stats['articles_total_list']);

                    // Articles dans la corbeille (state = -2)
                    $query = $db->getQuery(true)
                        ->select([$db->quoteName('c.id'), $db->quoteName('c.title'), $db->quoteName('c.created'), $db->quoteName('c.modified'), $db->quoteName('cat.title', 'category')])
                        ->from($db->quoteName('#__content', 'c'))
                        ->join('LEFT', $db->quoteName('#__categories', 'cat') . ' ON ' . $db->quoteName('cat.id') . ' = ' . $db->quoteName('c.catid'))
                        ->where($db->quoteName('c.state') . ' = -2');
                    $stats['articles_trash_list'] = $db->setQuery($query)->loadObjectList();
                    $stats['articles_trash'] = count($stats['articles_trash_list']);

                    // Articles "test" (titre contient "test")
                    $query = $db->getQuery(true)
                        ->select([$db->quoteName('c.id'), $db->quoteName('c.title'), $db->quoteName('c.created'), $db->quoteName('c.modified'), $db->quoteName('cat.title', 'category')])
                        ->from($db->quoteName('#__content', 'c'))
                        ->join('LEFT', $db->quoteName('#__categories', 'cat') . ' ON ' . $db->quoteName('cat.id') . ' = ' . $db->quoteName('c.catid'))
                        ->where($db->quoteName('c.title') . ' LIKE ' . $db->quote('%test%'));
                    $stats['articles_test_list'] = $db->setQuery($query)->loadObjectList();
                    $stats['articles_test'] = count($stats['articles_test_list']);

                    // Les stats lourdes (LIKE sur contenu HTML) sont chargées séparément via getInventoryHeavy
                    $stats['articles_table']        = null;
                    $stats['articles_table_list']   = null;
                    $stats['articles_frcard']       = null;
                    $stats['articles_frcard_list']  = null;
                    $stats['categories_frcard']     = null;
                    $stats['categories_frcard_list']= null;
                    $stats['articles_frtile']       = null;
                    $stats['articles_frtile_list']  = null;
                    $stats['categories_frtile']     = null;
                    $stats['categories_frtile_list']= null;
                    $stats['articles_alert']        = null;
                    $stats['articles_alert_list']   = null;
                    $stats['categories_alert']      = null;
                    $stats['categories_alert_list'] = null;

                    // Taille du site (recherche récursive simplifiée pour éviter le timeout)
                    // On va limiter le calcul à JPATH_SITE mais on pourrait aussi utiliser une commande système si on est sur Linux/Mac
                    if (is_callable('shell_exec') && (strpos(strtolower(PHP_OS), 'win') === false)) {
                        $output = shell_exec('du -sb ' . escapeshellarg(JPATH_SITE));
                        if ($output) {
                            $stats['site_size'] = (int) explode("\t", $output)[0];
                        }
                    }

                    // Fallback si du -sb ne marche pas
                    if ($stats['site_size'] <= 0) {
                        $stats['site_size'] = $this->getFolderSize(JPATH_SITE);
                    }

                    $this->sendCleanJsonResponse([
                        'success' => true,
                        'data' => [
                            'modules' => $modules,
                            'stats' => $stats
                        ]
                    ]);
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur inventaire: ' . $e->getMessage()], true);
                }
                return;
            }

            // Stats lourdes : LIKE sur contenu HTML des articles/catégories
            if ($task === 'module.getInventoryHeavy') {
                if (!$this->validateCsrfToken(false, $debug, $debugFile))
                    return;

                try {
                    $db    = Factory::getDbo();
                    $stats = [];

                    // Articles contenant des tableaux
                    $query = $db->getQuery(true)
                        ->select([$db->quoteName('c.id'), $db->quoteName('c.title'), $db->quoteName('c.created'), $db->quoteName('c.modified'), $db->quoteName('cat.title', 'category')])
                        ->from($db->quoteName('#__content', 'c'))
                        ->join('LEFT', $db->quoteName('#__categories', 'cat') . ' ON ' . $db->quoteName('cat.id') . ' = ' . $db->quoteName('c.catid'))
                        ->where('(' . $db->quoteName('c.introtext') . ' LIKE ' . $db->quote('%<table%') .
                            ' OR ' . $db->quoteName('c.fulltext') . ' LIKE ' . $db->quote('%<table%') . ')');
                    $stats['articles_table_list'] = $db->setQuery($query)->loadObjectList();
                    $stats['articles_table']      = count($stats['articles_table_list']);

                    // Articles contenant fr-card — avec introtext/fulltext pour détecter les problèmes de structure
                    $query = $db->getQuery(true)
                        ->select([$db->quoteName('c.id'), $db->quoteName('c.title'), $db->quoteName('c.created'), $db->quoteName('c.modified'), $db->quoteName('cat.title', 'category'), $db->quoteName('c.introtext'), $db->quoteName('c.fulltext')])
                        ->from($db->quoteName('#__content', 'c'))
                        ->join('LEFT', $db->quoteName('#__categories', 'cat') . ' ON ' . $db->quoteName('cat.id') . ' = ' . $db->quoteName('c.catid'))
                        ->where('(' . $db->quoteName('c.introtext') . ' LIKE ' . $db->quote('%fr-card%') .
                            ' OR ' . $db->quoteName('c.fulltext') . ' LIKE ' . $db->quote('%fr-card%') . ')');
                    $frcardRawList = $db->setQuery($query)->loadObjectList();
                    foreach ($frcardRawList as $art) {
                        $content = ($art->introtext ?? '') . ($art->fulltext ?? '');
                        $issues  = [];
                        if (strpos($content, 'fr-card__body')    === false) $issues[] = 'sans fr-card__body';
                        if (strpos($content, 'fr-card__content') === false) $issues[] = 'sans fr-card__content';
                        if (strpos($content, 'fr-card__title')   === false) $issues[] = 'sans fr-card__title';
                        if (strpos($content, 'fr-card__link')    === false) $issues[] = 'sans fr-card__link';
                        if (strpos($content, 'blog-items')       !== false) $issues[] = 'grille à corriger';
                        if (preg_match('/fr-card__desc[^"]*"[^>]*>[\s]*<\/p>/u', $content)) $issues[] = 'desc vide';
                        if (preg_match('/fr-card[^"\']*col-/', $content))   $issues[] = 'col-* résiduels';
                        if (substr_count($content, 'fr-card__body') > substr_count($content, 'fr-enlarge-link')) $issues[] = 'structure dupliquée';
                        $art->card_issues = implode(',', $issues);
                        $art->card_count  = substr_count($content, 'fr-enlarge-link');
                        unset($art->introtext, $art->fulltext);
                    }
                    $stats['articles_frcard_list'] = $frcardRawList;
                    $stats['articles_frcard']      = count($frcardRawList);

                    // Catégories contenant fr-card
                    $query = $db->getQuery(true)
                        ->select([$db->quoteName('id'), $db->quoteName('title')])
                        ->from($db->quoteName('#__categories'))
                        ->where($db->quoteName('description') . ' LIKE ' . $db->quote('%fr-card%'))
                        ->where($db->quoteName('extension') . ' = ' . $db->quote('com_content'));
                    $stats['categories_frcard_list'] = $db->setQuery($query)->loadObjectList();
                    $stats['categories_frcard']      = count($stats['categories_frcard_list']);

                    // Articles contenant fr-tile
                    $query = $db->getQuery(true)
                        ->select([$db->quoteName('c.id'), $db->quoteName('c.title'), $db->quoteName('c.created'), $db->quoteName('c.modified'), $db->quoteName('cat.title', 'category')])
                        ->from($db->quoteName('#__content', 'c'))
                        ->join('LEFT', $db->quoteName('#__categories', 'cat') . ' ON ' . $db->quoteName('cat.id') . ' = ' . $db->quoteName('c.catid'))
                        ->where('(' . $db->quoteName('c.introtext') . ' LIKE ' . $db->quote('%fr-tile%') .
                            ' OR ' . $db->quoteName('c.fulltext') . ' LIKE ' . $db->quote('%fr-tile%') . ')');
                    $stats['articles_frtile_list'] = $db->setQuery($query)->loadObjectList();
                    $stats['articles_frtile']      = count($stats['articles_frtile_list']);

                    // Catégories contenant fr-tile
                    $query = $db->getQuery(true)
                        ->select([$db->quoteName('id'), $db->quoteName('title')])
                        ->from($db->quoteName('#__categories'))
                        ->where($db->quoteName('description') . ' LIKE ' . $db->quote('%fr-tile%'))
                        ->where($db->quoteName('extension') . ' = ' . $db->quote('com_content'));
                    $stats['categories_frtile_list'] = $db->setQuery($query)->loadObjectList();
                    $stats['categories_frtile']      = count($stats['categories_frtile_list']);

                    // Articles contenant des alertes Bootstrap
                    $query = $db->getQuery(true)
                        ->select([$db->quoteName('c.id'), $db->quoteName('c.title'), $db->quoteName('c.created'), $db->quoteName('c.modified'), $db->quoteName('cat.title', 'category'), $db->quoteName('c.introtext'), $db->quoteName('c.fulltext')])
                        ->from($db->quoteName('#__content', 'c'))
                        ->join('LEFT', $db->quoteName('#__categories', 'cat') . ' ON ' . $db->quoteName('cat.id') . ' = ' . $db->quoteName('c.catid'))
                        ->where('(' . $db->quoteName('c.introtext') . ' LIKE ' . $db->quote('%alert alert-%') .
                            ' OR ' . $db->quoteName('c.fulltext') . ' LIKE ' . $db->quote('%alert alert-%') . ')');
                    $alertRawList = $db->setQuery($query)->loadObjectList();
                    foreach ($alertRawList as $art) {
                        $content = ($art->introtext ?? '') . ($art->fulltext ?? '');
                        $variants = [];
                        foreach (['alert-success', 'alert-info', 'alert-warning', 'alert-danger'] as $v) {
                            if (strpos($content, $v) !== false) $variants[] = $v;
                        }
                        $art->alert_variants = implode(',', $variants);
                        unset($art->introtext, $art->fulltext);
                    }
                    $stats['articles_alert_list'] = $alertRawList;
                    $stats['articles_alert']      = count($alertRawList);

                    // Catégories contenant des alertes Bootstrap
                    $query = $db->getQuery(true)
                        ->select([$db->quoteName('id'), $db->quoteName('title')])
                        ->from($db->quoteName('#__categories'))
                        ->where($db->quoteName('description') . ' LIKE ' . $db->quote('%alert alert-%'))
                        ->where($db->quoteName('extension') . ' = ' . $db->quote('com_content'));
                    $stats['categories_alert_list'] = $db->setQuery($query)->loadObjectList();
                    $stats['categories_alert']      = count($stats['categories_alert_list']);

                    $this->sendCleanJsonResponse(['success' => true, 'data' => ['stats' => $stats]]);
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur inventaire heavy: ' . $e->getMessage()], true);
                }
                return;
            }

            // Tâche pour vider le cache de Joomla
            if ($task === 'module.clearJoomlaCache') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                try {
                    $this->clearCache($debug, $debugFile);
                    $this->sendCleanJsonResponse(['success' => true, 'message' => 'Tous les caches de Joomla ont été vidés.']);
                } catch (\Throwable $e) {
                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | ERROR clearJoomlaCache: " . $e->getMessage() . "\n", FILE_APPEND);
                    }
                    $this->sendCleanJsonResponse(['message' => 'Erreur lors du vidage du cache: ' . $e->getMessage()], true, $debug, $debugFile);
                }
                return; // FIX: Return is present but good to confirm
            }

            // Tâche pour vider la corbeille des modules (state = -2)
            if ($task === 'module.clearModuleTrash') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                try {
                    $db = Factory::getDbo();

                    // Récupérer les IDs en corbeille
                    $query = $db->getQuery(true)
                        ->select($db->quoteName('id'))
                        ->from($db->quoteName('#__modules'))
                        ->where($db->quoteName('published') . ' = -2');
                    $trashIds = $db->setQuery($query)->loadColumn();

                    $deleted = 0;
                    if (!empty($trashIds)) {
                        $idList = implode(',', array_map('intval', $trashIds));
                        // Supprimer les assignations menu
                        $db->setQuery('DELETE FROM ' . $db->quoteName('#__modules_menu') . ' WHERE ' . $db->quoteName('moduleid') . " IN ($idList)")->execute();
                        // Supprimer les modules
                        $db->setQuery('DELETE FROM ' . $db->quoteName('#__modules') . ' WHERE ' . $db->quoteName('id') . " IN ($idList)")->execute();
                        $deleted = count($trashIds);
                    }

                    $this->sendCleanJsonResponse([
                        'success' => true,
                        'data' => [
                            'deleted' => $deleted
                        ]
                    ]);
                } catch (\Throwable $e) {
                    if ($debug && !empty($debugFile)) {
                        file_put_contents($debugFile, date('Y-m-d H:i:s') . " | ERROR clearModuleTrash: " . $e->getMessage() . "\n", FILE_APPEND);
                    }
                    $this->sendCleanJsonResponse(['message' => 'Erreur lors du vidage de la corbeille: ' . $e->getMessage()], true, $debug, $debugFile);
                }
                return;
            }

            // Appliquer le modèle de params menu latéral aux modules cibles
            if ($task === 'module.applyLateralModel') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                $targetIdsRaw = $input->getString('target_ids', '');
                $targetIds = array_filter(array_map('intval', explode(',', $targetIdsRaw)));

                if (empty($targetIds)) {
                    $this->sendCleanJsonResponse(['message' => 'Aucun module cible fourni.'], true);
                    return;
                }

                // Charger le fichier modèle
                $modelFile = __DIR__ . '/assets/json/menulateralgauche.json';
                if (!file_exists($modelFile)) {
                    $this->sendCleanJsonResponse(['message' => 'Fichier modèle introuvable (menulateralgauche.json).'], true);
                    return;
                }

                $modelJson = file_get_contents($modelFile);
                $modelData = json_decode($modelJson, true);

                $modelModule = $modelData['modules'][0]['module'] ?? null;
                if (!$modelModule) {
                    $this->sendCleanJsonResponse(['message' => 'Module modèle introuvable dans le JSON.'], true);
                    return;
                }

                $modelParamsRaw = $modelModule['params'] ?? null;
                if (!$modelParamsRaw) {
                    $this->sendCleanJsonResponse(['message' => 'Params modèle introuvables dans le JSON.'], true);
                    return;
                }

                $modelParams = json_decode($modelParamsRaw, true);
                if (!is_array($modelParams)) {
                    $this->sendCleanJsonResponse(['message' => 'Params modèle invalides (JSON malformé).'], true);
                    return;
                }

                // Champs directs à appliquer depuis le modèle (hors params JSON)
                $modelPosition  = $modelModule['position']  ?? null;
                $modelShowtitle = isset($modelModule['showtitle']) ? (int) $modelModule['showtitle'] : null;

                // Retirer menutype du modèle — il sera préservé depuis chaque module cible
                unset($modelParams['menutype']);

                $db = Factory::getDbo();
                $updated = [];
                $errors  = [];

                foreach ($targetIds as $targetId) {
                    try {
                        // Lire les params actuels de la cible pour récupérer son menutype
                        $query = $db->getQuery(true)
                            ->select($db->quoteName('params'))
                            ->from($db->quoteName('#__modules'))
                            ->where($db->quoteName('id') . ' = ' . (int) $targetId)
                            ->where($db->quoteName('client_id') . ' = 0');
                        $currentParamsRaw = $db->setQuery($query)->loadResult();

                        if ($currentParamsRaw === null) {
                            $errors[] = ['id' => $targetId, 'error' => 'Module introuvable'];
                            continue;
                        }

                        $currentParams = json_decode($currentParamsRaw, true) ?: [];
                        $menutype = $currentParams['menutype'] ?? '';

                        // Fusionner : params modèle + menutype de la cible
                        $newParams = array_merge($modelParams, ['menutype' => $menutype]);
                        $newParamsJson = json_encode($newParams, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

                        // Écrire en base : params + position + showtitle depuis le modèle
                        $query = $db->getQuery(true)
                            ->update($db->quoteName('#__modules'))
                            ->set($db->quoteName('params') . ' = ' . $db->quote($newParamsJson));

                        if ($modelPosition !== null) {
                            $query->set($db->quoteName('position') . ' = ' . $db->quote($modelPosition));
                        }
                        if ($modelShowtitle !== null) {
                            $query->set($db->quoteName('showtitle') . ' = ' . (int) $modelShowtitle);
                        }

                        $query->where($db->quoteName('id') . ' = ' . (int) $targetId);
                        $db->setQuery($query)->execute();

                        $updated[] = $targetId;

                    } catch (\Exception $e) {
                        $errors[] = ['id' => $targetId, 'error' => $e->getMessage()];
                    }
                }

                $this->sendCleanJsonResponse([
                    'success' => true,
                    'updated' => $updated,
                    'errors'  => $errors,
                    'message' => count($updated) . ' module(s) mis à jour.'
                ]);
                return;
            }

            // Correction de la structure fr-card vers la structure DSFR conforme
            if ($task === 'module.applyFrcardMigration') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                $articleIdsRaw = $input->getString('article_ids', '');
                $articleIds    = array_filter(array_map('intval', explode(',', $articleIdsRaw)));

                if (empty($articleIds)) {
                    $this->sendCleanJsonResponse(['message' => 'Aucun article cible fourni.'], true);
                    return;
                }

                $db      = Factory::getDbo();
                $updated = [];
                $errors  = [];

                foreach ($articleIds as $articleId) {
                    try {
                        $query = $db->getQuery(true)
                            ->select([$db->quoteName('introtext'), $db->quoteName('fulltext')])
                            ->from($db->quoteName('#__content'))
                            ->where($db->quoteName('id') . ' = ' . (int) $articleId);
                        $row = $db->setQuery($query)->loadObject();

                        if (!$row) {
                            $errors[] = ['id' => $articleId, 'error' => 'Article introuvable'];
                            continue;
                        }

                        $newIntro = $this->migrateFrcardHtml($row->introtext ?? '');
                        $newFull  = $this->migrateFrcardHtml($row->fulltext  ?? '');

                        $query = $db->getQuery(true)
                            ->update($db->quoteName('#__content'))
                            ->set($db->quoteName('introtext') . ' = ' . $db->quote($newIntro))
                            ->set($db->quoteName('fulltext')  . ' = ' . $db->quote($newFull))
                            ->where($db->quoteName('id') . ' = ' . (int) $articleId);
                        $db->setQuery($query)->execute();

                        $updated[] = $articleId;
                    } catch (\Exception $e) {
                        $errors[] = ['id' => $articleId, 'error' => $e->getMessage()];
                    }
                }

                $this->sendCleanJsonResponse([
                    'success' => true,
                    'updated' => $updated,
                    'errors'  => $errors,
                    'message' => count($updated) . ' article(s) corrigé(s).'
                ]);
                return;
            }

            // Migration des classes Bootstrap alert → DSFR fr-alert
            if ($task === 'module.applyAlertMigration') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                $articleIdsRaw = $input->getString('article_ids', '');
                $articleIds = array_filter(array_map('intval', explode(',', $articleIdsRaw)));

                if (empty($articleIds)) {
                    $this->sendCleanJsonResponse(['message' => 'Aucun article cible fourni.'], true);
                    return;
                }

                // Mapping Bootstrap → DSFR
                $search  = ['alert alert-success', 'alert alert-info', 'alert alert-warning', 'alert alert-danger'];
                $replace = ['fr-alert fr-alert--success', 'fr-alert fr-alert--info', 'fr-alert fr-alert--warning', 'fr-alert fr-alert--error'];

                $db      = Factory::getDbo();
                $updated = [];
                $errors  = [];

                foreach ($articleIds as $articleId) {
                    try {
                        $query = $db->getQuery(true)
                            ->select([$db->quoteName('introtext'), $db->quoteName('fulltext')])
                            ->from($db->quoteName('#__content'))
                            ->where($db->quoteName('id') . ' = ' . (int) $articleId);
                        $row = $db->setQuery($query)->loadObject();

                        if (!$row) {
                            $errors[] = ['id' => $articleId, 'error' => 'Article introuvable'];
                            continue;
                        }

                        $newIntro = str_replace($search, $replace, $row->introtext ?? '');
                        $newFull  = str_replace($search, $replace, $row->fulltext  ?? '');

                        $query = $db->getQuery(true)
                            ->update($db->quoteName('#__content'))
                            ->set($db->quoteName('introtext') . ' = ' . $db->quote($newIntro))
                            ->set($db->quoteName('fulltext')  . ' = ' . $db->quote($newFull))
                            ->where($db->quoteName('id') . ' = ' . (int) $articleId);
                        $db->setQuery($query)->execute();

                        $updated[] = $articleId;
                    } catch (\Exception $e) {
                        $errors[] = ['id' => $articleId, 'error' => $e->getMessage()];
                    }
                }

                $this->sendCleanJsonResponse([
                    'success' => true,
                    'updated' => $updated,
                    'errors'  => $errors,
                    'message' => count($updated) . ' article(s) migré(s).'
                ]);
                return;
            }

            // Traitement de l'export
            if ($task === 'module.exportmodule') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                $moduleId = $input->getInt('id');
                $disableModule = $input->getInt('disable_modules', 0);

                if (!$moduleId) {
                    $this->sendCleanJsonResponse(['message' => 'ID du module manquant'], true);
                    return;
                }

                try {
                    require_once __DIR__ . '/src/Handler/ExportHandler.php';
                    $exporter = new ExportHandler($this->params, $this->getLogger());
                    $result = $exporter->exportModule($moduleId, $disableModule);
                    $this->sendCleanJsonResponse(['success' => true, 'data' => $result]);
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur: ' . $e->getMessage()], true, $debug, $debugFile);
                }
                $app->close();
            }

            // Réception d'un fragment d'import (chunked upload)
            if ($task === 'module.importchunk') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                try {
                    $uploadId = preg_replace('/[^a-zA-Z0-9_-]/', '', $input->getString('upload_id', ''));
                    $chunkIndex = $input->getInt('chunk_index', -1);
                    $totalChunks = $input->getInt('total_chunks', 0);
                    $chunkData = $input->getRaw('chunk_data');

                    if (empty($uploadId) || $chunkIndex < 0 || $totalChunks < 1 || $chunkData === null || $chunkData === '') {
                        throw new \Exception('Paramètres de chunk invalides');
                    }

                    $tmpDir = sys_get_temp_dir();
                    $chunkFile = $tmpDir . '/me_chunk_' . $uploadId . '_' . str_pad($chunkIndex, 4, '0', STR_PAD_LEFT);

                    if (file_put_contents($chunkFile, $chunkData) === false) {
                        throw new \Exception('Erreur d\'écriture du chunk');
                    }

                    if ($debug) {
                        file_put_contents($debugFile, "[CHUNK] Chunk $chunkIndex/$totalChunks reçu (" . strlen($chunkData) . " bytes) -> $chunkFile\n", FILE_APPEND);
                    }

                    $this->sendCleanJsonResponse([
                        'success' => true,
                        'data' => ['chunk_index' => $chunkIndex, 'received' => strlen($chunkData)]
                    ]);

                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Chunk error: ' . $e->getMessage()], true, $debug, $debugFile);
                }
                return;
            }

            // Traitement de l'import
            if ($task === 'module.importmodule') {
                if (!$this->validateCsrfToken(true, $debug, $debugFile))
                    return;

                @set_time_limit(0);
                @ignore_user_abort(true);
                @ini_set('memory_limit', '256M');
                ob_start();

                // === Nouveau flux : délégation au ImportHandler (refactor) ===
                try {
                    require_once __DIR__ . '/src/Handler/ImportHandler.php';

                    // Reconstitution des données si upload chunké
                    $importData = $input->getRaw('import_data');
                    $uploadId = preg_replace('/[^a-zA-Z0-9_-]/', '', $input->getString('upload_id', ''));
                    if (!$importData && !empty($uploadId)) {
                        $totalChunks = $input->getInt('total_chunks', 0);
                        if ($totalChunks < 1) {
                            throw new Exception('Paramètre total_chunks manquant pour le réassemblage');
                        }
                        $tmpDir = sys_get_temp_dir();
                        $importData = '';
                        for ($i = 0; $i < $totalChunks; $i++) {
                            $chunkFile = $tmpDir . '/me_chunk_' . $uploadId . '_' . str_pad($i, 4, '0', STR_PAD_LEFT);
                            if (!file_exists($chunkFile)) {
                                throw new Exception("Chunk $i manquant pour l'upload $uploadId");
                            }
                            $importData .= file_get_contents($chunkFile);
                            unlink($chunkFile);
                        }
                        if ($debug) {
                            file_put_contents($debugFile, "[IMPORT] Données reconstituées à partir de $totalChunks chunks (" . strlen($importData) . " bytes)\n", FILE_APPEND);
                        }
                    }

                    if (!$importData) {
                        throw new Exception('Aucune donnée d\'importation fournie');
                    }

                    // Options pour le handler
                    $options = [
                        'id_mapping' => $input->getInt('id_mapping', 1) == 1,
                        'selected_modules' => $input->get('selected_modules', null, 'array'),
                        'find_replace' => [
                            'find' => $input->getString('find_text', ''),
                            'replace' => $input->getString('replace_text', '')
                        ]
                    ];

                    $jsonData = json_decode($importData, true);
                    if (json_last_error() !== JSON_ERROR_NONE) {
                        throw new Exception('JSON invalide : ' . json_last_error_msg());
                    }

                    $importer = new ImportHandler($this->params, $this->getLogger());
                    $result = $importer->importModules($jsonData, $options);

                    $this->sendCleanJsonResponse(['success' => true, 'data' => $result]);
                } catch (\Throwable $e) {
                    $this->sendCleanJsonResponse(['message' => 'Erreur critique lors de l\'import : ' . $e->getMessage()], true, $debug, $debugFile);
                }
                return;

                // --- Legacy flow (déprécié, conservé temporairement) ---
                try {
                    $filter = InputFilter::getInstance();



                    $runIdMapping = $input->getInt('id_mapping', 1);

                    // Réassemblage des chunks si upload fragmenté
                    $uploadId = preg_replace('/[^a-zA-Z0-9_-]/', '', $input->getString('upload_id', ''));
                    if (!$importData && !empty($uploadId)) {
                        $totalChunks = $input->getInt('total_chunks', 0);
                        if ($totalChunks < 1) {
                            throw new Exception('Paramètre total_chunks manquant pour le réassemblage');
                        }

                        $tmpDir = sys_get_temp_dir();
                        $importData = '';

                        for ($i = 0; $i < $totalChunks; $i++) {
                            $chunkFile = $tmpDir . '/me_chunk_' . $uploadId . '_' . str_pad($i, 4, '0', STR_PAD_LEFT);
                            if (!file_exists($chunkFile)) {
                                throw new Exception("Chunk $i manquant pour l'upload $uploadId");
                            }
                            $importData .= file_get_contents($chunkFile);
                            unlink($chunkFile);
                        }

                        if ($debug) {
                            file_put_contents($debugFile, "[IMPORT] Données reconstituées à partir de $totalChunks chunks (" . strlen($importData) . " bytes)\n", FILE_APPEND);
                        }
                    }

                    if (!$importData) {
                        throw new Exception('Aucune donnée d\'importation fournie');
                    }

                    if ($debug) {
                        $len = strlen($importData);
                        file_put_contents($debugFile, "[IMPORT] Taille données brutes: {$len} bytes\n", FILE_APPEND);
                        file_put_contents($debugFile, "[IMPORT] Données brutes (2000 chars max):\n" . substr($importData, 0, 2000) . "...\n", FILE_APPEND);
                    }

                    // NOUVEAU : Option de migration de thème
                    $bindToTemplate = $input->getInt('bind_to_template', 0);

                    // Suppression du nettoyage manuel qui peut corrompre le JSON. JSON.stringify/decode gèrent l'UTF-8.
                    $jsonData = json_decode($importData, true);

                    // Vérification de la validité du JSON
                    if (json_last_error() !== JSON_ERROR_NONE) {
                        throw new Exception('JSON invalide : ' . json_last_error_msg());
                    }

                    // Vérification que le JSON décodé est un tableau
                    if (!is_array($jsonData)) {
                        throw new Exception('Structure JSON invalide : le JSON doit contenir un tableau ou un objet');
                    }

                    // Libérer la chaîne brute pour économiser la mémoire
                    unset($importData);

                    $modulesToImport = [];

                    if (isset($jsonData['modules']) && is_array($jsonData['modules'])) {
                        $modulesToImport = $jsonData['modules'];
                        if ($debug) {
                            file_put_contents($debugFile, "[IMPORT] Format multi-modules détecté. Nombre de modules : " . count($modulesToImport) . "\n", FILE_APPEND);
                        }
                    } elseif (isset($jsonData['module']) && is_array($jsonData['module'])) {
                        $modulesToImport = [$jsonData];
                        if ($debug) {
                            file_put_contents($debugFile, "[IMPORT] Format module unique détecté.\n", FILE_APPEND);
                        }
                    } else {
                        // Essayer de détecter si c'est directement un module
                        if (isset($jsonData['title']) && isset($jsonData['module'])) {
                            $modulesToImport = [$jsonData];
                            if ($debug) {
                                file_put_contents($debugFile, "[IMPORT] Format module direct détecté.\n", FILE_APPEND);
                            }
                        } else {
                            throw new Exception('Structure JSON invalide. Le fichier doit contenir soit "modules" (tableau), soit "module" (objet unique).');
                        }
                    }

                    // Vérification finale que nous avons des modules à importer
                    if (empty($modulesToImport)) {
                        throw new Exception('Aucun module valide trouvé dans le fichier JSON.');
                    }

                    $importedCount = 0;
                    $failedCount = 0;
                    $failedModules = [];
                    $idMap = [];
                    $mappingLog = [];
                    $createdModules = [];
                    $importWarnings = []; // Initialisation du tableau des avertissements
                    $moduleRegistry = []; // ✅ NOUVEAU : Index des modules du JSON par Original ID
                    // ✅ Pattern robuste pour détecter {loadmoduleid} (gère espaces, NBSP et entités HTML)
                    $loadModulePattern = '/\{loadmoduleid(?:\s|&nbsp;|&#160;|\x{00A0})+(\d+)\}/iu';

                    $db = Factory::getDbo();
                    $user = $this->app->getIdentity();

                    // ═══════════════════════════════════════════════════════════════
                    // PHASE 1 : PRÉ-SCAN - Détection des références et dépendances
                    // ═══════════════════════════════════════════════════════════════
                    if ($debug) {
                        file_put_contents($debugFile, "\n[PHASE 1 - PRÉ-SCAN] ═══════════════════════════════════════\n", FILE_APPEND);
                    }

                    // 1.1 - Créer un registre enrichi des modules du JSON
                    $moduleDependencies = []; // module_id => [array of referenced IDs]
                    $allReferencedIds = []; // Tous les IDs référencés dans le JSON

                    foreach ($modulesToImport as $idx => $moduleItem) {
                        $moduleData = isset($moduleItem['module']) && is_array($moduleItem['module'])
                            ? $moduleItem['module']
                            : $moduleItem;
                        $originalId = $moduleItem['moduleId'] ?? ($moduleData['id'] ?? null);
                        $content = $moduleData['content'] ?? '';
                        $params = $moduleData['params'] ?? '{}';

                        // Convertir params en string si nécessaire
                        if (is_array($params) || is_object($params)) {
                            $params = json_encode($params);
                        }

                        if ($originalId && is_numeric($originalId)) {
                            // Enregistrer les métadonnées du module
                            $moduleRegistry[$originalId] = [
                                'title' => isset($moduleData['title']) ? trim($moduleData['title']) : '',
                                'module' => $moduleData['module'] ?? '',
                                'position' => isset($moduleData['position']) ? trim($moduleData['position']) : '',
                                'index' => $idx // Position dans le tableau JSON
                            ];

                            // Détecter les références dans content et params
                            $dependencies = [];

                            // Recherche dans le content
                            if (preg_match_all($loadModulePattern, $content, $matches)) {
                                foreach ($matches[1] as $refId) {
                                    $refId = (int) $refId;
                                    $dependencies[$refId] = true;
                                    $allReferencedIds[$refId] = true;
                                }
                            }

                            // Recherche dans les params
                            if (preg_match_all($loadModulePattern, $params, $matches)) {
                                foreach ($matches[1] as $refId) {
                                    $refId = (int) $refId;
                                    $dependencies[$refId] = true;
                                    $allReferencedIds[$refId] = true;
                                }
                            }

                            $moduleDependencies[$originalId] = array_keys($dependencies);

                            if ($debug) {
                                $depsStr = !empty($moduleDependencies[$originalId])
                                    ? implode(', ', $moduleDependencies[$originalId])
                                    : 'aucune';
                                file_put_contents($debugFile, "[PRÉ-SCAN] Module ID {$originalId} '{$moduleRegistry[$originalId]['title']}' → dépendances: {$depsStr}\n", FILE_APPEND);
                            }
                        }
                    }

                    // 1.2 - Rechercher les modules existants en BD pour les IDs référencés
                    $idMapExisting = [];
                    if ($runIdMapping == 1 && !empty($allReferencedIds)) {
                        if ($debug) {
                            file_put_contents($debugFile, "\n[PRÉ-SCAN] Recherche des modules existants pour " . count($allReferencedIds) . " ID(s) référencé(s)...\n", FILE_APPEND);
                        }

                        // CORRECTION N+1: Récupération en masse des modules candidats
                        $query = $db->getQuery(true)
                            ->select($db->quoteName(['id', 'title', 'note', 'params']))
                            ->from($db->quoteName('#__modules'))
                            ->where($db->quoteName('client_id') . ' = 0')
                            ->where('(' . $db->quoteName('note') . ' LIKE ' . $db->quote('%Original ID%') . ' OR ' . $db->quoteName('params') . ' LIKE ' . $db->quote('%moduleexport_original_id%') . ')');

                        $candidates = $db->setQuery($query)->loadObjectList();

                        foreach ($candidates as $cand) {
                            $foundOldId = null;

                            // Check note
                            if (preg_match('/\[Original ID: (\d+)\]/', $cand->note, $m)) {
                                $foundOldId = (int) $m[1];
                            }
                            // Check params
                            else {
                                $p = json_decode($cand->params, true);
                                if (isset($p['moduleexport_original_id'])) {
                                    $foundOldId = (int) $p['moduleexport_original_id'];
                                }
                            }

                            if ($foundOldId && isset($allReferencedIds[$foundOldId]) && !isset($moduleRegistry[$foundOldId])) {
                                $idMapExisting[$foundOldId] = $cand->id;
                                if ($debug) {
                                    file_put_contents($debugFile, "[PRÉ-SCAN] ✓ Module existant trouvé (Batch): Original ID {$foundOldId} → Actuel ID {$cand->id} '{$cand->title}'\n", FILE_APPEND);
                                }
                            }
                        }
                    }

                    if ($debug) {
                        file_put_contents($debugFile, "\n[PRÉ-SCAN] Résumé:\n", FILE_APPEND);
                        file_put_contents($debugFile, "  - Modules à importer: " . count($moduleRegistry) . "\n", FILE_APPEND);
                        file_put_contents($debugFile, "  - Modules existants mappés: " . count($idMapExisting) . "\n", FILE_APPEND);
                        file_put_contents($debugFile, "  - IDs référencés totaux: " . count($allReferencedIds) . "\n", FILE_APPEND);
                    }

                    // ═══════════════════════════════════════════════════════════════
                    // PHASE 2 : INSERTION ORDONNÉE - Tri par dépendances
                    // ═══════════════════════════════════════════════════════════════
                    if ($debug) {
                        file_put_contents($debugFile, "\n[PHASE 2 - TRI] ═══════════════════════════════════════\n", FILE_APPEND);
                    }

                    // Tri topologique simple : modules sans dépendances externes d'abord
                    $sortedModules = [];
                    $processed = [];
                    $maxIterations = count($modulesToImport) * 2; // Sécurité contre boucles infinies
                    $iteration = 0;

                    while (count($sortedModules) < count($modulesToImport) && $iteration < $maxIterations) {
                        $iteration++;
                        $progressMade = false;

                        foreach ($modulesToImport as $idx => $moduleItem) {
                            if (isset($processed[$idx]))
                                continue;

                            $moduleData = isset($moduleItem['module']) && is_array($moduleItem['module'])
                                ? $moduleItem['module']
                                : $moduleItem;
                            $originalId = $moduleItem['moduleId'] ?? ($moduleData['id'] ?? null);
                            $legacyId = $moduleItem['legacy_id'] ?? ($moduleData['legacy_id'] ?? ($moduleItem['original_id'] ?? ($moduleData['original_id'] ?? null)));

                            // Si le module n'a pas d'ID, on l'ajoute directement
                            if (!$originalId || !is_numeric($originalId)) {
                                $sortedModules[] = ['item' => $moduleItem, 'index' => $idx, 'id' => $originalId];
                                $processed[$idx] = true;
                                $progressMade = true;
                                continue;
                            }

                            // Vérifier si toutes les dépendances sont satisfaites
                            $deps = $moduleDependencies[$originalId] ?? [];
                            $canInsert = true;

                            foreach ($deps as $depId) {
                                // Dépendance OK si :
                                // 1. Le module dépendant existe déjà en BD (dans idMapExisting)
                                // 2. Le module dépendant est déjà dans sortedModules
                                if (!isset($idMapExisting[$depId])) {
                                    // Vérifier si déjà traité
                                    $found = false;
                                    foreach ($sortedModules as $sorted) {
                                        if ($sorted['id'] == $depId) {
                                            $found = true;
                                            break;
                                        }
                                    }
                                    if (!$found) {
                                        $canInsert = false;
                                        break;
                                    }
                                }
                            }

                            if ($canInsert) {
                                $sortedModules[] = ['item' => $moduleItem, 'index' => $idx, 'id' => $originalId];
                                $processed[$idx] = true;
                                $progressMade = true;
                            }
                        }

                        // Si aucun progrès n'a été fait, il y a probablement une dépendance circulaire
                        // On ajoute les modules restants dans l'ordre original
                        if (!$progressMade && count($sortedModules) < count($modulesToImport)) {
                            if ($debug) {
                                file_put_contents($debugFile, "[PHASE 2 - TRI] ⚠ Dépendance circulaire détectée ou modules non résolus. Ajout des modules restants dans l'ordre original.\n", FILE_APPEND);
                            }
                            foreach ($modulesToImport as $idx => $moduleItem) {
                                if (!isset($processed[$idx])) {
                                    $moduleData = isset($moduleItem['module']) && is_array($moduleItem['module'])
                                        ? $moduleItem['module']
                                        : $moduleItem;
                                    $originalId = $moduleItem['moduleId'] ?? ($moduleData['id'] ?? null);
                                    $sortedModules[] = ['item' => $moduleItem, 'index' => $idx, 'id' => $originalId];
                                    $processed[$idx] = true;
                                }
                            }
                            break;
                        }
                    }

                    if ($debug) {
                        file_put_contents($debugFile, "[PHASE 2 - TRI] Ordre d'insertion calculé:\n", FILE_APPEND);
                        foreach ($sortedModules as $i => $sorted) {
                            $modData = isset($sorted['item']['module']) && is_array($sorted['item']['module'])
                                ? $sorted['item']['module']
                                : $sorted['item'];
                            $title = $modData['title'] ?? 'Sans titre';
                            file_put_contents($debugFile, "  " . ($i + 1) . ". ID {$sorted['id']} - {$title}\n", FILE_APPEND);
                        }
                    }

                    // ═══════════════════════════════════════════════════════════════
                    // INSERTION DES MODULES (dans l'ordre trié)
                    // ═══════════════════════════════════════════════════════════════
                    if ($debug) {
                        file_put_contents($debugFile, "\n[INSERTION] ═══════════════════════════════════════\n", FILE_APPEND);
                    }

                    foreach ($sortedModules as $sortedItem) {
                        $moduleItem = $sortedItem['item'];
                        try {
                            if ($debug)
                                file_put_contents($debugFile, "\n[IMPORT] ═══════ Traitement d'un nouvel élément de module ═══════\n" . print_r($moduleItem, true) . "\n", FILE_APPEND);

                            // Vérification que $moduleItem est bien un tableau
                            if (!is_array($moduleItem)) {
                                throw new Exception('Structure de module invalide : attendu un tableau, reçu ' . gettype($moduleItem));
                            }

                            // Extraction sécurisée des données
                            $moduleData = isset($moduleItem['module']) && is_array($moduleItem['module'])
                                ? $moduleItem['module']
                                : $moduleItem;

                            // Vérification supplémentaire que $moduleData est un tableau
                            if (!is_array($moduleData)) {
                                throw new Exception('Données de module invalides : attendu un tableau, reçu ' . gettype($moduleData));
                            }

                            $originalId = $moduleItem['moduleId'] ?? ($moduleData['id'] ?? null);
                            $menuAssignments = isset($moduleItem['menu_assignments']) && is_array($moduleItem['menu_assignments'])
                                ? $moduleItem['menu_assignments']
                                : [];
                            $rlConditions = isset($moduleItem['regularlabs_conditions']) && is_array($moduleItem['regularlabs_conditions'])
                                ? $moduleItem['regularlabs_conditions']
                                : null;

                            // Reconstruction de l'objet item pour la compatibilité avec importFullConditions
                            $item = [
                                'moduleData' => $moduleData,
                                'rlConditions' => $rlConditions,
                                'menuAssignments' => $menuAssignments
                            ];



                            // Gestion de la migration de thème
                            if ($bindToTemplate) {
                                $query = $db->getQuery(true)
                                    ->select($db->quoteName('template'))
                                    ->from($db->quoteName('#__template_styles'))
                                    ->where($db->quoteName('client_id') . ' = 0')
                                    ->where($db->quoteName('home') . ' = 1');
                                $defaultTemplate = $db->setQuery($query)->loadResult();

                                if ($defaultTemplate) {
                                    $moduleData['template'] = $defaultTemplate;
                                    if ($debug)
                                        file_put_contents($debugFile, "[IMPORT] Module lié au template par défaut : {$defaultTemplate}\n", FILE_APPEND);
                                }
                            } else {
                                // Si on ne lie pas au template par défaut, vérifions si le template cible existe
                                if (!empty($moduleData['template'])) {
                                    if (!Folder::exists(JPATH_ROOT . '/templates/' . $moduleData['template'])) {
                                        $warningMsg = "Le template cible '{$moduleData['template']}' est absent. Le module '{$moduleData['title']}' a été assigné à 'Aucun' pour éviter une erreur.";
                                        $importWarnings[] = $warningMsg; // Collecte pour le rapport final

                                        if ($debug) {
                                            file_put_contents($debugFile, "[IMPORT] ⚠ {$warningMsg}\n", FILE_APPEND);
                                        }
                                        // On retire le template pour ne pas casser l'assignation
                                        $moduleData['template'] = null;
                                    }
                                }
                            }

                            // Gestion des Paramètres avec correction du style
                            $paramsRaw = $moduleData['params'] ?? '{}';
                            if ($debug) {
                                file_put_contents($debugFile, "[IMPORT] [PARAMS] Valeur brute reçue:\n" . (is_string($paramsRaw) ? substr($paramsRaw, 0, 500) : print_r($paramsRaw, true)) . "\n", FILE_APPEND);

                                // ✅ NOUVEAU : Logger la taille originale
                                $paramsOriginalSize = is_string($paramsRaw) ? strlen($paramsRaw) : strlen(json_encode($paramsRaw));
                                file_put_contents($debugFile, "[IMPORT] [PARAMS] Taille originale: $paramsOriginalSize caractères\n", FILE_APPEND);
                            }

                            // Conversion en array pour traitement
                            $paramsArray = [];
                            if (is_array($paramsRaw) || is_object($paramsRaw)) {
                                $paramsArray = (array) $paramsRaw;
                                if ($debug)
                                    file_put_contents($debugFile, "[IMPORT] [PARAMS] Format Array/Object détecté.\n", FILE_APPEND);
                            } else {
                                // String JSON, on décode
                                $paramsString = (string) $paramsRaw;
                                $decoded = json_decode($paramsString, true);
                                if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                                    $paramsArray = $decoded;
                                    if ($debug)
                                        file_put_contents($debugFile, "[IMPORT] [PARAMS] Format String JSON décodé.\n", FILE_APPEND);
                                } else {
                                    if ($debug)
                                        file_put_contents($debugFile, "[IMPORT] [PARAMS] ⚠ JSON invalide, utilisation d'un objet vide.\n", FILE_APPEND);
                                    $paramsArray = [];
                                }
                            }

                            // ✅ CORRECTION du paramètre 'style' pour éviter les warnings ModuleHelper.php:188 (J4/J5)
                            // Dans J4, '0' ou vide provoque un warning si non préfixé (ex: system-none).
                            $styleValue = isset($paramsArray['style']) ? (string) $paramsArray['style'] : '';
                            if ($styleValue === '0' || $styleValue === '') {
                                $paramsArray['style'] = 'system-none';
                                if ($debug) {
                                    file_put_contents($debugFile, "[IMPORT] [PARAMS] ✓ Style '{$styleValue}' corrigé en 'system-none'\n", FILE_APPEND);
                                }
                            } elseif (strpos($styleValue, '-') === false && strpos($styleValue, ':') === false) {
                                $paramsArray['style'] = 'system-' . $styleValue;
                                if ($debug) {
                                    file_put_contents($debugFile, "[IMPORT] [PARAMS] ✓ Style '{$styleValue}' préfixé en 'system-{$styleValue}'\n", FILE_APPEND);
                                }
                            }

                            // ✅ S'assurer que les {loadmoduleid} sont interprétés dans les modules custom
                            $moduleType = strtolower((string) ($moduleData['module'] ?? ''));
                            $contentRaw = (string) ($moduleData['content'] ?? '');
                            if ($moduleType === 'mod_custom' && stripos($contentRaw, '{loadmoduleid') !== false) {
                                $paramsArray['prepare_content'] = 1;
                                if ($debug) {
                                    file_put_contents($debugFile, "[IMPORT] [PARAMS] ✓ prepare_content forcé à 1 (loadmoduleid détecté)\n", FILE_APPEND);
                                }
                            }

                            // Stocker l'ID d'origine dans les params pour le mapping futur
                            if (is_numeric($originalId)) {
                                $paramsArray['moduleexport_original_id'] = (int) $originalId;
                            }

                            // Encoder en JSON
                            $params = json_encode($paramsArray, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

                            // Fallback sécurité : si vide, on met {}
                            if (empty(trim($params))) {
                                $params = '{}';
                            }

                            if ($debug) {
                                file_put_contents($debugFile, "[IMPORT] [PARAMS] Valeur finale injectée (longueur: " . strlen($params) . " caractères):\n" . substr($params, 0, 500) . "...\n", FILE_APPEND);

                                // ✅ NOUVEAU : Comparer les tailles et alerter si perte de données
                                if (isset($paramsOriginalSize) && $paramsOriginalSize > 0) {
                                    $paramsFinalSize = strlen($params);
                                    $lossPercentage = (($paramsOriginalSize - $paramsFinalSize) / $paramsOriginalSize) * 100;

                                    file_put_contents($debugFile, "[IMPORT] [PARAMS] Comparaison tailles - Original: $paramsOriginalSize, Final: $paramsFinalSize\n", FILE_APPEND);

                                    if ($lossPercentage > 10) {
                                        file_put_contents($debugFile, "[IMPORT] [PARAMS] ⚠️ ALERTE : Perte de données détectée ! " .
                                            "Perte de " . round($lossPercentage, 2) . "% des données\n", FILE_APPEND);
                                    } elseif ($lossPercentage < -10) {
                                        file_put_contents($debugFile, "[IMPORT] [PARAMS] ℹ️ INFO : Augmentation de taille de " .
                                            round(abs($lossPercentage), 2) . "% (probablement dû au formatage JSON)\n", FILE_APPEND);
                                    } else {
                                        file_put_contents($debugFile, "[IMPORT] [PARAMS] ✓ Tailles cohérentes (variation: " .
                                            round($lossPercentage, 2) . "%)\n", FILE_APPEND);
                                    }
                                }
                            }

                            $content = $moduleData['content'] ?? '';

                            if ($debug) {
                                file_put_contents($debugFile, "[IMPORT] [CONTENT] Content reçu du JSON (longueur: " . strlen($content) . " caractères)\n", FILE_APPEND);
                                if (strlen($content) > 0) {
                                    file_put_contents($debugFile, "[IMPORT] [CONTENT] Aperçu: " . substr($content, 0, 200) . "...\n", FILE_APPEND);

                                    // ✅ NOUVEAU : Vérifier la présence de {loadmoduleid}
                                    if (preg_match_all($loadModulePattern, $content, $matches)) {
                                        file_put_contents($debugFile, "[IMPORT] [CONTENT] ✓ Contient " . count($matches[0]) . " références {loadmoduleid}\n", FILE_APPEND);
                                        file_put_contents($debugFile, "[IMPORT] [CONTENT] IDs référencés: " . implode(', ', $matches[1]) . "\n", FILE_APPEND);
                                    } else {
                                        file_put_contents($debugFile, "[IMPORT] [CONTENT] ℹ️ Aucune référence {loadmoduleid} trouvée\n", FILE_APPEND);
                                    }
                                } else {
                                    file_put_contents($debugFile, "[IMPORT] [CONTENT] ⚠️ Le content est VIDE dans le JSON!\n", FILE_APPEND);
                                }
                            }

                            // Préparer les données du module
                            // Note : Pour le titre, on utilise trim() au lieu de filter->clean() pour préserver les caractères spéciaux
                            // ✅ AMÉLIORATION : Ajouter l'ID original dans la note pour faciliter le mapping lors d'imports ultérieurs
                            $originalNote = isset($moduleData['note']) ? trim($moduleData['note']) : '';
                            $noteWithOriginalId = $originalNote !== '' ? $originalNote : 'Importé via ModuleExport';

                            // Ajouter l'ID original s'il n'est pas déjà présent
                            if (is_numeric($originalId) && strpos($noteWithOriginalId, '[Original ID:') === false) {
                                $noteWithOriginalId .= ' [Original ID: ' . (int) $originalId . ']';
                            }

                            // STRATÉGIE "LIGHT INSERT": On insère avec params/content vides pour éviter les erreurs JTable/DB (Data too long)
                            // puis on fait un UPDATE SQL direct avec les vraies données juste après.
                            $data = [
                                'title' => isset($moduleData['title']) ? trim($moduleData['title']) : '',
                                'note' => $noteWithOriginalId,
                                'content' => '', // Vide pour l'insertion initiale (évite "Data too long")
                                'ordering' => $moduleData['ordering'] ?? 0,
                                'position' => isset($moduleData['position']) ? trim($moduleData['position']) : '',
                                'published' => $moduleData['published'] ?? 0,
                                'module' => $moduleData['module'],
                                'access' => $moduleData['access'] ?? 1,
                                'showtitle' => $moduleData['showtitle'] ?? 0,
                                'params' => '{}', // Vide pour l'insertion initiale (évite "Data too long")
                                'client_id' => $moduleData['client_id'] ?? 0,
                                'language' => $moduleData['language'] ?? '*',
                                'publish_up' => $moduleData['publish_up'] ?? null,
                                'publish_down' => $moduleData['publish_down'] ?? null,
                                'template' => $moduleData['template'] ?? null
                            ];

                            if ($debug) {
                                file_put_contents($debugFile, "[IMPORT] [TITLE] Titre importé : '" . $data['title'] . "'\n", FILE_APPEND);
                            }

                            if (isset($moduleData['description'])) {
                                $data['description'] = $filter->clean($moduleData['description'], 'HTML');
                            }

                            if ($debug)
                                file_put_contents($debugFile, "[IMPORT] [BIND] Données complètes envoyées à JTable::bind():\n" . print_r($data, true) . "\n", FILE_APPEND);

                            $table = TableFactory::getModuleTable();
                            if (!$table) {
                                throw new Exception('Échec de l\'instanciation de la table des modules (TableFactory a renvoyé null)');
                            }
                            $table->bind($data);
                            $table->created_by = $user->id;
                            $table->modified_by = $user->id;
                            $table->created = date('Y-m-d H:i:s');
                            $table->modified = date('Y-m-d H:i:s');
                            $table->id = 0;

                            if ($debug)
                                file_put_contents($debugFile, "[IMPORT] Params finaux avant création:\n" . $params . "\n", FILE_APPEND);

                            if (!$table->store()) {
                                throw new Exception('Erreur lors de la création du module : ' . $table->getError());
                            }

                            $newId = $table->id;
                            if ($debug) {
                                file_put_contents($debugFile, "[IMPORT] ✓ Module créé (ID: {$newId}).\n", FILE_APPEND);
                                $paramsAfterStore = $table->params;
                                file_put_contents($debugFile, "[IMPORT] [VERIF JTABLE] Valeur de 'params' dans l'objet JTable juste après store():\n" . $paramsAfterStore . "\n", FILE_APPEND);
                            }

                            // ✅ FORCE UPDATE : On réinjecte les params ET le content bruts via SQL pour contourner tout nettoyage intempestif de JTable
                            // Cela garantit que le menutype (et autres params) est bien présent en base, même si Joomla a tenté de le retirer.
                            // Et surtout, que le CONTENT est bien enregistré (problème fréquent avec JTable qui peut ignorer ce champ)
                            $query = $db->getQuery(true)
                                ->update($db->quoteName('#__modules'))
                                ->set($db->quoteName('params') . ' = ' . $db->quote($params))
                                ->set($db->quoteName('content') . ' = ' . $db->quote($content))
                                ->where($db->quoteName('id') . ' = ' . (int) $newId);
                            $db->setQuery($query)->execute();
                            if ($debug) {
                                file_put_contents($debugFile, "[IMPORT] [FORCE UPDATE] Params et Content réinjectés directement en SQL.\n", FILE_APPEND);
                                file_put_contents($debugFile, "[IMPORT] [FORCE UPDATE] Content length: " . strlen($content) . " caractères\n", FILE_APPEND);
                            }

                            // VÉRIFICATION IMMÉDIATE EN BASE
                            if ($debug) {
                                $query = $db->getQuery(true)
                                    ->select([$db->quoteName('params'), $db->quoteName('content')])
                                    ->from($db->quoteName('#__modules'))
                                    ->where($db->quoteName('id') . ' = ' . (int) $newId);
                                $storedData = $db->setQuery($query)->loadObject();

                                file_put_contents($debugFile, "[IMPORT] [VERIF DB] Params stockés immédiatement après création (ID {$newId}):\n" . $storedData->params . "\n", FILE_APPEND);
                                file_put_contents($debugFile, "[IMPORT] [VERIF DB] Content stocké (longueur: " . strlen($storedData->content) . " caractères)\n", FILE_APPEND);
                                if (strlen($storedData->content) > 0) {
                                    file_put_contents($debugFile, "[IMPORT] [VERIF DB] Aperçu du content: " . substr($storedData->content, 0, 200) . "...\n", FILE_APPEND);
                                } else {
                                    file_put_contents($debugFile, "[IMPORT] [VERIF DB] ⚠️ ATTENTION: Le content est VIDE en base!\n", FILE_APPEND);
                                }

                                $decoded = json_decode($storedData->params, true) ?: [];
                                $menutype = $decoded['menutype'] ?? 'ABSENT';
                                $layout = $decoded['layout'] ?? 'ABSENT';
                                $moduleclass_sfx = $decoded['moduleclass_sfx'] ?? 'ABSENT';
                                file_put_contents($debugFile, "[IMPORT] [VERIF DB] Analyse rapide -> menutype: {$menutype}, layout: {$layout}, moduleclass_sfx: {$moduleclass_sfx}\n", FILE_APPEND);

                                // Vérification de l'existence du menu pour aider au diagnostic
                                if ($menutype !== 'ABSENT') {
                                    $qMenu = $db->getQuery(true)->select('count(*)')->from($db->quoteName('#__menu_types'))->where($db->quoteName('menutype') . ' = ' . $db->quote($menutype));
                                    $menuExists = $db->setQuery($qMenu)->loadResult();
                                    file_put_contents($debugFile, "[IMPORT] [VERIF DB] Le type de menu '{$menutype}' existe-t-il dans #__menu_types ? " . ($menuExists ? "OUI" : "NON (⚠ C'est probablement la cause du problème)") . "\n", FILE_APPEND);
                                }
                            }

                            // Stocker la correspondance ID
                            if (is_numeric($originalId)) {
                                $idMap[$originalId] = $newId;
                            }
                            if (is_numeric($legacyId) && !isset($idMap[$legacyId])) {
                                $idMap[$legacyId] = $newId;
                            }

                            $createdModules[] = [
                                'id' => $newId,
                                'title' => $data['title'],
                                'content' => $content,
                                'params' => $params
                            ];

                            // Gérer les assignations de menu
                            // On effectue l'assignation de menu standard SEULEMENT si le fichier ne contient PAS de conditions Regular Labs.
                            // Les conditions AMM sont gérées plus tard et écraseront cette assignation si nécessaire.
                            // C'est la méthode la plus sûre pour gérer tous les cas.
                            // CORRECTION : On vérifie si RL est activé ET installé avant de bloquer l'assignation standard.
                            $hasRlConditions = $handleRlConditions && $isConditionsInstalled && !empty($item['rlConditions']['group']);

                            if (!$hasRlConditions && !empty($menuAssignments) && is_array($menuAssignments)) {
                                try {
                                    if ($debug)
                                        file_put_contents($debugFile, "[IMPORT] Assignation de menu standard pour ID {$newId}: " . implode(',', $menuAssignments) . "\n", FILE_APPEND);

                                    $db->setQuery('DELETE FROM ' . $db->quoteName('#__modules_menu') . ' WHERE ' . $db->quoteName('moduleid') . ' = ' . (int) $newId);
                                    $db->execute();

                                    $insertValues = [];
                                    foreach ($menuAssignments as $menuId) {
                                        if (is_numeric($menuId)) {
                                            $insertValues[] = '(' . (int) $newId . ',' . (int) $menuId . ')';
                                        }
                                    }

                                    if (!empty($insertValues)) {
                                        $insertQuery = 'INSERT INTO ' . $db->quoteName('#__modules_menu') .
                                            ' (' . $db->quoteName('moduleid') . ',' . $db->quoteName('menuid') . ') VALUES ' .
                                            implode(',', $insertValues);

                                        $db->setQuery($insertQuery);
                                        $db->execute();
                                        if ($debug)
                                            file_put_contents($debugFile, "[IMPORT] ✓ Assignation de menu standard effectuée.\n", FILE_APPEND);
                                    }
                                } catch (Exception $dbException) {
                                    $errorMsg = 'Erreur lors de l\'assignation de menu standard : ' . $dbException->getMessage();
                                    if ($debug)
                                        file_put_contents($debugFile, "[IMPORT] ✗ {$errorMsg}\n", FILE_APPEND);
                                    throw new Exception($errorMsg);
                                }
                            }

                            // ═══════════════════════════════════════════════════════════════
                            // APPEL UNIQUE ET CENTRALISÉ POUR TOUTES LES CONDITIONS
                            // ═══════════════════════════════════════════════════════════════
                            if ($handleRlConditions && $isConditionsInstalled) {
                                $this->importFullConditions($newId, $item, $debug, $debugFile, $this->params, $paramsArray);
                            }

                            // ✅ NOUVEAU : Mettre à jour les modules existants qui référencent ce module
                            if ($runIdMapping == 1) {
                                $idsToMap = array_unique(array_filter([
                                    is_numeric($originalId) ? (int) $originalId : null,
                                    is_numeric($legacyId) ? (int) $legacyId : null
                                ]));

                                foreach ($idsToMap as $mapId) {
                                    if ($debug) {
                                        file_put_contents($debugFile, "[ID MAPPING LIVE] Recherche des modules existants référençant l'ancien ID $mapId...\n", FILE_APPEND);
                                    }

                                    // Chercher tous les modules qui contiennent {loadmoduleid ID}
                                    $pattern = '%{loadmoduleid%' . $mapId . '%}%';
                                    $query = $db->getQuery(true)
                                        ->select($db->quoteName(['id', 'title', 'content', 'params']))
                                        ->from($db->quoteName('#__modules'))
                                        ->where($db->quoteName('content') . ' LIKE ' . $db->quote($pattern))
                                        ->where($db->quoteName('id') . ' != ' . (int) $newId); // Exclure le module qu'on vient de créer

                                    $existingModules = $db->setQuery($query)->loadObjectList();

                                    if (!empty($existingModules)) {
                                        foreach ($existingModules as $existingMod) {
                                            // Remplacer l'ancien ID par le nouveau dans le contenu
                                            $updatedContent = preg_replace(
                                                '/\{loadmoduleid(?:\s|&nbsp;|&#160;|\x{00A0})+' . preg_quote((string) $mapId, '/') . '\b\}/iu',
                                                '{loadmoduleid ' . $newId . '}',
                                                $existingMod->content
                                            );

                                            if ($updatedContent !== $existingMod->content) {
                                                $updateQuery = $db->getQuery(true)
                                                    ->update($db->quoteName('#__modules'))
                                                    ->set($db->quoteName('content') . ' = ' . $db->quote($updatedContent))
                                                    ->where($db->quoteName('id') . ' = ' . (int) $existingMod->id);
                                                $db->setQuery($updateQuery)->execute();

                                                if ($debug) {
                                                    file_put_contents($debugFile, "[ID MAPPING LIVE] ✓ Module existant '{$existingMod->title}' (ID: {$existingMod->id}) mis à jour: {loadmoduleid $mapId} → {loadmoduleid $newId}\n", FILE_APPEND);
                                                }
                                            }
                                        }
                                    } else {
                                        if ($debug) {
                                            file_put_contents($debugFile, "[ID MAPPING LIVE] Aucun module existant ne référence l'ID $mapId\n", FILE_APPEND);
                                        }
                                    }
                                }
                            }

                            $importedCount++;

                        } catch (\Throwable $e) {
                            $failedCount++;
                            $errorDetail = $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine();
                            // Ajout de détails sur la taille des données pour le débogage
                            $errorDetail .= " [Len Content: " . strlen($content) . ", Len Params: " . strlen($params) . "]";
                            $failedModules[] = [
                                'title' => $moduleData['title'] ?? 'Inconnu',
                                'error' => $errorDetail
                            ];
                            if ($debug) {
                                file_put_contents($debugFile, "[IMPORT] ✗✗✗ ERREUR: " . $errorDetail . "\n" . $e->getTraceAsString() . "\n", FILE_APPEND);
                            }
                        }


                        // Libération de la mémoire pour cette itération
                        unset($params, $content, $moduleData, $paramsArray, $data, $item);
                    }

                    // ═══════════════════════════════════════════════════════════════
                    // PHASE 3 : MAPPING FINAL - Mise à jour des références
                    // ═══════════════════════════════════════════════════════════════
                    $missingRefs = [];
                    if ($runIdMapping == 1 && !empty($createdModules)) {
                        if ($debug) {
                            file_put_contents($debugFile, "\n[PHASE 3 - MAPPING] ═══════════════════════════════════════\n", FILE_APPEND);
                        }

                        // Fusionner les mappings : modules existants (Phase 1) + modules nouvellement créés (Phase 2)
                        // IMPORTANT: conserver les clés numériques (IDs d'origine). array_merge() les réindexe.
                        $finalIdMap = array_replace($idMapExisting, $idMap);

                        if ($debug) {
                            file_put_contents($debugFile, "[PHASE 3 - MAPPING] Table de correspondance complète:\n", FILE_APPEND);
                            file_put_contents($debugFile, "  - Modules existants (Phase 1): " . count($idMapExisting) . "\n", FILE_APPEND);
                            file_put_contents($debugFile, "  - Modules importés (Phase 2): " . count($idMap) . "\n", FILE_APPEND);
                            file_put_contents($debugFile, "  - Total des mappings: " . count($finalIdMap) . "\n", FILE_APPEND);
                            // Log d'intégrité: vérifier que les clés sont bien les IDs d'origine (pas réindexées)
                            $finalKeys = array_keys($finalIdMap);
                            $keysSample = array_slice($finalKeys, 0, 10);
                            file_put_contents($debugFile, "  - Sample des clés (IDs d'origine): " . implode(', ', $keysSample) . "\n", FILE_APPEND);
                            if (!empty($finalIdMap)) {
                                foreach ($finalIdMap as $oldId => $newId) {
                                    $source = isset($idMapExisting[$oldId]) ? '[Existant]' : '[Importé]';
                                    file_put_contents($debugFile, "    {$source} ID {$oldId} → {$newId}\n", FILE_APPEND);
                                }
                            }
                        }

                        // Vérifier les références manquantes
                        foreach ($createdModules as $modInfo) {
                            if (preg_match_all($loadModulePattern, $modInfo['content'], $matches)) {
                                foreach ($matches[1] as $refId) {
                                    $refId = (int) $refId;
                                    if (!isset($finalIdMap[$refId])) {
                                        $missingRefs[$refId] = true;
                                    }
                                }
                            }
                            $paramsStr = $modInfo['params'] ?? '{}';
                            if (preg_match_all($loadModulePattern, $paramsStr, $matches)) {
                                foreach ($matches[1] as $refId) {
                                    $refId = (int) $refId;
                                    if (!isset($finalIdMap[$refId])) {
                                        $missingRefs[$refId] = true;
                                    }
                                }
                            }
                        }

                        if ($debug && !empty($missingRefs)) {
                            file_put_contents($debugFile, "[PHASE 3 - MAPPING] ⚠ Références non résolues: " . implode(', ', array_keys($missingRefs)) . "\n", FILE_APPEND);
                        }

                        // Utiliser finalIdMap au lieu de idMap pour tous les remplacements
                        $idMap = $finalIdMap;

                        $remainingOldRefs = [];
                        foreach ($createdModules as $modInfo) {
                            $modId = $modInfo['id'];
                            $contentToCommit = $modInfo['content'];
                            $paramsToCommit = $modInfo['params'];
                            $replacementCount = 0;

                            if ($debug) {
                                file_put_contents($debugFile, "\n[ID MAPPING] Traitement du module '{$modInfo['title']}' (ID: {$modId})\n", FILE_APPEND);
                            }

                            foreach ($idMap as $oldRef => $newRef) {
                                $oldRefStr = (string) $oldRef;
                                $newRefStr = (string) $newRef;
                                $moduleReplacements = 0;

                                // 1. Mappage amélioré pour {loadmoduleid ID} - Gère espaces multiples et tabulations
                                $pattern = '/\{loadmoduleid(?:\s|&nbsp;|&#160;|\x{00A0})+' . preg_quote($oldRefStr, '/') . '\b\}/iu';
                                $replacement = '{loadmoduleid ' . $newRefStr . '}';
                                $beforeReplace = $contentToCommit;
                                $contentToCommit = preg_replace($pattern, $replacement, $contentToCommit, -1, $count);
                                if ($count > 0) {
                                    $moduleReplacements += $count;
                                    if ($debug) {
                                        file_put_contents($debugFile, "[ID MAPPING]   ✓ {loadmoduleid}: $oldRefStr → $newRefStr ($count occurrence(s))\n", FILE_APPEND);
                                    }
                                }

                                // 2. Mappage pour {loadposition} avec référence de module
                                $pattern = '/\{loadposition\s+([^}]+?)\s*,\s*' . preg_quote($oldRefStr, '/') . '\b\}/i';
                                $replacement = '{loadposition $1,' . $newRefStr . '}';
                                $contentToCommit = preg_replace($pattern, $replacement, $contentToCommit, -1, $count);
                                if ($count > 0) {
                                    $moduleReplacements += $count;
                                    if ($debug) {
                                        file_put_contents($debugFile, "[ID MAPPING]   ✓ {loadposition avec ID}: $oldRefStr → $newRefStr ($count occurrence(s))\n", FILE_APPEND);
                                    }
                                }

                                // 3. Mappage Global (JSON & HTML) - Sécurisé par Regex (\b)
                                // Au lieu de str_replace qui peut remplacer "10" dans "100",
                                // on utilise preg_replace avec des délimiteurs de mots ou de structure.

                                $qOld = preg_quote($oldRefStr, '/');
                                $searchRegex = [
                                    // JSON patterns
                                    '/"' . $qOld . '"/',                   // "10"
                                    '/:' . $qOld . ',/',                   // :10,
                                    '/:' . $qOld . '}/',                   // :10}
                                    '/:\[' . $qOld . ',/',                 // :[10,
                                    '/:\[' . $qOld . ']/',                 // :[10]

                                    // HTML attribute patterns
                                    '/=' . $qOld . '\s/',                  // =10 (space)
                                    '/=' . $qOld . '>/',                   // =10>
                                    '/="' . $qOld . '"/',                  // ="10"
                                    "/='" . $qOld . "'/",                  // ='10'

                                    // Data attributes (redundant with above but kept for specificity)
                                    '/data-id="' . $qOld . '"/',
                                    '/data-module="' . $qOld . '"/',
                                    '/data-moduleid="' . $qOld . '"/',

                                    // Array/List patterns
                                    '/,' . $qOld . ',/',                   // ,10,
                                    '/,' . $qOld . ']/',                   // ,10]
                                    '/\[' . $qOld . ',/',                  // [10,
                                    '/\[' . $qOld . ']/',                  // [10]

                                    // URL parameters
                                    '/id=' . $qOld . '&/',                 // id=10&
                                    '/id=' . $qOld . '"/',                 // id=10"
                                    '/moduleId=' . $qOld . '\b/',          // moduleId=10 (WORD BOUNDARY)

                                    // Class patterns
                                    '/module-' . $qOld . '\b/',            // module-10 (WORD BOUNDARY)
                                    '/module-' . $qOld . '"/',
                                    "/module-" . $qOld . "'/",
                                ];

                                $replaceValues = [
                                    // JSON patterns
                                    '"' . $newRefStr . '"',
                                    ':' . $newRefStr . ',',
                                    ':' . $newRefStr . '}',
                                    ':[' . $newRefStr . ',',
                                    ':[' . $newRefStr . ']',

                                    // HTML attribute patterns
                                    '=' . $newRefStr . ' ',
                                    '=' . $newRefStr . '>',
                                    '="' . $newRefStr . '"',
                                    "='" . $newRefStr . "'",

                                    // Data attributes
                                    'data-id="' . $newRefStr . '"',
                                    'data-module="' . $newRefStr . '"',
                                    'data-moduleid="' . $newRefStr . '"',

                                    // Array/List patterns
                                    ',' . $newRefStr . ',',
                                    ',' . $newRefStr . ']',
                                    '[' . $newRefStr . ',',
                                    '[' . $newRefStr . ']',

                                    // URL parameters
                                    'id=' . $newRefStr . '&',
                                    'id=' . $newRefStr . '"',
                                    'moduleId=' . $newRefStr,

                                    // Class patterns
                                    'module-' . $newRefStr,
                                    'module-' . $newRefStr . '"',
                                    "module-" . $newRefStr . "'",
                                ];

                                $beforeContent = $contentToCommit;
                                $beforeParams = $paramsToCommit;

                                $contentToCommit = preg_replace($searchRegex, $replaceValues, $contentToCommit, -1, $count);
                                $paramsToCommit = preg_replace($searchRegex, $replaceValues, $paramsToCommit, -1, $count);

                                $contentChanged = ($beforeContent !== $contentToCommit);
                                $paramsChanged = ($beforeParams !== $paramsToCommit);

                                if ($contentChanged || $paramsChanged) {
                                    $moduleReplacements++;
                                    if ($debug) {
                                        $where = [];
                                        if ($contentChanged)
                                            $where[] = 'content';
                                        if ($paramsChanged)
                                            $where[] = 'params';
                                        file_put_contents($debugFile, "[ID MAPPING]   ✓ Patterns globaux: $oldRefStr → $newRefStr (dans " . implode(', ', $where) . ")\n", FILE_APPEND);
                                    }
                                }

                                $replacementCount += $moduleReplacements;
                            }

                            // Mise à jour effective
                            $contentHasChanges = ($contentToCommit !== $modInfo['content']);
                            $paramsHasChanges = ($paramsToCommit !== $modInfo['params']);

                            if ($contentHasChanges || $paramsHasChanges) {
                                $updateQuery = $db->getQuery(true)->update($db->quoteName('#__modules'));
                                if ($contentHasChanges)
                                    $updateQuery->set($db->quoteName('content') . ' = ' . $db->quote($contentToCommit));
                                if ($paramsHasChanges)
                                    $updateQuery->set($db->quoteName('params') . ' = ' . $db->quote($paramsToCommit));
                                $updateQuery->where($db->quoteName('id') . ' = ' . (int) $modId);
                                $db->setQuery($updateQuery)->execute();

                                $changes = [];
                                if ($contentHasChanges)
                                    $changes[] = 'content';
                                if ($paramsHasChanges)
                                    $changes[] = 'params';
                                $mappingLog[] = [
                                    'module' => $modInfo['title'],
                                    'changes' => implode(', ', $changes),
                                    'replacements' => $replacementCount
                                ];

                                if ($debug) {
                                    file_put_contents($debugFile, "[ID MAPPING]   ✅ Module mis à jour - $replacementCount remplacement(s) effectué(s)\n", FILE_APPEND);
                                }
                            } else {
                                if ($debug) {
                                    file_put_contents($debugFile, "[ID MAPPING]   ℹ Aucune modification nécessaire\n", FILE_APPEND);
                                }
                            }

                            // ✅ Vérification post-mapping: détecter les anciens IDs encore présents
                            $collectRemainingIds = function ($text) use ($loadModulePattern, $idMap) {
                                $remaining = [];
                                if (preg_match_all($loadModulePattern, (string) $text, $matches)) {
                                    foreach ($matches[1] as $refId) {
                                        $refId = (int) $refId;
                                        if (isset($idMap[$refId])) {
                                            $remaining[$refId] = true;
                                        }
                                    }
                                }
                                return $remaining;
                            };

                            $remainingIds = $collectRemainingIds($contentToCommit) + $collectRemainingIds($paramsToCommit);

                            // ✅ Second pass: remplacement ciblé des {loadmoduleid} restants
                            if (!empty($remainingIds)) {
                                if ($debug) {
                                    file_put_contents($debugFile, "[ID MAPPING]   ⟳ Second pass pour '{$modInfo['title']}' (ID {$modId})\n", FILE_APPEND);
                                }

                                $beforeSecondContent = $contentToCommit;
                                $beforeSecondParams = $paramsToCommit;
                                $secondPassCount = 0;

                                $callback = function ($m) use ($idMap, &$secondPassCount) {
                                    $oldId = (int) $m[1];
                                    if (isset($idMap[$oldId])) {
                                        $secondPassCount++;
                                        return '{loadmoduleid ' . $idMap[$oldId] . '}';
                                    }
                                    return $m[0];
                                };

                                $contentToCommit = preg_replace_callback($loadModulePattern, $callback, (string) $contentToCommit);
                                $paramsToCommit = preg_replace_callback($loadModulePattern, $callback, (string) $paramsToCommit);

                                $secondChanged = ($beforeSecondContent !== $contentToCommit) || ($beforeSecondParams !== $paramsToCommit);
                                if ($secondChanged) {
                                    $updateQuery = $db->getQuery(true)->update($db->quoteName('#__modules'));
                                    if ($beforeSecondContent !== $contentToCommit)
                                        $updateQuery->set($db->quoteName('content') . ' = ' . $db->quote($contentToCommit));
                                    if ($beforeSecondParams !== $paramsToCommit)
                                        $updateQuery->set($db->quoteName('params') . ' = ' . $db->quote($paramsToCommit));
                                    $updateQuery->where($db->quoteName('id') . ' = ' . (int) $modId);
                                    $db->setQuery($updateQuery)->execute();

                                    if ($debug) {
                                        file_put_contents($debugFile, "[ID MAPPING]   ✅ Second pass appliqué ({$secondPassCount} remplacement(s))\n", FILE_APPEND);
                                    }
                                } elseif ($debug) {
                                    file_put_contents($debugFile, "[ID MAPPING]   ℹ Second pass: aucune modification\n", FILE_APPEND);
                                }

                                // Re-calculer les références restantes après second pass
                                $remainingIds = $collectRemainingIds($contentToCommit) + $collectRemainingIds($paramsToCommit);
                            }
                            if (!empty($remainingIds)) {
                                $remainingOldRefs[] = [
                                    'module_id' => $modId,
                                    'module_title' => $modInfo['title'],
                                    'remaining_ids' => array_keys($remainingIds)
                                ];
                                if ($debug) {
                                    file_put_contents($debugFile, "[ID MAPPING]   ⚠ Références non remplacées dans '{$modInfo['title']}' (ID {$modId}): " . implode(', ', array_keys($remainingIds)) . "\n", FILE_APPEND);
                                }
                            }
                        }

                        // Libérer les données volumineuses de $createdModules (seul 'id' est encore nécessaire)
                        foreach ($createdModules as &$cm) {
                            unset($cm['content'], $cm['params']);
                        }
                        unset($cm);

                        // Libérer les données d'import brutes
                        // ATTENTION : $modulesToImport est utilisé plus bas, ne pas unset ici si nécessaire
                        // unset($modulesToImport); // Laisser commenté ou supprimer si utilisé
                        unset($jsonData, $sortedModules);

                        // 2.5 Correction automatique de la structure du header (DSFR)
                        try {
                            $createdIds = array_values(array_filter(array_map(function ($m) {
                                return isset($m['id']) ? (int) $m['id'] : 0;
                            }, $createdModules)));

                            if (!empty($createdIds)) {
                                $query = $db->getQuery(true)
                                    ->select($db->quoteName(['id', 'title', 'module', 'content', 'params', 'position']))
                                    ->from($db->quoteName('#__modules'))
                                    ->where($db->quoteName('id') . ' IN (' . implode(',', array_map('intval', $createdIds)) . ')');
                                $rows = $db->setQuery($query)->loadObjectList();

                                // Ajouter les structures sociales existantes si elles ne font pas partie de l'import
                                $querySocial = $db->getQuery(true)
                                    ->select($db->quoteName(['id', 'title', 'module', 'content', 'params', 'position']))
                                    ->from($db->quoteName('#__modules'))
                                    ->where('LOWER(' . $db->quoteName('position') . ') = ' . $db->quote('dsfrsocial'))
                                    ->where($db->quoteName('published') . ' >= 0');
                                $socialRows = $db->setQuery($querySocial)->loadObjectList();
                                $existingIds = array_flip(array_map('intval', array_column($rows, 'id')));
                                foreach ($socialRows as $row) {
                                    $id = (int) $row->id;
                                    if (!isset($existingIds[$id])) {
                                        $rows[] = $row;
                                        $existingIds[$id] = true;
                                    }
                                }

                                // Ajouter les structures header existantes si elles ne font pas partie de l'import
                                $queryHeader = $db->getQuery(true)
                                    ->select($db->quoteName(['id', 'title', 'module', 'content', 'params', 'position']))
                                    ->from($db->quoteName('#__modules'))
                                    ->where('LOWER(' . $db->quoteName('position') . ') IN (' . $db->quote('dsfrheader') . ',' . $db->quote('dsfrheader__item') . ')')
                                    ->where($db->quoteName('published') . ' >= 0');
                                $headerRows = $db->setQuery($queryHeader)->loadObjectList();
                                foreach ($headerRows as $row) {
                                    $id = (int) $row->id;
                                    if (!isset($existingIds[$id])) {
                                        $rows[] = $row;
                                        $existingIds[$id] = true;
                                    }
                                }

                                $parseParams = function ($paramsRaw) {
                                    if (is_array($paramsRaw) || is_object($paramsRaw)) {
                                        return (array) $paramsRaw;
                                    }
                                    if (!is_string($paramsRaw)) {
                                        return [];
                                    }
                                    $decoded = json_decode($paramsRaw, true);
                                    return (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) ? $decoded : [];
                                };

                                $getClassSfx = function ($params) {
                                    if (!is_array($params)) {
                                        return '';
                                    }
                                    return (string) ($params['moduleclass_sfx'] ?? ($params['class_sfx'] ?? ''));
                                };

                                $normalizeTitle = function ($value) {
                                    $value = strtolower((string) $value);
                                    $value = preg_replace('/\s+/', ' ', $value);
                                    return trim($value);
                                };

                                $preferredSearchTitlesPrimary = array_map($normalizeTitle, [
                                    'DSFR-Header__tools-searchBar : barre de recherche',
                                ]);
                                $preferredSearchTitlesSecondary = array_map($normalizeTitle, [
                                    'DSFR-Header__tools-searchBar',
                                ]);
                                $preferredSearchToken = 'dsfr-header__tools-searchbar';

                                $preferredSearchTitleFull = 'DSFR-Header__tools-searchBar : barre de recherche';
                                $preferredSearchTitleShort = 'DSFR-Header__tools-searchBar';
                                $preferredSearchTitleFullNorm = $normalizeTitle($preferredSearchTitleFull);
                                $preferredSearchTitleShortNorm = $normalizeTitle($preferredSearchTitleShort);

                                // Si seul le titre court existe dans le header, on le renomme en titre complet
                                $fullTitleId = null;
                                $shortTitleId = null;
                                foreach ($rows as $row) {
                                    $rowTitleNorm = $normalizeTitle($row->title ?? '');
                                    $rowPosition = strtolower((string) ($row->position ?? ''));
                                    if ($rowPosition !== 'dsfrheader__item') {
                                        continue;
                                    }
                                    if ($rowTitleNorm === $preferredSearchTitleFullNorm) {
                                        $fullTitleId = (int) $row->id;
                                        break;
                                    }
                                    if ($rowTitleNorm === $preferredSearchTitleShortNorm) {
                                        if (!$shortTitleId || (int) $row->id > (int) $shortTitleId) {
                                            $shortTitleId = (int) $row->id;
                                        }
                                    }
                                }
                                if (!$fullTitleId && $shortTitleId) {
                                    try {
                                        $updateTitleQuery = $db->getQuery(true)
                                            ->update($db->quoteName('#__modules'))
                                            ->set($db->quoteName('title') . ' = ' . $db->quote($preferredSearchTitleFull))
                                            ->where($db->quoteName('id') . ' = ' . (int) $shortTitleId);
                                        $db->setQuery($updateTitleQuery)->execute();
                                        foreach ($rows as $row) {
                                            if ((int) $row->id === (int) $shortTitleId) {
                                                $row->title = $preferredSearchTitleFull;
                                                break;
                                            }
                                        }
                                        $fullTitleId = $shortTitleId;
                                        if ($debug) {
                                            file_put_contents($debugFile, "[HEADER FIX] Renommage module recherche: ID {$shortTitleId} -> '{$preferredSearchTitleFull}'\n", FILE_APPEND);
                                        }
                                    } catch (\Throwable $e) {
                                        if ($debug) {
                                            file_put_contents($debugFile, "[HEADER FIX] ⚠ Impossible de renommer le module recherche (ID {$shortTitleId}): {$e->getMessage()}\n", FILE_APPEND);
                                        }
                                    }
                                }

                                $findModuleIdByClassSfx = function ($token, $excludeToken = null) use ($db, $parseParams, $getClassSfx) {
                                    if (!$token) {
                                        return null;
                                    }
                                    $like = '%' . $db->escape($token, true) . '%';
                                    $query = $db->getQuery(true)
                                        ->select($db->quoteName(['id', 'params']))
                                        ->from($db->quoteName('#__modules'))
                                        ->where($db->quoteName('params') . ' LIKE ' . $db->quote($like, false))
                                        ->where($db->quoteName('published') . ' >= 0')
                                        ->order($db->quoteName('id') . ' DESC');
                                    // Charger par lots pour éviter une allocation mémoire massive
                                    $offset = 0;
                                    $batchSize = 50;
                                    while (true) {
                                        $rows = $db->setQuery($query, $offset, $batchSize)->loadObjectList();
                                        if (empty($rows)) {
                                            break;
                                        }
                                        foreach ($rows as $row) {
                                            $params = $parseParams($row->params ?? '');
                                            $classSfx = strtolower($getClassSfx($params));
                                            if ($excludeToken && strpos($classSfx, strtolower($excludeToken)) !== false) {
                                                continue;
                                            }
                                            if (strpos($classSfx, strtolower($token)) !== false) {
                                                return (int) $row->id;
                                            }
                                        }
                                        unset($rows);
                                        $offset += $batchSize;
                                    }
                                    return null;
                                };

                                $logoId = null;
                                $operatorId = null;
                                $searchId = null;
                                $searchIdFromHeader = false;
                                $searchScore = -1;
                                $footerBrandId = null;
                                $footerContentId = null;
                                $footerContentListId = null;
                                $footerBottomListId = null;
                                $socialLinksId = null;
                                $socialContactId = null;
                                $searchModalId = null;

                                $findModuleIdByMenuType = function ($menuType) use ($db) {
                                    if (!$menuType) {
                                        return null;
                                    }
                                    $pattern = '%"menutype":"' . $db->escape($menuType, true) . '"%';
                                    $query = $db->getQuery(true)
                                        ->select($db->quoteName(['id']))
                                        ->from($db->quoteName('#__modules'))
                                        ->where($db->quoteName('params') . ' LIKE ' . $db->quote($pattern, false))
                                        ->where($db->quoteName('published') . ' >= 0')
                                        ->order($db->quoteName('id') . ' DESC');
                                    $id = (int) $db->setQuery($query, 0, 1)->loadResult();
                                    return $id ?: null;
                                };

                                $findModuleIdByLayout = function ($layout) use ($db) {
                                    if (!$layout) {
                                        return null;
                                    }
                                    $pattern = '%"layout":"' . $db->escape($layout, true) . '"%';
                                    $query = $db->getQuery(true)
                                        ->select($db->quoteName(['id']))
                                        ->from($db->quoteName('#__modules'))
                                        ->where($db->quoteName('params') . ' LIKE ' . $db->quote($pattern, false))
                                        ->where($db->quoteName('published') . ' >= 0')
                                        ->order($db->quoteName('id') . ' DESC');
                                    $id = (int) $db->setQuery($query, 0, 1)->loadResult();
                                    return $id ?: null;
                                };

                                $findSearchIdByPosition = function ($position) use ($db, $parseParams, $normalizeTitle, $preferredSearchTitlesPrimary, $preferredSearchTitlesSecondary, $preferredSearchToken, $preferredSearchTitleFullNorm, $preferredSearchTitleShortNorm) {
                                    if (!$position) {
                                        return null;
                                    }
                                    $pos = strtolower($position);
                                    $query = $db->getQuery(true)
                                        ->select($db->quoteName(['id', 'title', 'module', 'params', 'position', 'content']))
                                        ->from($db->quoteName('#__modules'))
                                        ->where('LOWER(' . $db->quoteName('position') . ') = ' . $db->quote($pos))
                                        ->where($db->quoteName('published') . ' >= 0')
                                        ->order($db->quoteName('id') . ' DESC');
                                    $rows = $db->setQuery($query)->loadObjectList();
                                    $bestId = null;
                                    $bestScore = -1;
                                    foreach ($rows as $row) {
                                        $params = $parseParams($row->params ?? '');
                                        $layout = strtolower((string) ($params['layout'] ?? ''));
                                        $title = $normalizeTitle($row->title ?? '');
                                        $moduleType = strtolower((string) ($row->module ?? ''));
                                        $content = (string) ($row->content ?? '');
                                        $isFinder = ($moduleType === 'mod_finder');
                                        $layoutMatch = (strpos($layout, 'finderdsfr') !== false);
                                        $titleExactPrimary = in_array($title, $preferredSearchTitlesPrimary, true);
                                        $titleExactSecondary = in_array($title, $preferredSearchTitlesSecondary, true);
                                        $titlePreferredPartial = (strpos($title, $preferredSearchToken) !== false);
                                        $titleMatch = (strpos($title, 'recherche') !== false) || (strpos($title, 'search') !== false);
                                        $contentMatch = (stripos($content, 'fr-search-bar') !== false) || (stripos($content, 'js-finder-search-query') !== false);
                                        $qualifies = $isFinder
                                            || $layoutMatch
                                            || $contentMatch
                                            || $titleExactPrimary
                                            || $titleExactSecondary
                                            || $titlePreferredPartial
                                            || ($titleMatch && $pos === 'dsfrheader__item');
                                        if ($qualifies) {
                                            $score = 0;
                                            $score += 300; // position déjà filtrée
                                            if ($titleExactPrimary) {
                                                $score += 1000;
                                            } elseif ($titleExactSecondary) {
                                                $score += 500;
                                            } elseif ($titlePreferredPartial) {
                                                $score += 200;
                                            }
                                            if ($layoutMatch)
                                                $score += 60;
                                            if ($isFinder)
                                                $score += 40;
                                            if ($contentMatch)
                                                $score += 30;
                                            if ($titleMatch)
                                                $score += 10;
                                            $candidateId = (int) $row->id;
                                            if ($score > $bestScore || ($score === $bestScore && $candidateId > (int) $bestId)) {
                                                $bestScore = $score;
                                                $bestId = $candidateId;
                                            }
                                        }
                                    }
                                    return $bestId ?: null;
                                };

                                foreach ($rows as $row) {
                                    $params = $parseParams($row->params ?? '');
                                    $classSfx = $getClassSfx($params);
                                    $title = $normalizeTitle($row->title ?? '');
                                    $layout = strtolower((string) ($params['layout'] ?? ''));
                                    $moduleType = strtolower((string) ($row->module ?? ''));
                                    $menutype = strtolower((string) ($params['menutype'] ?? ''));
                                    $position = strtolower((string) ($row->position ?? ''));
                                    $content = (string) ($row->content ?? '');

                                    if (!$searchModalId && preg_match('/<div\\s+[^>]*id=\"([^\"]+)\"[^>]*class=\"[^\"]*fr-header__search[^\"]*fr-modal[^\"]*\"/i', $content, $m)) {
                                        $searchModalId = $m[1];
                                    }

                                    if (!$logoId && stripos($classSfx, 'fr-header__logo') !== false) {
                                        $logoId = (int) $row->id;
                                    }
                                    if (!$operatorId && stripos($classSfx, 'fr-header__operator') !== false) {
                                        $operatorId = (int) $row->id;
                                    }
                                    $isFinder = ($moduleType === 'mod_finder');
                                    $layoutMatch = (strpos($layout, 'finderdsfr') !== false);
                                    $titleExactPrimary = in_array($title, $preferredSearchTitlesPrimary, true);
                                    $titleExactSecondary = in_array($title, $preferredSearchTitlesSecondary, true);
                                    $titlePreferredPartial = (strpos($title, $preferredSearchToken) !== false);
                                    $titleMatch = (strpos($title, 'recherche') !== false) || (strpos($title, 'search') !== false);
                                    $contentMatch = (stripos($content, 'fr-search-bar') !== false) || (stripos($content, 'js-finder-search-query') !== false);
                                    $qualifies = $isFinder
                                        || $layoutMatch
                                        || $contentMatch
                                        || $titleExactPrimary
                                        || $titleExactSecondary
                                        || $titlePreferredPartial
                                        || ($titleMatch && $position === 'dsfrheader__item');
                                    if ($qualifies) {
                                        $score = 0;
                                        if ($position === 'dsfrheader__item')
                                            $score += 300;
                                        if ($titleExactPrimary) {
                                            $score += 1000;
                                        } else if ($titleExactSecondary) {
                                            $score += 500;
                                        } else if ($titlePreferredPartial) {
                                            $score += 200;
                                        }
                                        if ($layoutMatch)
                                            $score += 60;
                                        if ($isFinder)
                                            $score += 40;
                                        if ($contentMatch)
                                            $score += 30;
                                        if ($titleMatch)
                                            $score += 10;
                                        $candidateId = (int) $row->id;
                                        if ($score > $searchScore || ($score === $searchScore && $candidateId > (int) $searchId)) {
                                            $searchScore = $score;
                                            $searchId = $candidateId;
                                            $searchIdFromHeader = ($position === 'dsfrheader__item');
                                        }
                                    }

                                    if (!$footerBrandId && stripos($classSfx, 'fr-footer__brand') !== false) {
                                        $footerBrandId = (int) $row->id;
                                    }
                                    if (!$footerContentListId && stripos($classSfx, 'fr-footer__content-list') !== false) {
                                        $footerContentListId = (int) $row->id;
                                    }
                                    if (!$footerBottomListId && stripos($classSfx, 'fr-footer__bottom-list') !== false) {
                                        $footerBottomListId = (int) $row->id;
                                    }
                                    if (!$footerBottomListId && $menutype === 'fr-footer-bottom') {
                                        $footerBottomListId = (int) $row->id;
                                    }
                                    if (!$footerContentListId && $menutype === 'fr-footer') {
                                        $footerContentListId = (int) $row->id;
                                    }
                                    if (!$socialLinksId && $menutype === 'fr-follow') {
                                        $socialLinksId = (int) $row->id;
                                    }
                                    if (
                                        !$footerContentId
                                        && stripos($classSfx, 'fr-footer__content') !== false
                                        && stripos($classSfx, 'content-list') === false
                                    ) {
                                        $footerContentId = (int) $row->id;
                                    }
                                    if (!$socialLinksId && strpos($layout, 'menuresauxsociaux') !== false) {
                                        $socialLinksId = (int) $row->id;
                                    }
                                    if (!$socialLinksId && stripos($classSfx, 'fr-follow__social') !== false) {
                                        $socialLinksId = (int) $row->id;
                                    }
                                    if (!$socialContactId && stripos($classSfx, 'fr-follow__newsletter') !== false) {
                                        $socialContactId = (int) $row->id;
                                    }
                                }

                                if (!$searchModalId) {
                                    $searchModalId = 'modal-575';
                                }

                                if (!$searchIdFromHeader) {
                                    $headerSearchId = $findSearchIdByPosition('dsfrHeader__item');
                                    if ($headerSearchId) {
                                        $searchId = $headerSearchId;
                                        $searchIdFromHeader = true;
                                    }
                                }

                                // ✅ Synchroniser les paramètres du module recherche avec le template JSON
                                $searchTemplateModule = null;
                                foreach ($modulesToImport as $moduleItem) {
                                    $moduleData = isset($moduleItem['module']) && is_array($moduleItem['module'])
                                        ? $moduleItem['module']
                                        : $moduleItem;
                                    $titleNorm = $normalizeTitle($moduleData['title'] ?? '');
                                    if (in_array($titleNorm, $preferredSearchTitlesPrimary, true)) {
                                        $searchTemplateModule = $moduleData;
                                        break;
                                    }
                                    if (in_array($titleNorm, $preferredSearchTitlesSecondary, true)) {
                                        $searchTemplateModule = $moduleData;
                                    }
                                }
                                unset($modulesToImport);
                                if ($searchId && $searchTemplateModule) {
                                    try {
                                        $templateParamsRaw = $searchTemplateModule['params'] ?? '{}';
                                        if (is_array($templateParamsRaw) || is_object($templateParamsRaw)) {
                                            $templateParamsArray = (array) $templateParamsRaw;
                                        } else {
                                            $decoded = json_decode((string) $templateParamsRaw, true);
                                            $templateParamsArray = (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) ? $decoded : [];
                                        }

                                        $templateParams = json_encode($templateParamsArray, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                                        if (empty(trim((string) $templateParams))) {
                                            $templateParams = '{}';
                                        }

                                        $templateTitle = (string) ($searchTemplateModule['title'] ?? $preferredSearchTitleFull);
                                        $templateModuleType = (string) ($searchTemplateModule['module'] ?? 'mod_finder');
                                        $templatePosition = (string) ($searchTemplateModule['position'] ?? 'dsfrHeader__item');
                                        $templateShowTitle = (int) ($searchTemplateModule['showtitle'] ?? 0);
                                        $templatePublished = (int) ($searchTemplateModule['published'] ?? 1);

                                        $updateQuery = $db->getQuery(true)
                                            ->update($db->quoteName('#__modules'))
                                            ->set($db->quoteName('title') . ' = ' . $db->quote($templateTitle))
                                            ->set($db->quoteName('module') . ' = ' . $db->quote($templateModuleType))
                                            ->set($db->quoteName('position') . ' = ' . $db->quote($templatePosition))
                                            ->set($db->quoteName('showtitle') . ' = ' . (int) $templateShowTitle)
                                            ->set($db->quoteName('published') . ' = ' . (int) $templatePublished)
                                            ->set($db->quoteName('params') . ' = ' . $db->quote($templateParams))
                                            ->where($db->quoteName('id') . ' = ' . (int) $searchId);
                                        $db->setQuery($updateQuery)->execute();
                                        if ($debug) {
                                            file_put_contents($debugFile, "[HEADER FIX] Synchro params recherche: ID {$searchId} '{$templateTitle}'\n", FILE_APPEND);
                                        }
                                    } catch (\Throwable $e) {
                                        if ($debug) {
                                            file_put_contents($debugFile, "[HEADER FIX] ⚠ Impossible de synchroniser params recherche (ID {$searchId}): {$e->getMessage()}\n", FILE_APPEND);
                                        }
                                    }
                                }

                                // ✅ Nettoyage optionnel : mettre à la corbeille le module de recherche "topbar" s'il existe
                                if ($searchId) {
                                    try {
                                        $targetTopbarTitle = 'recherche';
                                        $query = $db->getQuery(true)
                                            ->select($db->quoteName(['id', 'title', 'module', 'position']))
                                            ->from($db->quoteName('#__modules'))
                                            ->where('LOWER(' . $db->quoteName('position') . ') = ' . $db->quote('topbar'))
                                            ->where('('
                                                . $db->quoteName('module') . ' = ' . $db->quote('mod_finder')
                                                . ' OR LOWER(' . $db->quoteName('title') . ') = ' . $db->quote($targetTopbarTitle)
                                                . ')');
                                        $topbarSearchRows = $db->setQuery($query)->loadObjectList();
                                        foreach ($topbarSearchRows as $row) {
                                            $rowId = (int) $row->id;
                                            if ($rowId === (int) $searchId) {
                                                continue;
                                            }
                                            $updateQuery = $db->getQuery(true)
                                                ->update($db->quoteName('#__modules'))
                                                ->set($db->quoteName('published') . ' = -2')
                                                ->where($db->quoteName('id') . ' = ' . $rowId);
                                            $db->setQuery($updateQuery)->execute();
                                            if ($debug) {
                                                file_put_contents($debugFile, "[HEADER FIX] Mise à la corbeille module recherche topbar: ID {$rowId} '{$row->title}'\n", FILE_APPEND);
                                            }
                                        }
                                    } catch (\Throwable $e) {
                                        if ($debug) {
                                            file_put_contents($debugFile, "[HEADER FIX] ⚠ Impossible de mettre à la corbeille le module topbar: {$e->getMessage()}\n", FILE_APPEND);
                                        }
                                    }
                                }

                                // Fallback: chercher en base si un module clé n'est pas trouvé dans l'import
                                if (!$footerBottomListId) {
                                    $footerBottomListId = $findModuleIdByClassSfx('fr-footer__bottom-list');
                                }
                                if (!$footerBottomListId) {
                                    $footerBottomListId = $findModuleIdByMenuType('fr-footer-bottom');
                                }
                                if (!$footerContentListId) {
                                    $footerContentListId = $findModuleIdByClassSfx('fr-footer__content-list');
                                }
                                if (!$footerContentListId) {
                                    $footerContentListId = $findModuleIdByMenuType('fr-footer');
                                }
                                if (!$footerBrandId) {
                                    $footerBrandId = $findModuleIdByClassSfx('fr-footer__brand');
                                }
                                if (!$footerContentId) {
                                    $footerContentId = $findModuleIdByClassSfx('fr-footer__content', 'fr-footer__content-list');
                                }
                                if (!$socialLinksId) {
                                    $socialLinksId = $findModuleIdByClassSfx('fr-follow__social');
                                }
                                if (!$socialLinksId) {
                                    $socialLinksId = $findModuleIdByLayout('cassiopeia_dsfr:menuResauxSociaux');
                                }
                                if (!$socialLinksId) {
                                    $socialLinksId = $findModuleIdByMenuType('fr-follow');
                                }
                                if (!$socialContactId) {
                                    $socialContactId = $findModuleIdByClassSfx('fr-follow__newsletter');
                                }

                                $replaceSequence = function ($text, $ids) use ($loadModulePattern) {
                                    if (!is_string($text) || empty($ids)) {
                                        return $text;
                                    }
                                    $idx = 0;
                                    return preg_replace_callback($loadModulePattern, function ($m) use (&$idx, $ids) {
                                        if ($idx >= count($ids)) {
                                            return $m[0];
                                        }
                                        $next = $ids[$idx++];
                                        if (!$next) {
                                            return $m[0];
                                        }
                                        return '{loadmoduleid ' . (int) $next . '}';
                                    }, $text);
                                };



                                $headerFixCount = 0;
                                $footerFixCount = 0;
                                $socialFixCount = 0;

                                foreach ($rows as $row) {
                                    $params = $parseParams($row->params ?? '');
                                    $classSfx = strtolower($getClassSfx($params));
                                    $content = (string) ($row->content ?? '');
                                    $title = strtolower((string) ($row->title ?? ''));
                                    $position = strtolower((string) ($row->position ?? ''));

                                    $isBrand = (strpos($classSfx, 'fr-header__brand') !== false) || (strpos($content, 'fr-header__brand-top') !== false);
                                    $isTools = (strpos($classSfx, 'fr-header__tools') !== false) || (strpos($content, 'fr-header__tools') !== false);
                                    $isFooterBody = (strpos($classSfx, 'fr-footer__body') !== false);
                                    $isFooterContent = (strpos($classSfx, 'fr-footer__content') !== false) && (strpos($classSfx, 'content-list') === false);
                                    $isFooterBottom = (strpos($classSfx, 'fr-footer__bottom') !== false) && (strpos($classSfx, 'bottom-list') === false);
                                    $isSocialStructure = ($position === 'dsfrsocial');
                                    $hasCol4 = (strpos($classSfx, 'fr-col-md-4') !== false);
                                    $hasCol8 = (strpos($classSfx, 'fr-col-md-8') !== false);
                                    $isSocialFollow = $isSocialStructure && (strpos($title, 'suivez') !== false || strpos($title, 'réseaux') !== false || strpos($title, 'reseaux') !== false);
                                    $isSocialContact = $isSocialStructure && (strpos($title, 'ecrivez') !== false || strpos($title, 'contact') !== false);
                                    if ($isSocialStructure) {
                                        if ($hasCol4) {
                                            $isSocialFollow = true;
                                            $isSocialContact = false;
                                        } elseif ($hasCol8) {
                                            $isSocialContact = true;
                                            $isSocialFollow = false;
                                        }
                                    }

                                    if ($isBrand && ($logoId || $operatorId)) {
                                        $desired = array_values(array_filter([$logoId, $operatorId]));
                                        $newContent = $replaceSequence($content, $desired);
                                        if ($newContent !== $content) {
                                            $updateQuery = $db->getQuery(true)
                                                ->update($db->quoteName('#__modules'))
                                                ->set($db->quoteName('content') . ' = ' . $db->quote($newContent))
                                                ->where($db->quoteName('id') . ' = ' . (int) $row->id);
                                            $db->setQuery($updateQuery)->execute();
                                            $headerFixCount++;
                                        }
                                    }

                                    if ($isTools && $searchId) {
                                        $newContent = $replaceSequence($content, [$searchId]);
                                        // Si aucun {loadmoduleid} existant à remplacer, injecter dans la modale recherche
                                        if ($newContent === $content && stripos($content, 'fr-header__search') !== false && stripos($content, '{loadmoduleid') === false) {
                                            $injected = preg_replace(
                                                '/(fr-header__search[^>]*>\s*<div[^>]*fr-container[^>]*>)/si',
                                                '$1{loadmoduleid ' . (int) $searchId . '}',
                                                $content,
                                                1
                                            );
                                            if ($injected !== null && $injected !== $content) {
                                                $newContent = $injected;
                                            }
                                        }
                                        $paramsChanged = false;
                                        $paramsArray = $parseParams($row->params ?? '');
                                        $moduleType = strtolower((string) ($row->module ?? ''));
                                        if ($moduleType === 'mod_custom' && stripos($newContent, '{loadmoduleid') !== false) {
                                            $currentPrepare = (int) ($paramsArray['prepare_content'] ?? 0);
                                            if ($currentPrepare !== 1) {
                                                $paramsArray['prepare_content'] = 1;
                                                $paramsChanged = true;
                                            }
                                        }
                                        if ($newContent !== $content || $paramsChanged) {
                                            $updateQuery = $db->getQuery(true)
                                                ->update($db->quoteName('#__modules'));
                                            if ($newContent !== $content) {
                                                $updateQuery->set($db->quoteName('content') . ' = ' . $db->quote($newContent));
                                            }
                                            if ($paramsChanged) {
                                                $encodedParams = json_encode($paramsArray, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                                                if (empty(trim((string) $encodedParams))) {
                                                    $encodedParams = '{}';
                                                }
                                                $updateQuery->set($db->quoteName('params') . ' = ' . $db->quote($encodedParams));
                                            }
                                            $updateQuery->where($db->quoteName('id') . ' = ' . (int) $row->id);
                                            $db->setQuery($updateQuery)->execute();
                                            $headerFixCount++;
                                        }
                                    }

                                    if ($isFooterBody && ($footerBrandId || $footerContentId)) {
                                        $desired = array_values(array_filter([$footerBrandId, $footerContentId]));
                                        $newContent = $replaceSequence($content, $desired);
                                        if ($newContent !== $content) {
                                            $updateQuery = $db->getQuery(true)
                                                ->update($db->quoteName('#__modules'))
                                                ->set($db->quoteName('content') . ' = ' . $db->quote($newContent))
                                                ->where($db->quoteName('id') . ' = ' . (int) $row->id);
                                            $db->setQuery($updateQuery)->execute();
                                            $footerFixCount++;
                                        }
                                    }

                                    if ($isFooterContent && $footerContentListId) {
                                        $newContent = $replaceSequence($content, [$footerContentListId]);
                                        if ($newContent !== $content) {
                                            $updateQuery = $db->getQuery(true)
                                                ->update($db->quoteName('#__modules'))
                                                ->set($db->quoteName('content') . ' = ' . $db->quote($newContent))
                                                ->where($db->quoteName('id') . ' = ' . (int) $row->id);
                                            $db->setQuery($updateQuery)->execute();
                                            $footerFixCount++;
                                        }
                                    }

                                    if ($isFooterBottom && $footerBottomListId) {
                                        $newContent = $replaceSequence($content, [$footerBottomListId]);
                                        if ($newContent !== $content) {
                                            $updateQuery = $db->getQuery(true)
                                                ->update($db->quoteName('#__modules'))
                                                ->set($db->quoteName('content') . ' = ' . $db->quote($newContent))
                                                ->where($db->quoteName('id') . ' = ' . (int) $row->id);
                                            $db->setQuery($updateQuery)->execute();
                                            $footerFixCount++;
                                        }
                                    }

                                    if ($isSocialFollow && $socialLinksId) {
                                        $newContent = $replaceSequence($content, [$socialLinksId]);
                                        if ($newContent !== $content) {
                                            $updateQuery = $db->getQuery(true)
                                                ->update($db->quoteName('#__modules'))
                                                ->set($db->quoteName('content') . ' = ' . $db->quote($newContent))
                                                ->where($db->quoteName('id') . ' = ' . (int) $row->id);
                                            $db->setQuery($updateQuery)->execute();
                                            $socialFixCount++;
                                        }
                                    }

                                    if ($isSocialContact && $socialContactId) {
                                        $newContent = $replaceSequence($content, [$socialContactId]);
                                        if ($newContent !== $content) {
                                            $updateQuery = $db->getQuery(true)
                                                ->update($db->quoteName('#__modules'))
                                                ->set($db->quoteName('content') . ' = ' . $db->quote($newContent))
                                                ->where($db->quoteName('id') . ' = ' . (int) $row->id);
                                            $db->setQuery($updateQuery)->execute();
                                            $socialFixCount++;
                                        }
                                    }

                                    // Ne pas modifier les boutons de recherche : conserver la structure du module.
                                }

                                // Fallback: forcer le {loadmoduleid} du module structure recherche si non appliqué
                                if ($searchId) {
                                    try {
                                        $queryTools = $db->getQuery(true)
                                            ->select($db->quoteName(['id', 'title', 'content', 'params', 'module']))
                                            ->from($db->quoteName('#__modules'))
                                            ->where($db->quoteName('module') . ' = ' . $db->quote('mod_custom'))
                                            ->where('(' .
                                                $db->quoteName('title') . ' LIKE ' . $db->quote('%Header__tools(structure%') .
                                                ' OR ' . $db->quoteName('params') . ' LIKE ' . $db->quote('%"moduleclass_sfx":"%fr-header__tools%') .
                                                ' OR ' . $db->quoteName('content') . ' LIKE ' . $db->quote('%fr-header__tools%') .
                                                ')');
                                        $toolsRows = $db->setQuery($queryTools)->loadObjectList();

                                        foreach ($toolsRows as $toolsRow) {
                                            $content = (string) ($toolsRow->content ?? '');
                                            if ($content === '') {
                                                continue;
                                            }
                                            $newContent = $replaceSequence($content, [$searchId]);
                                            // Si aucun {loadmoduleid} existant à remplacer, injecter dans la modale recherche
                                            if ($newContent === $content && stripos($content, 'fr-header__search') !== false && stripos($content, '{loadmoduleid') === false) {
                                                $injected = preg_replace(
                                                    '/(fr-header__search[^>]*>\s*<div[^>]*fr-container[^>]*>)/si',
                                                    '$1{loadmoduleid ' . (int) $searchId . '}',
                                                    $content,
                                                    1
                                                );
                                                if ($injected !== null && $injected !== $content) {
                                                    $newContent = $injected;
                                                }
                                            }
                                            $paramsArray = $parseParams($toolsRow->params ?? '');
                                            $paramsChanged = false;
                                            if (stripos($newContent, '{loadmoduleid') !== false) {
                                                $currentPrepare = (int) ($paramsArray['prepare_content'] ?? 0);
                                                if ($currentPrepare !== 1) {
                                                    $paramsArray['prepare_content'] = 1;
                                                    $paramsChanged = true;
                                                }
                                            }
                                            if ($newContent !== $content || $paramsChanged) {
                                                $updateQuery = $db->getQuery(true)
                                                    ->update($db->quoteName('#__modules'));
                                                if ($newContent !== $content) {
                                                    $updateQuery->set($db->quoteName('content') . ' = ' . $db->quote($newContent));
                                                }
                                                if ($paramsChanged) {
                                                    $encodedParams = json_encode($paramsArray, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                                                    if (empty(trim((string) $encodedParams))) {
                                                        $encodedParams = '{}';
                                                    }
                                                    $updateQuery->set($db->quoteName('params') . ' = ' . $db->quote($encodedParams));
                                                }
                                                $updateQuery->where($db->quoteName('id') . ' = ' . (int) $toolsRow->id);
                                                $db->setQuery($updateQuery)->execute();
                                                if ($debug) {
                                                    file_put_contents($debugFile, "[HEADER FIX] Fallback tools module ajusté (ID {$toolsRow->id}) -> loadmoduleid {$searchId}\n", FILE_APPEND);
                                                }
                                            }
                                        }
                                    } catch (\Throwable $e) {
                                        if ($debug) {
                                            file_put_contents($debugFile, "[HEADER FIX] Fallback tools module échec: " . $e->getMessage() . "\n", FILE_APPEND);
                                        }
                                    }
                                }

                                // Assurer que tous les logos d'État pointent vers l'accueil
                                try {
                                    $queryLogo = $db->getQuery(true)
                                        ->select($db->quoteName(['id', 'content', 'params']))
                                        ->from($db->quoteName('#__modules'))
                                        ->where($db->quoteName('params') . ' LIKE ' . $db->quote('%"moduleclass_sfx":"%fr-header__logo%'));
                                    $logoRows = $db->setQuery($queryLogo)->loadObjectList();
                                    $homeUrl = 'index.php';

                                    foreach ($logoRows as $logoRow) {
                                        $params = $parseParams($logoRow->params ?? '');
                                        $classSfx = strtolower($getClassSfx($params));
                                        if (strpos($classSfx, 'fr-header__logo') === false) {
                                            continue;
                                        }
                                        $content = (string) ($logoRow->content ?? '');
                                        if ($content === '') {
                                            continue;
                                        }
                                        if (preg_match('/<a\\s+[^>]*href=[\"\\\'][^\"\\\']*[\"\\\'][^>]*>/i', $content)) {
                                            $newContent = preg_replace(
                                                '/<a\\s+([^>]*?)href=[\"\\\'][^\"\\\']*[\"\\\']([^>]*)>/i',
                                                '<a $1href="' . $homeUrl . '"$2>',
                                                $content,
                                                1
                                            );
                                        } else {
                                            $newContent = '<a href="' . $homeUrl . '" title="Retour à l\'accueil">' . $content . '</a>';
                                        }

                                        if ($newContent !== $content) {
                                            $updateQuery = $db->getQuery(true)
                                                ->update($db->quoteName('#__modules'))
                                                ->set($db->quoteName('content') . ' = ' . $db->quote($newContent))
                                                ->where($db->quoteName('id') . ' = ' . (int) $logoRow->id);
                                            $db->setQuery($updateQuery)->execute();
                                        }
                                    }
                                } catch (\Throwable $e) {
                                    if ($debug) {
                                        file_put_contents($debugFile, "[LOGO FIX] Échec: " . $e->getMessage() . "\n", FILE_APPEND);
                                    }
                                }

                                if ($debug) {
                                    file_put_contents(
                                        $debugFile,
                                        "[HEADER FIX] Logo={$logoId} Operateur={$operatorId} Recherche={$searchId} | Modules corrigés={$headerFixCount}\n",
                                        FILE_APPEND
                                    );
                                    file_put_contents(
                                        $debugFile,
                                        "[FOOTER FIX] Brand={$footerBrandId} Content={$footerContentId} ContentList={$footerContentListId} BottomList={$footerBottomListId} | Modules corrigés={$footerFixCount}\n",
                                        FILE_APPEND
                                    );
                                    file_put_contents(
                                        $debugFile,
                                        "[SOCIAL FIX] SocialLinks={$socialLinksId} Contact={$socialContactId} | Modules corrigés={$socialFixCount}\n",
                                        FILE_APPEND
                                    );
                                }

                                if (!$logoId || !$operatorId || !$searchId) {
                                    $missing = [];
                                    if (!$logoId)
                                        $missing[] = 'logo';
                                    if (!$operatorId)
                                        $missing[] = 'opérateur';
                                    if (!$searchId)
                                        $missing[] = 'recherche';
                                    $importWarnings[] = "Correction header partielle: élément(s) introuvable(s) (" . implode(', ', $missing) . ").";
                                }

                                if (!$footerBrandId || !$footerContentId || !$footerContentListId || !$footerBottomListId) {
                                    $missing = [];
                                    if (!$footerBrandId)
                                        $missing[] = 'footer-brand';
                                    if (!$footerContentId)
                                        $missing[] = 'footer-content';
                                    if (!$footerContentListId)
                                        $missing[] = 'footer-content-list';
                                    if (!$footerBottomListId)
                                        $missing[] = 'footer-bottom-list';
                                    $importWarnings[] = "Correction footer partielle: élément(s) introuvable(s) (" . implode(', ', $missing) . ").";
                                }

                                if (!$socialLinksId || !$socialContactId) {
                                    $missing = [];
                                    if (!$socialLinksId)
                                        $missing[] = 'social-links';
                                    if (!$socialContactId)
                                        $missing[] = 'social-contact';
                                    $importWarnings[] = "Correction social partielle: élément(s) introuvable(s) (" . implode(', ', $missing) . ").";
                                }
                            }
                        } catch (\Throwable $e) {
                            if ($debug) {
                                file_put_contents($debugFile, "[HEADER FIX] Échec: " . $e->getMessage() . "\n", FILE_APPEND);
                            }
                        }

                        // 2.6 Diagnostic de structure DSFR (header/footer)
                        try {
                            $createdIds = array_values(array_filter(array_map(function ($m) {
                                return isset($m['id']) ? (int) $m['id'] : 0;
                            }, $createdModules)));

                            if (!empty($createdIds)) {
                                $query = $db->getQuery(true)
                                    ->select($db->quoteName(['id', 'title', 'module', 'content', 'params', 'position']))
                                    ->from($db->quoteName('#__modules'))
                                    ->where($db->quoteName('id') . ' IN (' . implode(',', array_map('intval', $createdIds)) . ')');
                                $rows = $db->setQuery($query)->loadObjectList();

                                $rowMap = [];
                                foreach ($rows as $row) {
                                    $rowMap[(int) $row->id] = $row;
                                }

                                $moduleCache = [];
                                $getModuleById = function ($id) use ($db, &$moduleCache) {
                                    $id = (int) $id;
                                    if ($id <= 0) {
                                        return null;
                                    }
                                    if (array_key_exists($id, $moduleCache)) {
                                        return $moduleCache[$id];
                                    }
                                    $query = $db->getQuery(true)
                                        ->select($db->quoteName(['id', 'title', 'module', 'content', 'params', 'position']))
                                        ->from($db->quoteName('#__modules'))
                                        ->where($db->quoteName('id') . ' = ' . $id);
                                    $moduleCache[$id] = $db->setQuery($query)->loadObject() ?: null;
                                    return $moduleCache[$id];
                                };

                                $parseParams = function ($paramsRaw) {
                                    if (is_array($paramsRaw) || is_object($paramsRaw)) {
                                        return (array) $paramsRaw;
                                    }
                                    if (!is_string($paramsRaw)) {
                                        return [];
                                    }
                                    $decoded = json_decode($paramsRaw, true);
                                    return (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) ? $decoded : [];
                                };

                                $getClassSfx = function ($params) {
                                    if (!is_array($params)) {
                                        return '';
                                    }
                                    return (string) ($params['moduleclass_sfx'] ?? ($params['class_sfx'] ?? ''));
                                };

                                $extractIds = function ($text) use ($loadModulePattern) {
                                    $ids = [];
                                    if (preg_match_all($loadModulePattern, (string) $text, $matches)) {
                                        foreach ($matches[1] as $refId) {
                                            $ids[] = (int) $refId;
                                        }
                                    }
                                    return $ids;
                                };

                                $findRoleModules = function ($rows, $callback) {
                                    $matches = [];
                                    foreach ($rows as $row) {
                                        if ($callback($row)) {
                                            $matches[] = $row;
                                        }
                                    }
                                    return $matches;
                                };

                                $isHeaderBrand = function ($row) use ($parseParams, $getClassSfx) {
                                    $classSfx = strtolower($getClassSfx($parseParams($row->params ?? '')));
                                    $content = strtolower((string) ($row->content ?? ''));
                                    return (strpos($classSfx, 'fr-header__brand') !== false) || (strpos($content, 'fr-header__brand-top') !== false);
                                };
                                $isHeaderTools = function ($row) use ($parseParams, $getClassSfx) {
                                    $classSfx = strtolower($getClassSfx($parseParams($row->params ?? '')));
                                    $content = strtolower((string) ($row->content ?? ''));
                                    return (strpos($classSfx, 'fr-header__tools') !== false) || (strpos($content, 'fr-header__tools-links') !== false);
                                };
                                $isFooterBody = function ($row) use ($parseParams, $getClassSfx) {
                                    $classSfx = strtolower($getClassSfx($parseParams($row->params ?? '')));
                                    return (strpos($classSfx, 'fr-footer__body') !== false);
                                };
                                $isFooterContent = function ($row) use ($parseParams, $getClassSfx) {
                                    $classSfx = strtolower($getClassSfx($parseParams($row->params ?? '')));
                                    return (strpos($classSfx, 'fr-footer__content') !== false) && (strpos($classSfx, 'content-list') === false);
                                };
                                $isFooterBottom = function ($row) use ($parseParams, $getClassSfx) {
                                    $classSfx = strtolower($getClassSfx($parseParams($row->params ?? '')));
                                    return (strpos($classSfx, 'fr-footer__bottom') !== false) && (strpos($classSfx, 'bottom-list') === false);
                                };
                                $isSocialStructure = function ($row) {
                                    $position = strtolower((string) ($row->position ?? ''));
                                    return $position === 'dsfrsocial';
                                };

                                $headerBrandModules = $findRoleModules($rows, $isHeaderBrand);
                                $headerToolsModules = $findRoleModules($rows, $isHeaderTools);
                                $footerBodyModules = $findRoleModules($rows, $isFooterBody);
                                $footerContentModules = $findRoleModules($rows, $isFooterContent);
                                $footerBottomModules = $findRoleModules($rows, $isFooterBottom);
                                $socialStructureModules = $findRoleModules($rows, $isSocialStructure);

                                if (count($headerBrandModules) !== 1) {
                                    $importWarnings[] = "Diagnostic DSFR: header-brand attendu (1), trouvé: " . count($headerBrandModules);
                                }
                                if (count($headerToolsModules) !== 1) {
                                    $importWarnings[] = "Diagnostic DSFR: header-tools attendu (1), trouvé: " . count($headerToolsModules);
                                }
                                if (count($footerBodyModules) !== 1) {
                                    $importWarnings[] = "Diagnostic DSFR: footer-body attendu (1), trouvé: " . count($footerBodyModules);
                                }
                                if (count($footerContentModules) !== 1) {
                                    $importWarnings[] = "Diagnostic DSFR: footer-content attendu (1), trouvé: " . count($footerContentModules);
                                }
                                if (count($footerBottomModules) !== 1) {
                                    $importWarnings[] = "Diagnostic DSFR: footer-bottom attendu (1), trouvé: " . count($footerBottomModules);
                                }
                                if (count($socialStructureModules) !== 2) {
                                    $importWarnings[] = "Diagnostic DSFR: social structure attendue (2), trouvé: " . count($socialStructureModules);
                                }

                                $checkRefs = function ($moduleRow, $expectedCount, $label) use ($extractIds) {
                                    if (!$moduleRow) {
                                        return ['ids' => [], 'warn' => "Diagnostic DSFR: module {$label} introuvable."];
                                    }
                                    $ids = $extractIds($moduleRow->content ?? '');
                                    if (count($ids) !== $expectedCount) {
                                        return ['ids' => $ids, 'warn' => "Diagnostic DSFR: {$label} attend {$expectedCount} référence(s), trouvé: " . count($ids)];
                                    }
                                    return ['ids' => $ids, 'warn' => null];
                                };

                                $headerBrand = $headerBrandModules[0] ?? null;
                                $headerTools = $headerToolsModules[0] ?? null;
                                $footerBody = $footerBodyModules[0] ?? null;
                                $footerContent = $footerContentModules[0] ?? null;
                                $footerBottom = $footerBottomModules[0] ?? null;

                                $brandRefs = $checkRefs($headerBrand, 2, 'header-brand');
                                if ($brandRefs['warn'])
                                    $importWarnings[] = $brandRefs['warn'];
                                $toolsRefs = $checkRefs($headerTools, 1, 'header-tools');
                                if ($toolsRefs['warn'])
                                    $importWarnings[] = $toolsRefs['warn'];
                                $footerBodyRefs = $checkRefs($footerBody, 2, 'footer-body');
                                if ($footerBodyRefs['warn'])
                                    $importWarnings[] = $footerBodyRefs['warn'];
                                $footerContentRefs = $checkRefs($footerContent, 1, 'footer-content');
                                if ($footerContentRefs['warn'])
                                    $importWarnings[] = $footerContentRefs['warn'];
                                $footerBottomRefs = $checkRefs($footerBottom, 1, 'footer-bottom');
                                if ($footerBottomRefs['warn'])
                                    $importWarnings[] = $footerBottomRefs['warn'];
                                $socialRefs = [];
                                if (!empty($socialStructureModules)) {
                                    foreach ($socialStructureModules as $idx => $row) {
                                        $label = 'social-structure-' . ($idx + 1);
                                        $res = $checkRefs($row, 1, $label);
                                        if ($res['warn'])
                                            $importWarnings[] = $res['warn'];
                                        $socialRefs[] = ['row' => $row, 'ids' => $res['ids']];
                                    }
                                }

                                $getRoleFlags = function ($id) use ($getModuleById, $parseParams, $getClassSfx) {
                                    $row = $getModuleById($id);
                                    if (!$row)
                                        return [];
                                    $params = $parseParams($row->params ?? '');
                                    $classSfx = strtolower($getClassSfx($params));
                                    $title = strtolower((string) ($row->title ?? ''));
                                    $layout = strtolower((string) ($params['layout'] ?? ''));
                                    $moduleType = strtolower((string) ($row->module ?? ''));
                                    return [
                                        'header_logo' => (strpos($classSfx, 'fr-header__logo') !== false),
                                        'header_operator' => (strpos($classSfx, 'fr-header__operator') !== false),
                                        'footer_brand' => (strpos($classSfx, 'fr-footer__brand') !== false),
                                        'footer_content' => (strpos($classSfx, 'fr-footer__content') !== false) && (strpos($classSfx, 'content-list') === false),
                                        'footer_content_list' => (strpos($classSfx, 'fr-footer__content-list') !== false),
                                        'footer_bottom_list' => (strpos($classSfx, 'fr-footer__bottom-list') !== false),
                                        'social_links' => (strpos($classSfx, 'fr-follow__social') !== false),
                                        'social_contact' => (strpos($classSfx, 'fr-follow__newsletter') !== false),
                                        'search' => ($moduleType === 'mod_finder') || (strpos($layout, 'finderdsfr') !== false) || (strpos($title, 'recherche') !== false) || (strpos($title, 'search') !== false),
                                    ];
                                };

                                if (!empty($brandRefs['ids'])) {
                                    $logoOk = false;
                                    $operatorOk = false;
                                    foreach ($brandRefs['ids'] as $id) {
                                        $flags = $getRoleFlags($id);
                                        if (!empty($flags['header_logo']))
                                            $logoOk = true;
                                        if (!empty($flags['header_operator']))
                                            $operatorOk = true;
                                    }
                                    if (!$logoOk)
                                        $importWarnings[] = "Diagnostic DSFR: header-brand ne référence pas de module logo.";
                                    if (!$operatorOk)
                                        $importWarnings[] = "Diagnostic DSFR: header-brand ne référence pas de module opérateur.";
                                }

                                if (!empty($toolsRefs['ids'])) {
                                    $searchOk = false;
                                    foreach ($toolsRefs['ids'] as $id) {
                                        $flags = $getRoleFlags($id);
                                        if (!empty($flags['search']))
                                            $searchOk = true;
                                    }
                                    if (!$searchOk)
                                        $importWarnings[] = "Diagnostic DSFR: header-tools ne référence pas de module recherche.";
                                }

                                if (!empty($footerBodyRefs['ids'])) {
                                    $brandOk = false;
                                    $contentOk = false;
                                    foreach ($footerBodyRefs['ids'] as $id) {
                                        $flags = $getRoleFlags($id);
                                        if (!empty($flags['footer_brand']))
                                            $brandOk = true;
                                        if (!empty($flags['footer_content']))
                                            $contentOk = true;
                                    }
                                    if (!$brandOk)
                                        $importWarnings[] = "Diagnostic DSFR: footer-body ne référence pas de module footer-brand.";
                                    if (!$contentOk)
                                        $importWarnings[] = "Diagnostic DSFR: footer-body ne référence pas de module footer-content.";
                                }

                                if (!empty($footerContentRefs['ids'])) {
                                    $listOk = false;
                                    foreach ($footerContentRefs['ids'] as $id) {
                                        $flags = $getRoleFlags($id);
                                        if (!empty($flags['footer_content_list']))
                                            $listOk = true;
                                    }
                                    if (!$listOk)
                                        $importWarnings[] = "Diagnostic DSFR: footer-content ne référence pas de module footer-content-list.";
                                }

                                if (!empty($footerBottomRefs['ids'])) {
                                    $bottomOk = false;
                                    foreach ($footerBottomRefs['ids'] as $id) {
                                        $flags = $getRoleFlags($id);
                                        if (!empty($flags['footer_bottom_list']))
                                            $bottomOk = true;
                                    }
                                    if (!$bottomOk)
                                        $importWarnings[] = "Diagnostic DSFR: footer-bottom ne référence pas de module footer-bottom-list.";
                                }

                                if (!empty($socialRefs)) {
                                    $socialLinksOk = false;
                                    $socialContactOk = false;
                                    foreach ($socialRefs as $ref) {
                                        foreach ($ref['ids'] as $id) {
                                            $flags = $getRoleFlags($id);
                                            if (!empty($flags['social_links']))
                                                $socialLinksOk = true;
                                            if (!empty($flags['social_contact']))
                                                $socialContactOk = true;
                                        }
                                    }
                                    if (!$socialLinksOk)
                                        $importWarnings[] = "Diagnostic DSFR: social structure ne référence pas de module réseaux sociaux.";
                                    if (!$socialContactOk)
                                        $importWarnings[] = "Diagnostic DSFR: social structure ne référence pas de module contact.";
                                }

                                if ($debug) {
                                    file_put_contents($debugFile, "[DSFR DIAG] Warnings: " . count($importWarnings) . "\n", FILE_APPEND);
                                }
                            }
                        } catch (\Throwable $e) {
                            if ($debug) {
                                file_put_contents($debugFile, "[DSFR DIAG] Échec: " . $e->getMessage() . "\n", FILE_APPEND);
                            }
                        }

                        // 3. Post-traitement global pour les conditions Advanced Module Manager (AMM)
                        // On récupère toutes les règles de type 'module' pour faire un remplacement propre.
                        try {
                            $query = $db->getQuery(true)
                                ->select(['id', 'value'])
                                ->from($db->quoteName('#__conditions_rules'))
                                ->where($db->quoteName('rule') . ' = ' . $db->quote('module'));
                            $rules = $db->setQuery($query)->loadObjectList();

                            if (!empty($rules)) {
                                foreach ($rules as $rule) {
                                    $values = explode(',', $rule->value);
                                    $hasChanges = false;
                                    foreach ($values as &$v) {
                                        if (isset($idMap[$v])) {
                                            $v = $idMap[$v];
                                            $hasChanges = true;
                                        }
                                    }
                                    if ($hasChanges) {
                                        $newValue = implode(',', $values);
                                        $updateRule = $db->getQuery(true)
                                            ->update($db->quoteName('#__conditions_rules'))
                                            ->set($db->quoteName('value') . ' = ' . $db->quote($newValue))
                                            ->where($db->quoteName('id') . ' = ' . (int) $rule->id);
                                        $db->setQuery($updateRule)->execute();
                                    }
                                }
                            }
                        } catch (\Throwable $e) {
                            if ($debug)
                                file_put_contents($debugFile, "[IMPORT] AMM Rule mapping failed: " . $e->getMessage() . "\n", FILE_APPEND);
                        }
                    }

                    $response = [
                        'success' => true,
                        'message' => 'Import terminé',
                        'imported' => $importedCount,
                        'failed' => $failedCount,
                        'failed_modules' => $failedModules,
                        'mapping_log' => $mappingLog,
                        'id_map' => $idMap,
                        'unmapped_refs' => !empty($missingRefs) ? array_keys($missingRefs) : [],
                        'remaining_old_refs' => $remainingOldRefs,
                        'warnings' => $importWarnings // Avertissements pour l'utilisateur
                    ];

                    if ($debug)
                        file_put_contents($debugFile, "[IMPORT] Réponse finale:\n" . print_r($response, true) . "\n--- [END TASK] ---\n\n", FILE_APPEND);

                    // Utilisation de la méthode centralisée pour une réponse propre
                    $this->sendCleanJsonResponse(['success' => true, 'data' => $response]);

                } catch (\Throwable $e) {
                    if ($debug)
                        file_put_contents($debugFile, "[IMPORT] ERREUR CRITIQUE: " . $e->getMessage() . "\n--- [END TASK] ---\n\n", FILE_APPEND);
                    // Utilisation de la méthode centralisée pour une réponse d'erreur propre
                    $this->sendCleanJsonResponse(['message' => 'Erreur critique lors de l\'import : ' . $e->getMessage()], true, $debug, $debugFile);
                }
            }
        } catch (\Throwable $e) {
            if ($debug && !empty($debugFile)) {
                file_put_contents($debugFile, date('Y-m-d H:i:s') . " | GLOBAL ERROR in onAfterRoute: " . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n", FILE_APPEND);
            }
            $this->sendCleanJsonResponse(['message' => 'Erreur système : ' . $e->getMessage()], true, $debug, $debugFile);
        }
    }

    /**
     * Vide tous les caches de Joomla.
     */
    protected function clearCache($debug = false, $debugFile = '')
    {
        try {
            // Factory::getCache est compatible Joomla 4/5 alors que Application::getCache n'existe plus
            $cache = Factory::getCache('com_modules');
            $cache->clean();
            // Correction : gc() n'est pas statique sur l'objet retourné par Factory::getCache()
            if (method_exists($cache, 'gc')) {
                $cache->gc();
            }

            if ($debug && !empty($debugFile)) {
                file_put_contents($debugFile, date('Y-m-d H:i:s') . " | SUCCESS clearCache: Tous les caches ont été purgés.\n", FILE_APPEND);
            }
        } catch (\Exception $e) {
            if ($debug && !empty($debugFile)) {
                file_put_contents($debugFile, date('Y-m-d H:i:s') . " | ERROR clearCache: " . $e->getMessage() . "\n", FILE_APPEND);
            }
        }
    }

    /**
     * Crée automatiquement /media/templates/site/<template>/css/user.css si absent.
     */
    private function ensureMediaUserCss($templateName, $debug = false, $debugFile = '')
    {
        $filter = InputFilter::getInstance();
        $templateName = $filter->clean($templateName, 'CMD');

        $result = [
            'template' => $templateName,
            'path' => 'media/templates/site/' . $templateName . '/css/user.css',
            'status' => 'unknown',
            'created' => false,
            'message' => ''
        ];

        if (empty($templateName)) {
            $result['status'] = 'error';
            $result['message'] = 'Template invalide';
            return $result;
        }

        $cssDir = JPATH_ROOT . '/media/templates/site/' . $templateName . '/css';
        $cssPath = $cssDir . '/user.css';
        $cssDisabledPath = $cssPath . '.disabled';

        try {
            if (file_exists($cssPath)) {
                $result['status'] = 'enabled';
                $result['message'] = 'Déjà présent';
                return $result;
            }

            if (file_exists($cssDisabledPath)) {
                $result['status'] = 'disabled';
                $result['message'] = 'Désactivé';
                return $result;
            }

            if (!is_dir($cssDir) && !Folder::create($cssDir)) {
                throw new \RuntimeException('Impossible de créer le dossier css.');
            }

            $content = "/* user.css - auto-cree par ModuleExport */\n";
            if (!File::write($cssPath, $content)) {
                throw new \RuntimeException('Impossible de créer le fichier user.css.');
            }

            $result['status'] = 'created';
            $result['created'] = true;
            $result['message'] = 'Créé';
        } catch (\Throwable $e) {
            $result['status'] = 'error';
            $result['message'] = $e->getMessage();
            if ($debug && !empty($debugFile)) {
                file_put_contents($debugFile, date('Y-m-d H:i:s') . " | ERROR ensureMediaUserCss: " . $e->getMessage() . "\n", FILE_APPEND);
            }
        }

        return $result;
    }

    /**
     * Vérifie le token CSRF et renvoie une erreur JSON si invalide.
     * Ajoute également une vérification ACL optionnelle.
     *
     * @param bool $isWriteAction Si true, vérifie uniquement POST. Sinon, vérifie POST ou GET.
     * @param bool $debug Mode debug activé
     * @param string $debugFile Fichier de log debug
     * @param bool $checkAcl Vérifier également les droits 'core.manage' (défaut: true)
     * @return bool true si le token est valide, false sinon (et termine l'exécution)
     */
    private function validateCsrfToken(bool $isWriteAction = true, bool $debug = false, string $debugFile = '', bool $checkAcl = true): bool
    {
        // 1. Vérification CSRF
        $method = $isWriteAction ? 'post' : 'request';
        $tokenName = \Joomla\CMS\Session\Session::getFormToken();

        $isValid = Session::checkToken($method);
        if (!$isValid) {
            if ($debug && !empty($debugFile)) {
                $this->ensureLogDirExists();
                $payload = [
                    'method' => $method,
                    'expected' => $tokenName,
                    'uri' => $_SERVER['REQUEST_URI'] ?? '',
                ];
                file_put_contents(
                    $debugFile,
                    date('Y-m-d H:i:s') . ' [CSRF INVALID] ' . json_encode($payload) . PHP_EOL,
                    FILE_APPEND
                );
            }

            $this->sendCleanJsonResponse(
                [
                    'message' => 'Token CSRF invalide ou expiré. Veuillez recharger la page.',
                    'code' => 'csrf_invalid',
                    'method' => $method
                ],
                true,
                $debug,
                $debugFile
            );
            return false;
        }

        // 2. Vérification ACL (accès administration module)
        if ($checkAcl) {
            $user = $this->app->getIdentity();
            if (!$user->authorise('core.manage', 'com_modules')) {
                if ($debug && !empty($debugFile)) {
                    file_put_contents($debugFile, date('Y-m-d H:i:s') . " | ❌ ACL Access Denied for user " . $user->id . "\n", FILE_APPEND);
                }
                $this->sendCleanJsonResponse(['message' => 'Accès refusé. Droits insuffisants.'], true);
                return false;
            }
        }

        return true;
    }

    /**
     * Envoie une réponse JSON propre en vidant les tampons et en terminant le script.
     */
    private function sendCleanJsonResponse($data, $isError = false, $debug = false, $debugFile = '')
    {
        // Nettoyer tous les tampons de sortie existants
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        if (!headers_sent()) {
            header('Content-Type: application/json; charset=utf-8');
            // IMPORTANT: Toujours renvoyer 200 OK même en cas d'erreur logique.
            // Renvoyer 500 peut provoquer l'affichage de pages d'erreur HTML par le serveur (Apache/Nginx/Plesk),
            // ce qui casse le parsing JSON côté client (et fige l'interface).
            http_response_code(200);
        }

        if ($isError) {
            if ($debug && $debugFile) {
                file_put_contents($debugFile, "[RESPONSE ERROR] " . json_encode($data) . "\n", FILE_APPEND);
            }
            echo json_encode(['success' => false, 'message' => $data['message'] ?? 'Erreur inconnue', 'data' => null]);
        } else {
            echo json_encode($data);
        }

        try {
            Factory::getApplication()->close();
        } catch (\Exception $e) {
            exit(); // Fallback si close() échoue
        }
    }

    /**
     * Migre et corrige la structure HTML des fr-card vers la conformité DSFR.
     * Passe 1 : Restructure les cartes sans fr-card__body (ancien format Joomla)
     * Passe 2 : Supprime les fr-card__desc vides (espaces / &nbsp;)
     * Passe 3 : Fusionne les wrappers blog-items/d-flex en une grille fr-grid-row
     */
    private function migrateFrcardHtml(string $html): string
    {
        if (empty($html) || strpos($html, 'fr-card') === false) return $html;

        $dom = new \DOMDocument('1.0', 'UTF-8');
        libxml_use_internal_errors(true);
        $dom->loadHTML('<meta charset="utf-8"><div id="mxwrap">' . $html . '</div>');
        libxml_clear_errors();

        $xpath    = new \DOMXPath($dom);
        $modified = false;

        // === Passe 0 : Nettoyage des structures corrompues (double fr-card__body, header imbriqué) ===
        $rootCards = [];
        foreach ($xpath->query('//div[contains(concat(" ", normalize-space(@class), " "), " fr-card ")]') as $node) {
            $rootCards[] = $node;
        }
        foreach ($rootCards as $card) {
            // Correction : fr-card__body > fr-card__body (doublon)
            foreach ($card->childNodes as $child) {
                if ($child->nodeType !== XML_ELEMENT_NODE) continue;
                if (strpos($child->getAttribute('class'), 'fr-card__body') === false) continue;
                $innerBody = $xpath->query('./div[contains(@class, "fr-card__body")]', $child)->item(0);
                if ($innerBody) {
                    while ($innerBody->firstChild) $child->appendChild($innerBody->firstChild);
                    $child->removeChild($innerBody);
                    $modified = true;
                }
                break;
            }
            // Correction : fr-card__header contenant fr-card__body injecté + fr-card__header imbriqué
            foreach ($card->childNodes as $child) {
                if ($child->nodeType !== XML_ELEMENT_NODE) continue;
                if (strpos($child->getAttribute('class'), 'fr-card__header') === false) continue;
                $nestedHeader = $xpath->query('./div[contains(@class, "fr-card__header")]', $child)->item(0);
                if ($nestedHeader) {
                    $imgWrap = $xpath->query('./div[contains(@class, "fr-card__img")]', $nestedHeader)->item(0);
                    while ($child->firstChild) $child->removeChild($child->firstChild);
                    if ($imgWrap) $child->appendChild($imgWrap);
                    $modified = true;
                }
                break;
            }
        }

        // === Passe 1 : Restructuration interne des cartes sans fr-card__body ===
        $cards = [];
        foreach ($xpath->query('//div[contains(concat(" ", normalize-space(@class), " "), " fr-card ")]') as $node) {
            $cards[] = $node;
        }
        foreach ($cards as $card) {
            if ($xpath->query('.//div[contains(@class, "fr-card__body")]', $card)->length > 0) continue;

            $href = '#'; $titleText = 'Titre';
            $aQuery = $xpath->query('.//div[contains(@class,"page-header")]//a | .//h2//a | .//h3//a', $card);
            if ($aQuery->length > 0) {
                $href      = $aQuery->item(0)->getAttribute('href');
                $titleText = trim($aQuery->item(0)->textContent);
            }

            $descText = '';
            $pQuery   = $xpath->query('.//div[contains(@class,"item-content")]/p[1]', $card);
            if ($pQuery->length > 0) {
                $descText = trim(str_replace("\xc2\xa0", '', $pQuery->item(0)->textContent));
            }

            // Extraire l'image avant de vider la carte
            $imgSrc = ''; $imgAlt = '';
            $imgQuery = $xpath->query('.//img', $card);
            if ($imgQuery->length > 0) {
                $imgNode = $imgQuery->item(0);
                $imgSrc  = $imgNode->getAttribute('src');
                $imgAlt  = $imgNode->getAttribute('alt');
            }

            $parts   = preg_split('/\s+/', trim($card->getAttribute('class')));
            $frParts = array_values(array_filter($parts, fn($c) => strpos($c, 'fr-') === 0));
            $card->setAttribute('class', implode(' ', $frParts) ?: 'fr-card');

            $body    = $dom->createElement('div'); $body->setAttribute('class', 'fr-card__body');
            $content = $dom->createElement('div'); $content->setAttribute('class', 'fr-card__content');
            $h3      = $dom->createElement('h3');  $h3->setAttribute('class', 'fr-card__title');
            $a       = $dom->createElement('a');
            $a->setAttribute('class', 'fr-card__link');
            $a->setAttribute('href', $href);
            $a->appendChild($dom->createTextNode($titleText));
            $h3->appendChild($a);
            $content->appendChild($h3);

            if ($descText !== '') {
                $p = $dom->createElement('p'); $p->setAttribute('class', 'fr-card__desc');
                $p->appendChild($dom->createTextNode($descText));
                $content->appendChild($p);
            }

            $body->appendChild($content);
            while ($card->firstChild) $card->removeChild($card->firstChild);
            $card->appendChild($body);

            // Ajouter fr-card__header avec l'image si présente
            if ($imgSrc !== '') {
                $header  = $dom->createElement('div'); $header->setAttribute('class', 'fr-card__header');
                $imgWrap = $dom->createElement('div'); $imgWrap->setAttribute('class', 'fr-card__img');
                $img     = $dom->createElement('img');
                $img->setAttribute('class', 'fr-responsive-img');
                $img->setAttribute('src', $imgSrc);
                $img->setAttribute('alt', $imgAlt);
                $imgWrap->appendChild($img);
                $header->appendChild($imgWrap);
                $card->appendChild($header);
            }

            $modified = true;
        }

        // === Passe 2 : Suppression des fr-card__desc vides (espaces / &nbsp;) ===
        $emptyDescs = [];
        foreach ($xpath->query('//p[contains(@class, "fr-card__desc")]') as $node) {
            $emptyDescs[] = $node;
        }
        foreach ($emptyDescs as $p) {
            if (trim(str_replace("\xc2\xa0", '', $p->textContent)) === '') {
                $p->parentNode->removeChild($p);
                $modified = true;
            }
        }

        // === Passe 3 : Fusion des wrappers blog-items/d-flex en grille fr-grid-row ===
        $blogContainers = [];
        foreach ($xpath->query('//div[contains(@class, "blog-items")]') as $node) {
            if ($xpath->query('.//div[contains(@class, "fr-card")]', $node)->length > 0) {
                $blogContainers[] = $node;
            }
        }

        if (count($blogContainers) > 0) {
            $grid = $dom->createElement('div');
            $grid->setAttribute('class', 'fr-grid-row fr-grid-row--gutters');

            foreach ($blogContainers as $container) {
                $containerCards = [];
                foreach ($xpath->query('./div[contains(@class, "fr-card")]', $container) as $c) {
                    $containerCards[] = $c;
                }
                foreach ($containerCards as $card) {
                    $col = $dom->createElement('div');
                    $col->setAttribute('class', 'fr-col-12 fr-col-sm-6 fr-col-md-4');
                    $col->appendChild($card);
                    $grid->appendChild($col);
                }
            }

            // Insérer la grille avant le premier conteneur
            $first = $blogContainers[0];
            $first->parentNode->insertBefore($grid, $first);

            // Supprimer les anciens conteneurs
            foreach ($blogContainers as $container) {
                if ($container->parentNode) $container->parentNode->removeChild($container);
            }

            // Supprimer les <p> séparateurs vides restants
            $emptyPs = [];
            foreach ($xpath->query('//p') as $p) {
                if (trim(str_replace("\xc2\xa0", '', $p->textContent)) === '') $emptyPs[] = $p;
            }
            foreach ($emptyPs as $p) {
                if ($p->parentNode) $p->parentNode->removeChild($p);
            }

            // Ajouter un <p>&nbsp;</p> après la grille (après le nettoyage pour ne pas être supprimé)
            $spacer = $dom->createElement('p');
            $spacer->appendChild($dom->createTextNode("\xc2\xa0"));
            $grid->parentNode->insertBefore($spacer, $grid->nextSibling);

            $modified = true;
        }

        // === Passe 4 : Suppression des commentaires de mise en page devenus inutiles ===
        $comments = [];
        foreach ($xpath->query('//comment()') as $comment) {
            $text = trim($comment->nodeValue);
            if ($text === '' || preg_match('/[-]{3,}|début\s+ligne|fin\s+ligne|début ligne|fin ligne/i', $text)) {
                $comments[] = $comment;
            }
        }
        foreach ($comments as $comment) {
            if ($comment->parentNode) {
                $comment->parentNode->removeChild($comment);
                $modified = true;
            }
        }

        // Nettoyage final : <p> vides hors fr-card (s'exécute toujours, couvre les cas sans blog-items)
        $emptyPs = [];
        foreach ($xpath->query('//p[not(@class) and not(ancestor::div[contains(@class,"fr-card")])]') as $p) {
            if (trim(str_replace("\xc2\xa0", '', $p->textContent)) === '') $emptyPs[] = $p;
        }
        foreach ($emptyPs as $p) {
            if ($p->parentNode) { $p->parentNode->removeChild($p); $modified = true; }
        }

        // Spacer après chaque fr-grid-row si absent
        foreach ($xpath->query('//div[contains(concat(" ", normalize-space(@class), " "), " fr-grid-row ")]') as $grid) {
            $next = $grid->nextSibling;
            while ($next && $next->nodeType === XML_TEXT_NODE) $next = $next->nextSibling;
            $hasSpacerNext = $next && $next->nodeType === XML_ELEMENT_NODE
                && $next->nodeName === 'p'
                && trim(str_replace("\xc2\xa0", '', $next->textContent)) === '';
            if (!$hasSpacerNext) {
                $spacer = $dom->createElement('p');
                $spacer->appendChild($dom->createTextNode("\xc2\xa0"));
                $grid->parentNode->insertBefore($spacer, $grid->nextSibling);
                $modified = true;
            }
        }

        if (!$modified) return $html;

        $wrapper = $dom->getElementById('mxwrap');
        if (!$wrapper) return $html;

        $result = '';
        foreach ($wrapper->childNodes as $node) {
            $result .= $dom->saveHTML($node);
        }

        return $result;
    }

    /**
     * Calcule la taille d'un dossier de manière récursive.
     */
    private function getFolderSize($path)
    {
        $totalSize = 0;
        if (!file_exists($path)) {
            return 0;
        }
        if (is_file($path)) {
            return filesize($path);
        }

        $files = scandir($path);
        if ($files === false) {
            return 0;
        }

        foreach ($files as $file) {
            if ($file !== '.' && $file !== '..') {
                $filePath = $path . DIRECTORY_SEPARATOR . $file;
                try {
                    if (is_dir($filePath)) {
                        $totalSize += $this->getFolderSize($filePath);
                    } else {
                        $totalSize += (float) filesize($filePath);
                    }
                } catch (\Exception $e) {
                    continue;
                }
            }
        }
        return $totalSize;
    }

    /**
     * S'assure que le répertoire de logs du plugin existe.
     */
    private function ensureLogDirExists()
    {
        static $logDirExists = false;
        if ($logDirExists) {
            return;
        }

        $logDir = JPATH_ROOT . '/logs/moduleexport';

        if (!is_dir($logDir)) {
            @mkdir($logDir, 0755, true);
        }

        // Protéger le dossier (pas de listing ni d'accès direct)
        $htaccess = $logDir . '/.htaccess';
        if (!file_exists($htaccess)) {
            @file_put_contents($htaccess, "Deny from all\n");
        }

        $index = $logDir . '/index.html';
        if (!file_exists($index)) {
            @file_put_contents($index, '<!DOCTYPE html><html><head></head><body></body></html>');
        }

        // Nettoyer les logs de plus de 14 jours pour éviter l'accumulation
        $retentionDays = 14;
        $threshold = time() - ($retentionDays * 86400);
        foreach (glob($logDir . '/*.log') ?: [] as $file) {
            $mtime = @filemtime($file);
            if ($mtime !== false && $mtime < $threshold) {
                @unlink($file);
            }
        }

        $logDirExists = true;
    }

    /**
     * Injecte un fallback front pour ouvrir la recherche + debug optionnel (?debug=1)
     */
    private function injectFrontSearchFallback($app, $withDebug = false)
    {
        try {
            $doc = $this->app->getDocument();
            if ($doc->getType() !== 'html') {
                return;
            }
            $body = $app->getBody();
            if (!is_string($body) || $body === '') {
                return;
            }

            $debugFlag = $withDebug ? 'true' : 'false';

            $script = <<<JS
(function(){
  try {
    var fixHeaderIds = function(){
      var root = document.querySelector('.fr-header') || document;
      if (!root || !root.querySelectorAll) return;
      var seen = {};
      var idx = 0;
      root.querySelectorAll('button[id]').forEach(function(el){
        var id = el.id;
        if (!id) return;
        if (seen[id]) {
          idx++;
          var newId = id + '-dup' + idx;
          root.querySelectorAll('[aria-labelledby=\"' + id + '\"]').forEach(function(n){
            n.setAttribute('aria-labelledby', newId);
          });
          el.id = newId;
        } else {
          seen[id] = true;
        }
      });
    };
    var fixSearchLabel = function(){
      var searchBar = document.querySelector('.fr-header__search .fr-search-bar');
      if (!searchBar) return;
      var label = searchBar.querySelector('label[for]');
      var input = searchBar.querySelector('input');
      if (!label || !input) return;
      var forId = label.getAttribute('for') || '';
      var inputId = input.getAttribute('id') || '';
      if (forId && inputId && forId !== inputId) {
        if (!document.getElementById(forId) || document.getElementById(forId) === input) {
          input.setAttribute('id', forId);
        } else {
          label.setAttribute('for', inputId);
        }
      } else if (forId && !inputId) {
        input.setAttribute('id', forId);
      } else if (!forId && inputId) {
        label.setAttribute('for', inputId);
      }
    };
    var elevateHeaderButtons = function(){
      var navbar = document.querySelector('.fr-header__navbar');
      if (navbar) {
        navbar.style.position = 'relative';
        navbar.style.zIndex = '5';
        navbar.style.pointerEvents = 'auto';
      }
      document.querySelectorAll('.fr-header__navbar .fr-btn').forEach(function(btn){
        btn.style.position = 'relative';
        btn.style.zIndex = '6';
        btn.style.pointerEvents = 'auto';
      });
    };
    var forceSearchVisible = function(){
      if (!{$debugFlag}) return;
      var modal = document.querySelector('.fr-header__search');
      if (!modal) return;
      modal.removeAttribute('hidden');
      modal.setAttribute('aria-hidden', 'false');
      modal.setAttribute('data-fr-opened', 'true');
      if (modal.classList) {
        modal.classList.add('fr-modal--opened');
      }
      if (modal.style && modal.style.setProperty) {
        modal.style.setProperty('display', 'block', 'important');
        modal.style.setProperty('opacity', '1', 'important');
        modal.style.setProperty('visibility', 'visible', 'important');
        modal.style.setProperty('pointer-events', 'auto', 'important');
        modal.style.setProperty('position', 'static', 'important');
        modal.style.setProperty('inset', 'auto', 'important');
        modal.style.setProperty('transform', 'none', 'important');
        modal.style.setProperty('max-height', 'none', 'important');
      } else {
        modal.style.display = 'block';
        modal.style.opacity = '1';
        modal.style.visibility = 'visible';
        modal.style.pointerEvents = 'auto';
        modal.style.position = 'static';
        modal.style.inset = 'auto';
        modal.style.transform = 'none';
      }
    };
    var debugBox = null;
    var applyDebugStyles = function(){
      if (!{$debugFlag}) return;
      var modal = document.querySelector('.fr-header__search.fr-modal');
      var searchBar = document.querySelector('.fr-header__search .fr-search-bar');
      var searchBtn = document.querySelector('.fr-btn--search');
      var tools = document.querySelector('.fr-header__tools');
      if (modal) {
        modal.style.outline = '3px solid #e10600';
        modal.style.outlineOffset = '2px';
      }
      if (searchBar) {
        searchBar.style.border = '3px solid #e10600';
        searchBar.style.padding = '6px';
        searchBar.style.borderRadius = '6px';
        searchBar.style.background = 'rgba(225,6,0,0.06)';
      }
      if (searchBtn) {
        searchBtn.style.outline = '3px solid #e10600';
        searchBtn.style.outlineOffset = '2px';
      }
      if (tools) {
        tools.style.outline = '3px dashed #e10600';
        tools.style.outlineOffset = '3px';
      }
    };

    var updateDebug = function(){
      if (!{$debugFlag}) return;
      var form = document.querySelector('.mod-finder.js-finder-searchform');
      var formAction = form ? (form.getAttribute('action') || '') : '';
      var formMethod = form ? (form.getAttribute('method') || '') : '';
      var formHasInput = !!(form && form.querySelector('input[name="q"]'));
      var formHasButton = !!(form && form.querySelector('button[type="submit"], input[type="submit"]'));
      var dbgBtn = form ? (form.querySelector('button[type="submit"], input[type="submit"], button.fr-btn') || null) : null;
      var dbgInput = form ? (form.querySelector('input[name="q"]') || null) : null;
      var btnInForm = !!(form && dbgBtn && form.contains(dbgBtn));
      var hitTest = '';
      if (dbgBtn && dbgBtn.getBoundingClientRect && document.elementFromPoint) {
        var rect = dbgBtn.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          var cx = rect.left + rect.width / 2;
          var cy = rect.top + rect.height / 2;
          var el = document.elementFromPoint(cx, cy);
          if (el && el !== dbgBtn && !(dbgBtn.contains && dbgBtn.contains(el))) {
            var eid = el.id ? ('#' + el.id) : '';
            var ecls = el.className && typeof el.className === 'string' ? ('.' + el.className.trim().replace(/\s+/g, '.')) : '';
            hitTest = el.tagName.toLowerCase() + eid + ecls;
          } else {
            hitTest = 'OK';
          }
        }
      }
      var searchBtn = document.querySelector('.fr-btn--search');
      var modal = document.querySelector('.fr-header__search.fr-modal');
      var hasDsfr = !!window.dsfr;
      var modalId = modal && modal.id ? modal.id : '';
      var btnControls = searchBtn ? searchBtn.getAttribute('aria-controls') : '';
      var linkOk = !!(modalId && btnControls && modalId === btnControls);
      var hidden = modal ? (modal.hasAttribute('hidden') || (modal.getAttribute('aria-hidden') === 'true')) : false;
      var opened = modal ? (modal.getAttribute('data-fr-opened') === 'true' || modal.classList.contains('fr-modal--opened')) : false;

      var status = [];
      status.push('DSFR JS: ' + (hasDsfr ? 'ON' : 'OFF'));
      status.push('Modal: ' + (modal ? ('OK (' + modalId + ')') : 'ABSENTE'));
      status.push('Bouton: ' + (searchBtn ? 'OK' : 'ABSENT'));
      status.push('Lien btn->modal: ' + (linkOk ? 'OK' : 'KO'));
      status.push('Masquée: ' + (hidden ? 'Oui' : 'Non'));
      status.push('Ouverte: ' + (opened ? 'Oui' : 'Non'));
      status.push('Form: ' + (form ? 'OK' : 'ABSENTE'));
      if (form) {
        status.push('Action: ' + (formAction ? formAction : 'VIDE'));
        status.push('Method: ' + (formMethod ? formMethod.toUpperCase() : 'VIDE'));
        status.push('Input q: ' + (formHasInput ? 'OK' : 'ABSENT'));
        status.push('Submit btn: ' + (formHasButton ? 'OK' : 'ABSENT'));
        if (typeof window.__meSubmitSeen !== 'undefined') {
          status.push('Submit: ' + (window.__meSubmitSeen ? 'Oui' : 'Non'));
          status.push('Prevented: ' + (window.__meSubmitPrevented ? 'Oui' : 'Non'));
          status.push('Click: ' + (window.__meSubmitClick ? 'Oui' : 'Non'));
          status.push('ClickPrevented: ' + (window.__meSubmitClickPrevented ? 'Oui' : 'Non'));
          status.push('Forced: ' + (window.__meSubmitForced ? 'Oui' : 'Non'));
          status.push('Enter: ' + (window.__meEnterPressed ? 'Oui' : 'Non'));
          if (window.__meLastClick) {
            status.push('LastClick: ' + window.__meLastClick);
          }
          if (window.__meLastKey) {
            status.push('LastKey: ' + window.__meLastKey);
          }
          if (window.__meGlobalClick) {
            status.push('GlobalClick: ' + window.__meGlobalClick);
          }
          if (typeof window.__meGlobalClickInForm !== 'undefined') {
            status.push('GlobalInForm: ' + (window.__meGlobalClickInForm ? 'Oui' : 'Non'));
          }
          if (window.__meGlobalKey) {
            status.push('GlobalKey: ' + window.__meGlobalKey);
          }
          if (typeof window.__meClickInBtn !== 'undefined') {
            status.push('ClickInBtn: ' + (window.__meClickInBtn ? 'Oui' : 'Non'));
          }
          if (window.__meClickTarget) {
            status.push('ClickTarget: ' + window.__meClickTarget);
          }
          if (typeof window.__meBtnClickAt !== 'undefined') {
            if (window.__meBtnClickAt) {
              var ago = Math.round((Date.now() - window.__meBtnClickAt) / 100) / 10;
              status.push('BtnClick: ' + ago + 's');
            } else {
              status.push('BtnClick: Non');
            }
          }
        }
        if (dbgBtn && window.getComputedStyle) {
          var bcs = window.getComputedStyle(dbgBtn);
          status.push('BtnPE: ' + bcs.pointerEvents);
          status.push('BtnVis: ' + bcs.visibility);
          status.push('BtnDisp: ' + bcs.display);
          status.push('BtnOp: ' + bcs.opacity);
          status.push('BtnDis: ' + (dbgBtn.disabled ? 'Oui' : 'Non'));
          status.push('BtnInForm: ' + (btnInForm ? 'Oui' : 'Non'));
          if (hitTest) {
            status.push('HitTest: ' + hitTest);
          }
        }
        if (dbgInput && window.getComputedStyle) {
          var ics = window.getComputedStyle(dbgInput);
          status.push('InpPE: ' + ics.pointerEvents);
          status.push('InpVis: ' + ics.visibility);
          status.push('InpDisp: ' + ics.display);
          status.push('InpDis: ' + (dbgInput.disabled ? 'Oui' : 'Non'));
        }
      }

      if (!debugBox) {
        debugBox = document.createElement('div');
        debugBox.id = 'me-front-debug';
        debugBox.setAttribute('style',
          'position:fixed;bottom:12px;right:12px;z-index:99999;' +
          'max-width:70vw;padding:8px 10px;border-radius:6px;' +
          'font:12px/1.3 -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;' +
          'color:#fff;background:' + (hasDsfr && modal && searchBtn && linkOk ? 'rgba(16,124,65,0.9)' : 'rgba(176,0,0,0.9)') + ';' +
          'box-shadow:0 2px 8px rgba(0,0,0,0.2);'
        );
        document.body.appendChild(debugBox);
      }
      debugBox.textContent = status.join(' | ');
    };

    fixHeaderIds();
    fixSearchLabel();
    elevateHeaderButtons();
    applyDebugStyles();

    if ({$debugFlag}) {
      if (typeof window.__meSubmitSeen === 'undefined') {
        window.__meSubmitSeen = false;
        window.__meSubmitPrevented = false;
        window.__meSubmitClick = false;
        window.__meSubmitClickPrevented = false;
        window.__meSubmitForced = false;
        window.__meEnterPressed = false;
        window.__meLastClick = '';
        window.__meLastKey = '';
        window.__meGlobalClick = '';
        window.__meGlobalClickInForm = false;
        window.__meGlobalKey = '';
        window.__meClickInBtn = false;
        window.__meClickTarget = '';
        window.__meBtnClickAt = 0;
      }
      var dbgForm = document.querySelector('.mod-finder.js-finder-searchform');
      if (dbgForm) {
        dbgForm.addEventListener('submit', function(e){
          window.__meSubmitSeen = true;
          window.__meSubmitPrevented = !!e.defaultPrevented;
          dbgForm.__meSubmitAt = Date.now();
          setTimeout(updateDebug, 10);
        }, true);
        dbgForm.addEventListener('click', function(e){
          var t = e.target;
          if (t && t.tagName) {
            var id = t.id ? ('#' + t.id) : '';
            var cls = t.className && typeof t.className === 'string' ? ('.' + t.className.trim().replace(/\\s+/g, '.')) : '';
            window.__meLastClick = t.tagName.toLowerCase() + id + cls;
          } else {
            window.__meLastClick = 'unknown';
          }
          setTimeout(updateDebug, 10);
        }, true);
        dbgForm.addEventListener('keydown', function(e){
          window.__meLastKey = e.key || '';
          setTimeout(updateDebug, 10);
        }, true);
      }
      document.addEventListener('click', function(e){
        var t = e.target;
        if (t && t.tagName) {
          var id = t.id ? ('#' + t.id) : '';
          var cls = t.className && typeof t.className === 'string' ? ('.' + t.className.trim().replace(/\s+/g, '.')) : '';
          window.__meGlobalClick = t.tagName.toLowerCase() + id + cls;
        } else {
          window.__meGlobalClick = 'unknown';
        }
        window.__meGlobalClickInForm = !!(dbgForm && t && dbgForm.contains(t));
        setTimeout(updateDebug, 10);
      }, true);
      document.addEventListener('keydown', function(e){
        window.__meGlobalKey = e.key || '';
        setTimeout(updateDebug, 10);
      }, true);
      forceSearchVisible();
      setTimeout(forceSearchVisible, 50);
      setTimeout(forceSearchVisible, 300);
      setTimeout(function(){
        var btn = document.querySelector('.fr-btn--search');
        var modal = document.querySelector('.fr-header__search.fr-modal');
        if (modal) {
          openModal(modal, btn);
          updateDebug();
        }
      }, 100);
    }

    var openModal = function(modal, btn){
      if (!modal) return;
      modal.removeAttribute('hidden');
      modal.setAttribute('aria-hidden', 'false');
      modal.setAttribute('data-fr-opened', 'true');
      modal.classList.add('fr-modal--opened');
      modal.style.display = 'block';
      modal.style.opacity = '1';
      modal.style.visibility = 'visible';
      modal.style.pointerEvents = 'auto';
      if (document.documentElement) document.documentElement.classList.add('fr-no-scroll');
      if (document.body) document.body.classList.add('fr-no-scroll');
      if (btn) btn.setAttribute('data-fr-opened', 'true');
    };

    if ({$debugFlag}) {
      document.addEventListener('click', function(e){
        var target = e.target;
        if (target && target.closest && target.closest('.fr-btn--menu')) {
          return;
        }
        var btn = target && target.closest ? target.closest('.fr-btn--search') : null;
        var searchBtn = btn || document.querySelector('.fr-btn--search');
        var rect = searchBtn ? searchBtn.getBoundingClientRect() : null;
        var insideBtn = false;
        if (!btn && rect) {
          insideBtn = (e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom);
        }
        if (btn || insideBtn) {
          var targetId = searchBtn ? searchBtn.getAttribute('aria-controls') : '';
          var modal = (targetId && document.getElementById(targetId)) || document.querySelector('.fr-header__search.fr-modal');
          if (modal) {
            e.preventDefault();
            openModal(modal, searchBtn);
            setTimeout(updateDebug, 50);
          }
        }
      }, true);
    }

    var installSubmitFallback = function(){
      var form = document.querySelector('.mod-finder.js-finder-searchform');
      if (!form || form.__meSubmitBound) return;
      form.__meSubmitBound = true;
      var input = form.querySelector('input[name="q"]');
      var btn = form.querySelector('button[type="submit"], input[type="submit"]') || form.querySelector('button.fr-btn');
      if (btn && btn.tagName && btn.tagName.toLowerCase() === 'button' && !btn.getAttribute('type')) {
        btn.setAttribute('type', 'submit');
      }

      var forceSubmit = function(){
        try {
          if (typeof form.requestSubmit === 'function') {
            form.requestSubmit(btn || undefined);
          } else {
            form.submit();
          }
          if (typeof window.__meSubmitForced !== 'undefined') {
            window.__meSubmitForced = true;
            setTimeout(updateDebug, 10);
          }
        } catch (e) {}
      };

      if (btn) {
        btn.addEventListener('click', function(e){
          if (typeof window.__meSubmitClick !== 'undefined') {
            window.__meSubmitClick = true;
            window.__meSubmitClickPrevented = !!e.defaultPrevented;
            var t = e.target;
            if (t && t.tagName) {
              var id = t.id ? ('#' + t.id) : '';
              var cls = t.className && typeof t.className === 'string' ? ('.' + t.className.trim().replace(/\\s+/g, '.')) : '';
              window.__meLastClick = t.tagName.toLowerCase() + id + cls;
            }
          }
          form.__meClickAt = Date.now();
          setTimeout(function(){
            var lastSubmit = form.__meSubmitAt || 0;
            var lastClick = form.__meClickAt || 0;
            if (lastSubmit < lastClick) {
              forceSubmit();
            }
          }, 50);
          if ({$debugFlag}) setTimeout(updateDebug, 10);
        }, true);
      }
      if (input) {
        input.addEventListener('keydown', function(e){
          if (e.key === 'Enter') {
            if (typeof window.__meEnterPressed !== 'undefined') {
              window.__meEnterPressed = true;
            }
            window.__meLastKey = 'Enter';
            form.__meClickAt = Date.now();
            setTimeout(function(){
              var lastSubmit = form.__meSubmitAt || 0;
              var lastClick = form.__meClickAt || 0;
              if (lastSubmit < lastClick) {
                forceSubmit();
              }
            }, 50);
            if ({$debugFlag}) setTimeout(updateDebug, 10);
          }
        }, true);
      }

      document.addEventListener('click', function(e){
        if (!btn || !btn.getBoundingClientRect) return;
        var rect = btn.getBoundingClientRect();
        if (!rect || rect.width <= 0 || rect.height <= 0) return;
        var inside = (e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom);
        if (typeof window.__meClickInBtn !== 'undefined') {
          window.__meClickInBtn = inside;
        }
        if (typeof window.__meClickTarget !== 'undefined') {
          var t = e.target;
          if (t && t.tagName) {
            var id = t.id ? ('#' + t.id) : '';
            var cls = t.className && typeof t.className === 'string' ? ('.' + t.className.trim().replace(/\\s+/g, '.')) : '';
            window.__meClickTarget = t.tagName.toLowerCase() + id + cls;
          } else {
            window.__meClickTarget = 'unknown';
          }
        }
        if (inside && typeof window.__meBtnClickAt !== 'undefined') {
          window.__meBtnClickAt = Date.now();
          if (btn && btn.style) {
            var prev = btn.style.outline;
            btn.style.outline = '3px solid #2b8a3e';
            btn.style.outlineOffset = '2px';
            setTimeout(function(){
              btn.style.outline = prev || '';
              btn.style.outlineOffset = '';
            }, 800);
          }
          if ({$debugFlag}) {
            var toast = document.getElementById('me-click-toast');
            if (!toast) {
              toast = document.createElement('div');
              toast.id = 'me-click-toast';
              toast.setAttribute('style',
                'position:fixed;bottom:54px;right:12px;z-index:99999;' +
                'padding:6px 8px;border-radius:6px;font:12px/1.2 -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;' +
                'color:#fff;background:rgba(16,124,65,0.9);box-shadow:0 2px 6px rgba(0,0,0,0.2);'
              );
              document.body.appendChild(toast);
            }
            toast.textContent = 'CLICK BOUTON RECHERCHER';
            toast.style.display = 'block';
            setTimeout(function(){ toast.style.display = 'none'; }, 900);
          }
        }
        if (!inside) return;
        form.__meClickAt = Date.now();
        setTimeout(function(){
          var lastSubmit = form.__meSubmitAt || 0;
          var lastClick = form.__meClickAt || 0;
          if (lastSubmit < lastClick) {
            forceSubmit();
          }
        }, 50);
        if ({$debugFlag}) setTimeout(updateDebug, 10);
      }, true);
    };

    installSubmitFallback();

    updateDebug();
  } catch (e) {}
})();
JS;

            if (strpos($body, '</body>') !== false) {
                $body = str_replace('</body>', '<script>' . $script . '</script></body>', $body);
            } else {
                $body .= '<script>' . $script . '</script>';
            }
            $app->setBody($body);
        } catch (\Throwable $e) {
            // debug silencieux
        }
    }

    /**
     * Gère l'importation des conditions pour Advanced Module Manager et Regular Labs Conditions.
     */
    protected function importFullConditions($newId, $item, $debug, $debugFile, $params, $fallbackParams = [])
    {
        $db = Factory::getDbo();
        $isConditionsInstalled = \Joomla\CMS\Component\ComponentHelper::isEnabled('com_conditions');

        $moduleTitle = $item['moduleData']['title'];
        $rlDataFromFile = $item['rlConditions'] ?? null;

        $handleRlConditionsParam = $params->get('handle_rl_conditions', 1);

        $hasRlData = ($handleRlConditionsParam && $isConditionsInstalled && !empty($rlDataFromFile['group']));

        if ($debug) {
            file_put_contents($debugFile, "\n[CONDITIONS] ═══ Début traitement pour '{$moduleTitle}' (ID: {$newId}) ═══\n", FILE_APPEND);
            $query = $db->getQuery(true)->select($db->quoteName('params'))->from($db->quoteName('#__modules'))->where($db->quoteName('id') . ' = ' . (int) $newId);
            $p = $db->setQuery($query)->loadResult();
            file_put_contents($debugFile, "[CONDITIONS] [PRE-CHECK] Params en base avant traitement RL: " . $p . "\n", FILE_APPEND);
        }

        if ($hasRlData) {
            $db->transactionStart();
            try {
                $db->setQuery('DELETE FROM ' . $db->quoteName('#__modules_menu') . ' WHERE ' . $db->quoteName('moduleid') . ' = ' . (int) $newId);
                $db->execute();

                $conditionGroup = (object) $rlDataFromFile['group'];
                $conditionGroup->id = 0;
                $conditionGroup->name = 'For Module: ' . $moduleTitle;
                $conditionGroup->alias = '';
                $conditionGroup->checked_out = null;
                $conditionGroup->checked_out_time = null;
                if (!isset($conditionGroup->published)) {
                    $conditionGroup->published = 1;
                }

                $newGroupId = $this->findOrCreateConditionGroup($db, $conditionGroup->name, $conditionGroup, $debug, $debugFile);

                if (!empty($rlDataFromFile['rules']) && is_array($rlDataFromFile['rules'])) {
                    foreach ($rlDataFromFile['rules'] as $rule) {
                        $ruleObject = (object) $rule;
                        $ruleObject->id = 0;
                        $ruleObject->group_id = $newGroupId;

                        // NOTE : Le mappage des IDs à l'intérieur de la règle ('value') 
                        // sera fait globalement à la fin de l'import pour garantir que tous les nouveaux IDs sont connus.
                        $db->insertObject('#__conditions_rules', $ruleObject, 'id');
                    }
                }

                $query = $db->getQuery(true)->select($db->quoteName('params'))->from($db->quoteName('#__modules'))->where($db->quoteName('id') . ' = ' . (int) $newId);
                $currentParamsJson = $db->setQuery($query)->loadResult();
                $currentParams = json_decode($currentParamsJson, true) ?: [];
                $currentParams = array_merge($currentParams, $fallbackParams);
                $currentParams['conditions_assignment_id'] = (string) $newGroupId;

                $newParamsJson = json_encode($currentParams);
                $query = $db->getQuery(true)->update($db->quoteName('#__modules'))->set($db->quoteName('params') . ' = ' . $db->quote($newParamsJson))->where($db->quoteName('id') . ' = ' . (int) $newId);
                $db->setQuery($query)->execute();

                $db->transactionCommit();
            } catch (\Throwable $e) {
                $db->transactionRollback();
            }
        }

        try {
            // Nettoyage du cache modules sans utiliser Application::getCache (absent en J4/J5)
            $cache = Factory::getCache('com_modules');
            if ($cache) {
                $cache->clean();
            }
        } catch (\Exception $e) {
            // Erreur silencieuse lors du nettoyage du cache
        }
    }

    protected function findOrCreateConditionGroup($db, $name, $groupData, $debug, $debugFile)
    {
        $query = $db->getQuery(true)
            ->select($db->quoteName('id'))
            ->from($db->quoteName('#__conditions'))
            ->where($db->quoteName('name') . ' = ' . $db->quote($name));
        $existingGroupId = $db->setQuery($query)->loadResult();

        if ($existingGroupId) {
            $deleteQuery = $db->getQuery(true)
                ->delete($db->quoteName('#__conditions_rules'))
                ->where($db->quoteName('group_id') . ' = ' . (int) $existingGroupId);
            $db->setQuery($deleteQuery)->execute();
            return (int) $existingGroupId;
        }

        $db->insertObject('#__conditions', $groupData, 'id');
        return (int) $groupData->id;
    }
}
