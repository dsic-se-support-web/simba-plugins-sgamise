/**
 * ModuleExport - JavaScript principal
 * @package     Joomla.Plugin
 * @subpackage  System.ModuleExport
 *
 * Ce fichier contient toute la logique JavaScript pour les fonctionnalités
 * d'export et d'import de modules Joomla.
 *
 * Les variables de configuration suivantes sont injectées par PHP:
 * - DEBUG: Mode debug activé/désactivé
 * - VERSION: Version du plugin
 * - CONDITIONS_INSTALLED: Composant com_conditions installé
 * - HANDLE_RL_CONDITIONS: Gestion des conditions RegularLabs
 * - AUTODETECT_MODULE_ID: ID du module de détection automatique
 * - AUTODETECT_KEYWORDS: Mots-clés pour la détection automatique
 * - USER_CSS_PATH: Chemin du fichier user.css
 * - ALL_TEMPLATES: Liste de tous les thèmes disponibles
 */

/**
 * Analyse une chaîne de caractères pour en extraire un objet JSON.
 * @param {string} fileContent - Le contenu textuel du fichier.
 * @returns {object} L'objet JSON parsé.
 */
(function () {
    'use strict';
    const DEBUG_BASE = (__DEBUG_VALUE__ === true || __DEBUG_VALUE__ === 'true');
    // Étape 3 : chargement automatique du template par défaut (DSFR ou autre) si présent.
    // Remettre à true pour réactiver l'auto-détection du JSON fourni avec le plugin.
    const AUTO_LOAD_DEFAULT = true;
    const DEBUG_FORCED = new URLSearchParams(window.location.search).get('debug') === '1'
        || localStorage.getItem('me_debug') === '1';
    const DEBUG = DEBUG_BASE || DEBUG_FORCED;
    const VERSION = __VERSION_VALUE__;
    const JOOMLA_VERSION = __JOOMLA_VERSION__;
    const CONDITIONS_INSTALLED = __CONDITIONS_INSTALLED__;
    const HANDLE_RL_CONDITIONS = __HANDLE_RL_CONDITIONS__;
    const SHOW_THEME_DROPZONE = __SHOW_THEME_DROPZONE__;
    const AUTODETECT_MODULE_ID = __AUTODETECT_MODULE_ID__;
    const AUTODETECT_KEYWORDS = __AUTODETECT_KEYWORDS__;
    const USER_CSS_PATH = __USER_CSS_PATH__;
    const ALL_TEMPLATES = __ALL_TEMPLATES__;
    const log = (...msg) => DEBUG && console.log('%c[ModuleExport]', 'color:#4fc3f7; font-weight:bold;', ...msg);

    const pageOption = new URLSearchParams(window.location.search).get('option') || 'com_modules';
    log(`v${VERSION} - Script LOADED (Option: ${pageOption}, Debug: ${DEBUG_BASE})`);

    function injectVersionBadge() {
        if (!DEBUG) return;
        if (document.getElementById('me-js-badge')) return;
        const badge = document.createElement('div');
        badge.id = 'me-js-badge';
        badge.textContent = `ME JS v${VERSION}`;
        document.body.appendChild(badge);
    }


    function showInfoPanel(title, items, { reset = false, section = null, replace = true } = {}) {
        if (!DEBUG) return;
        let panel = document.getElementById('me-info-panel');
        if (!panel) {
            panel = document.createElement('div');
            panel.id = 'me-info-panel';
            const close = document.createElement('span');
            close.className = 'me-close';
            close.textContent = '×';
            close.addEventListener('click', () => panel.remove());
            panel.appendChild(close);
            document.body.appendChild(panel);
        }
        if (reset) {
            const close = panel.querySelector('.me-close');
            panel.innerHTML = '';
            if (close) panel.appendChild(close);
        }
        if (section && replace) {
            const existing = panel.querySelector(`[data-section="${section}"]`);
            if (existing) existing.remove();
        }
        const content = document.createElement('div');
        if (section) content.dataset.section = section;
        content.innerHTML = `<div style="font-weight:600;margin-bottom:6px;">${section ? escapeHtml(section) + ' • ' : ''}${escapeHtml(title)}</div>`;
        const list = document.createElement('ul');
        items.forEach(it => {
            const li = document.createElement('li');
            li.textContent = it;
            list.appendChild(li);
        });
        content.appendChild(list);
        panel.appendChild(content);
        panel.scrollTop = panel.scrollHeight;
    }
    // Fonction pour récupérer la valeur depuis localStorage
    function getLocalStorage(key, defaultValue) {
        const storedValue = localStorage.getItem(key);
        return storedValue === null ? defaultValue : storedValue === 'true'; // Convertit en booléen si c'est 'true' ou 'false'
    }

    // Récupération robuste du nom de jeton CSRF (Joomla 4/5)
    const getCsrfTokenName = () => {
        return Joomla?.getOptions?.('csrf.token')
            || Joomla?.getOptions?.('csrf-token')
            || document.querySelector('meta[name=\"csrf-token\"]')?.getAttribute('content')
            || document.querySelector('input[type=\"hidden\"][name][value]')?.getAttribute('name')
            || null;
    };

    const getCsrfParam = () => {
        const name = getCsrfTokenName();
        return name ? `&${encodeURIComponent(name)}=1` : '';
    };
    const appendCsrfToken = (formData) => {
        const token = getCsrfTokenName();
        if (token) formData.append(token, '1');
    };
    if (DEBUG) {
        console.log(`%c[ModuleExport] v${VERSION} LOADED`, 'background: #2563eb; color: #fff; font-size: 18px; font-weight: bold; padding: 10px; border-radius: 5px;');
        console.log('%c[ModuleExport] Correctif TypeError & Restauration UI cliquée', 'color:#4fc3f7;');
        // Alerte visuelle pour confirmer que cette version est bien chargée
        console.log('DEBUG: ' + new Date().toLocaleTimeString());
    }
    // Vérification déplacée dans addExportImportButtons



    function setImportButtonHidden(hidden) {
        const buttons = document.querySelectorAll('#btn-import-module');
        buttons.forEach(btn => {
            if (hidden) {
                btn.classList.add('d-none');
                btn.style.setProperty('display', 'none', 'important');
                btn.setAttribute('aria-hidden', 'true');
            } else {
                btn.classList.remove('d-none');
                btn.style.removeProperty('display');
                btn.removeAttribute('aria-hidden');
            }
        });
    }

    const setImportConfirmHidden = (hidden) => {
        const btn = document.querySelector('#confirm-import');
        if (!btn) return;
        btn.classList.toggle('d-none', hidden);
    };

    // --- TEMPLATES HTML (EXTRAITS) ---
    function getModalBaseHtml(version) {
        return `
            <div class="modal-dialog modal-dialog-centered modal-md">
                <div class="modal-content">
                    <div class="modal-header border-0 pb-0">
                        <h5 class="modal-title visually-hidden">Import JSON file</h5>
                        <button type="button" class="btn-close" data-action="close" aria-label="Close"></button>
                    </div>
                    <div class="modal-body px-4 pt-0">
                        <div class="text-center mb-4">
                            <h4 class="mb-0 fw-bold text-body">Assistant de migration</h4>
                            <p class="text-muted small mb-3">Plugin ModuleExport v${version}</p>
                        </div>
                        <div class="wizard-nav mb-4">
                            <div class="d-flex flex-column align-items-center cursor-pointer" onclick="document.dispatchEvent(new CustomEvent('nav-to-step', {detail: 1}))">
                                <div id="nav-step-1" class="nav-step active">1</div>
                                <div class="nav-step-label">Thème</div>
                            </div>
                            <div class="wizard-connector"></div>
                            <div class="d-flex flex-column align-items-center cursor-pointer" onclick="document.dispatchEvent(new CustomEvent('nav-to-step', {detail: 2}))">
                                <div id="nav-step-2" class="nav-step">2</div>
                                <div class="nav-step-label">Composants</div>
                            </div>
                            <div class="wizard-connector"></div>
                            <div class="d-flex flex-column align-items-center cursor-pointer" onclick="document.dispatchEvent(new CustomEvent('nav-to-step', {detail: 3}))">
                                <div id="nav-step-3" class="nav-step">3</div>
                                <div class="nav-step-label">Modules</div>
                            </div>
                            <div class="wizard-connector"></div>
                            <div class="d-flex flex-column align-items-center cursor-pointer" onclick="document.dispatchEvent(new CustomEvent('nav-to-step', {detail: 4}))">
                                <div id="nav-step-4" class="nav-step">4</div>
                                <div class="nav-step-label">Éditeur</div>
                            </div>
                        </div>

                        ${getStep1Html()}
                        ${getStep2Html()}
                        ${getStep3Html()}
                        ${getStep4Html()}

                    </div>
                    <div class="modal-footer border-top-0 pt-3 mt-3 px-4 pb-4">
                        <div class="d-flex justify-content-center w-100 gap-3">
                            <button id="export-inventory-btn" class="btn btn-premium btn-premium-action d-none">
                                Exporter
                            </button>
                            <button data-action="close" id="cancel-import" class="btn btn-premium btn-premium-secondary">Annuler</button>
                            <button data-action="confirm" id="confirm-import" class="btn btn-premium btn-premium-primary" disabled>
                                <span class="icon-download me-2"></span> Importer
                            </button>
                        </div>
                        <div class="text-center mt-2" style="font-size: 0.6em; color: #ccc; opacity: 0.5;">v${version} - JS ACTIF</div>
                    </div>
                </div>
            </div>
        `;
    }

    function getStep1Html() {
        return `
            <div id="step-1-content" class="wizard-step active">
                <div class="small text-muted mb-2">Configuration & Thème</div>
                <div id="all-templates-grid" class="status-card-grid mt-3"></div>
                <div class="validation-checklist" id="validation-checklist">
                    <div class="validation-checklist-title">Vérification de configuration</div>
                    <div class="validation-item" id="check-theme-parent"><div class="validation-icon pending"><span class="icon-clock"></span></div><div class="validation-text">Thème parent</div></div>
                    <div class="validation-item" id="check-theme-child"><div class="validation-icon pending"><span class="icon-clock"></span></div><div class="validation-text">Thème enfant DSFR</div></div>
                    <div class="validation-item" id="check-media-usercss"><div class="validation-icon pending"><span class="icon-clock"></span></div><div class="validation-text">Fichier user.css</div></div>
                    <div class="validation-item" id="check-menu-twitter"><div class="validation-icon pending"><span class="icon-clock"></span></div><div class="validation-text">Lien Twitter</div></div>
                    <div class="validation-item" id="check-menu-mapping"><div class="validation-icon pending"><span class="icon-clock"></span></div><div class="validation-text">Mapping SIMBA</div><div class="validation-actions d-none"><span id="menu-mapping-badge" class="badge bg-secondary" style="font-size:0.65rem;">...</span></div></div>
                    <div id="menu-mapping-status" class="validation-sub-status small text-muted d-none"></div>
                    <div class="validation-item" id="check-modules-trash"><div class="validation-icon pending"><span class="icon-clock"></span></div><div class="validation-text">Corbeille modules</div></div>
                </div>
                <p id="zip-method-info" class="mb-2" style="font-size:0.65rem;opacity:0.5;text-align:center;">Format&nbsp;: <code>.zip</code><span id="zip-method-separator"> — </span><span id="zip-method-label" style="font-style:italic;">détection...</span></p>
                <div id="drop-zone-theme" class="text-center p-4 mb-3 border-dashed rounded-3">
                    <div class="icon-upload-container mb-2"><span class="icon-archive fs-2"></span></div>
                    <h6 class="fw-bold text-body mb-1">Archive du Thème</h6>
                    <p class="text-muted extra-small mb-0">Déposez votre archive ici</p>
                    <input type="file" id="import-theme-zip" accept=".zip" class="d-none">
                </div>
                <div id="theme-deploy-status" class="mt-2"></div>
            </div>
        `;
    }

    function getStep2Html() {
        return `
            <div id="step-2-content" class="wizard-step">
                <div id="inventory-main-view">
                    <div class="mb-3 text-center"><h6 class="fw-bold mb-0" id="inventory-title" style="font-size:0.85rem">Composants</h6></div>
                    <div id="module-inventory-container" class="module-inventory-list mb-3 bg-light bg-opacity-50 d-none" style="max-height: 160px; overflow-y: auto;">
                        <div class="text-center p-4 text-muted small"><span class="spinner-border spinner-border-sm me-2"></span>Chargement...</div>
                    </div>
                    <div id="articles-inventory-container" class="module-inventory-list mb-3 bg-light bg-opacity-50 d-none" style="max-height: 160px; overflow-y: auto;"></div>
                </div>
                <div class="stats-grid">
                    <div class="stat-mini-card"><div class="stat-mini-label">Module de menu</div><div id="stat-modules-total" class="stat-mini-value">--</div></div>
                    <div class="stat-mini-card"><div class="stat-mini-label">Articles</div><div id="stat-articles-total" class="stat-mini-value">--</div></div>
                    <div class="stat-mini-card"><div class="stat-mini-label">Corbeille</div><div id="stat-articles-trash" class="stat-mini-value">--</div></div>
                    <div class="stat-mini-card"><div class="stat-mini-label">Test</div><div id="stat-articles-test" class="stat-mini-value">--</div></div>
                    <div class="stat-mini-card"><div class="stat-mini-label">Tableaux</div><div id="stat-articles-table" class="stat-mini-value">--</div></div>
                    <div class="stat-mini-card"><div class="stat-mini-label">Cartes</div><div id="stat-frcard-total" class="stat-mini-value">--</div></div>
                    <div class="stat-mini-card"><div class="stat-mini-label">Tuiles</div><div id="stat-frtile-total" class="stat-mini-value">--</div></div>
                    <div class="stat-mini-card"><div class="stat-mini-label">Alertes</div><div id="stat-alert-total" class="stat-mini-value">--</div></div>
                </div>
            </div>
        `;
    }

    function getStep3Html() {
        return `
            <div id="step-3-content" class="wizard-step">
                <div id="drop-zone-container">
                    <h6 class="fw-bold mb-3">Fichiers JSON</h6>
                    <div class="file-drop-zone mb-4 p-4 border rounded-3 text-center" style="background: rgba(0,0,0,0.02);">
                        <span class="icon-upload fs-2 d-block mb-2 text-muted"></span>
                        <input type="file" id="import-file" accept=".json" multiple class="d-none">
                        <button type="button" id="browse-files-btn" class="btn btn-primary">Parcourir</button>
                    </div>
                </div>
                <div id="file-preview-list" class="d-none"></div>
                <div id="system-tools-panel" class="system-tools-panel d-none">
                    <div class="tool-row"><div class="tool-info"><div class="tool-title">Choisir les modules</div></div><div class="form-check form-switch p-0"><input class="form-check-input ms-0" type="checkbox" id="toggle-module-selector"></div></div>
                    <div id="module-selector-section" class="d-none mt-2 p-3 border rounded-3 bg-light" style="max-height: 250px; overflow-y: auto;"><div id="module-checkbox-list"></div></div>
                    <div class="tool-row" id="toggle-id-editor-container"><div class="tool-info"><div class="tool-title">Édition des IDs</div></div><div class="form-check form-switch p-0"><input class="form-check-input ms-0" type="checkbox" id="toggle-id-editor"></div></div>
                    <div id="id-editor-section" class="d-none mt-2 p-3 border rounded-3 bg-light"><div id="id-editor-stats" class="small text-muted mb-2"></div><div id="id-editor-list"></div><div id="id-renumber-hint" class="small text-muted mt-2"></div><div id="id-renumber-status" class="small text-success mt-1 d-none"></div></div>
                    <div class="tool-row" id="toggle-user-css-container">
                        <div class="tool-info"><div class="tool-title">user.css <span id="template-inactive-badge" class="badge bg-secondary ms-1" style="font-size: 0.65rem;">Inactif</span></div><div id="user-css-path-display" class="extra-small text-muted"></div></div>
                        <div class="d-flex align-items-center gap-3"><span id="user-css-status-text" class="small fw-bold text-uppercase" style="font-size: 0.65rem;">...</span><div class="form-check form-switch p-0"><input class="form-check-input ms-0" type="checkbox" id="user-css-switch"></div></div>
                    </div>
                    <div id="find-replace-container" class="d-none">
                        <div class="tool-row"><div class="tool-info"><div class="tool-title">Rechercher / Remplacer</div></div><div class="form-check form-switch p-0"><input class="form-check-input ms-0" type="checkbox" id="toggle-replace-section"></div></div>
                        <div id="find-replace-section" class="d-none mt-2 p-3 border rounded-3 bg-light">
                            <div id="quick-replace-fields" class="mb-3"></div>
                            <div class="mb-3"><label for="main-title-replace-value" class="form-label small fw-bold text-muted">Titre principal</label><input type="text" id="main-title-replace-value" class="form-control" placeholder="Nouveau titre..." data-find-text=""></div>
                            <div class="mb-3"><label for="main-baseline-replace-value" class="form-label small fw-bold text-muted">Baseline</label><input type="text" id="main-baseline-replace-value" class="form-control" placeholder="Nouvelle baseline..." data-find-text=""></div>
                            <div class="mb-3"><label for="prefet-title-replace-value" class="form-label small fw-bold text-muted">Autorit\u00e9</label><input type="text" id="prefet-title-replace-value" class="form-control" placeholder="Nouvelle autorit\u00e9..." data-find-text=""></div>
                        </div>
                    </div>
                    <div id="clear-joomla-cache-container" class="d-none"></div>
                </div>
                <div id="import-progress" class="mt-4 d-none"><div class="progress" style="height: 10px;"><div id="import-progress-bar" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"></div></div><div id="progress-text" class="text-center small mt-2 fw-bold"></div></div>
                <div id="import-status"></div>
            </div>
        `;
    }

    function getStep4Html() {
        return `
            <div id="step-4-content" class="wizard-step">
                <div id="tinymce-config-container" class="p-3 border rounded-3 bg-light bg-opacity-50">
                    <div class="text-center p-4"><span class="spinner-border spinner-border-sm text-primary"></span><p class="mt-2 mb-0 small">Chargement...</p></div>
                </div>
            </div>
        `;
    }

    const observeImportButton = (() => {
        let observer = null;

        // Nettoyage automatique au déchargement
        window.addEventListener('unload', () => {
            if (observer) {
                observer.disconnect();
                observer = null;
            }
        });

        return () => {
            if (observer) return;
            observer = new MutationObserver(() => {
                const shouldHide = document.body.getAttribute('data-me-child-theme') === 'present';
                if (shouldHide) setImportButtonHidden(true);
            });
            observer.observe(document.body, { childList: true, subtree: true });
        };
    })();

    // ==========================================
    // UTILITAIRES STEP 3 (EXTRAITS)
    // ==========================================
    const step3Log = (...args) => DEBUG && console.log('[STEP3]', ...args);
    const step3Warn = (...args) => DEBUG && console.warn('[STEP3]', ...args);
    const step3Error = (...args) => DEBUG && console.error('[STEP3]', ...args);

    const getModuleObject = (item) => (item && item.module && typeof item.module === 'object') ? item.module : item;

    const getModuleTitle = (item) => {
        const mod = getModuleObject(item);
        return mod?.title || item?.title || mod?.module || item?.module || 'Sans titre';
    };

    const normalizeIdValue = (value) => {
        const raw = (value === undefined || value === null) ? '' : String(value).trim();
        return { raw, numericStr: /^\d+$/.test(raw) ? raw : null };
    };

    const escapeHtml = (value) => {
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    };

    const formatFileSize = (bytes) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    const parseJsonFromFileContent = (fileContent) => {
        if (!fileContent) throw new Error('Contenu du fichier vide.');
        const trimmedContent = fileContent.trim();
        const jsonStart = trimmedContent.search(/[[{]/);
        if (jsonStart < 0) throw new Error('JSON introuvable (aucun "{" ou "[" détecté).');
        try {
            return JSON.parse(trimmedContent.substring(jsonStart));
        } catch (e) {
            throw new Error(`JSON.parse: ${e.message}`);
        }
    };

    const LOADMODULEID_REGEX = /\{loadmoduleid(?:\s|&nbsp;|&#160;|\u00A0)+(\d+)\}/gi;

    const extractLoadModuleIdsFromText = (text) => {
        if (!text || typeof text !== 'string') return [];
        const ids = [];
        const re = new RegExp(LOADMODULEID_REGEX.source, 'giu');
        let m;
        while ((m = re.exec(text))) {
            if (m[1]) ids.push(String(parseInt(m[1], 10)));
        }
        return ids;
    };

    const extractLoadModuleIdsFromModule = (item) => {
        const mod = getModuleObject(item);
        const ids = new Set();
        if (mod && typeof mod.content === 'string') {
            extractLoadModuleIdsFromText(mod.content).forEach(id => ids.add(id));
        }
        if (mod && mod.params) {
            const paramsStr = (typeof mod.params === 'string') ? mod.params : JSON.stringify(mod.params);
            try { extractLoadModuleIdsFromText(paramsStr).forEach(id => ids.add(id)); } catch (e) { }
        }
        return Array.from(ids);
    };

    const replaceLoadModuleIdsInText = (text, mapping) => {
        if (!text || typeof text !== 'string' || !mapping) return text;
        return text.replace(LOADMODULEID_REGEX, (match, id) => {
            const mapped = mapping[id];
            return mapped ? `{loadmoduleid ${mapped}}` : match;
        });
    };

    const replaceLoadModuleIdsInParams = (params, mapping) => {
        if (!params || typeof params !== 'object' || !mapping) return params;
        Object.keys(params).forEach(k => {
            if (typeof params[k] === 'string') {
                params[k] = replaceLoadModuleIdsInText(params[k], mapping);
            } else if (typeof params[k] === 'object' && params[k] !== null) {
                replaceLoadModuleIdsInParams(params[k], mapping);
            }
        });
        return params;
    };

    const replaceLoadModuleIdsInItem = (item, mapping) => {
        const mod = getModuleObject(item);
        if (mod && typeof mod.content === 'string') {
            mod.content = replaceLoadModuleIdsInText(mod.content, mapping);
        }
        if (mod && mod.params) {
            if (typeof mod.params === 'string') {
                mod.params = replaceLoadModuleIdsInText(mod.params, mapping);
            } else if (typeof mod.params === 'object') {
                replaceLoadModuleIdsInParams(mod.params, mapping);
            }
        }
    };

    const getHtmlStats = (modules) => {
        let total = 0, withHtml = 0;
        (modules || []).forEach(item => {
            const mod = getModuleObject(item);
            total++;
            if (/<[^>]+>/.test(mod && typeof mod.content === 'string' ? mod.content : '')) withHtml++;
        });
        return { total, withHtml };
    };

    const getHtmlDetails = (modules) => {
        return (modules || []).map(item => {
            const mod = getModuleObject(item);
            const content = mod && typeof mod.content === 'string' ? mod.content : '';
            return {
                title: getModuleTitle(item),
                moduleType: mod?.module || item?.module || 'unknown',
                hasHtml: /<[^>]+>/.test(content),
                len: content.length
            };
        });
    };

    const getModuleParamsObject = (mod) => {
        if (!mod || !mod.params) return null;
        if (typeof mod.params === 'object') return mod.params;
        try {
            const trimmed = mod.params.trim();
            return (trimmed && trimmed.startsWith('{')) ? JSON.parse(trimmed) : null;
        } catch (e) { return null; }
    };

    const escapeRegExp = (string) => {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    };

    const hasClassToken = (value, token) => {
        if (!value || !token) return false;
        // CORRECTION: Échapper le token pour éviter l'injection de regex
        return (new RegExp(`(^|\\s)${escapeRegExp(token)}(\\s|$)`)).test(String(value));
    };

    const getModuleClassSfx = (mod) => {
        const params = getModuleParamsObject(mod);
        return params ? (params.moduleclass_sfx || params.class_sfx || '') : '';
    };

    const isFooterContentModule = (item) => {
        const mod = getModuleObject(item);
        if (!mod || typeof mod !== 'object') return false;
        const classSfx = getModuleClassSfx(mod);
        return hasClassToken(classSfx, 'fr-footer__content') && !hasClassToken(classSfx, 'fr-footer__content-list');
    };

    const MENU_ADJUSTMENT_HTML = [
        '<p class="fr-footer__content-desc">Ce site est g\u00e9r\u00e9 par le Service d\'Information du Gouvernement (SIG)</p>',
        '<ul class="fr-footer__content-list">',
        '  <li class="fr-footer__content-item"><a title="info.gouv.fr - Nouvelle fen\u00eatre" id="footer__link--info" href="https://www.info.gouv.fr" target="_blank" rel="noopener external" class="fr-footer__content-link">info.gouv.fr</a></li>',
        '  <li class="fr-footer__content-item"><a title="service-public.gouv.fr - Nouvelle fen\u00eatre" id="footer__link--service-public" href="https://www.service-public.gouv.fr" target="_blank" rel="noopener external" class="fr-footer__content-link">service-public.gouv.fr</a></li>',
        '  <li class="fr-footer__content-item"><a title="legifrance.gouv.fr - Nouvelle fen\u00eatre" id="footer__link--legifrance" href="https://www.legifrance.gouv.fr" target="_blank" rel="noopener external" class="fr-footer__content-link">legifrance.gouv.fr</a></li>',
        '  <li class="fr-footer__content-item"><a title="data.gouv.fr - Nouvelle fen\u00eatre" id="footer__link--data" href="https://www.data.gouv.fr" target="_blank" rel="noopener external" class="fr-footer__content-link">data.gouv.fr</a></li>',
        '</ul>'
    ].join('\n');

    const getModuleOriginalId = (item) => {
        const mod = getModuleObject(item);
        return item?.moduleId ?? mod?.id ?? item?.id ?? null;
    };

    const getModuleLegacyId = (item) => {
        const mod = getModuleObject(item);
        return item?.legacy_id ?? mod?.legacy_id ?? item?.original_id ?? mod?.original_id ?? null;
    };

    const setModuleOriginalId = (item, newId) => {
        if (!item || typeof item !== 'object') return;
        const mod = getModuleObject(item);
        if (Object.prototype.hasOwnProperty.call(item, 'moduleId')) item.moduleId = newId;
        if (Object.prototype.hasOwnProperty.call(item, 'id')) item.id = newId;
        if (mod && Object.prototype.hasOwnProperty.call(mod, 'id')) mod.id = newId;
    };

    const setModuleLegacyId = (item, legacyId) => {
        if (!item || typeof item !== 'object') return;
        const mod = getModuleObject(item);
        item.legacy_id = legacyId;
        if (mod && typeof mod === 'object') mod.legacy_id = legacyId;
    };

    // ==========================
    // UTILITAIRES (fusion utils.js)
    // ==========================
    function createAjaxRequest(taskName, params = {}, headers = {}) {
        const formData = new FormData();
        formData.append('option', params.option || pageOption);
        formData.append('task', taskName);
        formData.append('format', params.format || 'json');

        Object.entries(params).forEach(([key, value]) => {
            if (key !== 'option' && key !== 'format' && value !== undefined) {
                formData.append(key, value);
            }
        });

        const tokenName = getCsrfTokenName();
        let url = 'index.php';
        if (tokenName) {
            formData.append(tokenName, '1');
            url += (url.includes('?') ? '&' : '?') + encodeURIComponent(tokenName) + '=1';
        } else if (DEBUG) {
            console.warn('[ModuleExport][HTTP] CSRF token introuvable, requête sans jeton');
        }

        const newHeaders = new Headers(headers);
        if (tokenName) {
            newHeaders.set('X-CSRF-Token', tokenName);
        }

        return fetch(url, {
            method: 'POST',
            body: formData,
            headers: newHeaders
        });
    }

    function handleJsonResponse(response, errorMessage = 'Réponse serveur inattendue') {
        const contentType = response.headers.get('content-type');
        // CORRECTION : Tenter de parser le JSON même si !response.ok pour récupérer les détails d'erreur
        const isJson = contentType && contentType.includes('application/json');

        if (isJson) {
            return response.json().then(data => {
                if (!response.ok) {
                    const msg = data.message || data.error || errorMessage;
                    throw new Error(msg);
                }
                return data;
            });
        }

        if (response.ok) {
            // Cas rare : OK mais pas JSON ? On tente quand même .json() si ça ressemble, sinon texte
            // Pour l'instant on garde le comportement strict
            return response.text().then(text => {
                try {
                    return JSON.parse(text);
                } catch (e) {
                    throw new Error(errorMessage + ": Réponse invalide (pas de JSON)");
                }
            });
        }

        if (DEBUG) {
            console.warn('[ModuleExport][HTTP] Réponse non-JSON ou erreur HTTP', {
                status: response.status,
                statusText: response.statusText,
                contentType: contentType
            });
        }
        return response.text().then(text => {
            if (DEBUG) {
                console.warn('[ModuleExport][HTTP] Contenu brut (début):', text.substring(0, 500));
            }
            throw new Error(`${errorMessage}: ${text.substring(0, 200)}...`);
        });
    }

    function postJson(taskName, params = {}, headers = {}, errorMessage) {
        return createAjaxRequest(taskName, params, headers).then(response => handleJsonResponse(response, errorMessage));
    }


    /**
     * Déclenche le téléchargement d'un Blob côté client.
     * @param {Blob} blob - Le contenu du fichier à télécharger.
     * @param {string} filename - Le nom du fichier de destination.
     */
    function downloadBlob(blob, filename) {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    function addExportImportButtons(retryCount = 0) {
        if (DEBUG) console.log('[ModuleExport] addExportImportButtons() attempt:', retryCount);

        if (document.querySelector('#btn-export-module')) {
            if (DEBUG) console.log('[ModuleExport] Boutons déjà présents, arrêt.');
            return;
        }

        const selectors = [
            'joomla-toolbar',
            '#toolbar',
            '.joomla-toolbar-container',
            '.toolbar',
            '.toolbar-list',
            '#toolbar-box',
            '#toolbar-advancedmodules', // Spécifique Advanced Module Manager peut-être
            '.subhead',
            '#toolbar-container',
            '.main-toolbar',
            '.btn-toolbar'
        ];
        let toolbar = null;

        for (const selector of selectors) {
            toolbar = document.querySelector(selector);
            if (toolbar) {
                if (DEBUG) console.log('[ModuleExport] Toolbar trouvée:', selector);
                break;
            }
        }

        if (!toolbar) {
            if (retryCount < 5) {
                if (DEBUG) console.log('[ModuleExport] Toolbar non trouvée, nouvelle tentative dans 500ms...');
                setTimeout(() => addExportImportButtons(retryCount + 1), 500);
            } else {
                log('Impossible de localiser la toolbar Joomla après plusieurs tentatives.');
            }
            return;
        }

        // Si on a trouvé le container, il faut cibler la toolbar à l'intérieur
        if (toolbar.matches('.joomla-toolbar-container')) {
            const innerToolbar = toolbar.querySelector('joomla-toolbar, #toolbar');
            if (!innerToolbar) {
                console.warn('[ModuleExport] Conteneur de toolbar trouvé, mais la toolbar elle-même est introuvable à l\'intérieur. Abandon.');
                return;
            }
            toolbar = innerToolbar;
        }

        log('Ajout des boutons Export et Import avec Bootstrap 5');

        // Ajout des styles personnalisés
        // addCustomStyles removed

        // ============ BOUTON EXPORT ============
        const exportBtn = document.createElement('button');
        exportBtn.type = 'button';
        exportBtn.id = 'btn-export-module';
        exportBtn.className = 'btn btn-secondary';
        exportBtn.innerHTML = '<span class="icon-download me-2"></span>Exporter';
        exportBtn.title = 'Exporter le(s) module(s) sélectionné(s)';
        exportBtn.addEventListener('click', function (e) {
            e.preventDefault();
            const checkboxes = document.querySelectorAll('input[name="cid[]"]:checked');
            const moduleIds = [];
            checkboxes.forEach(cb => {
                if (cb.value && !isNaN(cb.value) && cb.value !== '') {
                    moduleIds.push(cb.value);
                }
            });
            if (moduleIds.length === 0) {
                alert('Veuillez sélectionner au moins un module à exporter.');
                return;
            }
            showExportConfirmDialog(moduleIds, pageOption);
        });
        // ============ BOUTON IMPORT ============
        const importBtn = document.createElement('button');
        importBtn.type = 'button';
        importBtn.id = 'btn-import-module';
        importBtn.className = 'btn btn-secondary';
        importBtn.innerHTML = '<span class="icon-upload me-2"></span>Importer';
        importBtn.title = 'Importer un ou plusieurs modules';
        importBtn.addEventListener('click', function (e) {
            e.preventDefault();
            log('Ouverture dialog import');
            showImportDialog();
        });

        // Logique d'insertion des boutons améliorée
        const buttonHolder = toolbar.querySelector('joomla-toolbar-buttons');
        const msAuto = toolbar.querySelector('.ms-auto');

        log('buttonHolder:', !!buttonHolder, 'msAuto:', !!msAuto);

        if (msAuto) {
            msAuto.parentNode.insertBefore(importBtn, msAuto);
            msAuto.parentNode.insertBefore(exportBtn, importBtn);
        } else if (buttonHolder) {
            buttonHolder.appendChild(exportBtn);
            buttonHolder.appendChild(importBtn);
        } else {
            toolbar.appendChild(exportBtn);
            toolbar.appendChild(importBtn);
        }
        setImportButtonHidden(document.body.getAttribute('data-me-child-theme') === 'present');
        observeImportButton();
        log('✓ Boutons ajoutés avec Bootstrap 5');
    }

    // ============ MODALE D'EXPORT ============
    function showExportConfirmDialog(moduleIds, option) {
        const modal = document.createElement('div');
        modal.id = 'export-confirm-modal';
        modal.className = 'modal fade show d-block';
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('role', 'dialog');
        modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
        modal.innerHTML = `
            <div class="modal-dialog modal-dialog-centered modal-md">
                <div class="modal-content rounded-3 shadow-lg border-0">
                    <div class="modal-header border-0 p-3 pb-0">
                        <h5 class="modal-title visually-hidden">Confirmation d'export</h5>
                        <button type="button" class="btn-close" data-action="close" aria-label="Close"></button>
                    </div>
                    <div class="modal-body px-4 pt-0">
                        <div class="text-center mb-4">
                            <h4 class="mb-0 fw-bold text-body">Exporter le(s) module(s)</h4>
                            <p class="text-muted small mb-3" id="export-modal-description">Plugin ModuleExport v${VERSION}</p>
                            <p class="text-muted small">Configurez vos options d'exportation pour ${moduleIds.length === 1 ? '1 module.' : moduleIds.length + ' modules.'}</p>
                        </div>
                        <!-- Options d'export -->
                        <div class="list-group list-group-flush border rounded-3 small mb-4">
                            <div class="list-group-item p-3">
                                <h6 class="mb-2 fw-bold text-body small text-uppercase">Format d'export</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="exportFormat" id="export-all-in-one" value="single" checked>
                                    <label class="form-check-label" for="export-all-in-one">Fichier unique (recommandé)</label>
                                    <small class="d-block text-muted">Tous les modules dans un seul fichier JSON.</small>
                                </div>
                                <div class="form-check mt-2">
                                    <input class="form-check-input" type="radio" name="exportFormat" id="export-multiple-files" value="multiple">
                                    <label class="form-check-label" for="export-multiple-files">Fichiers séparés</label>
                                    <small class="d-block text-muted">Un fichier JSON par module.</small>
                                </div>
                            </div>
                        </div>
                        <!-- Option pour désactiver les modules -->
                        <div class="list-group list-group-flush border rounded-3 small mb-4">
                            <div class="list-group-item p-3">
                                <h6 class="mb-2 fw-bold text-body small text-uppercase">Options supplémentaires</h6>
                                <div class="form-check form-switch p-0 d-flex justify-content-between align-items-center" onclick="this.querySelector('input[type=checkbox]').click();" style="cursor: pointer;">
                                    <label class="form-check-label flex-grow-1" for="export-disable-modules" style="pointer-events: none;">
                                        <span class="fw-bold text-body">Désactiver les modules avant l'export</span>
                                        <small class="d-block text-muted">Si activé, les modules exportés seront dépubliés sur ce site.</small>
                                    </label>
                                    <input class="form-check-input" type="checkbox" role="switch" id="export-disable-modules" style="width: 35px; height: 20px; pointer-events: none;" title="Activer/Désactiver l'option">
                                </div>
                            </div>
                        </div>

                        <!-- Liste des modules -->
                        <h6 class="mb-3 fw-bold text-body small text-uppercase">Modules inclus</h6>
                        <div id="module-list-export" class="mb-4" style="max-height: 250px; overflow-y: auto;">
                            <div class="list-group list-group-flush small"></div>
                        </div>
                    </div>
                    <div class="modal-footer border-top-0 p-4 pt-2 justify-content-center">
                        <button data-action="close" class="btn btn-outline-secondary me-3 px-4 rounded-3">Fermer</button>
                        <button data-action="confirm" class="btn btn-secondary px-4 rounded-3">Télécharger</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        let allModulesData = [];
        const modulesContainer = modal.querySelector('#module-list-export .list-group');
        const disableSwitch = modal.querySelector('#export-disable-modules');
        const formatSingle = modal.querySelector('#export-all-in-one');
        const formatMultiple = modal.querySelector('#export-multiple-files');

        // Charger les préférences depuis localStorage
        const storedFormat = localStorage.getItem('moduleExportFormat') || 'single';
        if (storedFormat === 'single') formatSingle.checked = true;
        else formatMultiple.checked = true;

        disableSwitch.checked = getLocalStorage('moduleExportDisable', false);

        if (moduleIds.length > 0) {
            // Afficher les placeholders de chargement
            moduleIds.forEach(moduleId => {
                const loadingItem = document.createElement('div');
                loadingItem.className = 'list-group-item d-flex justify-content-between align-items-center p-3 text-muted';
                loadingItem.dataset.loadingFor = moduleId;
                loadingItem.innerHTML = `Chargement du module #${moduleId}... <div class="spinner-border spinner-border-sm text-primary" role="status"><span class="visually-hidden">Chargement...</span></div>`;
                modulesContainer.appendChild(loadingItem);
            });

            const promises = moduleIds.map(moduleId => {
                return postJson(
                    'module.exportmodule',
                    { option, id: moduleId, disable_modules: '0' },
                    {},
                    `Réponse serveur inattendue pour le module #${moduleId}`
                )
                    .then(data => ({ success: true, moduleId, data }))
                    .catch(error => ({ success: false, moduleId, error }));
            });

            // Exécuter toutes les promesses en parallèle
            Promise.all(promises).then(results => {
                results.forEach(result => {
                    const { success, moduleId, data, error } = result;
                    const loadingItem = modulesContainer.querySelector(`[data-loading-for="${moduleId}"]`);

                    if (success && data.success && data.data) {
                        // Le contenu réel du module est une chaîne JSON dans data.data.content
                        // Il faut le parser pour obtenir l'objet complet.
                        // Sécurisation du parsing avec try/catch
                        let moduleFullData = {};
                        try {
                            moduleFullData = typeof data.data.content === 'string' ? JSON.parse(data.data.content) : data.data.content;
                        } catch (e) {
                            log('Erreur parsing JSON module #' + moduleId, e);
                            moduleFullData = { title: 'Erreur Data', module: 'error' };
                        }
                        log('Données complètes du module', moduleFullData);
                        const module = moduleFullData.module || {};

                        const status = module.published == 1 ? 'Publié' : 'Non publié';
                        const position = module.position || 'Aucune';
                        const type = module.module || 'N/A';
                        const statusClass = module.published == 1 ? 'badge-status-published' : 'badge-status-unpublished';
                        const title = module.title || 'Sans titre';
                        const clientId = module.client_id == 1 ? 'Admin' : 'Site';

                        allModulesData.push({ moduleId, moduleData: data.data });

                        const moduleItem = document.createElement('li');
                        moduleItem.className = 'list-group-item d-flex justify-content-between align-items-center p-3 module-export-list-item rounded-3';
                        moduleItem.dataset.moduleId = moduleId;
                        // Stocker l'état original pour la bascule visuelle
                        moduleItem.dataset.originalStatus = status;
                        moduleItem.innerHTML = `
                            <div class="flex-grow-1 me-3">
                                <div class="d-flex align-items-center">
                                    <span class="icon-cube text-muted me-2"></span>
                                    <div class="text-body text-truncate fw-bold">${escapeHtml(title)}</div>
                                </div>
                                <div class="small text-muted mt-1">
                                    <span class="badge ${statusClass} p-1 px-2 fw-bold">${escapeHtml(status)}</span>
                                    <span class="mx-2">|</span>
                                    <span><strong>ID:</strong> ${moduleId}</span><span class="mx-2">|</span>
                                    <span><strong>Type:</strong> ${escapeHtml(type)}</span>
                                    <span class="mx-2">|</span>
                                    <span><strong>Position:</strong> ${escapeHtml(position)}</span>
                                </div>
                            </div>
                            <div class="remove-file-btn" style="cursor: pointer;" title="Retirer ce module de l'export">
                                <span class="icon-cancel"></span>
                            </div>
                        `;
                        moduleItem.querySelector('.remove-file-btn').addEventListener('click', (e) => {
                            e.stopPropagation();
                            moduleItem.remove();
                            allModulesData = allModulesData.filter(item => item.moduleId != moduleId);
                            const descriptionElement = modal.querySelector('#export-modal-description + p');
                            if (descriptionElement) {
                                const remainingCount = modulesContainer.querySelectorAll('.list-group-item').length;
                                descriptionElement.textContent = `Configurez vos options d'exportation pour ${remainingCount === 1 ? '1 module.' : remainingCount + ' modules.'}`;
                            }
                        });
                        if (loadingItem) modulesContainer.replaceChild(moduleItem, loadingItem);

                    } else {
                        log('Erreur de chargement pour le module #' + moduleId, error || data.message);
                        if (loadingItem) {
                            loadingItem.classList.remove('text-muted');
                            loadingItem.classList.add('text-danger');
                            loadingItem.innerHTML = `Erreur de chargement pour le module #${moduleId} <span class="icon-warning"></span>`;
                            loadingItem.addEventListener('click', () => loadingItem.remove());
                        }
                    }
                });
            });
        } else {
            modulesContainer.innerHTML = '<div class="alert alert-light border p-3 mb-0 text-center">Aucun module sélectionné</div>';
        }

        // Ajout de l'écouteur pour la bascule visuelle du statut
        disableSwitch.addEventListener('change', (e) => {
            const shouldDisable = e.target.checked;
            const moduleItems = modulesContainer.querySelectorAll('.list-group-item');

            moduleItems.forEach(item => {
                const badge = item.querySelector('.badge');
                if (!badge) return;

                if (shouldDisable) {
                    // Si le module est initialement publié, on change son apparence
                    if (item.dataset.originalStatus === 'Publié') {
                        badge.textContent = 'Non publié';
                        badge.className = 'badge badge-status-unpublished p-1 px-2 fw-bold';
                    }
                } else {
                    // Rétablir l'état d'origine
                    badge.textContent = item.dataset.originalStatus;
                    badge.className = item.dataset.originalStatus === 'Publié' ? 'badge badge-status-published p-1 px-2 fw-bold' : 'badge badge-status-unpublished p-1 px-2 fw-bold';
                }
            });
            log(`Bascule de désactivation : ${shouldDisable}. Mise à jour visuelle des badges.`);
        });

        modal.addEventListener('change', (e) => {
            localStorage.setItem('moduleExportFormat', modal.querySelector('input[name="exportFormat"]:checked').value);
            localStorage.setItem('moduleExportDisable', disableSwitch.checked);
        });
        // Fonction pour fermer la modale et nettoyer les écouteurs
        const closeExportModal = () => {
            document.removeEventListener('keydown', handleEscKey);
            document.body.removeChild(modal);
            log('Export annulé');
        };

        // Gérer la touche Échap pour fermer
        const handleEscKey = (e) => {
            if (e.key === 'Escape') {
                closeExportModal();
            }
        };
        document.addEventListener('keydown', handleEscKey);

        modal.addEventListener('click', (e) => {
            // Fermer si on clique sur le fond ou sur un bouton de fermeture
            const action = e.target.dataset.action;
            if (action === 'close' || e.target === modal) {
                closeExportModal();
            } else if (action === 'confirm') {
                const disableSwitch = modal.querySelector('#export-disable-modules');
                const disableModules = disableSwitch ? disableSwitch.checked : false;
                const moduleItems = modulesContainer.querySelectorAll('.list-group-item');
                const remainingModuleIds = Array.from(moduleItems).map(item => item.dataset.moduleId).filter(id => id);
                const finalModulesToExport = allModulesData.filter(item => remainingModuleIds.includes(item.moduleId));
                if (finalModulesToExport.length === 0) {
                    alert('Veuillez sélectionner au moins un module à exporter.');
                    return;
                }
                // On utilise directement la fonction d'export groupé
                const exportFormat = modal.querySelector('input[name="exportFormat"]:checked').value;
                if (exportFormat === 'single') {
                    exportAllModulesToOneFile(finalModulesToExport, disableModules, option);
                } else { // Correction: passer l'option pour l'export multiple également
                    exportMultipleModulesSeparately(finalModulesToExport, disableModules, option);
                }
            }
        });
    }
    // ============ MODALE D'IMPORT ============
    function showImportDialog() {
        const overlay = document.createElement('div');
        overlay.id = 'import-modal-backdrop';
        overlay.className = 'modal-backdrop fade show';
        const modal = document.createElement('div');
        modal.id = 'import-modal';
        modal.className = 'modal fade show d-block';
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('data-bs-backdrop', 'static'); // Empêche la fermeture en cliquant à l'extérieur
        modal.setAttribute('role', 'dialog'); // Correction de la structure HTML et des styles
        modal.innerHTML = getModalBaseHtml(VERSION);
        document.body.appendChild(overlay);
        document.body.appendChild(modal);
        setImportConfirmHidden(true);
        if (typeof ALL_TEMPLATES !== 'undefined' && Array.isArray(ALL_TEMPLATES) && ALL_TEMPLATES.length > 0) {
            refreshCurrentThemeDisplay(ALL_TEMPLATES);
        } else {
            setTimeout(() => refreshCurrentThemeDisplay(), 0);
        }

        // Gestion unifiée de la fermeture et du nettoyage
        const cleanup = () => {
            document.removeEventListener('nav-to-step', navListener);
            document.removeEventListener('keydown', handleEscKey);
            // Reset état modal pour éviter les fuites entre ré-ouvertures
            if (typeof idEditorRefreshTimer !== 'undefined' && idEditorRefreshTimer) {
                clearTimeout(idEditorRefreshTimer);
            }
            if (document.body.contains(overlay)) overlay.remove();
            if (document.body.contains(modal)) modal.remove();
            log('Import modal fermée');
        };
        modal.addEventListener('click', (e) => {
            if (e.target.closest('[data-action="close"]') || e.target.closest('#cancel-import')) {
                cleanup();
            }
        });

        // Scoped Lookups
        const toggleContainer = modal.querySelector('#toggle-user-css-container');

        // Initialisation des variables DOM
        const step1Content = modal.querySelector('#step-1-content');
        const step2Content = modal.querySelector('#step-2-content');
        const step3Content = modal.querySelector('#step-3-content');
        const step4Content = modal.querySelector('#step-4-content');
        const navStep1 = modal.querySelector('#nav-step-1');
        const navStep2 = modal.querySelector('#nav-step-2');
        const navStep3 = modal.querySelector('#nav-step-3');
        const navStep4 = modal.querySelector('#nav-step-4');
        const confirmImportBtn = modal.querySelector('#confirm-import');
        const themeDropZone = modal.querySelector('#drop-zone-theme');
        const themeInput = modal.querySelector('#import-theme-zip');
        // Lance immédiatement le nettoyage corbeille à l'ouverture (sans attendre un changement d'étape)
        setTimeout(() => autoClearModuleTrash(), 50);

        // --- DÉFINITION DES FONCTIONS DU WIZARD (Portée globale de la modale) ---

        // Fonction pour mettre à jour un item de la checklist de validation
        function updateValidationItem(itemId, status, text) {
            const item = modal.querySelector(`#${itemId}`);
            if (!item) return;

            const icon = item.querySelector('.validation-icon');
            const textEl = item.querySelector('.validation-text');

            // Réinitialiser les classes
            icon.className = 'validation-icon';
            textEl.className = 'validation-text';

            if (status === 'success') {
                icon.classList.add('success');
                icon.innerHTML = '<span class="icon-check"></span>';
                textEl.classList.add('success');
            } else if (status === 'error') {
                icon.classList.add('error');
                icon.innerHTML = '<span class="icon-cancel"></span>';
                textEl.classList.add('error');
            } else {
                icon.classList.add('pending');
                icon.innerHTML = '<span class="icon-clock"></span>';
            }

            if (text) {
                textEl.textContent = text;
            }
        }

        // Vide la corbeille des modules (state = -2) et met à jour la pastille
        function autoClearModuleTrash() {
            updateValidationItem('check-modules-trash', 'pending', 'Nettoyage en cours...');
            const timeoutId = setTimeout(() => {
                updateValidationItem('check-modules-trash', 'error', 'Corbeille modules erreur');
            }, 5000);
            postJson('module.clearModuleTrash', {}, {}, 'Erreur vidage corbeille')
                .then(data => {
                    clearTimeout(timeoutId);
                    const deleted = data?.data?.deleted ?? 0;
                    log('clearModuleTrash ->', data);
                    if (deleted > 0) {
                        updateValidationItem('check-modules-trash', 'success', `Corbeille vidée (${deleted} modules)`);
                    } else if (data?.success) {
                        updateValidationItem('check-modules-trash', 'success', 'Corbeille modules vide');
                    } else {
                        updateValidationItem('check-modules-trash', 'error', 'Réponse inattendue');
                    }
                })
                .catch(err => {
                    clearTimeout(timeoutId);
                    log('clearModuleTrash error:', err);
                    updateValidationItem('check-modules-trash', 'error', 'Corbeille non vidée');
                });
        }

        // Vérifie et applique automatiquement la classe CSS du lien de menu "twitter"
        function checkTwitterMenuClass() {
            updateValidationItem('check-menu-twitter', 'pending', 'Lien Twitter...');
            return postJson('module.getTwitterMenuClass', {})
                .then(data => {
                    if (!data.success) {
                        updateValidationItem('check-menu-twitter', 'error', 'Lien Twitter introuvable');
                        return;
                    }
                    if (data.data.already_done) {
                        updateValidationItem('check-menu-twitter', 'success', 'Lien Twitter');
                    } else {
                        updateValidationItem('check-menu-twitter', 'pending', 'Lien Twitter...');
                        postJson('module.setTwitterMenuClass', {})
                            .then(res => {
                                if (res.success) {
                                    updateValidationItem('check-menu-twitter', 'success', 'Lien Twitter');
                                } else {
                                    updateValidationItem('check-menu-twitter', 'error', 'Lien Twitter erreur');
                                }
                            })
                            .catch(() => {
                                updateValidationItem('check-menu-twitter', 'error', 'Lien Twitter erreur');
                            });
                    }
                })
                .catch(error => {
                    log('[VALIDATION] Error checking twitter menu class:', error);
                    updateValidationItem('check-menu-twitter', 'error', 'Lien Twitter erreur');
                });
        }

        // Vérifie la présence du user.css dans media/templates/site/cassiopeia_dsfr/css
        function checkMediaUserCssStatus(hasDsfrTemplate) {
            const labelBase = 'Fichier user.css';
            if (!hasDsfrTemplate) {
                updateValidationItem('check-media-usercss', 'error', `${labelBase} indisponible (DSFR absent)`);
                return;
            }

            updateValidationItem('check-media-usercss', 'pending', `${labelBase} (vérification...)`);

            return postJson('module.getUserCssStatus', { template: 'cassiopeia_dsfr' })
                .then(data => {
                    if (!data.success) {
                        updateValidationItem('check-media-usercss', 'error', `${labelBase} erreur`);
                        return;
                    }

                    if (data.status === 'enabled') {
                        updateValidationItem('check-media-usercss', 'success', `${labelBase} présent`);
                    } else if (data.status === 'disabled') {
                        updateValidationItem('check-media-usercss', 'error', `${labelBase} désactivé`);
                    } else {
                        updateValidationItem('check-media-usercss', 'error', `${labelBase} absent`);
                    }
                })
                .catch(error => {
                    log('[VALIDATION] Error checking media user.css:', error);
                    updateValidationItem('check-media-usercss', 'error', `${labelBase} erreur vérification`);
                });
        }

        function goToStep(step) {
            // Masquer tous les contenus
            [step1Content, step2Content, step3Content, step4Content].forEach(el => {
                if (el) el.classList.remove('active');
            });
            // Réinitialiser les indicateurs de navigation
            [navStep1, navStep2, navStep3, navStep4].forEach((el, idx) => {
                if (!el) return;
                el.classList.remove('active');
                // Marquer comme complété si on est à une étape supérieure
                if (idx + 1 < step) {
                    el.classList.add('completed');
                } else {
                    el.classList.remove('completed');
                }
            });

            const exportBtn = modal.querySelector('#export-inventory-btn');

            if (step === 1) {
                if (step1Content) step1Content.classList.add('active');
                if (navStep1) navStep1.classList.add('active');
                if (confirmImportBtn) confirmImportBtn.classList.add('d-none');
                if (exportBtn) exportBtn.classList.add('d-none');
                setImportConfirmHidden(true);
                showInfoPanel('Étape 1', [
                    'Vérification des thèmes et prérequis'
                ], { section: 'stage', reset: true, replace: true });
                // Auto-vider la corbeille des modules et mettre à jour la pastille
                autoClearModuleTrash();
                // Auto-vérifier le mapping menu SIMBA
                if (typeof runMenuMappingCheck === 'function') runMenuMappingCheck();
            } else if (step === 2) {
                if (step2Content) step2Content.classList.add('active');
                if (navStep2) navStep2.classList.add('active');
                if (confirmImportBtn) confirmImportBtn.classList.add('d-none');
                if (exportBtn) exportBtn.classList.remove('d-none');
                loadModuleInventory(); // Charger l'inventaire à l'étape 2
                showInfoPanel('Étape 2', [
                    'Inventaire des modules (préparation export)'
                ], { section: 'stage', reset: true, replace: true });
            } else if (step === 3) {
                if (step3Content) step3Content.classList.add('active');
                if (navStep3) navStep3.classList.add('active');
                if (exportBtn) exportBtn.classList.add('d-none');
                if (confirmImportBtn) {
                    confirmImportBtn.classList.remove('d-none');
                    confirmImportBtn.innerHTML = '<span class="icon-download me-2"></span> Importer';
                    if (modal.querySelector('#file-preview-list')?.children.length > 0) {
                        confirmImportBtn.disabled = false;
                    }
                }
                setImportConfirmHidden(false);

                // Panneau debug: indiquer qu'on est sur l'étape 3 et réinitialiser les sections précédentes
                showInfoPanel('Étape 3', [
                    'Préparez un fichier JSON à importer',
                    'Le panneau se mettra à jour à chaque fichier traité'
                ], { section: 'stage', reset: true, replace: true });

                // Charger automatiquement le template par défaut (désactivé par défaut)
                if (AUTO_LOAD_DEFAULT) {
                    setTimeout(() => {
                        loadDefaultTemplate();
                    }, 150);
                }
            } else if (step === 4) {
                if (step4Content) step4Content.classList.add('active');
                if (navStep4) navStep4.classList.add('active');
                if (exportBtn) exportBtn.classList.add('d-none');
                if (confirmImportBtn) {
                    confirmImportBtn.classList.remove('d-none');
                    confirmImportBtn.textContent = 'Enregistrer';
                    confirmImportBtn.disabled = false;
                }
                setImportConfirmHidden(false);
                loadTinyMceParams(); // Charger les paramètres TinyMCE à l'étape 4
            }
        }

        function renderTinyMceParams(response) {
            const container = modal.querySelector('#tinymce-config-container');
            if (!container) return;

            const params = response.data || {};
            const detectedPath = response.detected_path || '';

            // Extraction des valeurs actuelles
            let templatePath = params.content_template_path || params.template_list_path || params.template_directory;

            // Support pour la structure Joomla 4/5 configuration -> setoptions
            if (params.configuration && Array.isArray(params.configuration.setoptions)) {
                const firstSet = params.configuration.setoptions[0] || {};
                if (!templatePath) templatePath = firstSet.content_template_path || firstSet.template_list_path || firstSet.template_directory || firstSet.path;
            }

            templatePath = templatePath || 'Non configuré';
            const isDsfr = templatePath !== 'Non configuré' && templatePath.toLowerCase().includes('dsfr');

            let wasAutoSelected = false;
            // Auto-sélection du DSFR si trouvé dans les chemins alternatifs
            if (!isDsfr && response.all_template_paths) {
                const dsfrCandidate = response.all_template_paths.find(p => p.toLowerCase().includes('dsfr'));
                if (dsfrCandidate) {
                    templatePath = dsfrCandidate;
                    wasAutoSelected = true;
                    // Déclenchement automatique de la sauvegarde pour persister la détection
                    log('Auto-détection DSFR : sauvegarde automatique...', templatePath);
                    setTimeout(() => saveTinyMceParams(templatePath), 500);
                }
            }

            // Si auto-sélection, on garde le badge en orange (Warning) initialement, sinon on suit la logique normale
            const dsfrStatusBadge = (templatePath.toLowerCase().includes('dsfr') && !wasAutoSelected)
                ? '<span id="dsfr-status-badge" class="badge bg-success"><span class="icon-check me-1"></span>Configuration DSFR Validée</span>'
                : '<span id="dsfr-status-badge" class="badge bg-warning text-dark"><span class="icon-warning me-1"></span>Rép. non-DSFR détecté</span>';

            let html = `
                <div class="tinymce-settings-view">
                    <div class="settings-section">
                        <div class="d-flex align-items-center justify-content-between mb-3 border-bottom pb-2">
                            <div class="d-flex align-items-center">
                                <span class="icon-folder-open me-2 fs-5"></span>
                                <span class="fw-bold small text-uppercase">Répertoire des modèles</span>
                            </div>
                            ${dsfrStatusBadge}
                        </div>
                        
                        <div class="p-0 mb-0">
                            <div class="input-group border-0">
                                <span class="input-group-text bg-white border-0"><span class="icon-location"></span></span>
                                <select id="tinymce-path-select" class="form-select border-0 ps-0 bg-white">
                                    <option value="${templatePath}" selected>${templatePath} ${templatePath === detectedPath ? '(Actuel)' : '(Auto-sélection)'}</option>
                                    ${(response.all_template_paths || []).filter(p => p !== templatePath).map(p => `<option value="${p}">${p}</option>`).join('')}
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            container.innerHTML = html;

            // Si c'était une auto-sélection, on attend 5 secondes pour passer le badge au vert
            if (wasAutoSelected) {
                setTimeout(() => {
                    const badge = container.querySelector('#dsfr-status-badge');
                    if (badge) {
                        badge.className = 'badge bg-success';
                        badge.innerHTML = '<span class="icon-check me-1"></span>Configuration DSFR Validée';
                    }
                }, 5000);
            }
        }

        function loadTinyMceParams() {
            const container = modal.querySelector('#tinymce-config-container');
            if (!container) return;

            const formData = new FormData();
            formData.append('option', 'com_modules');
            formData.append('task', 'module.getTinyMceParams');
            formData.append('format', 'json');

            appendCsrfToken(formData);

            fetch('index.php', {
                method: 'POST',
                body: formData,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
                .then(response => { if (!response.ok) throw new Error(`HTTP ${response.status}`); return response.json(); })
                .then(data => {
                    if (data.success) {
                        renderTinyMceParams(data); // Passer tout l'objet data
                    } else {
                        container.innerHTML = `<div class="alert alert-danger m-2 small">Erreur: ${data.message || 'Impossible de charger les réglages.'}</div>`;
                    }
                })
                .catch(err => {
                    log('Erreur TinyMCE:', err);
                    container.innerHTML = `<div class="alert alert-danger m-2 small">Erreur réseau lors de la récupération des paramètres.</div>`;
                });
        }

        function saveTinyMceParams(templatePath) {
            const saveBtn = modal.querySelector('#confirm-import'); // C'est notre bouton "Enregistrer" à l'étape 4

            if (saveBtn) {
                saveBtn.disabled = true;
                saveBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Enregistrement...';
            }

            const formData = new FormData();
            formData.append('option', 'com_modules');
            formData.append('task', 'module.saveTinyMceParams');
            formData.append('template_path', templatePath);
            formData.append('format', 'json');

            appendCsrfToken(formData);

            fetch('index.php', {
                method: 'POST',
                body: formData,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
                .then(response => { if (!response.ok) throw new Error(`HTTP ${response.status}`); return response.json(); })
                .then(data => {
                    if (data.success) {
                        // Recharger les paramètres pour confirmer visuellement
                        loadTinyMceParams();
                        // Afficher un succès temporaire sur le bouton
                        if (saveBtn) {
                            saveBtn.className = 'btn btn-success';
                            saveBtn.innerHTML = '<span class="icon-check me-2"></span>Enregistré !';
                            setTimeout(() => {
                                saveBtn.className = 'btn btn-primary';
                                saveBtn.textContent = 'Enregistrer';
                                saveBtn.disabled = false;
                            }, 2000);
                        }
                    } else {
                        alert('Erreur lors de la sauvegarde: ' + (data.message || 'Erreur inconnue'));
                        if (saveBtn) {
                            saveBtn.innerHTML = 'Enregistrer';
                            saveBtn.disabled = false;
                        }
                    }
                })
                .catch(err => {
                    log('Erreur sauvegarde TinyMCE:', err);
                    alert('Erreur réseau lors de la sauvegarde.');
                    if (saveBtn) {
                        saveBtn.innerHTML = 'Enregistrer';
                        saveBtn.disabled = false;
                    }
                });
        }

        function loadModuleInventory() {
            const container = modal.querySelector('#module-inventory-container');
            if (!container) return;
            postJson('module.getInventory')
                .then(data => {
                    if (data.success) {
                        const stats = data.data.stats;
                        renderInventory(data.data.modules, stats);
                        // Charger les stats lourdes (LIKE sur contenu HTML) en arrière-plan
                        postJson('module.getInventoryHeavy')
                            .then(heavyData => {
                                if (heavyData.success) {
                                    Object.assign(stats, heavyData.data.stats);
                                    updateHeavyStats(stats);
                                }
                            })
                            .catch(() => {
                                // Silencieux : laisser les tuiles lourdes à '…'
                            });
                    } else {
                        container.innerHTML = `<div class="alert alert-danger m-3 small">${data.message || 'Erreur chargement modules'}</div> `;
                    }
                })
                .catch(err => {
                    log('Erreur inventaire:', err);
                    container.innerHTML = `<div class="alert alert-danger m-3 small">Erreur réseau</div> `;
                });
        }

        function updateHeavyStats(stats) {
            const elTable  = modal.querySelector('#stat-articles-table');
            const elFrcard = modal.querySelector('#stat-frcard-total');
            const elFrtile = modal.querySelector('#stat-frtile-total');
            const elAlert  = modal.querySelector('#stat-alert-total');
            if (elTable)  elTable.textContent  = stats.articles_table || 0;
            if (elFrcard) elFrcard.textContent  = (stats.articles_frcard || 0) + (stats.categories_frcard || 0);
            if (elFrtile) elFrtile.textContent  = (stats.articles_frtile || 0) + (stats.categories_frtile || 0);
            if (elAlert)  elAlert.textContent   = (stats.articles_alert || 0) + (stats.categories_alert || 0);
        }

        function renderInventory(modules, stats) {
            const moduleContainer = modal.querySelector('#module-inventory-container');
            const articleContainer = modal.querySelector('#articles-inventory-container');
            const titleEl = modal.querySelector('#inventory-title');

            if (!moduleContainer) return;

            // Liste partagée des modules déjà migrés (dsfrMenuLateral) — accessible dans tous les blocs
            const dsfrLateralList = stats && stats.dsfrlateral_list ? [...stats.dsfrlateral_list] : [];

            // Mise à jour des statistiques
            if (stats) {
                const cards = {
                    'modules_total': { el: modal.querySelector('#stat-modules-total'), isModule: true, label: 'Module de menu' },
                    'articles_total': { el: modal.querySelector('#stat-articles-total'), list: stats.articles_total_list, label: 'Tous les articles' },
                    'articles_trash': { el: modal.querySelector('#stat-articles-trash'), list: stats.articles_trash_list, label: 'Articles en corbeille' },
                    'articles_test': { el: modal.querySelector('#stat-articles-test'), list: stats.articles_test_list, label: 'Articles de test' },
                    'articles_table': { el: modal.querySelector('#stat-articles-table'), list: stats.articles_table_list, label: 'Articles avec tableaux' },
                    'frcard_total':   { el: modal.querySelector('#stat-frcard-total'), isFrcard: true, label: 'Cartes (fr-card)' },
                    'frtile_total':   { el: modal.querySelector('#stat-frtile-total'), isFrtile: true, label: 'Tuiles (fr-tile)' },
                    'alert_total':    { el: modal.querySelector('#stat-alert-total'), isAlert: true, label: 'Alertes (fr-alert)' }
                };

                const formatDate = (dateStr) => {
                    if (!dateStr) return '—';
                    const d = new Date(dateStr);
                    return isNaN(d) ? dateStr : d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
                };

                Object.keys(cards).forEach(key => {
                    const card = cards[key];
                    if (!card.el) return;
                    const cardElement = card.el.parentElement;

                    if (card.isFrcard) {
                        card.el.textContent = stats.articles_frcard === null ? '…' : (stats.articles_frcard || 0) + (stats.categories_frcard || 0);
                    } else if (card.isFrtile) {
                        card.el.textContent = stats.articles_frtile === null ? '…' : (stats.articles_frtile || 0) + (stats.categories_frtile || 0);
                    } else if (card.isAlert) {
                        card.el.textContent = stats.articles_alert === null ? '…' : (stats.articles_alert || 0) + (stats.categories_alert || 0);
                    } else if (key === 'articles_table') {
                        card.el.textContent = stats.articles_table === null ? '…' : (stats.articles_table || 0);
                    } else {
                        card.el.textContent = stats[key] || 0;
                    }

                    cardElement.style.cursor = 'pointer';
                    cardElement.title = "Cliquez pour voir la liste";
                    cardElement.onclick = () => {
                        // Retirer la bordure active de toutes les cards
                        Object.keys(cards).forEach(k => {
                            if (cards[k].el) cards[k].el.parentElement.style.borderTop = '';
                        });
                        // Appliquer la bordure active sur la card cliquée
                        cardElement.style.borderTop = '3px solid #1f6fff';

                        if (card.isModule) {
                            // Revenir aux modules
                            moduleContainer.classList.remove('d-none');
                            articleContainer.classList.add('d-none');
                            titleEl.textContent = card.label;
                        } else if (card.isFrcard) {
                            moduleContainer.classList.add('d-none');
                            articleContainer.classList.remove('d-none');
                            titleEl.textContent = card.label;

                            const issueBadgeStyle = {
                                'sans fr-card__body':    'background:#ce0500;color:#fff;',
                                'sans fr-card__content': 'background:#ce0500;color:#fff;',
                                'sans fr-card__title':   'background:#b34000;color:#fff;',
                                'sans fr-card__link':    'background:#b34000;color:#fff;',
                                'grille à corriger':     'background:#6a0dad;color:#fff;',
                                'desc vide':             'background:#6c757d;color:#fff;',
                                'col-* résiduels':       'background:#6c757d;color:#fff;'
                            };

                            const articleFrcardList = stats.articles_frcard_list || [];
                            const total = articleFrcardList.length + (stats.categories_frcard || 0);
                            let html = '';
                            if (total === 0) {
                                html = '<div class="p-4 text-center text-muted small">Aucune carte DSFR trouvée.</div>';
                            } else {
                                const needsFix = articleFrcardList.filter(a => a.card_issues && a.card_issues.length > 0);
                                if (needsFix.length > 0) {
                                    html += `
                <div class="inventory-item d-flex align-items-center gap-2">
                    <div style="flex:1;">
                        <div class="fw-bold small" style="line-height:1.3;">Articles à corriger</div>
                        <div class="text-muted" style="font-size:0.7rem;">Ajout fr-card__body / fr-card__content / fr-card__title / fr-card__link</div>
                    </div>
                    <button class="btn-premium-action apply-frcard-all-btn" style="font-size:0.7rem; padding:4px 10px; white-space:nowrap;">→ Corriger tout</button>
                </div>`;
                                }
                                articleFrcardList.forEach(art => {
                                    const issues  = (art.card_issues || '').split(',').filter(v => v);
                                    const hasIssue = issues.length > 0;
                                    const cardCount = art.card_count || 0;
                                    const statusBadge = hasIssue
                                        ? `<span class="badge" style="font-size:0.65rem;background:#6c757d;color:#fff;">${cardCount}</span>`
                                        : `<span class="badge" style="font-size:0.65rem;background:#18753c;color:#fff;">✓ conforme</span>`;
                                    html += `
                <div class="inventory-item" data-id="${art.id}" data-card-count="${cardCount}">
                    <div class="d-flex align-items-center gap-2" style="flex:1; min-width:0;">
                        <div style="flex:1; min-width:0;">
                            <div class="fw-bold" style="font-size:0.8rem; line-height:1.3; display:flex; align-items:center; gap:8px; min-width:0; flex-wrap:wrap;">
                                ${statusBadge}
                                <span class="item-title" style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(art.title)}</span>
                                <span class="item-category" style="font-weight:400; opacity:0.6; white-space:nowrap;">${escapeHtml(art.category || 'Sans catégorie')}</span>
                                <span class="item-created" style="font-weight:400; opacity:0.6; white-space:nowrap;">créé : ${formatDate(art.created)}</span>
                                <span class="item-date" style="font-weight:400; opacity:0.6; white-space:nowrap;">màj : ${formatDate(art.modified)}</span>
                            </div>
                        </div>
                        ${hasIssue ? `<button class="btn-premium-action apply-frcard-btn" data-id="${art.id}" data-title="${escapeHtml(art.title)}" style="font-size:0.7rem; padding:4px 10px; white-space:nowrap;">→ Corriger</button>` : ''}
                    </div>
                </div>`;
                                });
                                (stats.categories_frcard_list || []).forEach(cat => {
                                    html += `
                <div class="inventory-item">
                    <div class="d-flex align-items-center gap-2" style="flex:1; min-width:0;">
                        <div style="flex:1; min-width:0;">
                            <div class="fw-bold" style="font-size:0.8rem; line-height:1.3; display:flex; align-items:center; gap:8px; min-width:0;">
                                <span class="badge bg-info text-dark" style="font-size:0.7rem; white-space:nowrap;">Catégorie</span>
                                <span style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(cat.title)}</span>
                            </div>
                        </div>
                    </div>
                </div>`;
                                });
                            }
                            articleContainer.innerHTML = html;

                            // Fonction de correction structure fr-card
                            const applyFrcardMigration = async (ids, labelForConfirm) => {
                                const ok = confirm(
                                    'Corriger la structure fr-card pour ' + labelForConfirm + ' ?\n\n' +
                                    'La structure sera mise en conformité DSFR :\n' +
                                    'fr-card__body > fr-card__content > fr-card__title > fr-card__link'
                                );
                                if (!ok) return;

                                articleContainer.querySelectorAll('.apply-frcard-btn, .apply-frcard-all-btn')
                                    .forEach(b => { b.disabled = true; b.style.opacity = '0.5'; });

                                try {
                                    const result = await postJson('module.applyFrcardMigration', {
                                        article_ids: ids.join(',')
                                    });
                                    if (result.success) {
                                        result.updated.forEach(id => {
                                            const item = articleContainer.querySelector('.inventory-item[data-id="' + id + '"]');
                                            if (item) {
                                                const btn = item.querySelector('.apply-frcard-btn');
                                                if (btn) {
                                                    btn.textContent = '✓ Corrigé';
                                                    btn.style.cssText = 'font-size:0.7rem; padding:4px 10px; white-space:nowrap; color:#16a34a; border-color:#16a34a; background:#f0fdf4; font-weight:600; border-radius:8px; border:1px solid; cursor:default;';
                                                }
                                                item.style.transition = 'opacity 0.4s ease';
                                                setTimeout(() => { item.style.opacity = '0'; setTimeout(() => item.remove(), 400); }, 800);
                                            }
                                        });
                                    } else {
                                        alert('Erreur : ' + (result.message || 'inconnue'));
                                    }
                                } catch (err) {
                                    alert('Erreur : ' + (err.message || 'inconnue'));
                                } finally {
                                    articleContainer.querySelectorAll('.apply-frcard-btn, .apply-frcard-all-btn')
                                        .forEach(b => {
                                            if (b.textContent.trim().startsWith('✓')) return;
                                            b.disabled = false;
                                            b.style.opacity = '';
                                        });
                                }
                            };

                            // Bouton individuel
                            articleContainer.addEventListener('click', (e) => {
                                const btn = e.target.closest('.apply-frcard-btn');
                                if (!btn) return;
                                const id    = parseInt(btn.dataset.id);
                                const title = btn.dataset.title;
                                applyFrcardMigration([id], '"' + title + '"');
                            });

                            // Bouton "Corriger tout"
                            const allFrcardBtn = articleContainer.querySelector('.apply-frcard-all-btn');
                            if (allFrcardBtn) {
                                allFrcardBtn.addEventListener('click', () => {
                                    const allIds = [...articleContainer.querySelectorAll('.inventory-item[data-id]')]
                                        .filter(el => el.querySelector('.apply-frcard-btn'))
                                        .map(el => parseInt(el.dataset.id));
                                    applyFrcardMigration(allIds, 'tous les ' + allIds.length + ' articles');
                                });
                            }
                        } else if (card.isFrtile) {
                            // Afficher liste mixte articles + catégories fr-tile
                            moduleContainer.classList.add('d-none');
                            articleContainer.classList.remove('d-none');
                            titleEl.textContent = card.label;

                            let html = '';
                            const total = (stats.articles_frtile || 0) + (stats.categories_frtile || 0);
                            if (total === 0) {
                                html = '<div class="p-4 text-center text-muted small">Aucune tuile DSFR trouvée.</div>';
                            } else {
                                (stats.articles_frtile_list || []).forEach(art => {
                                    html += `
                <div class="inventory-item">
                    <div class="d-flex align-items-center gap-2" style="flex:1; min-width:0;">
                        <div style="flex:1; min-width:0;">
                            <div class="fw-bold" style="font-size:0.8rem; line-height:1.3; display:flex; align-items:center; gap:12px; min-width:0;">
                                <span class="badge bg-primary" style="font-size:0.7rem; white-space:nowrap;">Article</span>
                                <span style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(art.title)}</span>
                                <span style="font-weight:400; opacity:0.6; white-space:nowrap;">${escapeHtml(art.category || 'Sans catégorie')}</span>
                                <span style="font-weight:400; opacity:0.6; white-space:nowrap;">créé : ${formatDate(art.created)}</span>
                                <span style="font-weight:400; opacity:0.6; white-space:nowrap;">màj : ${formatDate(art.modified)}</span>
                            </div>
                        </div>
                    </div>
                </div>`;
                                });
                                (stats.categories_frtile_list || []).forEach(cat => {
                                    html += `
                <div class="inventory-item">
                    <div class="d-flex align-items-center gap-2" style="flex:1; min-width:0;">
                        <div style="flex:1; min-width:0;">
                            <div class="fw-bold" style="font-size:0.8rem; line-height:1.3; display:flex; align-items:center; gap:12px; min-width:0;">
                                <span class="badge bg-info text-dark" style="font-size:0.7rem; white-space:nowrap;">Catégorie</span>
                                <span style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(cat.title)}</span>
                            </div>
                        </div>
                    </div>
                </div>`;
                                });
                            }
                            articleContainer.innerHTML = html;
                        } else if (card.isAlert) {
                            moduleContainer.classList.add('d-none');
                            articleContainer.classList.remove('d-none');
                            titleEl.textContent = card.label;

                            const alertBadgeStyle = {
                                'alert-success': 'background:#18753c;color:#fff;',
                                'alert-info':    'background:#0063cb;color:#fff;',
                                'alert-warning': 'background:#b34000;color:#fff;',
                                'alert-danger':  'background:#ce0500;color:#fff;'
                            };
                            const articleAlertList = stats.articles_alert_list || [];
                            const total = articleAlertList.length + (stats.categories_alert || 0);
                            let html = '';
                            if (total === 0) {
                                html = '<div class="p-4 text-center text-muted small">Aucune alerte Bootstrap trouvée.</div>';
                            } else {
                                if (articleAlertList.length > 0) {
                                    html += `
                <div class="inventory-item d-flex align-items-center gap-2">
                    <div style="flex:1;">
                        <div class="fw-bold small" style="line-height:1.3;">Articles</div>
                        <div class="text-muted" style="font-size:0.7rem;">alert-success/info/warning/danger → fr-alert--success/info/warning/error</div>
                    </div>
                    <button class="btn-premium-action apply-alert-all-btn" style="font-size:0.7rem; padding:4px 10px; white-space:nowrap;">→ Appliquer à tous</button>
                </div>`;
                                }
                                articleAlertList.forEach(art => {
                                    const variants = (art.alert_variants || '').split(',').filter(v => v);
                                    const badges = variants.map(v => `<span class="badge" style="font-size:0.65rem;${alertBadgeStyle[v] || 'background:#6c757d;color:#fff;'}">${v}</span>`).join(' ');
                                    html += `
                <div class="inventory-item" data-id="${art.id}">
                    <div class="d-flex align-items-center gap-2" style="flex:1; min-width:0;">
                        <div style="flex:1; min-width:0;">
                            <div class="fw-bold" style="font-size:0.8rem; line-height:1.3; display:flex; align-items:center; gap:8px; min-width:0; flex-wrap:wrap;">
                                ${badges}
                                <span class="item-title" style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(art.title)}</span>
                                <span class="item-category" style="font-weight:400; opacity:0.6; white-space:nowrap;">${escapeHtml(art.category || 'Sans catégorie')}</span>
                                <span class="item-created" style="font-weight:400; opacity:0.6; white-space:nowrap;">créé : ${formatDate(art.created)}</span>
                                <span class="item-date" style="font-weight:400; opacity:0.6; white-space:nowrap;">màj : ${formatDate(art.modified)}</span>
                            </div>
                        </div>
                        <button class="btn-premium-action apply-alert-btn"
                                data-id="${art.id}" data-title="${escapeHtml(art.title)}"
                                style="font-size:0.7rem; padding:4px 10px; white-space:nowrap;">
                            → DSFR
                        </button>
                    </div>
                </div>`;
                                });
                                (stats.categories_alert_list || []).forEach(cat => {
                                    html += `
                <div class="inventory-item">
                    <div class="d-flex align-items-center gap-2" style="flex:1; min-width:0;">
                        <div style="flex:1; min-width:0;">
                            <div class="fw-bold" style="font-size:0.8rem; line-height:1.3; display:flex; align-items:center; gap:8px; min-width:0;">
                                <span class="badge bg-secondary" style="font-size:0.65rem;">Catégorie</span>
                                <span style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(cat.title)}</span>
                            </div>
                        </div>
                    </div>
                </div>`;
                                });
                            }
                            articleContainer.innerHTML = html;

                            // Fonction de migration Bootstrap → DSFR
                            const applyAlertMigration = async (ids, labelForConfirm) => {
                                const ok = confirm(
                                    'Migrer les classes Bootstrap → DSFR pour ' + labelForConfirm + ' ?\n\n' +
                                    'alert-success/info/warning/danger → fr-alert--success/info/warning/error'
                                );
                                if (!ok) return;

                                articleContainer.querySelectorAll('.apply-alert-btn, .apply-alert-all-btn')
                                    .forEach(b => { b.disabled = true; b.style.opacity = '0.5'; });

                                try {
                                    const result = await postJson('module.applyAlertMigration', {
                                        article_ids: ids.join(',')
                                    });
                                    if (result.success) {
                                        result.updated.forEach(id => {
                                            const item = articleContainer.querySelector('.inventory-item[data-id="' + id + '"]');
                                            if (item) {
                                                const btn = item.querySelector('.apply-alert-btn');
                                                if (btn) {
                                                    btn.textContent = '✓ Migré';
                                                    btn.style.cssText = 'font-size:0.7rem; padding:4px 10px; white-space:nowrap; color:#16a34a; border-color:#16a34a; background:#f0fdf4; font-weight:600; border-radius:8px; border:1px solid; cursor:default;';
                                                }
                                                item.style.transition = 'opacity 0.4s ease';
                                                setTimeout(() => { item.style.opacity = '0'; setTimeout(() => item.remove(), 400); }, 800);
                                            }
                                        });
                                    } else {
                                        alert('Erreur : ' + (result.message || 'inconnue'));
                                    }
                                } catch (err) {
                                    alert('Erreur : ' + (err.message || 'inconnue'));
                                } finally {
                                    articleContainer.querySelectorAll('.apply-alert-btn, .apply-alert-all-btn')
                                        .forEach(b => {
                                            if (b.textContent.trim().startsWith('✓')) return;
                                            b.disabled = false;
                                            b.style.opacity = '';
                                        });
                                }
                            };

                            // Bouton individuel
                            articleContainer.addEventListener('click', (e) => {
                                const btn = e.target.closest('.apply-alert-btn');
                                if (!btn) return;
                                const id = parseInt(btn.dataset.id);
                                const title = btn.dataset.title;
                                applyAlertMigration([id], '"' + title + '"');
                            });

                            // Bouton "Appliquer à tous"
                            const allAlertBtn = articleContainer.querySelector('.apply-alert-all-btn');
                            if (allAlertBtn) {
                                allAlertBtn.addEventListener('click', () => {
                                    const allIds = [...articleContainer.querySelectorAll('.inventory-item[data-id]')]
                                        .map(el => parseInt(el.dataset.id));
                                    applyAlertMigration(allIds, 'tous les ' + allIds.length + ' articles');
                                });
                            }
                        } else {
                            // Afficher liste articles standard
                            moduleContainer.classList.add('d-none');
                            articleContainer.classList.remove('d-none');
                            titleEl.textContent = `${card.label} (${stats[key]})`;

                            let html = '';
                            if (!card.list || card.list.length === 0) {
                                html = '<div class="p-4 text-center text-muted small">Aucun article trouvé.</div>';
                            } else {
                                card.list.forEach(art => {
                                    html += `
                <div class="inventory-item">
                    <div class="d-flex align-items-center gap-2" style="flex:1; min-width:0;">
                        <div style="flex:1; min-width:0;">
                            <div class="fw-bold" style="font-size:0.8rem; line-height:1.3; display:flex; align-items:center; gap:12px; min-width:0;">
                                <span style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(art.title)}</span>
                                <span style="font-weight:400; opacity:0.6; white-space:nowrap;">${escapeHtml(art.category || 'Sans catégorie')}</span>
                                <span style="font-weight:400; opacity:0.6; white-space:nowrap;">créé : ${formatDate(art.created)}</span>
                                <span style="font-weight:400; opacity:0.6; white-space:nowrap;">màj : ${formatDate(art.modified)}</span>
                            </div>
                        </div>
                    </div>
                </div>
                `;
                                });
                            }
                            articleContainer.innerHTML = html;
                        }
                    };
                });


            }

            // Remplissage des modules - FILTRÉ : Afficher uniquement les modules de type "menu"
            if (modules && modules.length > 0) {
                // Filtrer pour ne garder que les modules de menu ET exclure ceux contenant "DSFR" ou "dsfrSocial__item" dans le titre OU la position
                const menuModules = modules.filter(m => {
                    const title = m.title.toLowerCase();
                    const position = (m.position || '').toLowerCase();
                    const isMenu = m.module && m.module.toLowerCase().includes('menu');
                    const isSidebarLeft = position === 'sidebar-left';

                    const hasExcludedKeyword = title.includes('dsfr') ||
                        title.includes('dsfrsocial__item') ||
                        position.includes('dsfr') ||
                        position.includes('dsfrsocial__item');

                    return isMenu && isSidebarLeft && !hasExcludedKeyword;
                });

                // Mettre à jour le compteur combiné : à migrer + déjà migrés
                if (stats && stats.modules_total !== undefined) {
                    const statElement = modal.querySelector('#stat-modules-total');
                    if (statElement) {
                        statElement.textContent = menuModules.length + dsfrLateralList.length;
                    }
                }

                if (menuModules.length > 0 || dsfrLateralList.length > 0) {
                    let html = '';

                    if (menuModules.length > 0) {
                        // Ligne en-tête "Appliquer à tous" — intégrée dans la tuile Menu
                        html += `
                <div class="inventory-item d-flex align-items-center gap-2">
                    <div style="flex:1;">
                        <div class="fw-bold small" style="line-height:1.3;">Menu</div>
                        <div class="text-muted" style="font-size:0.7rem;">Modèle : menuDsfrLateral — layout, class_sfx, startLevel\u2026 (menutype conservé)</div>
                    </div>
                    <button class="btn-premium-action apply-model-all-btn" style="font-size:0.7rem; padding:4px 10px; white-space:nowrap;">\u2193 Appliquer \u00e0 tous</button>
                </div>`;
                        menuModules.forEach(m => {
                            const status = parseInt(m.published);
                            let badgeClass = 'bg-secondary';
                            let badgeText = 'Inconnu';

                            if (status === 1) {
                                badgeClass = 'bg-success';
                                badgeText = 'Publié';
                            } else if (status === 0) {
                                badgeClass = 'bg-warning text-dark';
                                badgeText = 'Dépublié';
                            } else if (status === -2) {
                                badgeClass = 'bg-danger';
                                badgeText = 'Corbeille';
                            }

                            html += `
                <div class="inventory-item" data-id="${m.id}" data-status="${status}">
                    <div class="d-flex align-items-center gap-2" style="flex:1; min-width:0;">
                        <div style="flex:1; min-width:0;">
                            <div class="fw-bold" style="font-size:0.8rem; line-height:1.3; display:flex; align-items:center; gap:12px; min-width:0;">
                                <span style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(m.title)}</span>
                                <span style="font-weight:400; opacity:0.6; white-space:nowrap;">${escapeHtml(m.position || 'aucune')}</span>
                                <span style="font-weight:400; opacity:0.6; white-space:nowrap;">#${m.id}</span>
                            </div>
                        </div>
                        <span class="badge ${badgeClass}" style="font-size:0.75rem; padding:3px 7px; border-radius:4px; white-space:nowrap;">${badgeText}</span>
                        <button class="btn-premium-action apply-model-btn"
                                data-id="${m.id}" data-title="${escapeHtml(m.title)}"
                                title="Appliquer les params du modèle DsfrMenuLateral (menutype conservé)"
                                style="font-size:0.7rem; padding:4px 10px; white-space:nowrap;">
                            ↓ Modèle
                        </button>
                    </div>
                </div>
                `;
                        });
                    } // fin if (menuModules.length > 0)

                    moduleContainer.innerHTML = html;

                    // Ajouter les modules déjà migrés (dsfrMenuLateral) en bas de liste
                    if (dsfrLateralList.length > 0) {
                        let migratedHtml = '';
                        dsfrLateralList.forEach(m => {
                            migratedHtml += `
                <div class="inventory-item" data-id="${m.id}" data-status="migrated">
                    <div class="d-flex align-items-center gap-2" style="flex:1; min-width:0;">
                        <div style="flex:1; min-width:0;">
                            <div class="fw-bold" style="font-size:0.8rem; line-height:1.3; display:flex; align-items:center; gap:12px; min-width:0;">
                                <span style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(m.title)}</span>
                                <span style="font-weight:400; opacity:0.6; white-space:nowrap;">dsfrMenuLateral</span>
                                <span style="font-weight:400; opacity:0.6; white-space:nowrap;">#${m.id}</span>
                            </div>
                        </div>
                        <span style="font-size:0.7rem; color:#16a34a; font-weight:600;">✓ Migré</span>
                    </div>
                </div>`;
                        });
                        moduleContainer.innerHTML += migratedHtml;
                    }

                    // Listeners et helper — seulement si des modules sont en attente
                    if (menuModules.length > 0) {
                    // Helper : appelle module.applyLateralModel pour une liste d'IDs
                    const applyLateralModel = async (ids, labelForConfirm) => {
                        const ok = confirm(
                            'Appliquer le modèle DsfrMenuLateral à ' + labelForConfirm + ' ?\n\n' +
                            'Les params seront mis à jour (menutype conservé).'
                        );
                        if (!ok) return;

                        moduleContainer.querySelectorAll('.apply-model-btn, .apply-model-all-btn')
                            .forEach(b => { b.disabled = true; b.style.opacity = '0.5'; });

                        try {
                            const result = await postJson('module.applyLateralModel', {
                                target_ids: ids.join(',')
                            });
                            if (result.success) {
                                result.updated.forEach(id => {
                                    const item = moduleContainer.querySelector('.inventory-item[data-id="' + id + '"]');
                                    if (item) {
                                        // Feedback bref puis retrait de la carte (position changée)
                                        const btn = item.querySelector('.apply-model-btn');
                                        if (btn) {
                                            btn.textContent = '✓ Appliqué';
                                            btn.style.cssText = 'font-size:0.7rem; padding:4px 10px; white-space:nowrap; color:#16a34a; border-color:#16a34a; background:#f0fdf4; font-weight:600; border-radius:8px; border:1px solid; cursor:default;';
                                        }
                                        const migratedTitle = item.querySelector('.fw-bold')?.textContent?.trim() || '';
                                        dsfrLateralList.push({ id: id, title: migratedTitle });

                                        item.style.transition = 'opacity 0.4s ease';
                                        setTimeout(() => {
                                            item.style.opacity = '0';
                                            setTimeout(() => {
                                                item.remove();
                                                // Ajouter le module en bas de liste avec badge ✓ Migré
                                                const migratedEl = document.createElement('div');
                                                migratedEl.className = 'inventory-item';
                                                migratedEl.dataset.id = id;
                                                migratedEl.dataset.status = 'migrated';
                                                migratedEl.innerHTML = `
                                                    <div class="d-flex align-items-center gap-2" style="flex:1; min-width:0;">
                                                        <div style="flex:1; min-width:0;">
                                                            <div class="fw-bold" style="font-size:0.8rem; line-height:1.3; display:flex; align-items:center; gap:12px; min-width:0;">
                                                                <span style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(migratedTitle)}</span>
                                                                <span style="font-weight:400; opacity:0.6; white-space:nowrap;">dsfrMenuLateral</span>
                                                                <span style="font-weight:400; opacity:0.6; white-space:nowrap;">#${id}</span>
                                                            </div>
                                                        </div>
                                                        <span style="font-size:0.7rem; color:#16a34a; font-weight:600;">✓ Migré</span>
                                                    </div>`;
                                                moduleContainer.appendChild(migratedEl);
                                            }, 400);
                                        }, 800);
                                    }
                                });
                                if (result.errors && result.errors.length > 0) {
                                    alert(result.updated.length + ' module(s) mis à jour.\nErreurs : ' +
                                        result.errors.map(e => 'ID ' + e.id + ': ' + e.error).join('\n'));
                                }
                            }
                        } catch (err) {
                            alert('Erreur : ' + (err.message || 'inconnue'));
                        } finally {
                            moduleContainer.querySelectorAll('.apply-model-btn, .apply-model-all-btn')
                                .forEach(b => {
                                    if (b.textContent.trim().startsWith('✓')) return;
                                    b.disabled = false;
                                    b.style.opacity = '';
                                });
                        }
                    };

                    // Bouton individuel par module
                    moduleContainer.addEventListener('click', (e) => {
                        const btn = e.target.closest('.apply-model-btn');
                        if (!btn) return;
                        const id = parseInt(btn.dataset.id);
                        const title = btn.dataset.title;
                        applyLateralModel([id], '"' + title + '"');
                    });

                    // Bouton "Appliquer à tous"
                    const allBtn = moduleContainer.querySelector('.apply-model-all-btn');
                    if (allBtn) {
                        allBtn.addEventListener('click', () => {
                            const allIds = [...moduleContainer.querySelectorAll('.inventory-item[data-id]:not([data-status="migrated"])')]
                                .map(el => parseInt(el.dataset.id));
                            applyLateralModel(allIds, 'tous les ' + allIds.length + ' modules');
                        });
                    }
                    } // fin if (menuModules.length > 0) listeners

                } else {
                    moduleContainer.innerHTML = '<div class="p-4 text-center text-muted small">Aucun module de menu trouvé.</div>';
                }
            } else {
                moduleContainer.innerHTML = '<div class="p-4 text-center text-muted small">Aucun module trouvé.</div>';
            }

            // Masquer les listes par défaut — elles s'affichent uniquement au clic sur une stat-card
            moduleContainer.classList.add('d-none');
        }

        // Écouteur pour la navigation directe
        const navListener = (e) => goToStep(e.detail);
        document.addEventListener('nav-to-step', navListener);

        // Détection du moteur ZIP à l'ouverture de la modale (step 1 actif par défaut)
        postJson('module.checkZipMethod', {}).then(data => {
            const lbl = modal.querySelector('#zip-method-label');
            if (lbl && data?.data?.label) lbl.textContent = data.data.label;
        }).catch(() => {
            const lbl = modal.querySelector('#zip-method-label');
            const sep = modal.querySelector('#zip-method-separator');
            if (lbl) lbl.textContent = '';
            if (sep) sep.textContent = '';
        });

        // Gestionnaire pour le bouton Export XLS
        const exportBtn = modal.querySelector('#export-inventory-btn');
        if (exportBtn) {
            exportBtn.onclick = () => {
                const moduleContainer = modal.querySelector('#module-inventory-container');
                const articleContainer = modal.querySelector('#articles-inventory-container');
                const titleEl = modal.querySelector('#inventory-title');

                let data = [];
                let filename = 'export';
                let headers = [];

                // Déterminer quelle vue est active
                if (!moduleContainer.classList.contains('d-none')) {
                    // Vue modules
                    filename = 'modules_corbeille.xls';
                    headers = ['ID', 'Titre', 'Type', 'Position', 'Statut'];
                    const items = moduleContainer.querySelectorAll('.inventory-item');
                    items.forEach(item => {
                        const id = item.dataset.id || '';
                        const title = item.querySelector('.fw-bold')?.textContent.trim() || '';
                        const meta = item.querySelector('.extra-small')?.textContent.trim() || '';
                        const parts = meta.split('|');
                        const type = parts[0]?.trim() || '';
                        const position = parts[1]?.replace('Position:', '').trim() || '';
                        const status = item.dataset.status === 'active' ? 'Publié' : 'Non publié';
                        data.push([id, title, type, position, status]);
                    });
                } else if (!articleContainer.classList.contains('d-none')) {
                    // Vue articles
                    const currentTitle = titleEl.textContent.trim();
                    filename = 'articles_' + currentTitle.toLowerCase().replace(/[^a-z0-9]/g, '_') + '.xls';
                    headers = ['Titre', 'Catégorie', 'Créé le', 'Mis à jour'];
                    const items = articleContainer.querySelectorAll('.inventory-item[data-id]');
                    const hasCardCount = [...items].some(i => i.hasAttribute('data-card-count'));
                    if (hasCardCount) headers = ['Titre', 'Catégorie', 'Nb cartes', 'Mis à jour'];
                    items.forEach(item => {
                        const title    = item.querySelector('.item-title')?.textContent.trim() || '';
                        const category = item.querySelector('.item-category')?.textContent.trim() || '';
                        const modified = item.querySelector('.item-date')?.textContent.replace('màj : ', '').trim() || '';
                        if (!title) return;
                        if (hasCardCount) {
                            const count = item.dataset.cardCount || '0';
                            data.push([title, category, count, modified]);
                        } else {
                            data.push([title, category, '', modified]);
                        }
                    });
                }

                if (data.length === 0) {
                    alert('Aucune donnée à exporter.');
                    return;
                }

                // Générer le fichier XLS (format HTML pour Excel)
                let html = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
                html += '<head><meta charset="UTF-8"><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Sheet1</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head>';
                html += '<body><table border="1">';

                // En-têtes
                html += '<tr>';
                headers.forEach(header => {
                    html += '<th style="background-color: #4CAF50; color: white; font-weight: bold; padding: 8px;">' + header + '</th>';
                });
                html += '</tr>';

                // Données
                data.forEach(row => {
                    html += '<tr>';
                    row.forEach(cell => {
                        html += '<td style="padding: 5px;">' + (cell || '') + '</td>';
                    });
                    html += '</tr>';
                });

                html += '</table></body></html>';

                // Télécharger le fichier
                const blob = new Blob(['\uFEFF' + html], { type: 'application/vnd.ms-excel;charset=utf-8;' });
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = filename;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            };
        }

        let defaultTemplate = null;

        function updateUserCssStatus(templateFolder) {
            const pathDisplay = modal.querySelector('#user-css-path-display');
            const cssSwitch = modal.querySelector('#user-css-switch');
            const statusText = modal.querySelector('#user-css-status-text');
            if (!templateFolder || !cssSwitch || !pathDisplay || !statusText) return;

            cssSwitch.disabled = true;

            postJson('module.getUserCssStatus', { template: templateFolder })
                .then(data => {
                    if (data.success) {
                        pathDisplay.textContent = data.path || 'N/A';
                        const isEnabled = (data.status === 'enabled');
                        cssSwitch.checked = isEnabled;
                        statusText.textContent = isEnabled ? 'Actif' : (data.status === 'disabled' ? 'Désactivé' : 'Inexistant');
                        statusText.className = `small fw-bold text-uppercase ${isEnabled ? 'text-success' : 'text-danger'}`;
                    }
                })
                .catch(err => {
                    log('Erreur de statut CSS:', err);
                })
                .finally(() => {
                    cssSwitch.disabled = false;
                });
        }
        const cssSwitchListener = (e) => {
            if (!defaultTemplate) return;
            const cssSwitch = e.target;
            cssSwitch.disabled = true;

            postJson('module.toggleUserCss', { template: defaultTemplate })
                .then(data => {
                    if (data.success) {
                        updateUserCssStatus(defaultTemplate);
                    } else {
                        cssSwitch.checked = !cssSwitch.checked; // Revert
                        alert('Erreur: ' + (data.message || 'Action échouée'));
                    }
                })
                .catch(err => {
                    cssSwitch.checked = !cssSwitch.checked; // Revert
                    log('Erreur toggle CSS:', err);
                })
                .finally(() => {
                    cssSwitch.disabled = false;
                });
        };

        const clearCacheListener = (e) => {
            const btn = e.currentTarget;
            const originalContent = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '<span class="icon-spinner icon-spin me-1"></span> Nettoyage...';

            postJson('module.clearJoomlaCache')
                .then(data => {
                    if (data.success) {
                        alert(data.message || 'Cache vidé avec succès');
                    } else {
                        alert('Erreur: ' + (data.message || 'Action échouée'));
                    }
                })
                .catch(err => {
                    log('Erreur vider cache:', err);
                    alert('Erreur réseau lors du vidage du cache');
                })
                .finally(() => {
                    btn.disabled = false;
                    btn.innerHTML = originalContent;
                });
        };

        if (toggleContainer && ALL_TEMPLATES && ALL_TEMPLATES.length > 0) {
            // Trouver le template inactif (non par défaut)
            const inactiveTemplateObj = ALL_TEMPLATES.find(template => template.home != 1);
            if (inactiveTemplateObj) {
                defaultTemplate = inactiveTemplateObj.template;

                // Initial status check
                updateUserCssStatus(defaultTemplate);

                document.getElementById('user-css-switch')?.addEventListener('change', cssSwitchListener);

                // ============ LOGIQUE DU WIZARD ============
                // (Variables déjà définies plus haut)


                refreshCurrentThemeDisplay();
            } // End if (inactiveTemplateObj)
        } // End if (toggleContainer...)

        // ============ LOGIQUE GENERALE (Hors conditionnelle toggleContainer) ============

        // Utilitaire pour calculer le contraste (noir ou blanc) selon la couleur de fond
        function getContrastColor(hexcolor) {
            if (!hexcolor || hexcolor === 'transparent') return '#000000';
            hexcolor = hexcolor.replace("#", "");
            if (hexcolor.length === 3) hexcolor = hexcolor.split('').map(c => c + c).join('');
            const r = parseInt(hexcolor.substring(0, 2), 16);
            const g = parseInt(hexcolor.substring(2, 4), 16);
            const b = parseInt(hexcolor.substring(4, 6), 16);
            const yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
            return (yiq >= 128) ? '#000000' : '#ffffff';
        }

        // Recopie de la fonction pour qu'elle soit accessible globalement dans la modale
        window.cycleColorTag = function (btn) {
            // Si le bouton a une couleur AMM (style inline), on la retire pour entrer dans le cycle standard
            if (btn.style.backgroundColor) {
                btn.style.backgroundColor = '';
                btn.style.borderColor = '';
                btn.classList.add('bg-tag-none');
                return;
            }
            const colors = ['bg-tag-none', 'bg-tag-success', 'bg-tag-danger', 'bg-tag-warning'];
            let currentIdx = colors.findIndex(c => btn.classList.contains(c));
            if (currentIdx === -1) currentIdx = 0;
            btn.classList.remove(colors[currentIdx]);
            currentIdx = (currentIdx + 1) % colors.length;
            btn.classList.add(colors[currentIdx]);
        };

        // Mettre à jour l'affichage du thème actuel (Défini ici pour être sûr qu'il s'exécute toujours)
        // Mettre à jour l'affichage du thème actuel et enfant
        // Fonction pour rafraîchir le statut du thème via AJAX (Données fraîches)
        function refreshCurrentThemeDisplay(localData) {
            const allTemplatesGrid = modal.querySelector('#all-templates-grid');
            if (!allTemplatesGrid) return;

            // Fonction de rendu (réutilisable)
            const renderTemplates = (allTemplates) => {
                const themeDropZoneEl = modal.querySelector('#drop-zone-theme');
                const homeTemplate = allTemplates.find(t => t.home == 1 || t.home == '1');
                let parentTemplate = null;
                let childTemplate = null;
                const hasParentColumn = Array.isArray(allTemplates) && allTemplates.some(t => Object.prototype.hasOwnProperty.call(t, 'parent'));
                const dsfrTemplate = Array.isArray(allTemplates)
                    ? allTemplates.find(t => /dsfr/i.test(`${t.template || ''} ${t.title || ''}`))
                    : null;
                const hasDsfrTemplate = Boolean(dsfrTemplate);
                checkMediaUserCssStatus(hasDsfrTemplate);
                const childThemeSuccessLabel = 'Thème enfant DSFR';
                const childThemeMissingLabelDsfrPresent = 'Thème enfant DSFR manquant';
                const childThemeMissingLabelDsfrAbsent = 'Thème enfant DSFR absent';
                const childThemeMissingLabel = hasDsfrTemplate
                    ? childThemeMissingLabelDsfrPresent
                    : childThemeMissingLabelDsfrAbsent;
                if (homeTemplate) {
                    if (homeTemplate.parent) {
                        parentTemplate = allTemplates.find(t => t.template == homeTemplate.parent);
                        childTemplate = homeTemplate;
                    } else {
                        parentTemplate = homeTemplate;
                        childTemplate = allTemplates.find(t => t.parent == homeTemplate.template);
                    }

                    if (parentTemplate) {
                        updateValidationItem('check-theme-parent', 'success', 'Thème parent');
                    } else if (hasParentColumn && homeTemplate.parent) {
                        updateValidationItem('check-theme-parent', 'error', 'Thème parent introuvable');
                    } else {
                        // Pas de notion de parent (ou non applicable)
                        updateValidationItem('check-theme-parent', 'success', 'Thème parent');
                    }

                    if (childTemplate) {
                        // Ne masquer le wizard que si le thème enfant détecté est bien un DSFR
                        const childIsDsfr = /dsfr/i.test(`${childTemplate.template || ''} ${childTemplate.title || ''}`);
                        if (childIsDsfr) {
                            document.body.setAttribute('data-me-child-theme', 'present');
                            setImportButtonHidden(true);
                            if (themeDropZoneEl) {
                                if (SHOW_THEME_DROPZONE) {
                                    themeDropZoneEl.classList.remove('d-none');
                                    const dzTitle = themeDropZoneEl.querySelector('h6');
                                    if (dzTitle) dzTitle.textContent = 'Mettre à jour le thème';
                                } else {
                                    themeDropZoneEl.classList.add('d-none');
                                }
                            }
                            if (DEBUG) {
                                log('[STEP1] Thème enfant DSFR détecté -> drop zone ' + (SHOW_THEME_DROPZONE ? 'mise à jour' : 'masquée (paramètre plugin)'));
                            }
                        } else {
                            // Un thème enfant non-DSFR ne doit pas bloquer l'installation du DSFR
                            document.body.removeAttribute('data-me-child-theme');
                            setImportButtonHidden(false);
                            if (themeDropZoneEl) themeDropZoneEl.classList.remove('d-none');
                            if (DEBUG) {
                                log('[STEP1] Thème enfant non-DSFR détecté -> drop zone autorisée pour installer DSFR');
                            }
                        }

                        updateValidationItem(
                            'check-theme-child',
                            childIsDsfr ? 'success' : 'error',
                            childIsDsfr ? childThemeSuccessLabel : childThemeMissingLabel
                        );

                        checkTwitterMenuClass();

                        if (childIsDsfr) {
                            activateStep2UI();
                        }
                    } else {
                        document.body.removeAttribute('data-me-child-theme');
                        setImportButtonHidden(false);
                        if (themeDropZoneEl) themeDropZoneEl.classList.remove('d-none');
                        if (DEBUG) {
                            log('[STEP1] Aucun thème enfant -> Import + drop zone visibles');
                        }
                        updateValidationItem('check-theme-child', 'error', childThemeMissingLabel);
                        checkTwitterMenuClass();
                    }
                } else {
                    updateValidationItem('check-theme-parent', 'error', 'Thème parent introuvable');
                    updateValidationItem('check-theme-child', 'error', childThemeMissingLabel);
                    updateValidationItem('check-menu-twitter', 'error', 'Lien Twitter impossible');
                    allTemplatesGrid.innerHTML = '<div class="text-danger small">Aucun thème par défaut détecté (home=1). Count: ' + allTemplates.length + '</div>';
                }

                if (allTemplatesGrid) {
                    const cardsHtml = allTemplates.map(tpl => {
                        const isActive = tpl.home == 1 || tpl.home == '1';
                        const isChild = Boolean(tpl.parent) || (childTemplate && tpl.id === childTemplate.id);
                        const isParent = parentTemplate && tpl.id === parentTemplate.id;
                        const extraClass = isActive ? ' status-card-active' : ' status-card-alt';
                        const labelText = isParent ? 'Parent' : (isChild ? 'Enfant' : 'Thème');
                        const labelClass = isParent ? 'theme-label-parent' : (isChild ? 'theme-label-child' : 'theme-label-other');
                        const showActions = tpl.template === 'cassiopeia_systemedesign';
                        const itemActions = showActions
                            ? `<span id="save-child-theme-badge" class="badge bg-primary cursor-pointer" style="font-size:0.65em" title="Sauvegarder ce thème au format ZIP" data-template-name="${tpl.template}" data-template-title="${tpl.title}">
                                Sauvegarder
                            </span>
                            <span id="delete-child-theme-badge" class="badge bg-danger cursor-pointer" style="font-size:0.65em" title="Désinstaller ce thème" data-template-name="${tpl.template}" data-template-title="${tpl.title}">
                                Supprimer
                            </span>`
                            : '';
                        return `
                        <div class="status-card${extraClass}">
                            <div class="status-card-value d-flex flex-nowrap align-items-center gap-2" style="white-space: nowrap;">
                                <span class="${labelClass}">${labelText}</span>
                                <span class="theme-title-text">${tpl.title}</span>
                                ${itemActions}
                            </div>
                        </div>
                    `;
                    }).join('');
                    allTemplatesGrid.innerHTML = cardsHtml || '';
                    if (DEBUG) {
                        // Affichage d'un panneau synthétique
                        showInfoPanel('Templates détectés', [
                            `Total: ${allTemplates.length}`,
                            `Home: ${homeTemplate ? homeTemplate.template : 'none'}`,
                            `Parent: ${parentTemplate ? parentTemplate.template : 'none'}`,
                            `Enfant: ${childTemplate ? childTemplate.template : 'none'}`,
                            `DSFR détecté: ${hasDsfrTemplate ? 'oui' : 'non'}`
                        ], { section: 'step1' });
                    }
                }
            };

            // Fallback: Si des données locales sont passées (PHP injection)
            if (localData && Array.isArray(localData) && localData.length > 0) {
                renderTemplates(localData);
                return; // On ne fait pas l'AJAX si on a déjà les données locales fraîches du chargement de page
            }

            // Sinon, mode AJAX
            if (typeof ALL_TEMPLATES !== 'undefined' && Array.isArray(ALL_TEMPLATES) && ALL_TEMPLATES.length > 0) {
                renderTemplates(ALL_TEMPLATES);
            } else {
                allTemplatesGrid.innerHTML = '<div class="d-block small text-muted">Examen des thèmes... <span class="spinner-border spinner-border-sm ms-1"></span></div>';
            }
            postJson('module.getTemplateStatus')
                .then(data => {
                    if (data.success && Array.isArray(data.data)) {
                        renderTemplates(data.data);
                        showInfoPanel('API getTemplateStatus OK', [
                            `templates: ${data.data.length}`,
                            `message: ${data.message || 'OK'}`
                        ], { section: 'step1-api' });
                    } else {
                        allTemplatesGrid.innerHTML = '<div class="text-danger small">Err API: ' + (data.message || 'Succès=Faux') + '</div>';
                        showInfoPanel('API getTemplateStatus KO', [
                            `success: ${data.success}`,
                            `message: ${data.message || 'n/a'}`
                        ], { section: 'step1-api' });
                    }
                })
                .catch(e => {
                    log('Erreur refresh theme status', e);
                    // Tentative désespérée : utilisation des données PHP globales si disponibles
                    if (typeof ALL_TEMPLATES !== 'undefined' && Array.isArray(ALL_TEMPLATES)) {
                        allTemplatesGrid.innerHTML += ' <span class="text-warning small">(Fallback Local)</span>';
                        renderTemplates(ALL_TEMPLATES);
                    } else {
                        allTemplatesGrid.innerHTML = `<div class="text-danger small" style="white-space:normal; line-height:1.1;"> Err: ${e.message}</div> `;
                    }
                    showInfoPanel('API getTemplateStatus EX', [
                        `error: ${e.message}`,
                        `stack: ${(e.stack || '').substring(0, 120)}`
                    ], { section: 'step1-api' });
                });
        }

        function activateStep2UI() {
            // Changement de couleur de la pastille 2 (Selector corrigé)
            const nav2 = modal.querySelector('#nav-step-2');
            const nav1 = modal.querySelector('#nav-step-1');
            if (nav2) {
                nav2.classList.add('active');
                nav2.style.transition = 'all 0.3s ease';
            }
            if (nav1) {
                nav1.classList.remove('active');
                nav1.classList.add('completed');
            }

            // Illumination de la flèche centrale pour inciter au clic
            const arrow = modal.querySelector('.icon-arrow-right');
            if (arrow) {
                arrow.parentElement.style.cursor = 'pointer';
                arrow.parentElement.classList.add('text-primary');
                arrow.parentElement.onclick = () => goToStep(2);
            }
        }

        // Exécution immédiate
        refreshCurrentThemeDisplay();

        // Gestionnaire pour le badge de suppression du thème enfant (délégation d'événements)
        modal.addEventListener('click', function (e) {
            log('[DELETE-HANDLER] Click event on modal, target:', e.target);
            const deleteBadge = e.target.closest('#delete-child-theme-badge');
            log('[DELETE-HANDLER] deleteBadge found:', deleteBadge);
            if (!deleteBadge) return;

            e.stopPropagation();
            log('[DELETE-HANDLER] Delete badge clicked!');
            const templateName = deleteBadge.dataset.templateName;
            const themeName = deleteBadge.dataset.templateTitle || 'ce thème';
            log('[DELETE-HANDLER] Template to delete:', templateName, 'Theme name:', themeName);

            if (!templateName) {
                alert('Impossible de déterminer le thème à supprimer.');
                return;
            }

            // Confirmation de suppression avec modale Bootstrap personnalisée
            log('[DELETE-HANDLER] Showing confirmation dialog...');

            const confirmModal = document.createElement('div');
            confirmModal.className = 'modal fade show d-block';
            confirmModal.style.zIndex = '9999';
            confirmModal.tabIndex = -1;
            confirmModal.innerHTML = `
                <div class="modal-dialog modal-dialog-centered me-delete-modal">
                    <div class="modal-content">
                        <div class="modal-header bg-danger text-white py-3 px-4">
                            <h5 class="modal-title"><span class="icon-warning me-2"></span>Désinstaller le thème ?</h5>
                        </div>
                        <div class="modal-body py-3 px-4">
                            <p class="mb-1">Supprimer <strong>"${escapeHtml(themeName)}"</strong> ?</p>
                            <p class="text-danger mb-0"><strong>Cette action est irréversible.</strong></p>
                        </div>
                        <div class="modal-footer px-4 pb-4 pt-2">
                            <button type="button" class="btn btn-secondary" data-action="cancel">Annuler</button>
                            <button type="button" class="btn btn-danger" data-action="confirm">
                                <span class="icon-trash me-1"></span> Supprimer
                            </button>
                        </div>
                    </div>
                </div>
                `;

            const confirmBackdrop = document.createElement('div');
            confirmBackdrop.className = 'modal-backdrop fade show';
            confirmBackdrop.style.zIndex = '9998';

            document.body.appendChild(confirmBackdrop);
            document.body.appendChild(confirmModal);

            setTimeout(() => confirmModal.classList.add('show'), 10);
            confirmModal.focus();

            const closeConfirmModal = () => {
                document.removeEventListener('keydown', handleConfirmEsc, true);
                if (document.body.contains(confirmModal)) confirmModal.remove();
                if (document.body.contains(confirmBackdrop)) confirmBackdrop.remove();
            };

            const handleConfirmEsc = (e) => {
                if (e.key === 'Escape') {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    closeConfirmModal();
                }
            };

            document.addEventListener('keydown', handleConfirmEsc, true);

            // Fonction pour effectuer la suppression
            const performDeletion = () => {
                log('[DELETE-HANDLER] User confirmed, starting deletion process...');

                // Désactivation du badge pendant le traitement
                deleteBadge.style.pointerEvents = 'none';
                deleteBadge.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';

                log('[DELETE-HANDLER] Sending AJAX request...');
                postJson('module.uninstallTemplate', { template_name: templateName })
                    .then(data => {
                        log('[DELETE-HANDLER] Data received:', data);
                        if (data.success) {
                            log('[DELETE-HANDLER] Deletion successful!');
                            alert('Thème supprimé avec succès !');
                            refreshCurrentThemeDisplay();
                        } else {
                            log('[DELETE-HANDLER] ERROR: Deletion failed:', data.message);
                            alert('Erreur lors de la suppression : ' + (data.message || 'Erreur inconnue'));
                            deleteBadge.style.pointerEvents = '';
                            deleteBadge.innerHTML = '<span class="icon-trash"></span> Supprimer';
                        }
                    })
                    .catch(error => {
                        log('[DELETE-HANDLER] AJAX ERROR:', error);
                        log('Erreur de suppression:', error);
                        alert('Erreur lors de la suppression du thème.');
                        deleteBadge.style.pointerEvents = '';
                        deleteBadge.innerHTML = '<span class="icon-trash"></span> Supprimer';
                    });
            };

            // Gestionnaires d'événements pour la modale de confirmation
            confirmModal.addEventListener('click', function (e) {
                const action = e.target.closest('[data-action]')?.dataset.action;

                if (action === 'confirm') {
                    log('[DELETE-HANDLER] User clicked Confirm button');
                    closeConfirmModal();
                    performDeletion();
                } else if (action === 'cancel') {
                    log('[DELETE-HANDLER] User clicked Cancel button');
                    closeConfirmModal();
                }
            });

            // Fermer la modale en cliquant sur le backdrop
            confirmBackdrop.addEventListener('click', function () {
                log('[DELETE-HANDLER] User clicked backdrop (cancelled)');
                closeConfirmModal();
            });
        });

        // Gestionnaire pour le badge de sauvegarde des thèmes (parent et enfant)
        modal.addEventListener('click', function (e) {
            const saveBadge = e.target.closest('#save-parent-theme-badge, #save-child-theme-badge');
            if (!saveBadge) return;

            e.stopPropagation();
            const templateName = saveBadge.dataset.templateName;
            const templateTitle = saveBadge.dataset.templateTitle;

            if (!templateName) {
                alert('Impossible de déterminer le thème à sauvegarder.');
                return;
            }

            // Désactivation du badge pendant le traitement
            saveBadge.style.pointerEvents = 'none';
            const originalHtml = saveBadge.innerHTML;
            saveBadge.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Création...';

            // Appel AJAX pour créer le zip du thème
            postJson('module.saveParentThemeZip', { template_name: templateName })
                .then(data => {
                    if (data.success && data.data && data.data.download_url) {
                        const downloadLink = document.createElement('a');
                        downloadLink.href = data.data.download_url;
                        downloadLink.download = data.data.filename || `${templateName}.zip`;
                        document.body.appendChild(downloadLink);
                        downloadLink.click();
                        document.body.removeChild(downloadLink);

                        alert(`Thème "${templateTitle}" sauvegardé avec succès!\n\nFichier: ${data.data.filename} `);
                    } else {
                        alert('Erreur lors de la sauvegarde : ' + (data.message || 'Erreur inconnue'));
                    }
                })
                .catch(error => {
                    log('Erreur de sauvegarde:', error);
                    alert('Erreur lors de la sauvegarde du thème.');
                })
                .finally(() => {
                    saveBadge.style.pointerEvents = '';
                    saveBadge.innerHTML = originalHtml;
                });
        });

        if (themeDropZone && themeInput) {
            themeDropZone.addEventListener('click', () => themeInput.click());
            themeInput.addEventListener('change', (e) => handleThemeZip(e.target.files[0]));
            themeDropZone.addEventListener('dragover', (e) => {
                e.preventDefault();
                themeDropZone.classList.add('border-primary');
            });
            themeDropZone.addEventListener('dragleave', () => themeDropZone.classList.remove('border-primary'));
            themeDropZone.addEventListener('drop', (e) => {
                e.preventDefault();
                themeDropZone.classList.remove('border-primary');
                handleThemeZip(e.dataTransfer.files[0]);
            });
        }

        function handleThemeZip(file) {
            if (!file || !file.name.toLowerCase().endsWith('.zip')) {
                alert('Veuillez sélectionner un fichier ZIP valide.');
                return;
            }
            const statusDiv = modal.querySelector('#theme-deploy-status');
            if (statusDiv) {
                statusDiv.innerHTML = `<div class="alert alert-info py-2 small d-flex align-items-center rounded-3"> <span class="spinner-border spinner-border-sm me-2"></span>Déploiement en cours...</div> `;
            }
            postJson('module.deployThemeZip', { theme_zip: file })
                .then(data => {
                    if (data.success) {
                        const responseData = data.data || {};
                        const methodNote = responseData.extract_method === 'Joomla\\Archive'
                            ? ' <span style="font-size:0.65rem;opacity:0.6;">(via API Joomla)</span>'
                            : '';
                        if (statusDiv) statusDiv.innerHTML = `<div class="alert alert-success py-2 small rounded-3 border-0 shadow-sm" style="background-color: rgba(5, 150, 105, 0.1); color: #059669;"> <span class="icon-check me-2"></span>Thème installé !${methodNote}</div> `;
                        if (responseData.template_name) refreshCurrentThemeDisplay();
                    } else {
                        if (statusDiv) statusDiv.innerHTML = `<div class="alert alert-danger py-2 small rounded-3"> Erreur : ${data.message}</div> `;
                    }
                })
                .catch(err => {
                    log('Erreur déploiement thème:', err);
                    if (statusDiv) statusDiv.innerHTML = '<div class="alert alert-danger py-2 small rounded-3">Erreur réseau</div>';
                });
        }

        modal.querySelector('#clear-cache-btn')?.addEventListener('click', clearCacheListener);



        const fileInput = modal.querySelector('#import-file');
        const filePreviewList = modal.querySelector('#file-preview-list');

        // Vérification de la disponibilité de Joomla
        if (typeof Joomla === 'undefined') {
            log('Joomla n\'est pas défini. Le script Joomla principal n\'est pas chargé.');
        }



        const confirmBtn = modal.querySelector('#confirm-import');

        // Global variable for detected replacements
        const detectedReplacements = new Set();
        const parsedFilesModules = new Map(); // Stocke { fileName: [modules] }
        let idEditorUserToggled = false;
        const externalModuleCache = new Map();
        const externalModulePending = new Set();
        const existingIdCache = new Map();
        let existingIdPending = false;
        let maxExistingModuleId = null;
        let maxExistingModuleIdPending = false;
        let lastRenumberMapping = null;
        let autoRenumberDone = false;
        let autoRenumberPending = false;
        let autoRenumberAttempts = 0;
        let moduleSelectorTouched = false;
        const okHighlightTimers = new Map();
        const menuAdjustmentOriginalContent = new Map();
        let menuAdjustmentEnabled = false;
        let menuMappingRaw = null;
        let menuMappingData = null;

        const applyMenuAdjustmentToModules = (modules, fileName, enabled) => {
            if (!Array.isArray(modules)) return;
            modules.forEach((item, index) => {
                if (!isFooterContentModule(item)) return;
                const mod = getModuleObject(item);
                if (!mod || typeof mod !== 'object') return;
                const key = `${fileName}::${index}`;
                if (enabled) {
                    if (!menuAdjustmentOriginalContent.has(key)) {
                        menuAdjustmentOriginalContent.set(key, typeof mod.content === 'string' ? mod.content : '');
                    }
                    mod.content = MENU_ADJUSTMENT_HTML;
                } else if (menuAdjustmentOriginalContent.has(key)) {
                    mod.content = menuAdjustmentOriginalContent.get(key);
                }
            });
        };
        const applyMenuAdjustmentAll = (enabled) => {
            parsedFilesModules.forEach((modules, fileName) => {
                applyMenuAdjustmentToModules(modules, fileName, enabled);
            });
            if (typeof renderIdEditor === 'function') renderIdEditor();
            if (typeof updateQuickReplaceFieldsWithDetections === 'function') updateQuickReplaceFieldsWithDetections();
        };
        const buildModuleOptions = () => {
            const options = [];
            const seen = new Set();
            parsedFilesModules.forEach((modules) => {
                (modules || []).forEach(item => {
                    const idNorm = normalizeIdValue(getModuleOriginalId(item));
                    if (!idNorm.numericStr || seen.has(idNorm.numericStr)) return;
                    seen.add(idNorm.numericStr);
                    options.push({
                        id: idNorm.numericStr,
                        title: getModuleTitle(item)
                    });
                });
            });
            options.sort((a, b) => Number(a.id) - Number(b.id));
            return options;
        };
        const buildRefRowsHtml = (entry, moduleOptions) => {
            if (!entry.refDetails || entry.refDetails.length === 0) return '';
            return entry.refDetails.map(ref => {
                const currentId = String(ref.id);
                const currentOption = moduleOptions.find(o => o.id === currentId);
                const currentLabel = currentOption ? `${currentId} — ${currentOption.title}` : `${currentId} — EXTERNE`;
                const optionsHtml = [
                    `<option value="${escapeHtml(currentId)}" selected>${escapeHtml(currentLabel)}</option>`,
                    ...moduleOptions
                        .filter(o => o.id !== currentId)
                        .map(o => `<option value="${escapeHtml(o.id)}">${escapeHtml(o.id)} — ${escapeHtml(o.title)}</option>`)
                ].join('');

                return `
                    <div class="id-editor-ref-row">
                        <div class="id-editor-ref-label">${escapeHtml(ref.label)}</div>
                        <select class="form-select form-select-sm id-editor-ref-select"
                                data-file-name="${entry.fileName}"
                                data-module-index="${entry.index}"
                                data-old-id="${escapeHtml(currentId)}">
                            ${optionsHtml}
                        </select>
                    </div>
                `;
            }).join('');
        };
        const scheduleOkHighlight = (itemEl, hasIssues) => {
            if (!itemEl) return;
            const key = `${itemEl.dataset.fileName}::${itemEl.dataset.moduleIndex}`;
            if (hasIssues) {
                itemEl.classList.remove('is-ok');
                if (okHighlightTimers.has(key)) {
                    clearTimeout(okHighlightTimers.get(key));
                    okHighlightTimers.delete(key);
                }
                return;
            }
            if (itemEl.classList.contains('is-ok')) return;
            if (okHighlightTimers.has(key)) return;
            const timer = setTimeout(() => {
                itemEl.classList.add('is-ok');
                okHighlightTimers.delete(key);
            }, 1500);
            okHighlightTimers.set(key, timer);
        };
        const autoRenumberIfNeeded = () => {
            if (autoRenumberDone || autoRenumberPending) return;
            if (parsedFilesModules.size === 0) return;
            if (autoRenumberAttempts >= 3) return;
            autoRenumberAttempts += 1;
            autoRenumberPending = true;
            Promise.resolve(renumberModulesFromBase())
                .then((success) => {
                    if (success) {
                        autoRenumberDone = true;
                    } else {
                        setTimeout(() => {
                            autoRenumberPending = false;
                            autoRenumberIfNeeded();
                        }, 800);
                    }
                })
                .catch(() => {
                    setTimeout(() => {
                        autoRenumberPending = false;
                        autoRenumberIfNeeded();
                    }, 800);
                })
                .finally(() => {
                    if (autoRenumberDone) {
                        autoRenumberPending = false;
                    }
                });
        };
        const prefetchExistingIds = async (ids) => {
            const unique = Array.from(new Set((ids || []).filter(Boolean)));
            if (unique.length === 0) return;
            const missing = unique.filter(id => !existingIdCache.has(id));
            if (missing.length === 0 || existingIdPending) return;
            existingIdPending = true;
            try {
                const data = await postJson('module.checkids', { ids: JSON.stringify(missing) });
                const payload = (data && (data.data || data)) || {};
                const found = payload.found || payload || {};
                Object.keys(found).forEach(id => {
                    existingIdCache.set(String(id), found[id]);
                });
                missing.forEach(id => {
                    if (!existingIdCache.has(String(id))) existingIdCache.set(String(id), null);
                });
            } catch (e) {
            } finally {
                existingIdPending = false;
                scheduleIdEditorRefresh();
            }
        };
        const updateMaxIdHint = (maxId) => {
            const hint = document.getElementById('id-renumber-hint');
            if (!hint) return;
            if (maxId === undefined) {
                hint.textContent = 'Renumérotation auto · Max ID base: ...';
                return;
            }
            if (maxId === null) {
                hint.textContent = 'Renumérotation auto · Max ID base: indisponible';
                return;
            }
            hint.textContent = `Renumérotation auto · Max ID base: ${maxId}`;
        };
        const fetchMaxExistingModuleId = async (force = false) => {
            if (maxExistingModuleIdPending) return maxExistingModuleId;
            if (maxExistingModuleId !== null && !force) return maxExistingModuleId;
            maxExistingModuleIdPending = true;
            updateMaxIdHint(undefined);
            try {
                const data = await postJson('module.getmaxid');
                const payload = (data && (data.data || data)) || {};
                const maxId = parseInt(payload.max_id, 10);
                maxExistingModuleId = Number.isFinite(maxId) ? maxId : null;
                updateMaxIdHint(maxExistingModuleId);
                return maxExistingModuleId;
            } catch (e) {
                maxExistingModuleId = null;
                updateMaxIdHint(maxExistingModuleId);
                return maxExistingModuleId;
            } finally {
                maxExistingModuleIdPending = false;
            }
        };
        const prefetchExternalModules = (ids) => {
            const toFetch = (ids || []).filter(id => {
                return id && !externalModuleCache.has(id) && !externalModulePending.has(id);
            });

            if (toFetch.length === 0) return;

            // Marquer comme en cours pour éviter les doublons
            toFetch.forEach(id => externalModulePending.add(id));

            // Appel groupé (Batch)
            postJson('module.getcontent', { ids: JSON.stringify(toFetch) })
                .then(response => {
                    if (response.success && response.data) {
                        const results = response.data;
                        toFetch.forEach(id => {
                            const mod = results[id];
                            const info = mod
                                ? { title: mod.title || `Module ${id}`, content: mod.content || '' }
                                : { title: `Module ${id}`, content: '' };
                            externalModuleCache.set(id, info);
                            externalModulePending.delete(id);
                        });
                        scheduleIdEditorRefresh();
                    }
                })
                .catch(() => {
                    toFetch.forEach(id => {
                        externalModuleCache.set(id, { title: `Module ${id}`, content: '' });
                        externalModulePending.delete(id);
                    });
                    scheduleIdEditorRefresh();
                });
        };
        const computeIdDiagnostics = () => {
            const entries = [];
            const idCounts = new Map();
            const refCounts = new Map();
            const idToEntries = new Map();
            const renumberInverse = new Map();
            if (lastRenumberMapping) {
                Object.keys(lastRenumberMapping).forEach(oldId => {
                    const newId = String(lastRenumberMapping[oldId]);
                    renumberInverse.set(newId, String(oldId));
                });
            }

            parsedFilesModules.forEach((modules, fileName) => {
                (modules || []).forEach((item, index) => {
                    const title = getModuleTitle(item);
                    const idRaw = getModuleOriginalId(item);
                    const idNorm = normalizeIdValue(idRaw);
                    const legacyId = getModuleLegacyId(item);
                    if (idNorm.numericStr) {
                        idCounts.set(idNorm.numericStr, (idCounts.get(idNorm.numericStr) || 0) + 1);
                        if (!idToEntries.has(idNorm.numericStr)) idToEntries.set(idNorm.numericStr, []);
                        idToEntries.get(idNorm.numericStr).push({ title, fileName, index });
                    }
                    const refs = extractLoadModuleIdsFromModule(item);
                    refs.forEach(id => refCounts.set(id, (refCounts.get(id) || 0) + 1));
                    entries.push({ fileName, index, item, title, idRaw, idNorm, legacyId, refs });
                });
            });

            const missingRefs = new Set();
            const allowedExternalRefs = new Set(); // aucune ref externe tolérée désormais
            refCounts.forEach((_, id) => {
                if (!idCounts.has(id)) {
                    if (!allowedExternalRefs.has(String(id))) {
                        missingRefs.add(id);
                    }
                }
            });

            // Détection de cycles simples entre IDs uniques
            const graph = new Map();
            entries.forEach(entry => {
                const id = entry.idNorm.numericStr;
                if (!id) return;
                if ((idCounts.get(id) || 0) > 1) return;
                const targets = entry.refs.filter(refId => (idCounts.get(refId) || 0) === 1);
                if (!graph.has(id)) graph.set(id, new Set());
                targets.forEach(t => graph.get(id).add(t));
            });
            const cycleIds = new Set();
            const visited = new Set();
            const onStack = new Set();
            const stack = [];
            const markCycleFrom = (id) => {
                const idx = stack.indexOf(id);
                if (idx >= 0) {
                    for (let i = idx; i < stack.length; i++) {
                        cycleIds.add(stack[i]);
                    }
                }
            };
            const MAX_DFS_DEPTH = 100;
            const dfs = (id, depth = 0) => {
                if (visited.has(id) || depth > MAX_DFS_DEPTH) return;
                visited.add(id);
                onStack.add(id);
                stack.push(id);
                const nexts = graph.get(id) || [];
                for (const next of nexts) {
                    if (!visited.has(next)) {
                        dfs(next, depth + 1);
                    } else if (onStack.has(next)) {
                        markCycleFrom(next);
                    }
                }
                stack.pop();
                onStack.delete(id);
            };
            graph.forEach((_, id) => dfs(id));

            let issuesCount = 0;
            entries.forEach(entry => {
                const issues = [];
                if (!entry.idNorm.numericStr) {
                    issues.push('ID manquant ou invalide');
                } else if (idCounts.get(entry.idNorm.numericStr) > 1) {
                    issues.push('ID dupliqué');
                } else if (cycleIds.has(entry.idNorm.numericStr)) {
                    issues.push('Cycle {loadmoduleid} détecté');
                }
                let hasExistingConflict = false;
                if (entry.idNorm.numericStr && existingIdCache.has(entry.idNorm.numericStr)) {
                    const existing = existingIdCache.get(entry.idNorm.numericStr);
                    if (existing && existing.title) {
                        hasExistingConflict = true;
                    }
                }

                const refDetails = entry.refs.map(id => {
                    const isAllowedExternal = allowedExternalRefs.has(String(id));
                    const legacyForRef = renumberInverse.get(String(id));
                    const targets = idToEntries.get(id) || [];
                    if (targets.length === 0) {
                        const externalTitle = externalModuleCache.get(id)?.title;
                        const externalInfo = existingIdCache.get(String(id));
                        const externalExists = !!(externalInfo && externalInfo.title);
                        const suffix = isAllowedExternal
                            ? 'EXTERNE AUTORISÉ'
                            : (externalExists ? 'EXTERNE OK' : 'EXTERNE');
                        const titleText = externalTitle || externalInfo?.title;
                        const base = titleText ? `${id} -> ${titleText} (${suffix})` : `${id} -> ${suffix}`;
                        const label = legacyForRef ? `${legacyForRef} -> ${base}` : base;
                        if (isAllowedExternal) {
                            return { id, status: 'external-allowed', label, targets };
                        }
                        return { id, status: externalExists ? 'external-ok' : 'external', label, targets };
                    }
                    if (targets.length === 1) {
                        const targetTitle = targets[0].title || 'Sans titre';
                        const base = `${id} -> ${targetTitle}`;
                        const label = legacyForRef ? `${legacyForRef} -> ${base}` : base;
                        return { id, status: 'ok', label, targets };
                    }
                    const names = targets.map(t => t.title || 'Sans titre');
                    const preview = names.slice(0, 2).join(', ') + (names.length > 2 ? ' ...' : '');
                    const base = `${id} -> MULTIPLE (${preview})`;
                    const label = legacyForRef ? `${legacyForRef} -> ${base}` : base;
                    return { id, status: 'duplicate-target', label, targets };
                });

                const missing = refDetails.filter(r => r.status === 'external').map(r => r.id);
                if (missing.length) {
                    issues.push(`Références externes: ${Array.from(new Set(missing)).join(', ')}`);
                }

                const ambiguous = refDetails.filter(r => r.status === 'duplicate-target').map(r => r.id);
                if (ambiguous.length) {
                    issues.push(`Références ambiguës (ID dupliqué): ${Array.from(new Set(ambiguous)).join(', ')}`);
                }

                if (entry.idNorm.numericStr && entry.refs.includes(entry.idNorm.numericStr)) {
                    issues.push(`Auto-référence: {loadmoduleid ${entry.idNorm.numericStr}}`);
                }

                entry.issues = issues;
                entry.issuesDisplay = issues;
                entry.hasIssues = issues.length > 0 || hasExistingConflict;
                entry.refDetails = refDetails;
                entry.missingRefs = missing;
                if (entry.hasIssues) issuesCount++;
            });

            return { entries, idCounts, missingRefs, issuesCount, idToEntries };
        };
        const escapeSelectorValue = (value) => {
            if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(value);
            return String(value).replace(/["\\]/g, '\\$&');
        };
        const updateModuleIdDisplay = (fileName, moduleIndex, value) => {
            const safeFileName = escapeSelectorValue(fileName);
            const selector = `.module-id-display[data-file-name="${safeFileName}"][data-module-index="${moduleIndex}"]`;
            const el = document.querySelector(selector);
            if (el) {
                const display = value && String(value).trim() ? value : 'N/A';
                el.textContent = `#${display}`;
            }
        };
        const renderIdEditor = () => {
            const list = document.getElementById('id-editor-list');
            const statsEl = document.getElementById('id-editor-stats');
            if (!list) return;

            const diag = computeIdDiagnostics();
            if (!diag.entries.length) {
                list.innerHTML = '<div class="alert alert-info py-2 m-0 small"><span class="icon-info me-2"></span>Aucun module détecté</div>';
                if (statsEl) statsEl.textContent = '';
                return;
            }

            const moduleOptions = buildModuleOptions();
            const entryMap = new Map(diag.entries.map(e => [`${e.fileName}::${e.index}`, e]));
            const html = diag.entries.map(entry => {
                const displayId = entry.idNorm.raw || '';
                const legacyId = entry.legacyId;
                const issuesText = (entry.issuesDisplay || entry.issues || []).join(' · ');
                const hasIssues = !!entry.hasIssues;
                const refsRowsHtml = buildRefRowsHtml(entry, moduleOptions);
                const hasRefs = refsRowsHtml.length > 0;
                const rowClasses = hasIssues ? 'is-alert' : 'is-ok';
                return `
                    <div class="id-editor-item ${rowClasses}" data-file-name="${entry.fileName}" data-module-index="${entry.index}">
                        <div class="d-flex align-items-center gap-2">
                            <input type="text" class="form-control form-control-sm id-editor-input" value="${displayId}"
                                   data-file-name="${entry.fileName}" data-module-index="${entry.index}" data-prev-numeric-id="${entry.idNorm.numericStr || ''}"
                                   placeholder="ID..." style="max-width: 120px;">
                            <div class="small text-body fw-medium text-truncate" style="max-width: 55%;" title="${entry.title}">
                                ${entry.title}
                            </div>
                        </div>
                        <div class="id-editor-legacy small text-muted mt-1 ${legacyId ? '' : 'd-none'}">Ancien ID: ${legacyId || ''}</div>
                        <div class="id-editor-refs small text-muted mt-1 ${hasRefs ? '' : 'd-none'}">
                            <div class="id-editor-refs-title">Refs</div>
                            <div class="id-editor-refs-list">${refsRowsHtml}</div>
                        </div>
                        <div class="id-editor-issues small text-danger mt-1 ${issuesText ? '' : 'd-none'}">${issuesText}</div>
                    </div>
                `;
            }).join('');

            list.innerHTML = html;
            list.querySelectorAll('.id-editor-item').forEach(item => {
                const key = `${item.dataset.fileName}::${item.dataset.moduleIndex}`;
                const entry = entryMap.get(key);
                scheduleOkHighlight(item, entry ? entry.hasIssues : false);
            });

            if (statsEl) {
                const total = diag.entries.length;
                const idsCount = diag.idCounts.size;
                statsEl.textContent = `Modules: ${total} · IDs valides: ${idsCount} · Problèmes: ${diag.issuesCount}`;

                const missingExt = diag.missingRefs ? diag.missingRefs.size : 0;
                const missingList = diag.missingRefs ? Array.from(diag.missingRefs).slice(0, 10) : [];
                const issueSamples = diag.entries
                    .filter(e => e.hasIssues)
                    .slice(0, 5)
                    .map(e => {
                        const id = e.idNorm && e.idNorm.numericStr ? e.idNorm.numericStr : 'N/A';
                        const issuesText = (e.issuesDisplay || e.issues || []).join(' · ');
                        return `#${id} ${e.title || ''} → ${issuesText}`;
                    });

                const items = [
                    `Modules analysés: ${total}`,
                    `IDs uniques: ${idsCount}`,
                    `Problèmes: ${diag.issuesCount}`,
                    `Références externes manquantes: ${missingExt}`
                ];
                if (missingList.length) {
                    items.push(`IDs externes (extraits): ${missingList.join(', ')}`);
                }
                if (issueSamples.length) {
                    items.push('Exemples:');
                    issueSamples.forEach(s => items.push(`- ${s}`));
                }

                showInfoPanel('Étape 3 • IDs', items, { section: 'import-diag', replace: true });
            }

            const toggle = document.getElementById('toggle-id-editor');
            const section = document.getElementById('id-editor-section');
            if (toggle && section && diag.issuesCount > 0 && !idEditorUserToggled) {
                toggle.checked = true;
                section.classList.remove('d-none');
            }

            prefetchExternalModules(Array.from(diag.missingRefs));
            prefetchExistingIds(Array.from(new Set([...diag.idCounts.keys(), ...diag.missingRefs])));
            fetchMaxExistingModuleId();
        };
        const refreshIdEditor = () => {
            const list = document.getElementById('id-editor-list');
            if (!list) return;
            const diag = computeIdDiagnostics();
            const statsEl = document.getElementById('id-editor-stats');

            if (!diag.entries.length) {
                list.innerHTML = '<div class="alert alert-info py-2 m-0 small"><span class="icon-info me-2"></span>Aucun module détecté</div>';
                if (statsEl) statsEl.textContent = '';
                return;
            }

            const entryMap = new Map(diag.entries.map(e => [`${e.fileName}::${e.index}`, e]));
            const moduleOptions = buildModuleOptions();
            list.querySelectorAll('.id-editor-item').forEach(item => {
                const key = `${item.dataset.fileName}::${item.dataset.moduleIndex}`;
                const entry = entryMap.get(key);
                if (!entry) return;
                const issuesEl = item.querySelector('.id-editor-issues');
                const refsEl = item.querySelector('.id-editor-refs');
                const legacyEl = item.querySelector('.id-editor-legacy');
                const input = item.querySelector('.id-editor-input');
                const hasIssues = !!entry.hasIssues;
                const refsRowsHtml = buildRefRowsHtml(entry, moduleOptions);
                const hasRefs = refsRowsHtml.length > 0;
                item.classList.toggle('is-alert', hasIssues);
                item.classList.toggle('is-ok', !hasIssues);
                if (refsEl) {
                    if (hasRefs) {
                        refsEl.innerHTML = `<div class="id-editor-refs-title">Refs</div><div class="id-editor-refs-list">${refsRowsHtml}</div>`;
                        refsEl.classList.remove('d-none');
                    } else {
                        refsEl.textContent = '';
                        refsEl.classList.add('d-none');
                    }
                }
                if (legacyEl) {
                    if (entry.legacyId) {
                        legacyEl.textContent = `Ancien ID: ${entry.legacyId}`;
                        legacyEl.classList.remove('d-none');
                    } else {
                        legacyEl.textContent = '';
                        legacyEl.classList.add('d-none');
                    }
                }
                if (issuesEl) {
                    const displayIssues = (entry.issuesDisplay || entry.issues || []).join(' · ');
                    if (displayIssues) {
                        issuesEl.textContent = displayIssues;
                        issuesEl.classList.remove('d-none');
                    } else {
                        issuesEl.textContent = '';
                        issuesEl.classList.add('d-none');
                    }
                }
                if (input) {
                    input.classList.toggle('is-alert', hasIssues);
                }
                scheduleOkHighlight(item, hasIssues);
            });

            if (statsEl) {
                const total = diag.entries.length;
                const idsCount = diag.idCounts.size;
                statsEl.textContent = `Modules: ${total} · IDs valides: ${idsCount} · Problèmes: ${diag.issuesCount}`;
            }

            prefetchExternalModules(Array.from(diag.missingRefs));
            prefetchExistingIds(Array.from(new Set([...diag.idCounts.keys(), ...diag.missingRefs])));
            fetchMaxExistingModuleId();
        };
        const applyLoadModuleIdMapping = (mapping) => {
            if (!mapping || Object.keys(mapping).length === 0) return;
            parsedFilesModules.forEach((modules) => {
                modules.forEach(item => replaceLoadModuleIdsInItem(item, mapping));
            });
        };
        let idEditorRefreshTimer = null;
        const scheduleIdEditorRefresh = () => {
            if (idEditorRefreshTimer) clearTimeout(idEditorRefreshTimer);
            idEditorRefreshTimer = setTimeout(() => {
                refreshIdEditor();
                idEditorRefreshTimer = null;
            }, 150);
        };
        const renumberModulesFromBase = async () => {
            const statusEl = document.getElementById('id-renumber-status');
            if (statusEl) {
                statusEl.textContent = 'Renumérotation en cours...';
                statusEl.classList.remove('d-none');
            }

            const maxId = await fetchMaxExistingModuleId(true);
            if (!Number.isFinite(maxId)) {
                if (statusEl) {
                    statusEl.textContent = 'Renumérotation auto: Max ID base indisponible.';
                    statusEl.classList.remove('d-none');
                }
                return false;
            }
            const startId = (maxId || 0) + 1;

            const diag = computeIdDiagnostics();
            if (!diag.entries.length) {
                if (statusEl) statusEl.textContent = 'Aucun module à renuméroter.';
                return false;
            }

            const idCounts = diag.idCounts;
            const mapping = {};
            const duplicateOldIds = new Set();
            const assigned = new Map();
            let nextId = startId;

            diag.entries.forEach(entry => {
                const key = `${entry.fileName}::${entry.index}`;
                assigned.set(key, nextId++);
            });

            diag.entries.forEach(entry => {
                const key = `${entry.fileName}::${entry.index}`;
                const newId = assigned.get(key);
                if (entry.idNorm.numericStr) {
                    setModuleLegacyId(entry.item, parseInt(entry.idNorm.numericStr, 10));
                }
                setModuleOriginalId(entry.item, newId);

                const oldId = entry.idNorm.numericStr;
                if (oldId && idCounts.get(oldId) === 1) {
                    mapping[oldId] = String(newId);
                } else if (oldId) {
                    duplicateOldIds.add(oldId);
                }

                updateModuleIdDisplay(entry.fileName, entry.index, newId);
            });

            applyLoadModuleIdMapping(mapping);
            lastRenumberMapping = { ...mapping };
            existingIdCache.clear();

            renderIdEditor();

            if (statusEl) {
                if (duplicateOldIds.size > 0) {
                    statusEl.textContent = `Renumérotation OK. Références non modifiées pour IDs dupliqués: ${Array.from(duplicateOldIds).join(', ')}`;
                } else {
                    statusEl.textContent = `Renumérotation OK à partir de ${startId}.`;
                }
            }
            return true;
        };
        const handleIdEditorInputChange = (input) => {
            const fileName = input.dataset.fileName;
            const moduleIndex = parseInt(input.dataset.moduleIndex, 10);
            const prevNumeric = input.dataset.prevNumericId || '';
            const nextNorm = normalizeIdValue(input.value);

            const modules = parsedFilesModules.get(fileName);
            if (!modules || !modules[moduleIndex]) return;

            if (nextNorm.numericStr) {
                setModuleOriginalId(modules[moduleIndex], parseInt(nextNorm.numericStr, 10));
                if (prevNumeric && prevNumeric !== nextNorm.numericStr) {
                    applyLoadModuleIdMapping({ [prevNumeric]: nextNorm.numericStr });
                }
                input.dataset.prevNumericId = nextNorm.numericStr;
            } else {
                const raw = nextNorm.raw || null;
                setModuleOriginalId(modules[moduleIndex], raw);
            }

            const display = nextNorm.numericStr || nextNorm.raw || 'N/A';
            updateModuleIdDisplay(fileName, moduleIndex, display);
            scheduleIdEditorRefresh();
        };

        // Global helper to strip HTML
        const stripHtml = (html) => {
            const doc = new DOMParser().parseFromString(html, 'text/html');
            return doc.body.textContent || "";
        };

        // Function to fetch content from specific modules
        const fetchTargetModulesContent = async () => {
            const targetModules = ['Titre', 'Titre principal', 'Nom du service', 'Logo Marianne (En Tête)', 'Logo opérateur'];
            let allContent = '';

            for (const moduleName of targetModules) {
                try {
                    log(`[AUTODETECT] Recherche du module "${moduleName}"...`);
                    const searchData = await postJson('module.searchbytitle', { title: moduleName });
                    log(`[AUTODETECT] Résultat de recherche pour "${moduleName}":`, searchData);

                    if (searchData.success && searchData.data && searchData.data.id) {
                        const moduleId = searchData.data.id;
                        log(`[AUTODETECT] Module "${moduleName}" trouvé(ID: ${moduleId})`);
                        const contentData = await postJson('module.getcontent', { id: moduleId });
                        if (contentData.success && contentData.data && contentData.data.content) {
                            allContent += ' ' + (contentData.data.content || '');
                            log(`[AUTODETECT] Contenu du module "${moduleName}" récupéré`);
                        }
                    } else {
                        log(`[AUTODETECT] Module "${moduleName}" non trouvé`);
                    }
                } catch (err) {
                    log(`[AUTODETECT] Erreur lors de la récupération du module "${moduleName}": `, err);
                }
            }

            return allContent;
        };

        // Fonction générique pour pré-remplir un champ depuis une source (titre de module ou ID)
        const prefillFieldFromSource = async (targetFieldId, source, labelBaseText) => {
            log(`[PREFILL] Tentative de pré - remplissage pour le champ #${targetFieldId} depuis la source`, source);
            const csrfParam = getCsrfParam();
            let moduleId;
            let searchData = null;
            try {
                if (source.type === 'title') {
                    log(`[PREFILL] Recherche du module par titre: "${source.value}"`);
                    searchData = await postJson('module.searchbytitle', { title: source.value });
                    log(`[PREFILL] Résultat de recherche pour "${source.value}":`, searchData);
                    if (searchData.success && searchData.data && searchData.data.id) {
                        moduleId = searchData.data.id;
                    }
                } else if (source.type === 'id') {
                    log(`[PREFILL] Utilisation directe de l'ID de module: ${source.value}`);
                    moduleId = source.value;
                }

                if (moduleId) {
                    const foundTitle = searchData?.data?.title || null;
                    const expectedTitle = 'Titre';
                    const label = modal.querySelector(`label[for="${targetFieldId}"]`);
                    if (label && labelBaseText) label.textContent = `${labelBaseText} (ID: ${moduleId})`;

                    // Renommage automatique si le module n'est pas titré "Titre"
                    if (targetFieldId === 'main-title-replace-value' && foundTitle && foundTitle !== expectedTitle) {
                        log(`[PREFILL] Renommage automatique "${foundTitle}" → "${expectedTitle}"`);
                        postJson('module.renamemodule', { id: moduleId, newtitle: expectedTitle })
                            .catch(err => log('[PREFILL] Erreur renommage automatique:', err));
                    }

                    log(`[PREFILL] Module trouvé (ID: ${moduleId}). Récupération du contenu...`);
                    const contentData = await postJson('module.getcontent', { id: moduleId });

                    if (contentData.success && contentData.data && contentData.data.content) {
                        const rawContent = contentData.data.content || '';
                        log(`[PREFILL] Contenu HTML brut (${rawContent.length} caractères):`, rawContent.substring(0, 200));

                        let plainTextContent = '';

                        if (targetFieldId === 'main-title-replace-value') {
                            // Extraction via DOMParser : classe service-title si présente, sinon texte brut
                            const doc = new DOMParser().parseFromString(rawContent, 'text/html');
                            const serviceTitle = doc.querySelector('.fr-header__service-title, [class*="service-title"]');
                            plainTextContent = serviceTitle
                                ? serviceTitle.textContent.trim()
                                : doc.body.textContent.replace(/\s+/g, ' ').trim();
                            log(`[PREFILL] Titre extrait (${serviceTitle ? 'via classe' : 'texte brut'}): "${plainTextContent}"`);
                        } else {
                            let cleanContent = rawContent
                                .replace(/<br\s*\/?>/gi, '___LINEBREAK___')
                                .replace(/<\/(p|div|h[1-6]|li|a)>/gi, ' ')
                                .replace(/<(p|div|h[1-6]|li|a)[^>]*>/gi, ' ');
                            plainTextContent = stripHtml(cleanContent)
                                .replace(/___LINEBREAK___/g, '<br>')
                                .replace(/\s+/g, ' ')
                                .replace(/ <br> /g, '<br>')
                                .trim()
                                .replace(/^<br>/i, '')
                                .replace(/<br>$/i, '');
                        }

                        log(`[PREFILL] Contenu nettoyé pour #${targetFieldId}: "${plainTextContent}"`);
                        const targetField = modal.querySelector('#' + targetFieldId);
                        if (targetField) targetField.value = plainTextContent;
                    } else {
                        log(`[PREFILL] Échec de la récupération du contenu pour le module ID ${moduleId}`);
                    }
                } else {
                    log(`[PREFILL] Source non trouvée pour le champ #${targetFieldId}`, source);
                }
            } catch (err) {
                log(`[PREFILL] Erreur lors du pré-remplissage pour #${targetFieldId}:`, err);
            }
        };

        // Function to update fields with detected replacements
        function updateQuickReplaceFieldsWithDetections() {
            const quickReplaceFieldsContainer = modal.querySelector('#quick-replace-fields');
            if (!quickReplaceFieldsContainer) {
                console.warn('[QUICK-REPLACE] Container #quick-replace-fields non trouvé');
                return;
            }

            log('[QUICK-REPLACE] Initialisation des champs détectés automatiquement');
            log('[QUICK-REPLACE] detectedReplacements:', Array.from(detectedReplacements));
            log('[QUICK-REPLACE] Taille:', detectedReplacements.size);

            let dynamicHtml = '';

            // AJOUT DES CHAMPS DÉTECTÉS AUTOMATIQUEMENT UNIQUEMENT
            if (detectedReplacements.size > 0) {
                dynamicHtml += '<h6 class="mb-3 fw-bold text-body small text-uppercase">Titres détectés automatiquement depuis l\'intranet</h6>';
                dynamicHtml += '<p class="text-muted small mb-3">Détectés dans les modules "Titre", "Logo Marianne (En Tête)" et "Logo opérateur"</p>';

                let detectedIndex = 0;
                detectedReplacements.forEach(textToFind => {
                    const findTextId = `quick-replace-detected-${detectedIndex}`;
                    log(`[QUICK-REPLACE] Création champ ${detectedIndex}: "${textToFind}"`);
                    dynamicHtml += `
                        <div class="mb-3">
                            <label for="${findTextId}" class="form-label small fw-bold text-muted">Remplacer "${textToFind}" par :</label>
                            <input type="text" id="${findTextId}" class="form-control"
                                   placeholder="Nouvelle valeur..."
                                   data-find-text="${encodeURIComponent(textToFind)}">
                        </div>
                    `;
                    detectedIndex++;
                });

                log('[QUICK-REPLACE] ✅', detectedIndex, 'champs créés');
            } else {
                log('[QUICK-REPLACE] ⚠ Aucune détection automatique - Section vide');
                dynamicHtml = '<p class="text-muted small fst-italic">Aucun élément détecté automatiquement. Les champs Titre, Baseline et Autorité ci-dessous sont disponibles pour modification manuelle.</p>';
            }

            // Remplacer tout le contenu
            quickReplaceFieldsContainer.innerHTML = dynamicHtml;
            log('[QUICK-REPLACE] Container mis à jour');
        }

        // ✅ LANCEMENT DE LA DÉTECTION AUTOMATIQUE (après déclaration des fonctions)
        // Lancer la détection automatique des mots-clés au démarrage
        (async () => {
            if (AUTODETECT_KEYWORDS && AUTODETECT_KEYWORDS.length > 0) {
                log('[AUTODETECT] Démarrage de la détection automatique avec', AUTODETECT_KEYWORDS.length, 'mots-clés');
                try {
                    const content = await fetchTargetModulesContent();
                    if (content) {
                        const plainContent = stripHtml(content).toLowerCase();
                        log('[AUTODETECT] Contenu récupéré (longueur:', plainContent.length, ')');

                        AUTODETECT_KEYWORDS.forEach(keyword => {
                            if (keyword && plainContent.includes(keyword.toLowerCase())) {
                                detectedReplacements.add(keyword);
                                log('[AUTODETECT] ✓ Mot-clé détecté:', keyword);
                            } else {
                                log('[AUTODETECT] ✗ Mot-clé non trouvé:', keyword);
                            }
                        });

                        log('[AUTODETECT] Détection terminée. Total détecté:', detectedReplacements.size);

                        // ✅ AJOUT : Mise à jour immédiate de l'interface après détection
                        updateQuickReplaceFieldsWithDetections();

                    } else {
                        log('[AUTODETECT] Aucun contenu récupéré');
                    }
                } catch (err) {
                    log('[AUTODETECT] Erreur:', err);
                }
            } else {
                log('[AUTODETECT] Aucun mot-clé configuré dans les paramètres du plugin');
            }

            // ✅ AJOUT : Pré-remplissage des champs TITRE et AUTORITÉ
            // Pré-remplir le champ "Titre principal" depuis le module "Titre"
            await prefillFieldFromSource(
                'main-title-replace-value',
                { type: 'title', value: 'Titre' },
                'Titre principal'
            );

            // Note : La baseline n'existe pas sur l'intranet, elle sera dans le JSON importé
            // L'utilisateur pourra la modifier manuellement dans le champ baseline

            // Pré-remplir le champ "Autorité" depuis le module "Logo Marianne (En Tête)"
            await prefillFieldFromSource(
                'prefet-title-replace-value',
                { type: 'title', value: 'Logo Marianne (En Tête)' },
                'Autorité'
            );

            log('[PREFILL] Pré-remplissage des champs terminé');
        })();


        // Gestion de la sélection de fichiers
        fileInput.addEventListener('change', handleFiles);

        // Bouton "Parcourir" pour ouvrir le sélecteur de fichiers
        modal.querySelector('#browse-files-btn')?.addEventListener('click', () => {
            fileInput.click();
        });

        // ============================================
        // GESTION DU DRAG & DROP (Étape 3)
        // ============================================
        const importDropZone = modal.querySelector('.file-drop-zone');
        if (importDropZone) {
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                importDropZone.addEventListener(eventName, preventDefaults, false);
            });

            function preventDefaults(e) {
                e.preventDefault();
                e.stopPropagation();
            }

            ['dragenter', 'dragover'].forEach(eventName => {
                importDropZone.addEventListener(eventName, highlight, false);
            });

            ['dragleave', 'drop'].forEach(eventName => {
                importDropZone.addEventListener(eventName, unhighlight, false);
            });

            function highlight(e) {
                importDropZone.classList.add('border-primary');
                importDropZone.classList.add('bg-light');
            }

            function unhighlight(e) {
                importDropZone.classList.remove('border-primary');
                importDropZone.classList.remove('bg-light');
            }

            importDropZone.addEventListener('drop', handleDrop, false);

            function handleDrop(e) {
                const dt = e.dataTransfer;
                const files = dt.files;

                // Mettre à jour l'input file (optionnel, mais bon pour la cohérence)
                if (files.length > 0) {
                    fileInput.files = files;
                    handleFiles(); // Appeler la fonction de traitement existante
                }
            }
        }

        let validFilesCount = 0; // Suivi des fichiers valides (locaux ou URL)
        let defaultFileData = null; // ✅ Stocke les données du template par défaut
        let filesCurrentlyProcessing = 0; // Suivi des fichiers en cours de lecture par FileReader


        // ============================================
        // CHARGEMENT AUTOMATIQUE DU TEMPLATE PAR DÉFAUT
        // ============================================

        /**
         * Charge automatiquement le fichier JSON DSFR par défaut au démarrage de l'étape 3
         */
        function loadDefaultTemplate() {
            // Ne charger que si aucun fichier n'est déjà chargé
            if (validFilesCount > 0) {
                log('[AUTO-LOAD] ℹ️ Fichiers déjà chargés, pas de chargement automatique');
                return;
            }

            log('[AUTO-LOAD] 🔄 Chargement du template DSFR par défaut...');

            // Utiliser la constante injectée par PHP ou un fallback
            const defaultJsonUrl = (typeof DEFAULT_JSON_URL !== 'undefined')
                ? DEFAULT_JSON_URL
                : window.location.origin + '/plugins/system/moduleexport/assets/json/export_modules_dsfr.json';

            fetch(defaultJsonUrl, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json'
                }
            })
                .then(response => {
                    if (!response.ok) {
                        console.warn('[AUTO-LOAD] ⚠️ Template par défaut non trouvé, mode manuel uniquement');
                        return null;
                    }
                    return response.json();
                })
                .then(jsonData => {
                    if (!jsonData) return;

                    log('[AUTO-LOAD] ✅ Template chargé avec succès');

                    // Vérifier la structure du JSON et extraire les modules proprement
                    // IMPORTANT : Préserver la structure wrapper {moduleId, module: {...}} pour le mapping côté serveur
                    let modules = [];
                    if (Array.isArray(jsonData)) {
                        modules = jsonData;
                    } else if (jsonData?.modules) {
                        modules = jsonData.modules;
                    } else if (jsonData?.module || jsonData?.title) {
                        modules = [jsonData];
                    }

                    if (modules.length === 0) {
                        console.warn('[AUTO-LOAD] ⚠️ Aucun module détecté dans le template');
                        return;
                    }

                    // Créer un objet File simulé
                    const defaultFile = {
                        name: 'export_modules_dsfr.json',
                        size: JSON.stringify(jsonData).length,
                        type: 'application/json',
                        isDefault: true,
                        jsonContent: jsonData,
                        modules: modules
                    };

                    defaultFileData = defaultFile; // ✅ Sauvegarder globalement pour l'import

                    log(`[AUTO-LOAD] 📦 ${modules.length} module(s) détecté(s)`);

                    // Traiter le fichier par défaut
                    processDefaultFile(defaultFile);
                })
                .catch(error => {
                    log('[AUTO-LOAD] ❌ Erreur de chargement:', error);
                    // Mode silencieux : si le template n'existe pas, on continue en mode manuel
                });
        }

        // Helper pour afficher/masquer la zone de drop
        function toggleDropZone(show) {
            // Cible le conteneur global qui inclut le titre et la zone
            const container = modal.querySelector('#drop-zone-container');
            if (container) {
                if (show) {
                    container.classList.remove('d-none');
                } else {
                    container.classList.add('d-none');
                }
            }
        }

        /**
         * Traite le fichier JSON par défaut et met à jour l'interface
         * @param {Object} defaultFile - Objet contenant les données du fichier par défaut
         */
        function processDefaultFile(defaultFile) {
            const filePreviewList = modal.querySelector('#file-preview-list');

            if (!filePreviewList) {
                log('[AUTO-LOAD] ❌ Élément #file-preview-list introuvable');
                return;
            }

            log('[AUTO-LOAD] 🎨 Création de la carte fichier...');

            // Masquer la zone de drop pour gagner de la place
            toggleDropZone(false);

            // S'assurer que la liste est visible
            filePreviewList.classList.remove('d-none');

            // (Message d'alerte supprimé à la demande de l'utilisateur)

            // Compter les modules
            const modulesCount = defaultFile.modules.length;
            const htmlStats = getHtmlStats(defaultFile.modules);

            // Créer la carte de preview avec badge "Template DSFR"
            const fileCard = document.createElement('div');
            fileCard.className = 'file-preview-card border rounded-3 p-3 mb-2';
            fileCard.dataset.fileName = defaultFile.name;
            fileCard.dataset.isDefault = 'true';
            fileCard.style.background = 'transparent';
            fileCard.style.borderColor = 'rgba(0, 0, 0, 0.08)';

            fileCard.innerHTML = `
                <div class="d-flex align-items-center justify-content-between">
                    <div class="flex-grow-1 overflow-hidden">
                        <div class="d-flex align-items-center mb-1">
                            <span class="icon-file-2 text-muted me-3 fs-4"></span>
                            <div class="overflow-hidden">
                                <div class="text-truncate fw-bold text-body" style="max-width: 90%;" title="${escapeHtml(defaultFile.name)}">
                                    ${escapeHtml(defaultFile.name)}
                                </div>
                                <div class="mt-1 small text-muted d-flex align-items-center gap-2">
                                    <span>${formatFileSize(defaultFile.size)}</span>
                                    <span class="badge bg-success" style="font-size:0.6em;">HTML OK (${htmlStats.withHtml}/${htmlStats.total})</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div role="button" class="text-danger p-2 cursor-pointer opacity-75 hover-opacity-100" data-action="remove-file" title="Retirer ce fichier" style="cursor: pointer;">
                        <span class="icon-cancel fs-5"></span>
                    </div>
                </div>
            `;

            // =========================================
            // GÉRER LE RETRAIT DU FICHIER
            // =========================================
            fileCard.querySelector('[data-action="remove-file"]').addEventListener('click', () => {
                log('[AUTO-LOAD] 🗑️ Retrait du template par défaut');

                // Retirer de l'interface
                fileCard.remove();

                // Retirer le message informatif s'il existe
                const infoMsg = filePreviewList.parentElement.querySelector('.alert-info');
                if (infoMsg) infoMsg.remove();

                // Retirer des données
                parsedFilesModules.delete(defaultFile.name);
                defaultFileData = null; // ✅ Reset global
                validFilesCount--; // ✅ IMPORTANT : Décrémenter le compteur

                log(`[AUTO-LOAD] ℹ️ validFilesCount après retrait: ${validFilesCount}`);

                // Mettre à jour l'interface
                updateActionButtonsState();

                // Masquer la liste si vide et RÉAFFICHER LA DROP ZONE
                if (validFilesCount === 0) {
                    filePreviewList.classList.add('d-none');
                    toggleDropZone(true); // Réafficher la drop zone pour permettre un nouveau drop

                    // Vider la liste des modules
                    const moduleList = document.getElementById('module-checkbox-list');
                    if (moduleList) moduleList.innerHTML = '';
                }
            });

            // Ajouter la carte à la liste
            filePreviewList.appendChild(fileCard);

            // =========================================
            // MISE À JOUR DES DONNÉES GLOBALES
            // =========================================

            // ✅ Incrémenter le compteur de fichiers valides
            validFilesCount++;
            log(`[AUTO-LOAD] ℹ️ validFilesCount: ${validFilesCount}`);

            // ✅ Ajouter les modules à la Map globale (requis pour renderModuleSelector)
            parsedFilesModules.set(defaultFile.name, defaultFile.modules);
            log(`[AUTO-LOAD] ✅ ${defaultFile.modules.length} modules ajoutés à parsedFilesModules`);
            if (menuAdjustmentEnabled) {
                applyMenuAdjustmentToModules(defaultFile.modules, defaultFile.name, true);
            }

            // =========================================
            // AFFICHAGE DES OPTIONS
            // =========================================

            // ✅ Mettre à jour l'état des boutons et afficher le panel d'options
            updateActionButtonsState();
            log('[AUTO-LOAD] ✅ Panel d\'options affiché');

            // ✅ Peupler la liste des modules pour "Choisir les modules"
            moduleSelectorTouched = false;
            renderModuleSelector();
            log('[AUTO-LOAD] ✅ Liste des modules peuplée');
            autoRenumberIfNeeded();

            // Logs finaux
            log('[AUTO-LOAD] 🎉 Chargement automatique terminé avec succès');
            log(`[AUTO-LOAD] 📊 État: ${validFilesCount} fichier(s), ${defaultFile.modules.length} module(s)`);
        }

        function handleFiles() {
            const files = Array.from(fileInput.files);

            if (files.length === 0) return;

            step3Log(`📁 ${files.length} fichier(s) sélectionné(s)`);
            files.forEach((f, idx) => {
                step3Log(`Fichier ${idx + 1}:`, { name: f.name, size: f.size, type: f.type });
            });

            // ✅ Si un fichier par défaut est chargé, le retirer automatiquement
            const defaultFileCard = filePreviewList.querySelector('[data-is-default="true"]');
            if (defaultFileCard) {
                const defaultFileName = defaultFileCard.dataset.fileName;

                log('[FILE-SELECT] 🔄 Retrait du template par défaut avant chargement des nouveaux fichiers...');

                // Retirer le message informatif
                const infoMsg = filePreviewList.parentElement.querySelector('.alert-info');
                if (infoMsg) infoMsg.remove();

                // Retirer des données
                parsedFilesModules.delete(defaultFileName);

                log('[FILE-SELECT] ✅ Template par défaut retiré, chargement des nouveaux fichiers');
            }

            const invalidFiles = files.filter(file => !file.name.toLowerCase().endsWith('.json'));

            filePreviewList.innerHTML = '';
            validFilesCount = 0;
            filesCurrentlyProcessing = 0;
            lastRenumberMapping = null;
            moduleSelectorTouched = false;

            if (invalidFiles.length > 0) {
                step3Warn('Fichiers invalides détectés:', invalidFiles.map(f => f.name));
                alert(`Action annulée. Un ou plusieurs fichiers ne sont pas des JSON valides :\n\n- ${invalidFiles.map(f => f.name).join('\n- ')}\n\nVeuillez sélectionner uniquement des fichiers avec l'extension .json.`);
                fileInput.value = '';
                filePreviewList.classList.add('d-none');
                document.getElementById('find-replace-container')?.classList.add('d-none');
                confirmBtn.disabled = true;
                return;
            }

            if (files.length > 0) {
                filePreviewList.classList.remove('d-none');
                // Style de la liste parente V4
                filePreviewList.className = 'my-4 rounded-3 p-0 border-0';
                filePreviewList.style.backgroundColor = 'transparent';

                files.forEach(file => {
                    filesCurrentlyProcessing++;
                    const reader = new FileReader();

                    // Création de l'élément de prévisualisation
                    const filePreviewItem = document.createElement('div');
                    filePreviewItem.className = 'd-flex justify-content-between align-items-center p-3 file-preview-item';
                    filePreviewItem.dataset.fileName = file.name;
                    filePreviewItem.innerHTML = `
                        <div class="d-flex align-items-center flex-grow-1 overflow-hidden">
                            <span class="icon-file-code text-primary me-3 fs-3"></span>
                            <div class="overflow-hidden">
                                <div class="text-body fw-bold text-truncate" title="${escapeHtml(file.name)}">${escapeHtml(file.name)}</div>
                                <div class="file-info small text-secondary d-flex align-items-center gap-2">
                                    <span>${formatFileSize(file.size)}</span>
                                    <span class="file-status-detail">Chargement...</span>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex align-items-center gap-3">
                            <button type="button" class="remove-file-btn" data-remove-file="${file.name}" title="Supprimer ce fichier">
                                <span class="icon-cancel"></span>
                            </button>
                        </div>
                    `;

                    filePreviewList.appendChild(filePreviewItem);

                    reader.onload = function (e) {
                        filesCurrentlyProcessing--;
                        try {
                            step3Log(`Lecture terminée: ${file.name} (${e.target.result?.length || 0} chars)`);
                            const jsonData = parseJsonFromFileContent(e.target.result);
                            let fileModules = [];

                            if (Array.isArray(jsonData)) {
                                fileModules = jsonData; // Garder la structure telle quelle (wrapped ou pas)
                            } else if (jsonData?.modules) {
                                fileModules = jsonData.modules;
                            } else if (jsonData?.module || jsonData?.title) {
                                fileModules = [jsonData];
                            }

                            if (fileModules.length > 0) {
                                const htmlStats = getHtmlStats(fileModules);
                                validFilesCount++;
                                parsedFilesModules.set(file.name, fileModules);
                                if (menuAdjustmentEnabled) {
                                    applyMenuAdjustmentToModules(fileModules, file.name, true);
                                }

                                filePreviewItem.querySelector('.file-status-detail').innerHTML = `<span class="text-success"><span class="icon-checkmark me-1"></span>Prêt pour l'import</span> <span class="badge bg-success ms-2" style="font-size:0.6em;">HTML OK (${htmlStats.withHtml}/${htmlStats.total})</span>`;
                                step3Log(`Modules détectés: ${fileModules.length} pour ${file.name}`);
                            } else {
                                throw new Error('Aucun module trouvé.');
                            }
                        } catch (error) {
                            step3Error(`Erreur parsing ${file.name}:`, error.message);
                            const preview = (e.target.result || '').substring(0, 300);
                            if (preview) step3Warn(`Aperçu du contenu (${file.name}):`, preview);
                            filePreviewItem.querySelector('.file-status-detail').innerHTML = `<span class="text-danger"><span class="icon-warning me-1"></span>JSON invalide</span>`;
                            filePreviewItem.querySelector('.icon-file-code').className = 'icon-file-code text-danger me-3 fs-3';
                        }

                        if (filesCurrentlyProcessing === 0) {
                            // Masquer la zone de drop si des fichiers valides sont présents
                            if (validFilesCount > 0) {
                                toggleDropZone(false);
                            }

                            moduleSelectorTouched = false;
                            renderModuleSelector();
                            updateQuickReplaceFieldsWithDetections();
                            updateActionButtonsState();
                            autoRenumberIfNeeded();
                        }
                    };
                    reader.readAsText(file);
                });
            }
        }

        function updateActionButtonsState() {
            const systemPanel = document.getElementById('system-tools-panel');
            const replaceContainer = document.getElementById('find-replace-container');
            const toggleCssContainer = document.getElementById('toggle-user-css-container');
            const clearCacheContainer = document.getElementById('clear-joomla-cache-container');
            const idEditorContainer = document.getElementById('toggle-id-editor-container');
            const idEditorSection = document.getElementById('id-editor-section');
            const confirmButton = modal.querySelector('#confirm-import');

            if (validFilesCount > 0) {
                if (systemPanel) systemPanel.classList.remove('d-none');
                if (replaceContainer) replaceContainer.classList.remove('d-none');
                if (toggleCssContainer) toggleCssContainer.classList.remove('d-none');
                if (clearCacheContainer) clearCacheContainer.classList.remove('d-none');
                if (idEditorContainer) idEditorContainer.classList.remove('d-none');
                if (confirmButton) confirmButton.disabled = false;
            } else {
                if (systemPanel) systemPanel.classList.add('d-none');
                if (replaceContainer) replaceContainer.classList.add('d-none');
                if (toggleCssContainer) toggleCssContainer.classList.add('d-none');
                if (clearCacheContainer) clearCacheContainer.classList.add('d-none');
                if (idEditorContainer) idEditorContainer.classList.add('d-none');
                if (idEditorSection) idEditorSection.classList.add('d-none');
                idEditorUserToggled = false;
                autoRenumberDone = false;
                autoRenumberPending = false;
                autoRenumberAttempts = 0;
                if (confirmButton) confirmButton.disabled = true;
            }
        }

        function renderModuleSelector() {
            const container = document.getElementById('module-checkbox-list');
            if (!container) return;

            let html = '';
            parsedFilesModules.forEach((modules, fileName) => {
                html += `<div class="mb-4 border-bottom pb-3">`;
                modules.forEach((item, modIndex) => {
                    if (modIndex === 0) log('[DIAG] Premier module du fichier:', fileName, item);

                    let mod = getModuleObject(item);

                    // Sécurité : si mod n'est pas un objet (ex: type de module string), utiliser l'item racine
                    if (!mod || typeof mod !== 'object') {
                        if (DEBUG) console.warn('[DIAG] Mod n\'est pas un objet pour index', modIndex, 'utilisant item directement');
                        mod = item;
                    }

                    const originalId = item.moduleId || mod.id || item.id || 'N/A';
                    const title = mod.title || item.title || mod.module || 'Sans titre';

                    if (modIndex === 0) log('[DIAG] Titre extrait:', title, 'ID extrait:', originalId);
                    const checkboxId = `mod-select-${fileName}-${modIndex}`;
                    const isPublished = mod.published == 1;
                    const statusBadge = isPublished
                        ? '<span class="badge bg-success me-2 publish-toggle" data-published="1" style="font-size: 0.55rem; padding: 0.25em 0.5em; cursor: pointer;" title="Cliquer pour dépublier">PUBLIÉ</span>'
                        : '<span class="badge bg-secondary me-2 publish-toggle" data-published="0" style="font-size: 0.55rem; padding: 0.25em 0.5em; cursor: pointer;" title="Cliquer pour publier">DÉPUBLIÉ</span>';

                    html += `
                        <div class="module-selection-item d-flex align-items-center p-2 rounded-2 mb-1 border-bottom border-light hover-bg-light" style="transition: background-color 0.2s;">
                            <div class="form-check small mb-0 d-flex align-items-center w-100">
                                <input class="form-check-input module-import-checkbox me-2 mt-0" type="checkbox" checked
                                       id="${checkboxId}" data-file-name="${fileName}" data-module-index="${modIndex}" style="cursor:pointer; width: 1.1rem; height: 1.1rem;">
                                ${statusBadge}
                                <label class="form-check-label d-flex align-items-center flex-grow-1 mb-0" for="${checkboxId}" style="cursor:pointer;">
                                    <span class="text-body fw-medium">${title}</span>
                                    <span class="ms-auto extra-small text-muted font-monospace module-id-display" data-file-name="${fileName}" data-module-index="${modIndex}" style="font-size: 0.65rem;">#${originalId}</span>
                                </label>
                            </div>
                        </div>
                    `;
                });
                html += `</div>`;
            });
            container.innerHTML = html || '<div class="alert alert-info py-2 m-0 small"><span class="icon-info me-2"></span>Aucun module détecté</div>';
            renderIdEditor();
        }

        document.getElementById('toggle-menu-adjustment')?.addEventListener('change', (e) => {
            menuAdjustmentEnabled = !!e.target.checked;
            applyMenuAdjustmentAll(menuAdjustmentEnabled);
        });

        const menuMappingAutoToggle = document.getElementById('toggle-menu-mapping-auto');
        const menuMappingStatus = document.getElementById('menu-mapping-status');
        const menuMappingBadge = document.getElementById('menu-mapping-badge');
        const menuMappingActions = document.querySelector('#check-menu-mapping .validation-actions');
        let menuMappingApplyBtn = null;
        const menuMappingUiHidden = false; // Badge SIMBA réactivé
        const ensureMenuMappingVisible = () => {
            if (menuMappingUiHidden) return;
            if (menuMappingActions) menuMappingActions.classList.remove('d-none');
            if (menuMappingBadge) menuMappingBadge.classList.remove('d-none');
            if (menuMappingStatus) menuMappingStatus.classList.remove('d-none');
        };
        const hideMenuMappingApply = () => {
            if (menuMappingApplyBtn) {
                menuMappingApplyBtn.classList.add('d-none');
                menuMappingApplyBtn.setAttribute('aria-hidden', 'true');
            }
        };

        let menuMappingAutoEnabled = false;
        let menuMappingAutoOnceDone = false;
        let menuMappingAutoPending = false;
        let menuMappingApplying = false;
        let menuMappingLastState = 'idle';
        let menuMappingLastDetails = '';

        const setMenuMappingStatus = (message, tone = 'muted') => {
            if (menuMappingUiHidden) return;
            if (!menuMappingStatus) return;
            if (!message) {
                menuMappingStatus.textContent = '';
                menuMappingStatus.classList.add('d-none');
                return;
            }
            ensureMenuMappingVisible();
            const toneClass = tone === 'danger' ? 'text-danger' : tone === 'success' ? 'text-success' : 'text-muted';
            menuMappingStatus.className = `validation-sub-status small ${toneClass}`;
            menuMappingStatus.textContent = message;
            menuMappingStatus.classList.remove('d-none');
        };
        const setMenuMappingBadge = (state, details = '', options = {}) => {
            if (menuMappingUiHidden) return;
            if (!menuMappingBadge) return;
            const persist = options.persist !== false;
            if (persist) {
                menuMappingLastState = state;
                menuMappingLastDetails = details || '';
            }
            if (state === 'warn') {
                menuMappingBadge.classList.remove('d-none');
                menuMappingBadge.className = 'badge badge-sig-warning';
                menuMappingBadge.textContent = details ? `SIMBA: A vérifier (${details})` : 'SIMBA: A vérifier';
            } else if (state === 'error') {
                menuMappingBadge.classList.remove('d-none');
                menuMappingBadge.className = 'badge badge-sig-error';
                menuMappingBadge.textContent = 'SIMBA: Erreur';
            } else {
                // ok ou idle : badge masqué
                menuMappingBadge.classList.add('d-none');
            }
        };

        const updateMenuMappingBadgeFromResponse = (data) => {
            const status = data?.data?.status_after || data?.data?.status || null;
            const notFoundCount = Array.isArray(data?.data?.not_found) ? data.data.not_found.length : 0;
            if (!status) {
                setMenuMappingBadge('idle', '', { persist: false });
                return;
            }
            const orderOnlyMismatch = (status.items_total > 0) &&
                (status.items_ok === status.items_total) &&
                !status.up_to_date;

            if (status.up_to_date || orderOnlyMismatch) {
                const detail = status.order_ok
                    ? `${status.items_ok}/${status.items_total}`
                    : `${status.items_ok}/${status.items_total} + ordre`;
                const extra = notFoundCount > 0 ? ` · manquants: ${notFoundCount}` : '';
                setMenuMappingBadge('ok', detail + extra);
                if (notFoundCount === 0) hideMenuMappingApply();
            } else {
                const detail = status.order_ok
                    ? `${status.items_ok}/${status.items_total}`
                    : `${status.items_ok}/${status.items_total} + ordre`;
                const extra = notFoundCount > 0 ? ` · manquants: ${notFoundCount}` : '';
                setMenuMappingBadge('warn', detail + extra);
            }
        };

        const loadMenuMappingFromUrl = async (url) => {
            const response = await fetch(url, { method: 'GET', headers: { 'Accept': 'application/json' } });
            if (!response.ok) {
                throw new Error('Fichier mapping introuvable');
            }
            const raw = await response.text();
            const parsed = JSON.parse(raw);
            if (!parsed || typeof parsed !== 'object' || !parsed.menutype || !Array.isArray(parsed.items)) {
                throw new Error('Mapping incomplet (menutype/items).');
            }
            return { raw, parsed };
        };

        const loadMenuMappingWithFallback = async () => {
            const defaultUrl = (typeof MENU_MAPPING_DEFAULT_URL !== 'undefined')
                ? MENU_MAPPING_DEFAULT_URL
                : (window.location.origin + '/plugins/system/moduleexport/assets/json/menu_mapping_simba.json');
            try {
                if (DEBUG) console.log('[SIMBA] Chargement mapping URL:', defaultUrl);
                setMenuMappingStatus(`Chargement mapping (${defaultUrl})`, 'muted');
                const loaded = await loadMenuMappingFromUrl(defaultUrl);
                return loaded;
            } catch (err) {
                if (typeof MENU_MAPPING_EMBEDDED === 'string' && MENU_MAPPING_EMBEDDED.trim().length > 0) {
                    try {
                        const parsed = JSON.parse(MENU_MAPPING_EMBEDDED);
                        if (parsed && typeof parsed === 'object' && parsed.menutype && Array.isArray(parsed.items)) {
                            if (DEBUG) console.log('[SIMBA] Fallback mapping embarqué utilisé');
                            setMenuMappingStatus('Mapping chargé via copie embarquée.', 'muted');
                            return { raw: MENU_MAPPING_EMBEDDED, parsed };
                        }
                    } catch (_) { /* ignore */ }
                }
                throw err;
            }
        };

        const applyMenuMappingRaw = async (mappingRaw, options = {}) => {
            return postJson('module.applymenumapping', {
                mapping: mappingRaw,
                dry_run: options.dryRun ? '1' : '0'
            });
        };

        const runMenuMappingCheck = async () => {
            if (menuMappingApplying) return;
            menuMappingApplying = true;
            menuMappingAutoPending = false;
            setMenuMappingStatus('Vérification SIMBA en cours...', 'muted');
            setMenuMappingBadge('idle', '', { persist: false });
            updateValidationItem('check-menu-mapping', 'pending', 'Mapping SIMBA (vérification...)');

            try {
                let mappingRawToApply = menuMappingRaw;
                if (!mappingRawToApply) {
                    const loaded = await loadMenuMappingWithFallback();
                    menuMappingRaw = loaded.raw;
                    menuMappingData = loaded.parsed;
                    mappingRawToApply = loaded.raw;
                }

                const data = await applyMenuMappingRaw(mappingRawToApply, { dryRun: true });
                if (data && data.success) {
                    updateMenuMappingBadgeFromResponse(data);
                    const status = data?.data?.status_after || data?.data?.status || null;
                    const notFoundCount = Array.isArray(data?.data?.not_found) ? data.data.not_found.length : 0;
                    const orderOnlyMismatch = status && status.items_total > 0 && status.items_ok === status.items_total && !status.up_to_date;

                    if (status && (status.up_to_date || orderOnlyMismatch) && notFoundCount === 0) {
                        updateValidationItem('check-menu-mapping', 'success', orderOnlyMismatch ? 'Mapping SIMBA (ordre à ajuster)' : 'Mapping SIMBA');
                        setMenuMappingStatus('', 'muted');
                        hideMenuMappingApply();
                    } else {
                        updateValidationItem('check-menu-mapping', 'error', notFoundCount > 0 ? `Mapping SIMBA manquant (${notFoundCount})` : 'Mapping SIMBA à vérifier');
                        setMenuMappingStatus(notFoundCount > 0 ? `Liens manquants: ${notFoundCount}` : 'Différences détectées, application automatique...', 'muted');
                        if (!menuMappingAutoOnceDone && notFoundCount === 0) {
                            menuMappingAutoOnceDone = true;
                            setTimeout(() => runMenuMappingAuto(), 300);
                        }
                    }
                } else {
                    setMenuMappingStatus(`Erreur vérification: ${data?.message || 'inconnue'}`, 'danger');
                    setMenuMappingBadge('error');
                    updateValidationItem('check-menu-mapping', 'error', 'Mapping SIMBA erreur');
                }
            } catch (err) {
                setMenuMappingStatus(`Erreur vérification: ${err.message || err}`, 'danger');
                setMenuMappingBadge('error');
                updateValidationItem('check-menu-mapping', 'error', 'Mapping SIMBA erreur');
            } finally {
                menuMappingApplying = false;
            }
        };

        const runMenuMappingAuto = async () => {
            if (menuMappingApplying) return;
            menuMappingApplying = true;
            setMenuMappingStatus('Application du mapping en cours...', 'muted');
            setMenuMappingBadge('idle', '', { persist: false });
            updateValidationItem('check-menu-mapping', 'pending', 'Mapping SIMBA (application...)');

            try {
                let mappingRawToApply = menuMappingRaw;
                if (!mappingRawToApply) {
                    const loaded = await loadMenuMappingWithFallback();
                    menuMappingRaw = loaded.raw;
                    menuMappingData = loaded.parsed;
                    mappingRawToApply = loaded.raw;
                }

                const data = await applyMenuMappingRaw(mappingRawToApply);
                if (data && data.success) {
                    const matched = data?.data?.matched?.length || 0;
                    const updated = data?.data?.updated?.length || 0;
                    const notFound = data?.data?.not_found?.length || 0;
                    setMenuMappingStatus(`Mapping appliqué. Liens: ${matched} · MàJ: ${updated} · Non trouvés: ${notFound}`, 'success');
                    updateMenuMappingBadgeFromResponse(data);
                    const status = data?.data?.status_after || data?.data?.status || null;
                    const orderOnlyMismatch = status && status.items_total > 0 && status.items_ok === status.items_total && !status.up_to_date;
                    if (notFound > 0) {
                        updateValidationItem('check-menu-mapping', 'error', `Mapping SIMBA manquant (${notFound})`);
                    } else {
                        updateValidationItem('check-menu-mapping', 'success', orderOnlyMismatch ? 'Mapping SIMBA (ordre à ajuster)' : `Mapping SIMBA appliqué (${updated} MàJ)`);
                        hideMenuMappingApply();
                    }
                } else {
                    setMenuMappingStatus(`Erreur mapping: ${data?.message || 'inconnue'}`, 'danger');
                    setMenuMappingBadge('error');
                    updateValidationItem('check-menu-mapping', 'error', 'Mapping SIMBA erreur');
                }
            } catch (err) {
                setMenuMappingStatus(`Erreur mapping: ${err.message || err}`, 'danger');
                setMenuMappingBadge('error');
                updateValidationItem('check-menu-mapping', 'error', 'Mapping SIMBA erreur');
            } finally {
                menuMappingApplying = false;
                if (menuMappingAutoPending) {
                    menuMappingAutoPending = false;
                    setTimeout(() => runMenuMappingAuto(), 150);
                }
            }
        };

        menuMappingAutoToggle?.addEventListener('change', (e) => {
            menuMappingAutoEnabled = !!e.target.checked;
            if (menuMappingAutoEnabled) {
                runMenuMappingAuto();
            } else {
                setMenuMappingStatus('Mapping auto désactivé.', 'muted');
                setMenuMappingBadge(menuMappingLastState, menuMappingLastDetails, { persist: false });
                runMenuMappingCheck();
            }
        });

        // Initialiser l'état du badge dès l'ouverture (sans modifier la base)
        setMenuMappingBadge('idle', '', { persist: false });
        runMenuMappingCheck();

        document.getElementById('toggle-module-selector')?.addEventListener('change', (e) => {
            document.getElementById('module-selector-section').classList.toggle('d-none', !e.target.checked);
        });

        document.getElementById('toggle-id-editor')?.addEventListener('change', (e) => {
            idEditorUserToggled = true;
            document.getElementById('id-editor-section').classList.toggle('d-none', !e.target.checked);
        });

        document.getElementById('toggle-replace-section')?.addEventListener('change', (e) => { document.getElementById('find-replace-section').classList.toggle('d-none', !e.target.checked); });

        document.getElementById('id-editor-list')?.addEventListener('input', (e) => {
            const input = e.target.closest('.id-editor-input');
            if (!input) return;
            handleIdEditorInputChange(input);
        });

        document.getElementById('id-editor-list')?.addEventListener('change', (e) => {
            const select = e.target.closest('.id-editor-ref-select');
            if (!select) return;
            const fileName = select.dataset.fileName;
            const moduleIndex = parseInt(select.dataset.moduleIndex, 10);
            const oldId = select.dataset.oldId;
            const newId = select.value;

            if (!fileName || Number.isNaN(moduleIndex) || !oldId || !newId || oldId === newId) return;

            const modules = parsedFilesModules.get(fileName);
            if (!modules || !modules[moduleIndex]) return;

            replaceLoadModuleIdsInItem(modules[moduleIndex], { [oldId]: newId });
            select.dataset.oldId = newId;

            renderIdEditor();
        });

        // Event delegation pour les pastilles de publication
        document.getElementById('module-checkbox-list')?.addEventListener('click', (e) => {
            const badge = e.target.closest('.publish-toggle');
            if (badge) {
                e.preventDefault();
                e.stopPropagation();

                const item = badge.closest('.module-selection-item');
                const checkbox = item.querySelector('.module-import-checkbox');
                const fileName = checkbox.dataset.fileName;
                const moduleIndex = parseInt(checkbox.dataset.moduleIndex);

                // Récupérer le module dans parsedFilesModules
                const modules = parsedFilesModules.get(fileName);
                if (modules && modules[moduleIndex]) {
                    const currentStatus = badge.dataset.published === '1';
                    const newStatus = currentStatus ? 0 : 1;

                    // Mettre à jour dans la structure de données
                    const target = getModuleObject(modules[moduleIndex]);
                    if (target) {
                        target.published = newStatus;
                    }

                    // Mettre à jour le badge visuellement
                    if (newStatus === 1) {
                        badge.className = 'badge bg-success me-2 publish-toggle';
                        badge.textContent = 'PUBLIÉ';
                        badge.dataset.published = '1';
                        badge.title = 'Cliquer pour dépublier';
                    } else {
                        badge.className = 'badge bg-secondary me-2 publish-toggle';
                        badge.textContent = 'DÉPUBLIÉ';
                        badge.dataset.published = '0';
                        badge.title = 'Cliquer pour publier';
                    }
                }
            }
        });

        document.getElementById('module-checkbox-list')?.addEventListener('change', (e) => {
            const checkbox = e.target.closest('.module-import-checkbox');
            if (checkbox) {
                moduleSelectorTouched = true;
            }
        });


        filePreviewList.addEventListener('click', function (e) {
            const removeBtn = e.target.closest('[data-remove-file]');
            if (removeBtn) {
                const fileNameToRemove = removeBtn.dataset.removeFile;
                const dt = new DataTransfer();
                const files = Array.from(fileInput.files);
                let removedFileWasValid = false;

                files.forEach(file => {
                    if (file.name !== fileNameToRemove) {
                        dt.items.add(file);
                    } else {
                        // On vérifie si l'élément qu'on supprime était valide
                        const item = filePreviewList.querySelector(`[data-file-name="${fileNameToRemove}"]`);
                        if (item && item.querySelector('.text-success')) {
                            removedFileWasValid = true;
                        }
                    }
                });
                fileInput.files = dt.files;

                if (removedFileWasValid) {
                    validFilesCount--;
                }

                parsedFilesModules.delete(fileNameToRemove);

                // Si plus aucun fichier valide, recharger le template par défaut "Bonus"
                if (validFilesCount === 0) {
                    toggleDropZone(true); // Réafficher la drop zone

                    // Rechargement automatique du template désactivé
                    if (AUTO_LOAD_DEFAULT) {
                        setTimeout(() => {
                            loadDefaultTemplate();
                        }, 50);
                    }
                }

                renderModuleSelector();
                handleFiles();
            }
        });

        // closeImportModal unifié via cleanup() ci-dessus
        const closeImportModal = cleanup;

        // Gérer la touche Échap pour fermer
        const handleEscKey = (e) => {
            if (e.key === 'Escape') {
                closeImportModal();
            }
        };
        document.addEventListener('keydown', handleEscKey);
        overlay.addEventListener('click', closeImportModal);

        modal.addEventListener('click', (e) => {
            const btn = e.target.closest('[data-action]');
            const action = btn ? btn.dataset.action : null;

            log('[DIAG] Click detecté:', { target: e.target, btnFound: !!btn, action: action });

            if (action === 'close') {
                closeImportModal();
            } else if (action === 'confirm') {
                log('[DIAG] Bouton de confirmation cliqué');

                // Si on est à l'étape 4, on sauvegarde les paramètres TinyMCE au lieu d'importer
                if (step4Content && step4Content.classList.contains('active')) {
                    log('[DIAG] Mode sauvegarde TinyMCE (Etape 4)');
                    const select = modal.querySelector('#tinymce-path-select');
                    if (select) {
                        saveTinyMceParams(select.value);
                    }
                    return;
                }

                log('[DIAG] Mode Importation (Etape 3)');

                // ✅ Sauvegarder la config de remplacement dynamique pour le FRONT
                const saveDynamicReplaceConfig = () => {
                    const toggle = document.getElementById('toggle-replace-section');
                    const enabled = !!(toggle && toggle.checked);
                    const mainTitle = document.getElementById('main-title-replace-value')?.value || '';
                    const baseline = document.getElementById('main-baseline-replace-value')?.value || '';
                    const authority = document.getElementById('prefet-title-replace-value')?.value || '';

                    const rules = Array.from(document.querySelectorAll('#find-replace-section input[type="text"][data-find-text]'))
                        .map(field => ({
                            find: decodeURIComponent(field.dataset.findText || ''),
                            replace: field.value || ''
                        }))
                        .filter(r => r.find && r.replace);

                    const payload = {
                        enabled,
                        mainTitle,
                        baseline,
                        authority,
                        rules
                    };

                    step3Log('Sauvegarde config dynamique (front):', payload);

                    postJson('module.saveDynamicReplaceConfig', { config: JSON.stringify(payload) })
                        .then(data => {
                            if (!data.success) {
                                step3Warn('Échec sauvegarde config dynamique:', data.message || data);
                            } else {
                                step3Log('Config dynamique sauvegardée.');
                            }
                        })
                        .catch(err => {
                            step3Error('Erreur sauvegarde config dynamique:', err.message || err);
                        });
                };

                saveDynamicReplaceConfig();

                // ✅ Nouvelle logique de collecte des fichiers
                const filesToProcess = [];

                // 1. Ajouter les fichiers manuels via l'input
                if (fileInput.files.length > 0) {
                    Array.from(fileInput.files).forEach(f => filesToProcess.push(f));
                }

                // 2. Ajouter le fichier par défaut s'il est chargé
                if (defaultFileData && modal.querySelector('.file-preview-card[data-is-default="true"]')) {
                    // S'assurer qu'on ne l'ajoute pas deux fois s'il est aussi dans fileInput (peu probable)
                    if (!filesToProcess.find(f => f.name === defaultFileData.name)) {
                        filesToProcess.push(defaultFileData);
                    }
                }

                if (filesToProcess.length === 0) {
                    alert('Veuillez sélectionner au moins un fichier JSON.');
                    return;
                }

                // Utiliser filesToProcess au lieu de fileInput.files pour toute la suite
                const files = filesToProcess;
                const logTimestamp = new Date().getTime() + '_' + Math.random().toString(36).substring(2, 7);

                const runIdMapping = true;
                const progressDiv = document.getElementById('import-progress');
                const progressBar = document.getElementById('import-progress-bar');
                progressBar.style.backgroundColor = '#2563eb'; // Couleur bleue du bouton Importer

                const progressText = document.getElementById('progress-text');
                const statusDiv = document.getElementById('import-status');
                progressDiv.classList.remove('d-none');
                document.getElementById('confirm-import').disabled = true;
                document.getElementById('cancel-import').disabled = true;
                fileInput.disabled = true;
                let completed = 0;
                let succeeded = 0;

                let failed = 0;
                const failedFiles = [];

                function updateProgress() {
                    const percent = Math.round((completed / files.length) * 100);
                    progressBar.style.width = percent + '%';
                    progressBar.textContent = percent + '%';
                    progressText.textContent = completed + ' / ' + files.length + ' fichiers traités';

                }

                // --- Fonctions utilitaires pour l'import (définies une seule fois) ---
                const decodeHtml = (html) => {
                    if (!html || typeof html !== 'string') return html || "";

                    // ✅ PROTECTION v6.5.1 : Si la chaîne contient des balises HTML brutes,
                    // on ne doit PAS utiliser textContent car cela les supprimerait.
                    if (html.includes('<') && html.includes('>')) {
                        return html;
                    }

                    try {
                        const doc = new DOMParser().parseFromString(html, 'text/html');
                        return doc.body.textContent || "";
                    } catch (e) {
                        return html;
                    }
                };

                // LOADMODULEID_TEST : variante sans capture, pour test simple
                const LOADMODULEID_TEST = /\{loadmoduleid(?:\s|&nbsp;|&#160;|\u00A0)+\d+\}/i;

                // Fonction pour décoder récursivement tout le contenu HTML encodé dans le JSON
                const decodeAllContent = (data) => {
                    if (Array.isArray(data)) {
                        data.forEach(item => decodeAllContent(item));
                    } else if (data && typeof data === 'object') {
                        // ✅ RESTAURATION v6.2.1 : Réactivation du décodage HTML
                        // Le décodage fonctionne correctement, c'était les remplacements dynamiques
                        // qui écrasaient le contenu. Maintenant qu'ils sont sécurisés, on peut décoder.

                        if (data.module && typeof data.module.content === 'string') {
                            data.module.content = decodeHtml(data.module.content);
                        } else if (data.content && typeof data.content === 'string') {
                            data.content = decodeHtml(data.content);
                        }

                        if (DEBUG) {
                            const content = data.module?.content || data.content;
                            if (content && typeof content === 'string') {
                                log(`Module "${data.module?.title || 'Sans titre'}": ${content.length} car.`);
                            }
                        }

                        // NOUVEAU : Décodage récursif des paramètres s'ils sont sous forme d'objet
                        // Cela corrige les problèmes d'encodage HTML dans les paramètres pour certains modules
                        const decodeParams = (obj) => {
                            if (obj && typeof obj === 'object') {
                                Object.keys(obj).forEach(key => {
                                    if (typeof obj[key] === 'string') {
                                        obj[key] = decodeHtml(obj[key]);
                                    } else if (typeof obj[key] === 'object') {
                                        decodeParams(obj[key]);
                                    }
                                });
                            }
                        };

                        if (data.modules) decodeAllContent(data.modules);
                    }
                };

                const performReplace = (moduleData, find, replace) => {
                    if (!moduleData) return;

                    const processValue = (value) => {
                        if (typeof value !== 'string') return value;
                        const decodedContent = decodeHtml(value);
                        let newContent = decodedContent;

                        if (find instanceof RegExp) {
                            newContent = decodedContent.replace(find, replace);
                        } else if (typeof find === 'string' && find.startsWith('/') && find.lastIndexOf('/') > 0) {
                            try {
                                const lastSlash = find.lastIndexOf('/');
                                const pattern = find.substring(1, lastSlash);
                                const flags = find.substring(lastSlash + 1);
                                const regex = new RegExp(pattern, flags);
                                newContent = decodedContent.replace(regex, replace);
                            } catch (e) {
                                log(`Erreur de Regex pour "${find}":`, e.message);
                            }
                        } else {
                            newContent = decodedContent.replaceAll(find, replace);
                        }
                        // CORRECTION ReDoS: Limiter la taille de l'entrée ou utiliser une méthode sans regex si possible
                        // Ici on garde replace mais on s'assure que newContent n'explose pas mémoire
                        return newContent;
                    };

                    // Traiter 'content'
                    if (moduleData.content && typeof moduleData.content === 'string') {
                        const oldContent = moduleData.content;
                        moduleData.content = processValue(moduleData.content);
                        if (moduleData.content !== oldContent) log(`Contenu (content) remplacé.`);
                    }

                    // Traiter 'params'
                    if (moduleData.params) {
                        if (typeof moduleData.params === 'object' && moduleData.params !== null) {
                            const recursiveReplaceParams = (obj) => {
                                Object.keys(obj).forEach(key => {
                                    if (typeof obj[key] === 'string') {
                                        obj[key] = processValue(obj[key]);
                                    } else if (typeof obj[key] === 'object' && obj[key] !== null) {
                                        recursiveReplaceParams(obj[key]);
                                    }
                                });
                            };
                            recursiveReplaceParams(moduleData.params);
                            log(`Paramètres (params object) traités.`);
                        } else if (typeof moduleData.params === 'string' && moduleData.params.startsWith('{')) {
                            try {
                                const parsed = JSON.parse(moduleData.params);
                                const recursiveReplaceParams = (obj) => {
                                    Object.keys(obj).forEach(key => {
                                        if (typeof obj[key] === 'string') {
                                            obj[key] = processValue(obj[key]);
                                        } else if (typeof obj[key] === 'object' && obj[key] !== null) {
                                            recursiveReplaceParams(obj[key]);
                                        }
                                    });
                                };
                                recursiveReplaceParams(parsed);
                                moduleData.params = JSON.stringify(parsed);
                                log(`Paramètres (params JSON string) traités.`);
                            } catch (e) {
                                moduleData.params = processValue(moduleData.params);
                            }
                        }
                    }
                };

                const traverseAndReplace = (data, find, replace) => {
                    if (!find || find.length === 0) return; // évite les remplacements vides qui peuvent boucler
                    if (Array.isArray(data)) {
                        data.forEach(item => traverseAndReplace(item, find, replace));
                    } else if (data && typeof data === 'object') {
                        // Un module peut avoir 'module' (objet) ou être l'objet lui-même si un-wrapped
                        if (data.module && typeof data.module === 'object') {
                            performReplace(data.module, find, replace);
                        } else if (data.content !== undefined || data.params !== undefined) {
                            performReplace(data, find, replace);
                        }

                        // Continuer la traversée pour les sous-éléments (ex: modules imbriqués)
                        if (data.modules && Array.isArray(data.modules)) {
                            data.modules.forEach(item => traverseAndReplace(item, find, replace));
                        }
                    }
                };

                // Helper pour remplacement via DOM (plus robuste que Regex pour le HTML imbriqué)
                const replaceInHtml = (htmlContent, selector, newHtml) => {
                    if (!htmlContent) return null;
                    try {
                        const parser = new DOMParser();
                        // text/html permet de gérer correctement toute la structure
                        const doc = parser.parseFromString(htmlContent, 'text/html');
                        const targets = doc.querySelectorAll(selector);
                        if (targets.length > 0) {
                            targets.forEach(target => {
                                const tempWrapper = document.createElement('div');
                                tempWrapper.innerHTML = newHtml;
                                target.replaceWith(...tempWrapper.childNodes);
                            });
                            return doc.body.innerHTML;
                        }
                    } catch (e) {
                        log('Erreur DOM replacement:', e);
                    }
                    return null;
                };

                const containsLoadModuleIdInSelector = (htmlContent, selector) => {
                    if (!htmlContent) return false;
                    try {
                        const parser = new DOMParser();
                        const doc = parser.parseFromString(htmlContent, 'text/html');
                        const target = doc.querySelector(selector);
                        if (!target) return false;
                        const targetHtml = target.outerHTML || target.innerHTML || '';
                        return LOADMODULEID_TEST.test(targetHtml);
                    } catch (e) {
                        console.warn('Erreur detection {loadmoduleid} dans selector:', e);
                        return false;
                    }
                };

                const syncHeaderServiceTitleAttr = (htmlContent) => {
                    if (!htmlContent) return null;
                    try {
                        if (containsLoadModuleIdInSelector(htmlContent, '.fr-header__service')) {
                            return null;
                        }
                        const parser = new DOMParser();
                        const doc = parser.parseFromString(htmlContent, 'text/html');
                        const service = doc.querySelector('.fr-header__service');
                        if (!service) return null;
                        const link = service.querySelector('a');
                        const titleNode = service.querySelector('.fr-header__service-title');
                        if (!link || !titleNode) return null;
                        const serviceTitle = (titleNode.textContent || '').replace(/\s+/g, ' ').trim();
                        if (!serviceTitle) return null;
                        const currentTitle = link.getAttribute('title') || '';
                        link.setAttribute('title', `Accueil - ${serviceTitle} - République Française`);
                        return doc.body.innerHTML;
                    } catch (e) {
                        console.warn('Erreur MAJ title header service:', e);
                        return null;
                    }
                };

                // Normaliser les tokens {loadmoduleid} pour éviter les soucis d'espaces invisibles
                const normalizeLoadModuleIds = (data) => {
                    const normalizeText = (text) => {
                        if (typeof text !== 'string') return text;
                        return text.replace(LOADMODULEID_REGEX, '{loadmoduleid $1}');
                    };

                    const normalizeParams = (params) => {
                        if (!params) return params;
                        if (typeof params === 'object') {
                            Object.keys(params).forEach(k => {
                                if (typeof params[k] === 'string') params[k] = normalizeText(params[k]);
                                else if (typeof params[k] === 'object' && params[k] !== null) normalizeParams(params[k]);
                            });
                            return params;
                        }
                        if (typeof params === 'string') {
                            return normalizeText(params);
                        }
                        return params;
                    };

                    const walk = (node) => {
                        if (Array.isArray(node)) {
                            node.forEach(walk);
                        } else if (node && typeof node === 'object') {
                            const target = getModuleObject(node);
                            if (typeof target.content === 'string') target.content = normalizeText(target.content);
                            if (target.params) target.params = normalizeParams(target.params);
                            if (node.modules && Array.isArray(node.modules)) node.modules.forEach(walk);
                        }
                    };

                    walk(data);
                };

                // Helper partagé : traite récursivement les params d'un module avec une fonction de transformation
                const deepProcessParams = (params, processFn) => {
                    const walk = (obj) => {
                        Object.keys(obj).forEach(k => {
                            if (typeof obj[k] === 'string') obj[k] = processFn(obj[k]);
                            else if (typeof obj[k] === 'object' && obj[k] !== null) walk(obj[k]);
                        });
                    };
                    if (typeof params === 'object') {
                        walk(params);
                    } else if (typeof params === 'string' && params.startsWith('{')) {
                        try {
                            const p = JSON.parse(params);
                            walk(p);
                            return JSON.stringify(p);
                        } catch (e) { }
                    }
                    return params;
                };

                const applyDynamicReplacements = (jsonData) => {
                    const replaceSectionToggle = document.getElementById('toggle-replace-section');
                    if (!replaceSectionToggle || !replaceSectionToggle.checked) {
                        log('Toggle remplacements désactivé');
                        return;
                    }

                    const replacementFields = document.querySelectorAll('#find-replace-section input[type="text"][data-find-text]');
                    log('Remplacements dynamiques:', replacementFields.length, 'champs');

                    replacementFields.forEach((field) => {
                        const replaceValue = field.value;
                        const findText = decodeURIComponent(field.dataset.findText);
                        if (replaceValue && findText && findText.trim().length > 0) {
                            log(`Remplacement : "${findText}" → "${replaceValue}"`);
                            traverseAndReplace(jsonData, findText, replaceValue);
                        }
                    });
                };

                const replaceTitleContent = (jsonData) => {
                    const mainTitleReplaceField = document.getElementById('main-title-replace-value');
                    const mainBaselineReplaceField = document.getElementById('main-baseline-replace-value');
                    const mainTitleRaw = (mainTitleReplaceField && mainTitleReplaceField.value) ? mainTitleReplaceField.value : '';
                    const hasMainTitle = !!mainTitleRaw;
                    let dsfrTemplate = null;

                    if (hasMainTitle) {
                        let mainTitleReplaceValue = mainTitleRaw;

                        traverseAndReplace(jsonData, mainTitleReplaceValue, mainTitleReplaceValue);
                        // Gérer les sauts de ligne du textarea
                        mainTitleReplaceValue = mainTitleReplaceValue.replace(/\n/g, '<br>');
                        // On nettoie les balises HTML pour l'attribut title (tooltip)
                        const safeTitle = mainTitleReplaceValue.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().replace(/"/g, '&quot;');
                        // Correction : Si vide, on ne met pas de texte par défaut
                        let mainBaselineReplaceValue = (mainBaselineReplaceField && mainBaselineReplaceField.value) ? mainBaselineReplaceField.value : "";
                        // Gérer les sauts de ligne pour la baseline aussi
                        mainBaselineReplaceValue = mainBaselineReplaceValue.replace(/\n/g, '<br>');
                        const baselineHtml = mainBaselineReplaceValue ? `<p class="fr-header__service-tagline">${mainBaselineReplaceValue}</p>` : '';

                        // Structure HTML DSFR souhaitée
                        dsfrTemplate = `<div class="fr-header__service">
                                    <a title="Accueil - ${safeTitle} - République Française" href="index.php">
                                    <p class="fr-header__service-title">${mainTitleReplaceValue}</p>
                                    ${baselineHtml}
                                    </a></div>`;
                    }

                    const recursiveReplace = (data) => {
                        if (Array.isArray(data)) {
                            data.forEach(item => recursiveReplace(item));
                        } else if (data && typeof data === 'object') {
                            let target = getModuleObject(data);
                            let content = target.content || '';
                            if (typeof content !== 'string') content = '';

                            const hasServiceBlock = content.includes("Nom du site")
                                || content.includes("fr-header__service")
                                || content.includes("service-title");

                            if (hasServiceBlock && hasMainTitle) {
                                // ✅ PROTECTION CIBLÉE : on bloque seulement si {loadmoduleid} est DANS le bloc ciblé
                                const hasLoadInTarget = containsLoadModuleIdInSelector(content, '.fr-header__service');

                                if (hasLoadInTarget) {
                                    log('TITRE: {loadmoduleid} dans .fr-header__service - préservation');
                                } else if (dsfrTemplate) {
                                    const newContentDom = replaceInHtml(content, '.fr-header__service', dsfrTemplate);
                                    if (newContentDom) {
                                        target.content = newContentDom;
                                        content = newContentDom;
                                    } else {
                                        log('TITRE: remplacement DOM échoué, préservation du contenu');
                                    }
                                }
                            }

                            if (hasServiceBlock) {
                                const syncedContent = syncHeaderServiceTitleAttr(content);
                                if (syncedContent && syncedContent !== content) {
                                    target.content = syncedContent;
                                    content = syncedContent;
                                }
                            }

                            // Remplacement DSFR dans les params si motif trouvé
                            if (target.params) {
                                const processParamValue = (val) => {
                                    if (typeof val === 'string' && (val.includes("Nom du site") || val.includes("fr-header__service") || val.includes("service-title"))) {
                                        let nextVal = val;
                                        if (hasMainTitle) {
                                            if (containsLoadModuleIdInSelector(nextVal, '.fr-header__service')) return nextVal;
                                            if (dsfrTemplate) nextVal = replaceInHtml(nextVal, '.fr-header__service', dsfrTemplate) || nextVal;
                                        }
                                        return syncHeaderServiceTitleAttr(nextVal) || nextVal;
                                    }
                                    return val;
                                };
                                target.params = deepProcessParams(target.params, processParamValue);
                            }

                            if (data.modules && Array.isArray(data.modules)) {
                                data.modules.forEach(item => recursiveReplace(item));
                            }
                        }
                    };
                    recursiveReplace(jsonData);
                };

                const replaceAuthorityContent = (jsonData) => {
                    const prefetReplaceField = document.getElementById('prefet-title-replace-value');
                    if (prefetReplaceField && prefetReplaceField.value) {
                        const prefetReplaceValue = prefetReplaceField.value;
                        log('AUTORITE: remplacement avec:', prefetReplaceValue);
                        const formattedPrefetValue = prefetReplaceValue.replace(/\n/g, '<br>');

                        // Template DSFR pour le bloc Marque (Logo)
                        const dsfrLogoContentTemplate = `<p class="fr-logo">${formattedPrefetValue}<span class="fr-sr-only">Liberté Égalité Fraternité</span></p>`;

                        const dsfrLogoDivTemplate = `<div class="fr-header__logo">${dsfrLogoContentTemplate}</div>`;

                        const recursiveReplace = (data) => {
                            if (Array.isArray(data)) {
                                data.forEach(item => recursiveReplace(item));
                            } else if (data && typeof data === 'object') {
                                let target = getModuleObject(data);
                                let content = target.content || '';
                                if (typeof content !== 'string') content = '';

                                // Regex sans flag g pour .test() (évite les problèmes de lastIndex)
                                // CORRECTION : s'assurer que les regex utilisées pour .test() ou via new RegExp dans la boucle ne conservent pas d'état
                                const prefetTest = new RegExp("\\b(préfet|préfète|prefet|prefète)\\b", "i");
                                const logoDivTest = new RegExp("<div[^>]*class=\"[^\"]*fr-header__logo[^\"]*\"[^>]*>[\\s\\S]*?<\\/div>", "i");
                                const logoPTest = new RegExp("<p[^>]*class=\"[^\"]*fr-logo[^\"]*\"[^>]*>[\\s\\S]*?<\\/p>", "i");

                                // Si le motif est détecté dans content
                                if (prefetTest.test(content) || logoDivTest.test(content) || logoPTest.test(content) ||
                                    content.includes("fr-header__logo") || content.includes("fr-logo") || content.includes("Liberté")) {

                                    // ✅ PROTECTION CIBLÉE : on bloque seulement si {loadmoduleid} est DANS le bloc ciblé
                                    const hasLoadInTarget = containsLoadModuleIdInSelector(content, '.fr-header__logo')
                                        || containsLoadModuleIdInSelector(content, '.fr-logo');

                                    if (hasLoadInTarget) {
                                        log('AUTORITE: {loadmoduleid} dans bloc logo - préservation');
                                    } else {
                                        const newContentDom = replaceInHtml(content, '.fr-header__logo', dsfrLogoDivTemplate);
                                        if (newContentDom) {
                                            target.content = newContentDom;
                                        } else if (logoDivTest.test(content)) {
                                            target.content = content.replace(/<div[^>]*class="[^"]*fr-header__logo[^"]*"[^>]*>[\s\S]*?<\/div>/gi, dsfrLogoDivTemplate);
                                        } else if (logoPTest.test(content)) {
                                            target.content = content.replace(/<p[^>]*class="[^"]*fr-logo[^"]*"[^>]*>[\s\S]*?<\/p>/gi, dsfrLogoContentTemplate);
                                        } else {
                                            performReplace(target, /\b(préfet|préfète|prefet|prefète)\b/gi, prefetReplaceValue);
                                        }
                                    }
                                }

                                // NOUVEAU : Traitement des params
                                if (target.params) {
                                    const processParamValue = (val) => {
                                        if (typeof val === 'string' && (/\b(préfet|préfète|prefet|prefète)\b/gi.test(val) || val.includes("fr-header__logo") || val.includes("fr-logo"))) {
                                            if (containsLoadModuleIdInSelector(val, '.fr-header__logo') || containsLoadModuleIdInSelector(val, '.fr-logo')) return val;
                                            return replaceInHtml(val, '.fr-header__logo', dsfrLogoDivTemplate) || val;
                                        }
                                        return val;
                                    };
                                    target.params = deepProcessParams(target.params, processParamValue);
                                }

                                if (data.modules && Array.isArray(data.modules)) {
                                    data.modules.forEach(item => recursiveReplace(item));
                                }
                            }
                        };
                        recursiveReplace(jsonData);
                    } else {
                        log('AUTORITE: pas de remplacement (champ vide)');
                    }
                };

                const proceedToNext = (index) => {
                    updateProgress();
                    if (completed === files.length) {
                        finishImport();
                    } else if (index + 1 < files.length) {
                        setTimeout(() => processFile(files[index + 1], index + 1), 300);
                    }
                };
                function processFile(file, index) {
                    const handleJsonData = (jsonContent) => {
                        try {
                            // IMPORTANT : Utiliser parsedFilesModules au lieu de relire le fichier
                            // pour préserver les modifications (publication, etc.)
                            let jsonData;
                            const modulesFromParsed = parsedFilesModules.get(file.name);
                            const originalData = jsonContent;

                            if (modulesFromParsed) {
                                // Utiliser les données modifiées de parsedFilesModules
                                // Reconstruire la structure JSON avec les modules modifiés
                                if (Array.isArray(originalData)) {
                                    // Format : tableau de modules
                                    jsonData = modulesFromParsed;
                                } else if (originalData?.modules) {
                                    // Format : objet avec propriété modules
                                    jsonData = { ...originalData, modules: modulesFromParsed };
                                } else {
                                    // Format : objet single module - utiliser le premier module
                                    jsonData = modulesFromParsed[0] || originalData;
                                }
                            } else {
                                // Fallback : utiliser les données originales
                                jsonData = jsonContent;
                            }

                            const extractLoadModuleIds = (moduleObj) => {
                                const mod = getModuleObject(moduleObj);
                                const content = (mod && typeof mod.content === 'string') ? mod.content : '';
                                const params = (mod && typeof mod.params === 'string') ? mod.params : JSON.stringify(mod?.params || {});
                                const matches = [];
                                const re = new RegExp(LOADMODULEID_REGEX.source, 'gi');
                                let m;
                                while ((m = re.exec(content))) matches.push(parseInt(m[1], 10));
                                while ((m = re.exec(params))) matches.push(parseInt(m[1], 10));
                                return Array.from(new Set(matches.filter(Boolean)));
                            };

                            const normalizeTitle = (value) => {
                                return String(value || '').toLowerCase().replace(/\s+/g, ' ').trim();
                            };

                            const ensureDependencies = (selected, allModules) => {
                                const selectedIds = new Set(selected.map(getModuleOriginalId).filter(Boolean));
                                const allById = new Map(allModules.map(m => [getModuleOriginalId(m), m]));
                                const queue = [];
                                selected.forEach(m => extractLoadModuleIds(m).forEach(id => queue.push(id)));
                                let added = 0;
                                while (queue.length) {
                                    const id = queue.shift();
                                    if (!id || selectedIds.has(id)) continue;
                                    const dep = allById.get(id);
                                    if (dep) {
                                        selected.push(dep);
                                        selectedIds.add(id);
                                        added++;
                                        extractLoadModuleIds(dep).forEach(next => queue.push(next));
                                    }
                                }
                                if (added > 0) {
                                    step3Log(`Dépendances ajoutées automatiquement: ${added}`);
                                }
                                return selected;
                            };

                            const ensureModuleByTitle = (selected, allModules, titles) => {
                                if (!Array.isArray(selected) || !Array.isArray(allModules) || !Array.isArray(titles)) return selected;
                                const wanted = titles.map(normalizeTitle).filter(Boolean);
                                if (wanted.length === 0) return selected;
                                const selectedIds = new Set(selected.map(getModuleOriginalId).filter(Boolean));
                                const selectedTitles = new Set(selected.map(m => normalizeTitle(getModuleTitle(m))));
                                let added = 0;
                                wanted.forEach(title => {
                                    if (selectedTitles.has(title)) return;
                                    const candidate = allModules.find(m => normalizeTitle(getModuleTitle(m)) === title);
                                    if (candidate) {
                                        const id = getModuleOriginalId(candidate);
                                        if (!id || !selectedIds.has(id)) {
                                            selected.push(candidate);
                                            if (id) selectedIds.add(id);
                                            selectedTitles.add(title);
                                            added++;
                                        }
                                    }
                                });
                                if (added > 0) {
                                    step3Log(`Module forcé par titre: ${added}`);
                                }
                                return selected;
                            };

                            const allModules = Array.isArray(modulesFromParsed)
                                ? modulesFromParsed
                                : (Array.isArray(originalData) ? originalData : (originalData?.modules || []));
                            const searchTitleVariants = [
                                'DSFR-Header__tools-searchBar : barre de recherche',
                                'DSFR-Header__tools-searchBar'
                            ];

                            // Filtrage des modules si le sélecteur est activé
                            const useSelector = document.getElementById('toggle-module-selector')?.checked;
                            const shouldFilter = useSelector && moduleSelectorTouched;
                            if (useSelector && !moduleSelectorTouched) {
                                step3Log(`Sélection modules (${file.name}): mode complet (aucune sélection manuelle)`);
                            }
                            if (shouldFilter) {
                                const selectedIndices = Array.from(document.querySelectorAll(`.module-import-checkbox[data-file-name="${file.name}"]:checked`))
                                    .map(cb => parseInt(cb.dataset.moduleIndex));
                                step3Log(`Sélection modules (${file.name}):`, selectedIndices.length, 'sélectionnés');

                                if (Array.isArray(jsonData)) {
                                    jsonData = jsonData.filter((_, idx) => selectedIndices.includes(idx));
                                } else if (jsonData?.modules) {
                                    jsonData.modules = jsonData.modules.filter((_, idx) => selectedIndices.includes(idx));
                                }

                                // Ajouter automatiquement les dépendances {loadmoduleid}
                                if (Array.isArray(jsonData)) {
                                    jsonData = ensureDependencies(jsonData, allModules);
                                } else if (jsonData?.modules) {
                                    jsonData.modules = ensureDependencies(jsonData.modules, allModules);
                                }
                            }

                            // ✅ S'assurer que la barre de recherche DSFR est bien incluse
                            if (Array.isArray(jsonData)) {
                                jsonData = ensureModuleByTitle(jsonData, allModules, searchTitleVariants);
                            } else if (jsonData?.modules) {
                                jsonData.modules = ensureModuleByTitle(jsonData.modules, allModules, searchTitleVariants);
                            }

                            if ((Array.isArray(jsonData) && jsonData.length === 0) || (jsonData?.modules && jsonData.modules.length === 0)) {
                                log('Fichier sauté car aucun module sélectionné:', file.name);
                                completed++;
                                proceedToNext(index);
                                return;
                            }

                            // ✅ STEP3 : Résumé HTML AVANT traitements
                            const beforeModules = jsonData.modules || (Array.isArray(jsonData) ? jsonData : []);
                            const beforeStats = getHtmlStats(beforeModules);
                            step3Log(`HTML AVANT traitements (${file.name}):`, `${beforeStats.withHtml}/${beforeStats.total}`);

                            // Collecter les IDs {loadmoduleid} attendus pour vérification finale du mapping
                            let expectedLoadIds = [];
                            beforeModules.forEach(m => {
                                expectedLoadIds = expectedLoadIds.concat(extractLoadModuleIds(m));
                            });
                            expectedLoadIds = Array.from(new Set(expectedLoadIds)).filter(Boolean);

                            // LOG 1 : Contenu AVANT decodeAllContent (debug uniquement)
                            if (DEBUG && jsonData.modules && jsonData.modules.length > 0) {
                                log('ÉTAPE 1 : AVANT decodeAllContent');
                                jsonData.modules.forEach((item, idx) => {
                                    const mod = getModuleObject(item);
                                    if (mod.content && mod.content.length > 0) {
                                        log(`Module ${idx + 1} "${mod.title}": ${mod.content.length} car., aperçu: ${mod.content.substring(0, 200)}...`);
                                    }
                                });
                            }

                            decodeAllContent(jsonData);
                            normalizeLoadModuleIds(jsonData);

                            // LOG 2 : Contenu APRÈS decodeAllContent (debug uniquement)
                            if (DEBUG && jsonData.modules && jsonData.modules.length > 0) {
                                log('ÉTAPE 2 : APRÈS decodeAllContent');
                                jsonData.modules.forEach((item, idx) => {
                                    const mod = getModuleObject(item);
                                    if (mod.content && mod.content.length > 0) {
                                        log(`Module ${idx + 1} "${mod.title}": ${mod.content.length} car.`);
                                    }
                                });
                            }

                            // Vérifier si le toggle des remplacements dynamiques est activé
                            const replaceSectionToggle = document.getElementById('toggle-replace-section');
                            const isReplacementEnabled = replaceSectionToggle && replaceSectionToggle.checked;

                            if (isReplacementEnabled) {
                                log('Remplacements dynamiques activés');
                                applyDynamicReplacements(jsonData);
                                replaceTitleContent(jsonData);
                                replaceAuthorityContent(jsonData);
                            } else {
                                log('Remplacements dynamiques désactivés (HTML conservé à l\'identique)');
                            }

                            // ✅ STEP3 : Résumé HTML APRÈS traitements
                            const afterModules = jsonData.modules || (Array.isArray(jsonData) ? jsonData : []);
                            const afterStats = getHtmlStats(afterModules);
                            step3Log(`HTML APRÈS traitements (${file.name}):`, `${afterStats.withHtml}/${afterStats.total}`);
                            if (afterStats.withHtml < beforeStats.withHtml) {
                                const beforeDetails = getHtmlDetails(beforeModules);
                                const afterDetails = getHtmlDetails(afterModules);
                                const lost = beforeDetails
                                    .map((b, i) => ({ title: b.title, before: b.hasHtml, after: afterDetails[i]?.hasHtml }))
                                    .filter(x => x.before && !x.after)
                                    .map(x => x.title);
                                step3Warn('⚠ HTML perdu après traitements:', lost);
                            }

                            // ✅ STEP3 : Liste des modules sans HTML (info)
                            const afterDetailsAll = getHtmlDetails(afterModules);
                            const noHtml = afterDetailsAll.filter(d => !d.hasHtml)
                                .map(d => ({ title: d.title, module: d.moduleType, len: d.len }));
                            if (noHtml.length) {
                                step3Log('Modules sans HTML (liste):');
                                noHtml.forEach((m, i) => {
                                    step3Log(`- ${i + 1}. ${m.title} (${m.module}) len=${m.len}`);
                                });
                            }

                            // Utilisation de JSON.stringify pour inclure les modifications (remplacements)
                            const jsonString = JSON.stringify(jsonData);

                            if (DEBUG) {
                                log(`Envoi serveur: ${jsonString.length} car., aperçu: ${jsonString.substring(0, 300)}...`);
                            }

                            step3Log(`Envoi import: ${file.name}`, { size: jsonString.length, id_mapping: runIdMapping ? 1 : 0 });

                            // Envoi fragmenté si les données dépassent 6 MB (marge sous la limite post_max_size PHP de 8 MB)
                            const CHUNK_THRESHOLD = 6 * 1024 * 1024;
                            const CHUNK_SIZE = 2 * 1024 * 1024;
                            let importPromise;

                            if (jsonString.length > CHUNK_THRESHOLD) {
                                const uploadId = 'me_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);
                                const totalChunks = Math.ceil(jsonString.length / CHUNK_SIZE);
                                step3Log(`Données volumineuses (${(jsonString.length / 1024 / 1024).toFixed(1)} MB), envoi en ${totalChunks} fragments...`);

                                let chunkChain = Promise.resolve();
                                for (let i = 0; i < totalChunks; i++) {
                                    const chunkIdx = i;
                                    const chunkData = jsonString.substring(chunkIdx * CHUNK_SIZE, (chunkIdx + 1) * CHUNK_SIZE);
                                    chunkChain = chunkChain.then(() => {
                                        step3Log(`Fragment ${chunkIdx + 1}/${totalChunks} (${(chunkData.length / 1024).toFixed(0)} KB)...`);
                                        return postJson('module.importchunk', {
                                            upload_id: uploadId,
                                            chunk_index: String(chunkIdx),
                                            total_chunks: String(totalChunks),
                                            chunk_data: chunkData
                                        });
                                    });
                                }
                                importPromise = chunkChain.then(() => {
                                    step3Log('Fragments envoyés, lancement import...');
                                    return postJson('module.importmodule', {
                                        upload_id: uploadId,
                                        total_chunks: String(totalChunks),
                                        id_mapping: runIdMapping ? '1' : '0',
                                        log_timestamp: logTimestamp
                                    });
                                });
                            } else {
                                importPromise = postJson('module.importmodule', {
                                    import_data: jsonString,
                                    id_mapping: runIdMapping ? '1' : '0',
                                    log_timestamp: logTimestamp
                                });
                            }

                            importPromise
                                .then(data => {
                                    const resp = data.data || data;
                                    if (data.success && resp.success) {
                                        const importedCount = resp.imported || 0;
                                        const failedCount = resp.failed || resp.failed_count || data.failed || data.failed_count || 0;
                                        succeeded += importedCount;
                                        log(`Fichier ${file.name} importé avec succès:`, resp.message, 'imported:', importedCount, 'failed:', failedCount);

                                        // Afficher les erreurs détaillées des modules échoués
                                        const failedMods = resp.failed_modules || data.failed_modules || [];
                                        if (failedMods.length > 0) {
                                            console.warn(`[ModuleExport] ${failedMods.length} module(s) échoué(s):`, failedMods);
                                            step3Warn(`${failedMods.length} module(s) échoué(s):`);
                                            failedMods.slice(0, 5).forEach((fm, i) => {
                                                step3Warn(`  ${i + 1}. "${fm.title}": ${fm.error}`);
                                            });
                                            if (failedMods.length > 5) {
                                                step3Warn(`  ... et ${failedMods.length - 5} autres (voir console)`);
                                            }
                                        }

                                        // Vérification du mapping attendu
                                        const mapping = resp.id_mapping || resp.id_map || data.id_map || data.id_mapping || {};
                                        const mappingKeys = Object.keys(mapping || {});
                                        if (mappingKeys.length) {
                                            step3Log('Mapping recu:', mappingKeys.length, 'entrees (sample):', mappingKeys.slice(0, 10).join(', '));
                                        } else {
                                            step3Warn('Aucun mapping recu dans la reponse serveur.');
                                        }
                                        if (expectedLoadIds.length) {
                                            const previewPairs = expectedLoadIds
                                                .slice(0, 10)
                                                .map(id => `${id}->${mapping[id] ?? 'NONE'}`);
                                            step3Log('Mapping attendu (apercu):', previewPairs.join(', '));
                                            const missing = expectedLoadIds.filter(id => !mapping[id]);
                                            if (missing.length) {
                                                step3Warn('⚠ Mapping incomplet, IDs non mappés:', missing);
                                                if (statusDiv) {
                                                    statusDiv.innerHTML += `
                                                        <div class="alert alert-warning mt-3 p-3 small border">
                                                            <strong>Mapping incomplet :</strong>
                                                            <div>IDs non mappés : ${missing.join(', ')}</div>
                                                        </div>`;
                                                }
                                            } else {
                                                step3Log('✅ Mapping OK pour tous les IDs attendus.');
                                            }
                                        }

                                        // Afficher les références non mappées si présentes
                                        const warnings = resp.warnings || data.warnings;
                                        const unmapped = (resp.unmapped_refs && resp.unmapped_refs.length)
                                            ? resp.unmapped_refs
                                            : (warnings && (warnings.unmapped_refs || warnings['unmapped_refs']));
                                        if (unmapped && Array.isArray(unmapped) && unmapped.length) {
                                            step3Warn('Références non mappées détectées:', unmapped);
                                            if (statusDiv) {
                                                const list = unmapped.map(u => {
                                                    const ids = (u.remaining_ids || []).join(', ');
                                                    return `<li><strong>${u.module_title || 'Module'}</strong> (ID: ${u.module_id}) → ${ids}</li>`;
                                                }).join('');
                                                statusDiv.innerHTML += `
                                                    <div class="alert alert-warning mt-3 p-3 small border">
                                                        <strong>Références non mappées :</strong>
                                                        <ul class="mb-0 mt-2">${list}</ul>
                                                    </div>`;
                                            }
                                        }

                                        // ✅ Vérification: anciennes références encore présentes après mapping
                                        const remainingOldRefs = (resp.remaining_old_refs && resp.remaining_old_refs.length)
                                            ? resp.remaining_old_refs
                                            : (data.remaining_old_refs || []);
                                        if (remainingOldRefs && Array.isArray(remainingOldRefs) && remainingOldRefs.length) {
                                            step3Warn('⚠ Références {loadmoduleid} non remplacées détectées:', remainingOldRefs);
                                            if (statusDiv) {
                                                const list = remainingOldRefs.map(r => {
                                                    const ids = (r.remaining_ids || []).join(', ');
                                                    return `<li><strong>${r.module_title || 'Module'}</strong> (ID: ${r.module_id}) → ${ids}</li>`;
                                                }).join('');
                                                statusDiv.innerHTML += `
                                                <div class="alert alert-warning mt-3 p-3 small border">
                                                    <strong>Références non remplacées :</strong>
                                                    <ul class="mb-0 mt-2">${list}</ul>
                                                </div>`;
                                            }
                                        }

                                        // Panneau synthétique (debug) sur le résultat d'import
                                        const warnCount = (warnings && Array.isArray(warnings)) ? warnings.length : (warnings ? Object.keys(warnings).length : 0);
                                        const unmappedCount = Array.isArray(unmapped) ? unmapped.length : 0;
                                        const remainingCount = Array.isArray(remainingOldRefs) ? remainingOldRefs.length : 0;
                                        const panelLines = [
                                            `fichier: ${file.name}`,
                                            `importés: ${importedCount}`,
                                            `échecs: ${failedCount}`,
                                            `succès backend: ${data.success} / ${resp.success}`,
                                            `message: ${resp.message || data.message || 'n/a'}`,
                                            `warnings: ${warnCount}`,
                                            `unmapped_refs: ${unmappedCount}`,
                                            `remaining_old_refs: ${remainingCount}`
                                        ];
                                        if (failedMods.length > 0) {
                                            panelLines.push('--- Erreurs modules ---');
                                            failedMods.slice(0, 5).forEach((fm, i) => {
                                                panelLines.push(`${i + 1}. "${fm.title}": ${fm.error}`);
                                            });
                                            if (failedMods.length > 5) {
                                                panelLines.push(`... et ${failedMods.length - 5} autres`);
                                            }
                                        }
                                        showInfoPanel('Import OK', panelLines, { section: 'import' });
                                    } else {
                                        failed++;
                                        failedFiles.push({ name: file.name, error: resp.message || data.message || 'Erreur serveur inconnue.' });
                                        showInfoPanel('Import KO', [
                                            `fichier: ${file.name}`,
                                            `message: ${resp.message || data.message || 'Erreur inconnue'}`,
                                            `code: ${resp.code || data.code || 'n/a'}`
                                        ], { section: 'import', replace: true });
                                    }
                                    completed++;
                                    proceedToNext(index);
                                })
                                .catch(error => {
                                    log(`Erreur de traitement pour le fichier ${file.name}:`, error);
                                    completed++;
                                    failed++;
                                    failedFiles.push({ name: file.name, error: error.message || 'Erreur réseau.' });
                                    showInfoPanel('Import EX', [
                                        `fichier: ${file.name}`,
                                        `error: ${error.message}`
                                    ], { section: 'import', replace: true });
                                    proceedToNext(index);
                                });
                        } catch (error) {
                            completed++;
                            failed++;
                            failedFiles.push({ name: file.name, error: error.message || 'Fichier JSON invalide' });
                            proceedToNext(index);
                        }
                    };

                    // ✅ Gestion différenciée selon le type de fichier
                    if (file.isDefault && file.jsonContent) {
                        step3Log(`Traitement fichier par défaut: ${file.name}`);
                        showInfoPanel('Import en cours', [
                            `fichier: ${file.name}`,
                            `taille: ${file.size || 0} bytes`,
                            `mode: fichier par défaut`
                        ], { section: 'import', replace: true });
                        handleJsonData(file.jsonContent);
                    } else {
                        step3Log(`Lecture fichier manuel: ${file.name}`);
                        showInfoPanel('Import en cours', [
                            `fichier: ${file.name}`,
                            `taille: ${file.size} bytes`,
                            `mode: fichier manuel`
                        ], { section: 'import', replace: true });
                        const reader = new FileReader();
                        reader.onload = function (e) {
                            try {
                                const jsonData = parseJsonFromFileContent(e.target.result);
                                handleJsonData(jsonData);
                            } catch (err) {
                                step3Error(`Lecture/parse échoué pour ${file.name}:`, err.message);
                                completed++;
                                failed++;
                                failedFiles.push({ name: file.name, error: err.message || 'Fichier JSON invalide' });
                                proceedToNext(index);
                            }
                        };
                        reader.readAsText(file);
                    }
                }
                function finishImport() {
                    let message = `
                        <div class="alert ${failed === 0 ? 'alert-success' : 'alert-warning'} p-3 shadow-sm">
                            <h6 class="alert-heading mb-3">✓ Import terminé !</h6>
                            <p class="mb-2"><strong>✓ ${succeeded} module(s) importé(s) avec succès</strong></p>`;
                    if (failed > 0) {
                        message += `<p class="mb-2"><strong>✗ ${failed} échec(s)</strong></p>`;
                        if (failedFiles.length > 0) {
                            message += `
                                <div class="alert alert-warning mt-3 mb-0 p-3 small border">
                                    <strong>Détails des échecs :</strong>
                                    <ul class="mb-0 mt-2" style="max-height: 100px; overflow-y: auto;">
                                        ${failedFiles.map(f => `<li><strong>${f.name}</strong> : ${f.error}</li>`).join('')}
                                    </ul>
                                </div>`;
                        }

                        // (Logique d'avertissement temporairement désactivée pour debug)
                    }
                    message += '</div>';
                    statusDiv.innerHTML = message;
                    if (succeeded > 0) {
                        statusDiv.innerHTML += '<p class="text-center mt-3 text-success small fw-bold">✅ Import terminé avec succès ! Vous pouvez fermer cette fenêtre.</p>';

                        document.getElementById('cancel-import').disabled = false;
                        document.getElementById('cancel-import').textContent = 'Fermer';
                    } else {
                        document.getElementById('cancel-import').disabled = false;
                        document.getElementById('cancel-import').textContent = 'Fermer';
                    }
                }
                processFile(files[0], 0);
            }
        });
    }
    // ============ FONCTIONS D'EXPORT ============
    function exportAllModulesToOneFile(modulesToExport, disableModules, option) {
        const exportData = {
            modules: modulesToExport.map(item => {
                try {
                    return JSON.parse(item.moduleData.content);
                } catch (e) {
                    log('Erreur JSON.parse pour le module', item.moduleId, ':', e.message);
                    return null;
                }
            }).filter(Boolean),
            disable_on_export: disableModules, // Ajout de l'info
            export_date: new Date().toISOString(),
            exported_by: 'Admin',
            joomla_version: JOOMLA_VERSION
        };
        const jsonContent = JSON.stringify(exportData, null, 2);
        const blob = new Blob([jsonContent], { type: 'application/json' });
        downloadBlob(blob, 'export_tous_les_modules_' + new Date().getTime() + '.json');
        log('✓ Fichier "all-in-one" téléchargé');
        if (disableModules) {
            const moduleIds = modulesToExport.map(item => item.moduleId);
            disableExportedModules(moduleIds, option).then(() => {
                alert('Export terminé : ' + modulesToExport.length + ' module(s) exporté(s) et désactivé(s). La page va se recharger.');
                window.location.href = window.location.href;
            });
        } else {
            alert('Export terminé : ' + modulesToExport.length + ' module(s) exporté(s) dans un seul fichier JSON.');
        }
    }

    function disableExportedModules(moduleIds) {
        log('Désactivation des modules exportés (Batch):', moduleIds);
        if (!moduleIds || moduleIds.length === 0) return Promise.resolve();

        // Envoi groupé des IDs
        return postJson('module.publish', {
            cid: moduleIds,
            value: '0'
        }).catch(error => {
            log(`Échec de la désactivation groupée:`, error.message);
            // Fallback: essayer un par un si le batch échoue
            const promises = moduleIds.map(moduleId => {
                return postJson('module.publish', {
                    cid: [moduleId],
                    value: '0'
                });
            });
            return Promise.all(promises);
        });
    }

    async function exportMultipleModulesSeparately(modulesToExport, disableModules, option) {
        let successCount = 0;

        // CORRECTION: Téléchargement séquentiel avec délai pour éviter le blocage navigateur
        for (const item of modulesToExport) {
            const blob = new Blob([item.moduleData.content], { type: 'application/json' });
            downloadBlob(blob, item.moduleData.filename);
            successCount++;
            await new Promise(resolve => setTimeout(resolve, 200)); // 200ms delay
        }
        if (disableModules) {
            const moduleIds = modulesToExport.map(item => item.moduleId);
            disableExportedModules(moduleIds, option).then(() => {
                alert(`${successCount} sur ${modulesToExport.length} module(s) exporté(s) et désactivé(s). La page va se recharger.`);
                window.location.href = window.location.href;
            });
        } else {
            alert(`${successCount} sur ${modulesToExport.length} module(s) exporté(s) avec succès dans des fichiers séparés.`);
        }
    }

    const initModuleExport = () => {
        if (DEBUG) console.log('[ModuleExport] Appel initModuleExport()');
        addExportImportButtons();
    };

    if (document.readyState === 'complete') {
        initModuleExport();
    } else {
        document.addEventListener('DOMContentLoaded', initModuleExport);
        window.addEventListener('load', initModuleExport);
    }
})();
