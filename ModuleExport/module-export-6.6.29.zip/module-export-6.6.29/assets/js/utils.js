/**
 * ModuleExport - Fonctions utilitaires
 */

/**
 * ========================================
 * AJAX / FETCH UTILITIES
 * ========================================
 */

/**
 * Crée une requête AJAX standardisée avec gestion automatique du token CSRF
 * @param {string} taskName - Nom de la tâche Joomla
 * @param {Object} params - Paramètres supplémentaires
 * @param {Object} headers - Headers HTTP additionnels
 * @returns {Promise<Response>}
 */
function createAjaxRequest(taskName, params = {}, headers = {}) {
    const formData = new FormData();
    formData.append('option', params.option || 'com_modules');
    formData.append('task', taskName);
    formData.append('format', params.format || 'json');

    Object.entries(params).forEach(([key, value]) => {
        if (key !== 'option' && key !== 'format' && value !== undefined) {
            formData.append(key, value);
        }
    });

    const token = Joomla.getOptions('csrf.token');
    if (token) {
        formData.append(token, '1');
    }

    return fetch('index.php', {
        method: 'POST',
        body: formData,
        ...headers
    });
}

/**
 * Gère la réponse JSON et valide le content-type
 * @param {Response} response
 * @param {string} errorMessage
 * @returns {Promise<Object>}
 */
function handleJsonResponse(response, errorMessage = 'Réponse serveur inattendue') {
    const contentType = response.headers.get("content-type");
    if (response.ok && contentType?.includes("application/json")) {
        return response.json();
    }
    return response.text().then(text => {
        throw new Error(`${errorMessage}: ${text.substring(0, 200)}...`);
    });
}

/**
 * ========================================
 * FILE & FORMAT UTILITIES
 * ========================================
 */

/**
 * Formate une taille de fichier en format lisible
 * @param {number} bytes
 * @returns {string}
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Supprime les balises HTML d'une chaîne
 * @param {string} html
 * @returns {string}
 */
function stripHtml(html) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    return doc.body.textContent || "";
}

/**
 * Décode les entités HTML
 * @param {string} html
 * @returns {string}
 */
function decodeHtml(html) {
    if (!html) return "";
    const txt = document.createElement("textarea");
    txt.innerHTML = html;
    return txt.value;
}

/**
 * ========================================
 * JSON TRAVERSAL UTILITIES
 * ========================================
 */

/**
 * Traverse récursivement une structure JSON et applique un callback
 * @param {Object|Array} data
 * @param {Function} callback
 */
function traverseJsonData(data, callback) {
    if (Array.isArray(data)) {
        data.forEach(item => traverseJsonData(item, callback));
    } else if (data && typeof data === 'object') {
        callback(data);
        if (data.modules && Array.isArray(data.modules)) {
            data.modules.forEach(item => traverseJsonData(item, callback));
        }
        if (data.module && typeof data.module === 'object') {
            traverseJsonData(data.module, callback);
        }
    }
}

/**
 * Décode récursivement le contenu HTML dans une structure JSON
 * @param {Object|Array} data
 */
function decodeAllContent(data) {
    traverseJsonData(data, (obj) => {
        if (obj.module?.content && typeof obj.module.content === 'string') {
            obj.module.content = decodeHtml(obj.module.content);
        } else if (obj.content && typeof obj.content === 'string') {
            obj.content = decodeHtml(obj.content);
        }

        if (obj.params) {
            if (typeof obj.params === 'string') {
                try {
                    const parsedParams = JSON.parse(obj.params);
                    if (parsedParams && typeof parsedParams === 'object') {
                        Object.keys(parsedParams).forEach(key => {
                            if (typeof parsedParams[key] === 'string') {
                                parsedParams[key] = decodeHtml(parsedParams[key]);
                            }
                        });
                        obj.params = JSON.stringify(parsedParams);
                    }
                } catch (e) {}
            }
        }
    });
}

/**
 * Effectue un remplacement find/replace dans une structure JSON
 * @param {Object|Array} data
 * @param {string} find
 * @param {string} replace
 */
function traverseAndReplace(data, find, replace) {
    if (!find) return;

    traverseJsonData(data, (obj) => {
        const fields = ['title', 'content', 'params'];
        fields.forEach(field => {
            if (obj[field] && typeof obj[field] === 'string') {
                obj[field] = obj[field].replace(new RegExp(find, 'g'), replace);
            }
        });
    });
}

/**
 * ========================================
 * STORAGE UTILITIES
 * ========================================
 */

/**
 * Récupère une valeur depuis localStorage avec valeur par défaut
 * @param {string} key
 * @param {*} defaultValue
 * @returns {*}
 */
function getLocalStorage(key, defaultValue = null) {
    try {
        const value = localStorage.getItem(key);
        if (value === null) return defaultValue;
        if (value === 'true') return true;
        if (value === 'false') return false;
        return value;
    } catch (e) {
        return defaultValue;
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        createAjaxRequest,
        handleJsonResponse,
        formatFileSize,
        stripHtml,
        decodeHtml,
        traverseJsonData,
        decodeAllContent,
        traverseAndReplace,
        getLocalStorage
    };
}
