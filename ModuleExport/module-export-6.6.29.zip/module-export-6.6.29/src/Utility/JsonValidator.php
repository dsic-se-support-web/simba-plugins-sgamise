<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.ModuleExport
 */
defined('_JEXEC') or die;


class JsonValidator
{
    /**
     * Valide et décode une chaîne JSON
     */
    public static function decode($jsonString)
    {
        $data = json_decode($jsonString, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('JSON invalide : ' . json_last_error_msg());
        }

        if (!is_array($data)) {
            throw new Exception('Structure JSON invalide : le JSON doit contenir un tableau ou un objet');
        }

        return $data;
    }

    /**
     * Encode des données en JSON avec options par défaut
     */
    public static function encode($data)
    {
        return json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }

    /**
     * Vérifie si les données JSON contiennent des modules valides
     */
    public static function extractModules($jsonData)
    {
        $modules = [];

        // Format multi-modules
        if (isset($jsonData['modules']) && is_array($jsonData['modules'])) {
            $modules = $jsonData['modules'];
        }
        // Format module unique avec clé 'module'
        elseif (isset($jsonData['module']) && is_array($jsonData['module'])) {
            $modules = [$jsonData];
        }
        // Format module direct (sans wrapper)
        elseif (isset($jsonData['title']) && isset($jsonData['module'])) {
            $modules = [$jsonData];
        }

        if (empty($modules)) {
            throw new Exception('Structure JSON invalide. Le fichier doit contenir soit "modules" (tableau), soit "module" (objet unique).');
        }

        return $modules;
    }

    /**
     * Nettoie le titre d'un module pour utilisation comme nom de fichier
     */
    public static function sanitizeFilename($title)
    {
        $cleanedTitle = preg_replace('/[^a-z0-9]/i', '_', $title);
        return rtrim($cleanedTitle, '_');
    }
}
