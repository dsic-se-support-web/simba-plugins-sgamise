<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.ModuleExport
 */
defined('_JEXEC') or die;


class ModuleExportLogger
{
    private $logDir;
    private $enabled;

    public function __construct($enabled = false)
    {
        $this->enabled = $enabled;
        $this->logDir = JPATH_PLUGINS . '/system/moduleexport/logs';
        $this->ensureLogDirExists();
    }

    public function log($message, $file = 'debug.log')
    {
        if (!$this->enabled) {
            return;
        }

        $logFile = $this->logDir . '/' . $file;
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
    }

    public function logArray($label, $data, $file = 'debug.log')
    {
        if (!$this->enabled) {
            return;
        }

        $this->log("$label:\n" . print_r($data, true), $file);
    }

    private function ensureLogDirExists()
    {
        if (!is_dir($this->logDir)) {
            mkdir($this->logDir, 0755, true);
        }
    }

    public function getLogDir()
    {
        return $this->logDir;
    }
}
