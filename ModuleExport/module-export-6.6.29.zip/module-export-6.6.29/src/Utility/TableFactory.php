<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.ModuleExport
 */
defined('_JEXEC') or die;


use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Table\TableInterface;

/**
 * Factory pour créer des Tables Joomla 5 de manière moderne
 * Remplace l'API dépréciée Table::getInstance()
 */
class TableFactory
{
    /**
     * Cache des MVCFactory pour éviter les appels répétés à bootComponent
     * @var array
     */
    private static array $factories = [];

    /**
     * Crée une instance de Table Module
     * @return TableInterface
     */
    public static function getModuleTable(): ?TableInterface
    {
        return self::getTable('com_modules', 'Module');
    }

    /**
     * Crée une instance de Table Menu
     * @return TableInterface
     */
    public static function getMenuTable(): ?TableInterface
    {
        return self::getTable('com_menus', 'Menu');
    }

    /**
     * Méthode générique pour créer une Table via MVCFactory
     * @param string $component Le nom du composant (ex: 'com_modules')
     * @param string $tableName Le nom de la table (ex: 'Module')
     * @return TableInterface
     */
    private static function getTable(string $component, string $tableName): ?TableInterface
    {
        if (!isset(self::$factories[$component])) {
            $app = Factory::getApplication();
            self::$factories[$component] = $app->bootComponent($component)->getMVCFactory();
        }

        // Tentative via la Factory moderne du composant
        $table = self::$factories[$component]->createTable($tableName, 'Administrator');

        // Fallback 1 : Administrator (pour les composants avec tables custom)
        if (!$table) {
            $table = Table::getInstance($tableName, 'Administrator');
        }

        // Fallback 2 : JTable (pour les tables core de Joomla, ex: Module)
        if (!$table) {
            $table = Table::getInstance($tableName, 'JTable');
        }

        // Fallback 3 : Namespace complet Joomla\CMS\Table
        if (!$table) {
            $table = Table::getInstance($tableName, '\\Joomla\\CMS\\Table\\');
        }

        return ($table && $table instanceof TableInterface) ? $table : null;
    }

    /**
     * Réinitialise le cache des factories (utile pour les tests)
     */
    public static function reset(): void
    {
        self::$factories = [];
    }
}
