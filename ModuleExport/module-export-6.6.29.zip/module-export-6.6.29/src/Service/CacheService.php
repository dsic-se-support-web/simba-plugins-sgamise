<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.ModuleExport
 */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Cache\Cache;

class CacheService
{
    private $logger;

    public function __construct($logger = null)
    {
        $this->logger = $logger;
    }

    /**
     * Nettoie le cache Joomla
     */
    public function clearCache()
    {
        try {
            $conf = Factory::getConfig();
            $options = [
                'defaultgroup' => '',
                'cachebase' => $conf->get('cache_path', JPATH_CACHE)
            ];

            $cache = Cache::getInstance('', $options);
            $cache->clean();

            $this->log("Cache nettoyé avec succès");
            return true;

        } catch (Exception $e) {
            $this->log("Erreur lors du nettoyage du cache: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Nettoie un groupe de cache spécifique
     */
    public function clearCacheGroup($group)
    {
        try {
            $conf = Factory::getConfig();
            $options = [
                'defaultgroup' => $group,
                'cachebase' => $conf->get('cache_path', JPATH_CACHE)
            ];

            $cache = Cache::getInstance('', $options);
            $cache->clean($group);

            $this->log("Cache du groupe '$group' nettoyé");
            return true;

        } catch (Exception $e) {
            $this->log("Erreur lors du nettoyage du cache du groupe '$group': " . $e->getMessage());
            return false;
        }
    }

    /**
     * Nettoie les caches critiques après import/export
     */
    public function clearModuleCaches()
    {
        $groups = ['com_modules', 'mod_menu', '_system'];
        $success = true;

        foreach ($groups as $group) {
            if (!$this->clearCacheGroup($group)) {
                $success = false;
            }
        }

        return $success;
    }

    private function log($message)
    {
        if ($this->logger) {
            $this->logger->log($message, 'cache.log');
        }
    }
}
