<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.ModuleExport
 */
defined('_JEXEC') or die;


use Joomla\CMS\Factory;
use Joomla\CMS\Table\Table;
require_once __DIR__ . '/../Utility/TableFactory.php';

class ModuleService
{
    private $db;
    private $logger;
    private static $moduleColumns = null;

    public function __construct($logger = null)
    {
        $this->db = Factory::getDbo();
        $this->logger = $logger;
    }

    /**
     * Récupère les données complètes d'un module
     */
    public function getModule($id)
    {
        $query = $this->db->getQuery(true);
        $query->select('*')
            ->from($this->db->quoteName('#__modules'))
            ->where($this->db->quoteName('id') . ' = ' . (int) $id);

        $this->db->setQuery($query);
        return $this->db->loadAssoc();
    }

    /**
     * Récupère les assignations de menu d'un module
     */
    public function getMenuAssignments($moduleId)
    {
        $query = $this->db->getQuery(true);
        $query->select($this->db->quoteName('menuid'))
            ->from($this->db->quoteName('#__modules_menu'))
            ->where($this->db->quoteName('moduleid') . ' = ' . (int) $moduleId);

        $this->db->setQuery($query);
        return $this->db->loadColumn();
    }

    /**
     * Crée un nouveau module
     */
    public function createModule($moduleData)
    {
        $table = TableFactory::getModuleTable();
        if (!$table) {
            throw new Exception('Impossible d\'instancier la table Module (TableFactory).');
        }

        // S'assurer que les modules custom interprètent {loadmoduleid}
        $moduleData = $this->ensurePrepareContent($moduleData);

        // Nettoyer les champs qui n'existent pas dans #__modules (ex: template sur anciens schémas)
        $moduleData = $this->filterAllowed($moduleData);

        // Conserver les valeurs brutes pour réinjection après le store (contourne les limites de taille)
        $rawContent = $moduleData['content'] ?? '';
        $rawParams = $moduleData['params'] ?? '{}';
        $rawParamsNorm = $this->normalizeParams($rawParams);

        // Éviter les erreurs de taille lors du check/store Joomla
        $safeData = $moduleData;
        $safeData['content'] = '';
        $safeData['params'] = '{}';

        // Bypass direct si la taille dépasse largement (sélection personnalisée susceptible d'avoir des gros blobs)
        $paramLen = strlen($rawParamsNorm);
        $contentLen = strlen($rawContent);
        $shouldBypass = ($paramLen > 60000 || $contentLen > 60000);

        if ($shouldBypass) {
            $this->log("[CREATE] Bypass JTable (paramLen={$paramLen}, contentLen={$contentLen})");
            $newId = $this->fallbackInsert($safeData, $rawContent, $rawParamsNorm);
        } else {
            try {
                if (!$table->bind($safeData)) {
                    throw new Exception($table->getError());
                }

            if (!$table->check()) {
                throw new Exception($table->getError());
            }

            if (!$table->store()) {
                throw new Exception($table->getError());
            }

                $newId = $table->id;
            } catch (Exception $e) {
                // Log détaillé et fallback manuel si dépassement de taille
                $this->log("[CREATE] Échec JTable::store(): {$e->getMessage()} | params_len=" . strlen($rawParams) . " | content_len=" . strlen($rawContent));
                if (stripos($e->getMessage(), 'Data too long') !== false || stripos($e->getMessage(), 'content') !== false || stripos($e->getMessage(), 'params') !== false) {
                    $newId = $this->fallbackInsert($safeData, $rawContent, $rawParams);
                } else {
                    throw $e;
                }
            }
        }

        // Réinjecter les valeurs complètes (content/params) via SQL direct pour éviter les restrictions JTable
        $finalParams = $rawParamsNorm;
        $query = $this->db->getQuery(true)
            ->update($this->db->quoteName('#__modules'))
            ->set($this->db->quoteName('content') . ' = ' . $this->db->quote($rawContent))
            ->set($this->db->quoteName('params') . ' = ' . $this->db->quote($finalParams))
            ->where($this->db->quoteName('id') . ' = ' . (int) $newId);
        $this->db->setQuery($query)->execute();

        $this->log("Module créé avec ID: " . $newId);
        return $newId;
    }

    /**
     * Met à jour un module existant
     */
    public function updateModule($id, $moduleData)
    {
        $table = TableFactory::getModuleTable();
        if (!$table) {
            throw new Exception('Impossible d\'instancier la table Module (TableFactory).');
        }

        // S'assurer que les modules custom interprètent {loadmoduleid}
        $moduleData = $this->ensurePrepareContent($moduleData);

        // Nettoyer les champs qui n'existent pas dans #__modules
        $moduleData = $this->filterAllowed($moduleData);

        $rawContent = array_key_exists('content', $moduleData) ? $moduleData['content'] : null;
        $rawParams = array_key_exists('params', $moduleData) ? $moduleData['params'] : null;
        $rawParamsNorm = $rawParams !== null ? $this->normalizeParams($rawParams) : null;

        // Pour passer le check, on retire les champs volumineux puis on les réinjecte après store.
        $safeData = $moduleData;
        if ($rawContent !== null) {
            $safeData['content'] = '';
        }
        if ($rawParams !== null) {
            $safeData['params'] = '{}';
        }

        // Bypass direct si très volumineux
        $paramLen = $rawParamsNorm !== null ? strlen($rawParamsNorm) : 0;
        $contentLen = $rawContent !== null ? strlen($rawContent) : 0;
        $shouldBypass = ($paramLen > 60000 || $contentLen > 60000);

        if (!$table->load($id)) {
            throw new Exception("Module introuvable: $id");
        }

        if ($shouldBypass) {
            $this->log("[UPDATE] Bypass JTable (paramLen={$paramLen}, contentLen={$contentLen}) pour ID=$id");
        } else {
            try {
                if (!$table->bind($safeData)) {
                    throw new Exception($table->getError());
                }

                if (!$table->check()) {
                    throw new Exception($table->getError());
                }

                if (!$table->store()) {
                    throw new Exception($table->getError());
                }
            } catch (Exception $e) {
                $this->log("[UPDATE] Échec JTable::store() ID=$id: {$e->getMessage()} | params_len=" . ($rawParamsNorm !== null ? strlen($rawParamsNorm) : 0) . " | content_len=" . ($rawContent !== null ? strlen($rawContent) : 0));
                if (stripos($e->getMessage(), 'Data too long') !== false || stripos($e->getMessage(), 'content') !== false || stripos($e->getMessage(), 'params') !== false) {
                    // Bypass direct
                    $shouldBypass = true;
                } else {
                    throw $e;
                }
            }
        }

        // Réinjecter ou bypass si nécessaire
        if ($shouldBypass || $rawContent !== null || $rawParams !== null) {
            $query = $this->db->getQuery(true)
                ->update($this->db->quoteName('#__modules'));
            if ($rawContent !== null) {
                $query->set($this->db->quoteName('content') . ' = ' . $this->db->quote($rawContent));
            }
            if ($rawParams !== null) {
                $query->set($this->db->quoteName('params') . ' = ' . $this->db->quote($rawParamsNorm ?? $this->normalizeParams($rawParams)));
            }
            $query->where($this->db->quoteName('id') . ' = ' . (int) $id);
            $this->db->setQuery($query)->execute();
        }

        $this->log("Module $id mis à jour");
        return true;
    }

    /**
     * Définit les assignations de menu pour un module
     */
    public function setMenuAssignments($moduleId, $menuIds)
    {
        // Supprimer les anciennes assignations
        $query = $this->db->getQuery(true);
        $query->delete($this->db->quoteName('#__modules_menu'))
            ->where($this->db->quoteName('moduleid') . ' = ' . (int) $moduleId);

        $this->db->setQuery($query);
        $this->db->execute();

        // Ajouter les nouvelles assignations
        if (!empty($menuIds)) {
            $query = $this->db->getQuery(true);
            $query->insert($this->db->quoteName('#__modules_menu'))
                ->columns($this->db->quoteName(['moduleid', 'menuid']));

            foreach ($menuIds as $menuId) {
                $query->values((int) $moduleId . ',' . (int) $menuId);
            }

            $this->db->setQuery($query);
            $this->db->execute();

            $this->log("Assignations de menu définies pour module $moduleId: " . count($menuIds) . " éléments");
        }
    }

    /**
     * Publie/Dépublie un module
     */
    public function setPublished($moduleId, $published)
    {
        $query = $this->db->getQuery(true);
        $query->update($this->db->quoteName('#__modules'))
            ->set($this->db->quoteName('published') . ' = ' . (int) $published)
            ->where($this->db->quoteName('id') . ' = ' . (int) $moduleId);

        $this->db->setQuery($query);
        $this->db->execute();

        $this->log("Module $moduleId " . ($published ? "publié" : "dépublié"));
    }

    /**
     * Vérifie si un module existe
     */
    public function exists($moduleId)
    {
        $query = $this->db->getQuery(true);
        $query->select('COUNT(*)')
            ->from($this->db->quoteName('#__modules'))
            ->where($this->db->quoteName('id') . ' = ' . (int) $moduleId);

        $this->db->setQuery($query);
        return (bool) $this->db->loadResult();
    }

    /**
     * Supprime un module
     */
    public function deleteModule($moduleId)
    {
        Table::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_modules/tables');
        $table = Table::getInstance('Module', 'Joomla\\Component\\Modules\\Administrator\\Table\\');

        if (!$table->delete($moduleId)) {
            throw new Exception($table->getError());
        }

        $this->log("Module $moduleId supprimé");
        return true;
    }

    private function log($message)
    {
        if ($this->logger) {
            $this->logger->log($message);
        }
    }

    /**
     * Normalise le champ params en chaîne JSON.
     */
    private function normalizeParams($params)
    {
        if (is_string($params)) {
            return $params;
        }
        if (is_array($params) || is_object($params)) {
            return json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        return '{}';
    }

    /**
    * Filtre les champs selon les colonnes réellement présentes dans #__modules
    */
    private function filterAllowed(array $data): array
    {
        $cols = $this->getModuleColumns();
        return array_filter(
            $data,
            function ($k) use ($cols) {
                return in_array($k, $cols, true);
            },
            ARRAY_FILTER_USE_KEY
        );
    }

    /**
     * Retourne la liste des colonnes de #__modules (mise en cache)
     */
    private function getModuleColumns(): array
    {
        if (self::$moduleColumns === null) {
            $columns = $this->db->getTableColumns('#__modules');
            self::$moduleColumns = array_keys($columns);
        }
        return self::$moduleColumns;
    }

    private function hasColumn(string $name): bool
    {
        return in_array($name, $this->getModuleColumns(), true);
    }

    /**
     * Retourne l'ID d'un module déjà importé ayant l'ID original donné
     * (détecté dans params.moduleexport_original_id ou note "[Original ID: X]").
     */
    public function findModuleIdByOriginalId(int $originalId): ?int
    {
        if ($originalId <= 0) {
            return null;
        }

        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName('id'))
            ->from($this->db->quoteName('#__modules'))
            ->where('(' .
                $this->db->quoteName('note') . ' LIKE ' . $this->db->quote('%[Original ID: ' . (int)$originalId . ']%') .
                ' OR ' . $this->db->quoteName('params') . ' LIKE ' . $this->db->quote('%"moduleexport_original_id":' . (int)$originalId . '%') .
            ')')
            ->order($this->db->quoteName('id') . ' DESC');

        $this->db->setQuery($query);
        $found = (int) $this->db->loadResult();
        return $found > 0 ? $found : null;
    }

    /**
     * Insertion manuelle fallback pour contourner les limites de JTable (taille content/params).
     */
    private function fallbackInsert(array $safeData, string $rawContent, $rawParams): int
    {
        $user = Factory::getUser();
        $now = Factory::getDate()->toSql();

        $fields = [
            'title' => $safeData['title'] ?? 'Module importé',
            'note' => $safeData['note'] ?? '',
            'content' => '', // on réinjectera après
            'ordering' => $safeData['ordering'] ?? 0,
            'position' => $safeData['position'] ?? '',
            'published' => $safeData['published'] ?? 0,
            'module' => $safeData['module'] ?? '',
            'access' => $safeData['access'] ?? 1,
            'showtitle' => $safeData['showtitle'] ?? 1,
            'params' => '{}', // on réinjectera après
            'client_id' => $safeData['client_id'] ?? 0,
            'language' => $safeData['language'] ?? '*',
            'publish_up' => $safeData['publish_up'] ?? null,
            'publish_down' => $safeData['publish_down'] ?? null,
            // 'template' ajouté plus bas uniquement si la colonne existe
            'created' => $now,
            'created_by' => $user->id ?? 0,
            'modified' => $now,
            'modified_by' => $user->id ?? 0
        ];

        if ($this->hasColumn('template')) {
            $fields['template'] = $safeData['template'] ?? null;
        }

        $columns = [];
        $values = [];
        $allowed = $this->getModuleColumns();
        foreach ($fields as $k => $v) {
            if (!in_array($k, $allowed, true)) {
                continue;
            }
            $columns[] = $this->db->quoteName($k);
            $values[] = $v === null ? 'NULL' : $this->db->quote($v);
        }

        $query = $this->db->getQuery(true)
            ->insert($this->db->quoteName('#__modules'))
            ->columns($columns)
            ->values(implode(',', $values));
        $this->db->setQuery($query)->execute();

        $newId = (int) $this->db->insertid();
        $this->log("[CREATE][fallback] Module inséré ID=$newId (fallback).");
        return $newId;
    }

    /**
     * Si module=mod_custom et content contient {loadmoduleid}, forcer prepare_content=1
     */
    private function ensurePrepareContent(array $moduleData): array
    {
        $moduleType = strtolower((string)($moduleData['module'] ?? ''));
        $content = (string)($moduleData['content'] ?? '');
        if ($moduleType === 'mod_custom' && stripos($content, '{loadmoduleid') !== false) {
            $paramsArr = $this->paramsToArray($moduleData['params'] ?? '{}');
            $paramsArr['prepare_content'] = 1;
            $moduleData['params'] = $paramsArr;
            $this->log("[PREPARE_CONTENT] forcé (mod_custom + loadmoduleid) title=\"" . ($moduleData['title'] ?? '') . "\"");
        }
        return $moduleData;
    }

    /**
     * Convertit params en array pour manipulation.
     */
    private function paramsToArray($params): array
    {
        if (is_array($params)) {
            return $params;
        }
        if (is_object($params)) {
            return (array)$params;
        }
        if (is_string($params)) {
            $decoded = json_decode($params, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                return $decoded;
            }
        }
        return [];
    }
}
