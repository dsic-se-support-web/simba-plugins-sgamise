<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.ModuleExport
 */
defined('_JEXEC') or die;


class IdMappingService
{
    private $idMap = [];
    private $mappingLog = [];
    private $logger;

    public function __construct($logger = null)
    {
        $this->logger = $logger;
    }

    /**
     * Enregistre un mapping entre ancien et nouvel ID
     */
    public function addMapping($oldId, $newId, $moduleTitle = '')
    {
        $this->idMap[$oldId] = $newId;
        $logEntry = "ID Mapping: $oldId → $newId";
        if ($moduleTitle) {
            $logEntry .= " ($moduleTitle)";
        }
        $this->mappingLog[] = $logEntry;
        $this->log($logEntry);
    }

    /**
     * Récupère le nouvel ID correspondant à un ancien ID
     */
    public function getNewId($oldId)
    {
        return $this->idMap[$oldId] ?? null;
    }

    /**
     * Récupère tous les mappings
     */
    public function getAllMappings()
    {
        return $this->idMap;
    }

    /**
     * Récupère le log des mappings
     */
    public function getMappingLog()
    {
        return $this->mappingLog;
    }

    /**
     * Vérifie si un ID a été mappé
     */
    public function isMapped($oldId)
    {
        return isset($this->idMap[$oldId]);
    }

    /**
     * Remplace les références {loadmoduleid X} dans une chaîne
     */
    public function replaceReferences($content)
    {
        if (empty($content)) {
            return $content;
        }

        $pattern = '/\{loadmoduleid\s+(\d+)\}/i';
        $replacedContent = preg_replace_callback($pattern, function($matches) {
            $oldId = (int) $matches[1];
            $newId = $this->getNewId($oldId);

            if ($newId !== null) {
                $this->log("Remplacement référence: {loadmoduleid $oldId} → {loadmoduleid $newId}");
                return "{loadmoduleid $newId}";
            }

            // Si pas de mapping trouvé, on garde l'original
            $this->log("Avertissement: Référence non mappée {loadmoduleid $oldId}");
            return $matches[0];
        }, $content);

        return $replacedContent;
    }

    /**
     * Remplace les références dans un tableau de données de module
     */
    public function replaceReferencesInModule(&$moduleData)
    {
        // Remplacer dans le content
        if (isset($moduleData['content'])) {
            $moduleData['content'] = $this->replaceReferences($moduleData['content']);
        }

        // Remplacer dans les params
        if (isset($moduleData['params'])) {
            if (is_string($moduleData['params'])) {
                $moduleData['params'] = $this->replaceReferences($moduleData['params']);
            } elseif (is_array($moduleData['params']) || is_object($moduleData['params'])) {
                $paramsJson = json_encode($moduleData['params']);
                $paramsJson = $this->replaceReferences($paramsJson);
                $moduleData['params'] = json_decode($paramsJson, true);
            }
        }
    }

    /**
     * Détecte toutes les références {loadmoduleid X} dans une chaîne
     */
    public function detectReferences($content)
    {
        if (empty($content)) {
            return [];
        }

        $pattern = '/\{loadmoduleid\s+(\d+)\}/i';
        preg_match_all($pattern, $content, $matches);

        return array_map('intval', $matches[1] ?? []);
    }

    /**
     * Génère un rapport de mapping
     */
    public function generateReport()
    {
        $report = [
            'total_mappings' => count($this->idMap),
            'mappings' => $this->idMap,
            'log' => $this->mappingLog
        ];

        return $report;
    }

    /**
     * Réinitialise tous les mappings
     */
    public function reset()
    {
        $this->idMap = [];
        $this->mappingLog = [];
        $this->log("Mappings réinitialisés");
    }

    private function log($message)
    {
        if ($this->logger) {
            $this->logger->log($message, 'id_mapping.log');
        }
    }
}
