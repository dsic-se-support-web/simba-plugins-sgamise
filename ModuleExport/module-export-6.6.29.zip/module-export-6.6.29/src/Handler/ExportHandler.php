<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.ModuleExport
 */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;

require_once __DIR__ . '/../Service/ModuleService.php';
require_once __DIR__ . '/../Utility/Logger.php';
require_once __DIR__ . '/../Utility/JsonValidator.php';

class ExportHandler
{
    private $moduleService;
    private $logger;
    private $params;

    public function __construct($params, $logger = null)
    {
        $this->params = $params;
        $this->logger = $logger ?: new ModuleExportLogger();
        $this->moduleService = new ModuleService($this->logger);
    }

    /**
     * Exporte un module unique
     */
    public function exportModule($moduleId, $disableModule = false)
    {
        $this->logger->log("Début export module ID: $moduleId");

        // Récupérer les données du module
        $fullModule = $this->moduleService->getModule($moduleId);

        if (!$fullModule) {
            throw new Exception("Module introuvable: $moduleId");
        }

        // Récupérer les assignations de menu
        $menuAssignments = $this->moduleService->getMenuAssignments($moduleId);

        // Récupérer les conditions Regular Labs si disponible
        $rlConditions = $this->getRegularLabsConditions($moduleId);

        // Préparer les données d'export
        $user = Factory::getUser();
        $exportData = [
            'module' => [
                'title' => $fullModule['title'],
                'content' => $fullModule['content'],
                'ordering' => $fullModule['ordering'],
                'position' => $fullModule['position'],
                'published' => $fullModule['published'],
                'module' => $fullModule['module'],
                'access' => $fullModule['access'],
                'showtitle' => $fullModule['showtitle'],
                'params' => $fullModule['params'],
                'client_id' => $fullModule['client_id'],
                'language' => $fullModule['language'],
                'description' => $fullModule['description'] ?? '',
                'publish_up' => $fullModule['publish_up'],
                'publish_down' => $fullModule['publish_down'],
                'id' => $fullModule['id']
            ],
            'menu_assignments' => $menuAssignments,
            'export_date' => date('Y-m-d H:i:s'),
            'joomla_version' => JVERSION,
            'exported_by' => $user->username
        ];

        if ($rlConditions !== null) {
            $exportData['regularlabs_conditions'] = $rlConditions;
        }

        // Désactiver le module si demandé
        if ($disableModule) {
            $this->moduleService->setPublished($moduleId, 0);
            $this->logger->log("Module $moduleId désactivé après export");
        }

        // Générer le nom de fichier
        $filename = JsonValidator::sanitizeFilename($fullModule['title']) . '.json';

        $this->logger->log("Export module $moduleId terminé avec succès");

        return [
            'content' => JsonValidator::encode($exportData),
            'filename' => $filename,
            'module_title' => $fullModule['title']
        ];
    }

    /**
     * Exporte plusieurs modules
     */
    public function exportMultipleModules($moduleIds, $disableModules = false, $format = 'single')
    {
        $this->logger->log("Début export multiple: " . count($moduleIds) . " modules");

        $results = [];
        $errors = [];

        foreach ($moduleIds as $moduleId) {
            try {
                $result = $this->exportModule($moduleId, $disableModules);
                $results[] = $result;
            } catch (Exception $e) {
                $errors[] = [
                    'module_id' => $moduleId,
                    'error' => $e->getMessage()
                ];
                $this->logger->log("Erreur export module $moduleId: " . $e->getMessage());
            }
        }

        if ($format === 'single') {
            // Un seul fichier contenant tous les modules
            return $this->createSingleFile($results);
        } else {
            // Fichiers séparés
            return [
                'format' => 'multiple',
                'files' => $results,
                'errors' => $errors
            ];
        }
    }

    /**
     * Crée un fichier unique contenant plusieurs modules
     */
    private function createSingleFile($exportResults)
    {
        $modules = [];

        foreach ($exportResults as $result) {
            $moduleData = json_decode($result['content'], true);
            $modules[] = $moduleData;
        }

        $multiExportData = [
            'modules' => $modules,
            'export_date' => date('Y-m-d H:i:s'),
            'joomla_version' => JVERSION,
            'total_modules' => count($modules)
        ];

        $filename = 'modules_export_' . date('Y-m-d_His') . '.json';

        return [
            'format' => 'single',
            'content' => JsonValidator::encode($multiExportData),
            'filename' => $filename,
            'total_modules' => count($modules)
        ];
    }

    /**
     * Récupère les conditions Regular Labs pour un module
     */
    private function getRegularLabsConditions($moduleId)
    {
        $handleRlConditions = $this->params->get('handle_rl_conditions', 1);

        if (!$handleRlConditions) {
            return null;
        }

        $isConditionsInstalled = \Joomla\CMS\Component\ComponentHelper::isEnabled('com_conditions');

        if (!$isConditionsInstalled) {
            return null;
        }

        try {
            $db = Factory::getDbo();
            $query = $db->getQuery(true);
            $query->select('*')
                ->from($db->quoteName('#__conditions'))
                ->where($db->quoteName('item_id') . ' = ' . (int) $moduleId)
                ->where($db->quoteName('item_type') . ' = ' . $db->quote('modules'));

            $db->setQuery($query);
            $conditions = $db->loadAssocList();

            return $conditions ?: null;

        } catch (Exception $e) {
            $this->logger->log("Erreur récupération conditions RL pour module $moduleId: " . $e->getMessage());
            return null;
        }
    }
}
