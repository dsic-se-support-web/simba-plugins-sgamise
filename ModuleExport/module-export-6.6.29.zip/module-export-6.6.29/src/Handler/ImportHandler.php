<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.ModuleExport
 */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;

require_once __DIR__ . '/../Service/ModuleService.php';
require_once __DIR__ . '/../Service/IdMappingService.php';
require_once __DIR__ . '/../Service/CacheService.php';
require_once __DIR__ . '/../Utility/Logger.php';
require_once __DIR__ . '/../Utility/JsonValidator.php';

class ImportHandler
{
    private $moduleService;
    private $idMappingService;
    private $cacheService;
    private $logger;
    private $params;

    public function __construct($params, $logger = null)
    {
        $this->params = $params;
        $this->logger = $logger ?: new ModuleExportLogger();
        $this->moduleService = new ModuleService($this->logger);
        $this->idMappingService = new IdMappingService($this->logger);
        $this->cacheService = new CacheService($this->logger);
    }

    /**
     * Importe des modules depuis des données JSON
     */
    public function importModules($jsonData, $options = [])
    {
        $this->logger->log("=== DÉBUT IMPORT ===");

        // Options par défaut
        $runIdMapping = $options['id_mapping'] ?? true;
        $selectedModules = $options['selected_modules'] ?? null;
        $findReplace = $options['find_replace'] ?? null;

        // Extraire les modules du JSON
        $modulesToImport = JsonValidator::extractModules($jsonData);

        $this->logger->log("Modules détectés: " . count($modulesToImport));

        // Filtrer les modules sélectionnés si applicable
        if (is_array($selectedModules) && count($selectedModules) > 0) {
            $modulesToImport = array_filter($modulesToImport, function($module, $index) use ($selectedModules) {
                return in_array($index, $selectedModules);
            }, ARRAY_FILTER_USE_BOTH);

            $this->logger->log("Modules filtrés: " . count($modulesToImport));
        } elseif (is_array($selectedModules) && count($selectedModules) === 0) {
            // Aucun module explicitement sélectionné => on importe tout (comportement plus permissif)
            $this->logger->log("Aucun module sélectionné explicitement, import de tous les modules.");
        }

        // Appliquer find/replace si demandé
        if ($findReplace && !empty($findReplace['find'])) {
            $this->applyFindReplace($modulesToImport, $findReplace['find'], $findReplace['replace']);
        }

        // Phase 1: Pré-scan - Détecter les dépendances
        $dependencies = [];
        $moduleRegistry = [];

        if ($runIdMapping) {
            $this->logger->log("--- PHASE 1: PRÉ-SCAN ---");
            list($dependencies, $moduleRegistry) = $this->prescanModules($modulesToImport);
        }

        // Phase 2: Tri topologique
        if ($runIdMapping && !empty($dependencies)) {
            $this->logger->log("--- PHASE 2: TRI TOPOLOGIQUE ---");
            $modulesToImport = $this->sortModulesByDependencies($modulesToImport, $dependencies, $moduleRegistry);
        }

        // Phase 3: Import des modules
        $this->logger->log("--- PHASE 3: IMPORT ---");
        $results = $this->importModulesPhase($modulesToImport, $runIdMapping);

        // Phase 4: Mise à jour des références
        if ($runIdMapping) {
            $this->logger->log("--- PHASE 4: MISE À JOUR RÉFÉRENCES ---");
            $this->updateReferences($results['created_modules']);
        }

        // Nettoyer le cache
        $this->cacheService->clearModuleCaches();

        $this->logger->log("=== FIN IMPORT ===");
        $this->logger->log("Succès: {$results['imported_count']} | Échecs: {$results['failed_count']}");

        return [
            'success' => true,
            // Alias pour compat frontend legacy
            'imported' => $results['imported_count'],
            'failed' => $results['failed_count'],
            'imported_count' => $results['imported_count'],
            'failed_count' => $results['failed_count'],
            'failed_modules' => $results['failed_modules'],
            'created_modules' => $results['created_modules'],
            'id_mapping' => $runIdMapping ? $this->idMappingService->getAllMappings() : [],
            'mapping_log' => $runIdMapping ? $this->idMappingService->getMappingLog() : [],
            'warnings' => $results['warnings']
        ];
    }

    /**
     * Phase 1: Pré-scan des modules pour détecter les dépendances
     */
    private function prescanModules($modulesToImport)
    {
        $dependencies = [];
        $moduleRegistry = [];

        foreach ($modulesToImport as $idx => $moduleItem) {
            $moduleData = isset($moduleItem['module']) && is_array($moduleItem['module'])
                ? $moduleItem['module']
                : $moduleItem;

            $originalId = $moduleItem['moduleId'] ?? ($moduleData['id'] ?? null);
            $content = $moduleData['content'] ?? '';
            $params = $moduleData['params'] ?? '{}';

            if (is_array($params) || is_object($params)) {
                $params = json_encode($params);
            }

            if ($originalId && is_numeric($originalId)) {
                $moduleRegistry[$originalId] = [
                    'title' => $moduleData['title'] ?? '',
                    'module' => $moduleData['module'] ?? '',
                    'position' => $moduleData['position'] ?? '',
                    'index' => $idx
                ];

                // Détecter les références dans content et params
                $refs = array_merge(
                    $this->idMappingService->detectReferences($content),
                    $this->idMappingService->detectReferences($params)
                );

                $dependencies[$originalId] = array_unique($refs);

                if (!empty($refs)) {
                    $this->logger->log("Module ID $originalId a des dépendances: " . implode(', ', $refs));
                }
            }
        }

        return [$dependencies, $moduleRegistry];
    }

    /**
     * Phase 2: Tri topologique des modules selon leurs dépendances
     */
    private function sortModulesByDependencies($modulesToImport, $dependencies, $moduleRegistry)
    {
        // Algorithme de tri topologique simplifié
        // Les modules sans dépendances sont importés en premier

        $sorted = [];
        $noDeps = [];
        $withDeps = [];

        foreach ($modulesToImport as $idx => $module) {
            $moduleData = isset($module['module']) ? $module['module'] : $module;
            $originalId = $module['moduleId'] ?? ($moduleData['id'] ?? null);

            if (empty($dependencies[$originalId])) {
                $noDeps[] = $module;
            } else {
                $withDeps[] = $module;
            }
        }

        $this->logger->log("Modules sans dépendances: " . count($noDeps));
        $this->logger->log("Modules avec dépendances: " . count($withDeps));

        return array_merge($noDeps, $withDeps);
    }

    /**
     * Phase 3: Import des modules
     */
    private function importModulesPhase($modulesToImport, $runIdMapping)
    {
        $importedCount = 0;
        $failedCount = 0;
        $failedModules = [];
        $createdModules = [];
        $warnings = [];

        foreach ($modulesToImport as $idx => $moduleItem) {
            try {
                $moduleData = isset($moduleItem['module']) && is_array($moduleItem['module'])
                    ? $moduleItem['module']
                    : $moduleItem;

                $originalId = $moduleItem['moduleId'] ?? ($moduleData['id'] ?? null);

                // Si un module avec le même Original ID existe déjà, on met à jour au lieu de dupliquer
                $existingId = null;
                if ($runIdMapping && $originalId) {
                    $existingId = $this->moduleService->findModuleIdByOriginalId((int) $originalId);
                    if ($existingId) {
                        $this->logger->log("Original ID {$originalId} déjà présent (ID {$existingId}), mise à jour au lieu de création.");
                    }
                }

                // DEBUG : tailles avant insertion
                $contentLen = isset($moduleData['content']) ? strlen((string)$moduleData['content']) : 0;
                $paramsLen = isset($moduleData['params'])
                    ? (is_string($moduleData['params']) ? strlen($moduleData['params']) : strlen(json_encode($moduleData['params'])))
                    : 0;
                $this->logger->log("[IMPORT][MODULE] title=\"{$moduleData['title']}\" mod={$moduleData['module']} original_id={$originalId} existing_id=" . ($existingId ?? 'null') . " content_len={$contentLen} params_len={$paramsLen}");

                // Préparer les données pour l'insertion
                $newModuleData = [
                    'title' => $moduleData['title'] ?? 'Module importé',
                    'content' => $moduleData['content'] ?? '',
                    'ordering' => $moduleData['ordering'] ?? 0,
                    'position' => $moduleData['position'] ?? '',
                    'published' => $moduleData['published'] ?? 0,
                    'module' => $moduleData['module'] ?? '',
                    'access' => $moduleData['access'] ?? 1,
                    'showtitle' => $moduleData['showtitle'] ?? 1,
                    'params' => is_string($moduleData['params']) ? $moduleData['params'] : json_encode($moduleData['params']),
                    'client_id' => $moduleData['client_id'] ?? 0,
                    'language' => $moduleData['language'] ?? '*',
                    'publish_up' => $moduleData['publish_up'] ?? null,
                    'publish_down' => $moduleData['publish_down'] ?? null
                ];

                // Créer ou mettre à jour le module
                if ($existingId) {
                    $this->moduleService->updateModule($existingId, $newModuleData);
                    $newId = $existingId;
                } else {
                    $newId = $this->moduleService->createModule($newModuleData);
                }

                $this->logger->log("[IMPORT][MODULE] post-save ID={$newId} (original={$originalId})");

                // Enregistrer le mapping
                if ($runIdMapping && $originalId) {
                    $this->idMappingService->addMapping($originalId, $newId, $newModuleData['title']);
                }

                // Définir les assignations de menu
                if (isset($moduleItem['menu_assignments'])) {
                    $this->moduleService->setMenuAssignments($newId, $moduleItem['menu_assignments']);
                }

                $createdModules[] = [
                    'new_id' => $newId,
                    'original_id' => $originalId,
                    'title' => $newModuleData['title']
                ];

                $importedCount++;

                $this->logger->log("Module importé: {$newModuleData['title']} (ID: $newId)");

            } catch (Exception $e) {
                $failedCount++;
                $failedModules[] = [
                    'title' => $moduleData['title'] ?? 'Inconnu',
                    'error' => $e->getMessage()
                ];
                $this->logger->log("Échec import: " . $e->getMessage());
            }
        }

        return [
            'imported_count' => $importedCount,
            'failed_count' => $failedCount,
            'failed_modules' => $failedModules,
            'created_modules' => $createdModules,
            'warnings' => $warnings
        ];
    }

    /**
     * Phase 4: Mise à jour des références {loadmoduleid}
     */
    private function updateReferences($createdModules)
    {
        foreach ($createdModules as $module) {
            try {
                $moduleData = $this->moduleService->getModule($module['new_id']);

                // Remplacer les références
                $this->idMappingService->replaceReferencesInModule($moduleData);

                // Mettre à jour le module
                $this->moduleService->updateModule($module['new_id'], [
                    'content' => $moduleData['content'],
                    'params' => $moduleData['params']
                ]);

                $this->logger->log("Références mises à jour pour module {$module['new_id']}");
                $this->logger->log("[MAPPING][MODULE] ID {$module['new_id']} content_len=" . strlen((string)$moduleData['content']) . " params_len=" . strlen((string)$moduleData['params']));

            } catch (Exception $e) {
                $this->logger->log("Erreur mise à jour références module {$module['new_id']}: " . $e->getMessage());
            }
        }
    }

    /**
     * Applique un find/replace sur tous les modules
     */
    private function applyFindReplace(&$modulesToImport, $find, $replace)
    {
        $this->logger->log("Application find/replace: '$find' => '$replace'");

        foreach ($modulesToImport as &$moduleItem) {
            $moduleData = &$moduleItem['module'];

            if (isset($moduleData['title'])) {
                $moduleData['title'] = str_replace($find, $replace, $moduleData['title']);
            }

            if (isset($moduleData['content'])) {
                $moduleData['content'] = str_replace($find, $replace, $moduleData['content']);
            }

            if (isset($moduleData['params'])) {
                if (is_string($moduleData['params'])) {
                    $moduleData['params'] = str_replace($find, $replace, $moduleData['params']);
                }
            }
        }
    }

    /**
     * Récupère le service de mapping d'IDs
     */
    public function getIdMappingService()
    {
        return $this->idMappingService;
    }
}
