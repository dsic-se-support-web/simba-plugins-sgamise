import { getCurrentComponent } from "./utils/component.js";
import { formatChartData } from "./utils/formSerializer.js";
import {
    getTamponBarligne,
    getTamponCarte,
    getTamponGauge,
    getTamponGraphe,
} from './template-engine.js'
import { generateDsfrId } from "./utils/uid.js";
import { injectDsfrAttributes } from "./utils/attributes.js";


async function generate(){
    const component = getCurrentComponent()
    if (!component) return -1; 
    const key = component.key; 

    const formElement = document.getElementById(key);
    const formData = formatChartData(new FormData(formElement))
    
    if (!formElement.checkValidity()) {
        formElement.reportValidity(); 
        return -1; 
    }
    
    let resultTampon = "";
    try {
        switch (key) {
            case "graphe-dsfr":
                resultTampon = await getTamponGraphe(formData);
                break;
            case "graphe-jauge-dsfr":
                resultTampon = await getTamponGauge(formData);
                break;
            case "graphe-barligne-dsfr":
                resultTampon = await getTamponBarligne(formData);
                break;
            case "graphe-carte-dsfr":
                resultTampon = await getTamponCarte(formData);
                break;
            default:
                console.warn("Composant inconnu :", key);
                return -1;
        }
        const id = component.dsfrId ? component.dsfrId : generateDsfrId()
        const finalTampon =  injectDsfrAttributes(
            resultTampon, id, formData, component.key
        )
        return finalTampon

    } catch (error) {
        console.error("Erreur lors de la génération du Tampon :", error);
        return -1;
    }

}

export {
    generate
}