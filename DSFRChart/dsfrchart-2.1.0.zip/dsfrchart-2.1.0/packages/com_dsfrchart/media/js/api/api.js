import { fetchJson, fetchText } from '../utils/fetch.js';

const BASE = 'index.php?option=com_dsfrchart';

export async function getTemplate(name){    
    return fetchText(
        `${BASE}&task=display.getTemplate&name=${name}&format=raw`
    )
}


export async function renderPreview(shortcode) {

    const formData = new FormData();

    formData.append('shortcode', shortcode);
    formData.append(Joomla.getOptions('csrf.token'), '1');

    return fetchJson(
        `${BASE}&task=display.render&format=json`,
        {
            method: 'POST',
            body: formData
        }
    );
}

export async function getDataFromCSV(file, type){
    const formData = new FormData();
    formData.append('csv_file', file);
    formData.append('type', type);
    formData.append(Joomla.getOptions('csrf.token'), '1');

    return fetchJson(
        `${BASE}&task=display.getDataFromCSV&format=json`,
        {
            method: 'POST',
            body: formData
        }
    );
}

export async function getForm(key){
    const formData = new FormData();
    formData.append('key', key);
    formData.append(Joomla.getOptions('csrf.token'), '1');
    const result = await fetchJson(
        `${BASE}&task=display.getForm&format=json`,
        {
            method: 'POST',
            body: formData
        }
    );
    return result.data.html;
}
