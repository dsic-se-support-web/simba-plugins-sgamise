import { getCurrentComponent } from "./component.js";
import { getForm } from "../api/api.js";
import { hydrateForm } from "./formHydrater.js";

function updateFormMap() {
    if(getCurrentComponent().key !== 'graphe-carte-dsfr') return

    const selectNiveau = document.getElementById('graphe_carte_dsfr_niveau');
    const radiosIsolation = document.querySelectorAll('input[name="graphe-carte-dsfr[isolation_regional]"]');
    const selectRegion = document.getElementById('graphe_carte_dsfr_region');

    if (selectNiveau) selectNiveau.addEventListener('change', updateAffichageFormMap);
    if (selectRegion) selectRegion.addEventListener('change', updateAffichageFormMap);
    
    radiosIsolation.forEach(radio => {
        radio.addEventListener('change', updateAffichageFormMap);
    });

    updateAffichageFormMap();
}

function updateAffichageFormMap() {
    const selectNiveau = document.getElementById('graphe_carte_dsfr_niveau'); // reg, dep, aca, ou monde
    const selectRegion = document.getElementById('graphe_carte_dsfr_region'); // si dep et isolation region
    
    if (!selectNiveau) return;
    const niveauVal = selectNiveau.value;
    
    const radioChecked = document.querySelector('input[name="graphe-carte-dsfr[isolation_regional]"]:checked');
    const isolationVal = radioChecked ? radioChecked.value : '0'; 
    const regionChoisie = selectRegion ? selectRegion.value : '';

    const inputIsolation = document.querySelector('input[name="graphe-carte-dsfr[isolation_regional]"]');
    const wrapperIsolation = inputIsolation ? inputIsolation.closest('.control-group') : null; 
    const wrapperRegion = selectRegion ? selectRegion.closest('.control-group') : null; 
    
    const fieldsetReg = document.querySelector('[name="donnees_regionales"]'); 
    const fieldsetDep = document.querySelector('[name="donnees_departementales"]'); 
    const fieldsetAca = document.querySelector('[name="donnees_academiques"]'); 
    const fieldsetMonde = document.querySelector('[name="donnees_mondiales"]'); 

    const deps = document.querySelectorAll('input[id^="graphe_carte_dsfr_dep_"]'); // tous les départements

    const handleFieldsets = () => {
        if (fieldsetReg) fieldsetReg.style.display = niveauVal === 'reg' ? 'grid' : 'none';
        if (fieldsetDep) fieldsetDep.style.display = niveauVal === 'dep' ? 'grid' : 'none';
        if (fieldsetAca) fieldsetAca.style.display = niveauVal === 'aca' ? 'grid' : 'none';
        if (fieldsetMonde) fieldsetMonde.style.display = niveauVal === 'monde' ? 'grid' : 'none';
        
        if (wrapperIsolation) wrapperIsolation.style.display = niveauVal === 'dep' ? 'grid' : 'none';
        if (wrapperRegion) wrapperRegion.style.display = niveauVal === 'dep' && isolationVal === '1' ? 'grid' : 'none';

        if (fieldsetReg) fieldsetReg.disabled = niveauVal === 'reg' ? false : true;
        if (fieldsetDep) fieldsetDep.disabled = niveauVal === 'dep' ? false : true;
        if (fieldsetAca) fieldsetAca.disabled = niveauVal === 'aca' ? false : true;
        if (fieldsetMonde) fieldsetMonde.disabled = niveauVal === 'monde' ? false : true;
        
        if (wrapperIsolation) wrapperIsolation.disabled = niveauVal === 'dep' ? false : true;
        if (wrapperRegion) wrapperRegion.disabled = niveauVal === 'dep' && isolationVal === '1' ? false : true;
    }

    handleFieldsets();
   
    if (niveauVal === 'dep') {        
        if (isolationVal === '0') {            
            deps.forEach(dep => {
                const wrapperDep = dep.closest('.control-group');
                if (wrapperDep) wrapperDep.style.display = 'block';
                dep.disabled = false;
            });
        } 
        else if (isolationVal === '1') {            
            const classReg = 'region-' + regionChoisie;
            deps.forEach(dep => {
                const wrapperDep = dep.closest('.control-group');
                if (wrapperDep) {
                    if (dep.classList.contains(classReg)) {
                        wrapperDep.style.display = 'block'; 
                        dep.disabled = false;
                    } else {
                        wrapperDep.style.display = 'none'; 
                        dep.disabled = true;
                    }
                }
            });
        }
    }
}

function updateForm() {

    const radiosSourceIa = document.querySelectorAll(`input[name="${getCurrentComponent().key}[est_source_ia]"]`);
    if(!radiosSourceIa) return;
    radiosSourceIa.forEach(radio => {
        radio.addEventListener('change', updateAffichage);
    });

    updateAffichage();
}

function updateAffichage() {
    const radioChecked = document.querySelector(`input[name="${getCurrentComponent().key}[est_source_ia]"]:checked`);
    
    if (!radioChecked) return;

    const estSourceIaVal = radioChecked.value;
    const inputLienIa = document.querySelector(`input[name="${getCurrentComponent().key}[lien_ia]"]`);
    if (!inputLienIa) return;

    const wrapperLienIa = inputLienIa.closest('.control-group');

    if (wrapperLienIa) {
        if (estSourceIaVal === '1') {
            wrapperLienIa.style.display = 'block';
            inputLienIa.disabled = false;
        } else {
            wrapperLienIa.style.display = 'none';
            inputLienIa.disabled = true;
        }
    }
}

export async function loadCurrentComposantForm(propsObject = null){
    const currentComponent = getCurrentComponent();
    document.getElementById('form').innerHTML = await getForm(currentComponent.key);

    const currentForm = document.getElementById(currentComponent.key);
    if (currentForm) {
        document.querySelector('.main-content').scrollTop = 0
        if(propsObject) hydrateForm(currentForm, propsObject, currentComponent.key)
        if (currentComponent.key === 'graphe-carte-dsfr'){
            updateFormMap()
        }
        updateForm()
    }
}

