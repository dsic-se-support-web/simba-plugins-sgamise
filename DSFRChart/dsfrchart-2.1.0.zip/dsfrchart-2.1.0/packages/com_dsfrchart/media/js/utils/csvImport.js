import { getDataFromCSV } from '../api/api.js'
import { getCurrentComponent } from './component.js';
import { loadCurrentComposantForm } from './formUdpater.js';
import { formatChartData } from './formSerializer.js';

export async function importCSVData() {
    const currentComponent = getCurrentComponent();
    const fileInput = document.getElementById('csvFileInput');
    const resultMessage = document.getElementById('resultMessage');
    if (fileInput.files.length === 0) {
        resultMessage.innerHTML = '<span style="color:red;">Veuillez sélectionner un fichier CSV.</span>';
        return;
    }

    resultMessage.innerHTML = `<span>Chargement en cours...</span>`;
    const file = fileInput.files[0];

    const processedData = await getDataFromCSV(file, currentComponent.key)
    
    try {

        if(!processedData.success) throw new Error(processedData.message);
        
        const data = processedData.data;
        // Pour éviter de predre les autres valeur avec le reset
        const component = getCurrentComponent()
        const key = component.key; 
        const formElement = document.getElementById(key);
        let formData = formatChartData(new FormData(formElement))
        
        formData['y_series'] = [] // Pour éviter d'avoir le premier vide

        let mapKey = [];

        switch(currentComponent.key){
            case 'graphe-dsfr':
                for (const [key, value] of Object.entries(data)) {
                    if (key === "valeurX") {
                        formData['x_values'] = value;
                    } else { // donc les Y
                        formData['y_series'].push({
                            "y_values": value
                        })
                    }    
                }
                break;

            case 'graphe-barligne-dsfr':
                for (const [key, value] of Object.entries(data)) {
                    if(key === 'valeurX') formData['valeur_abscisse'] = value;
                    if(key === 'valeurBar') formData['ordonnée_bar'] = value;
                    if(key === 'valeurLigne') formData['ordonnée_ligne'] = value;
                }
                break;

            case 'graphe-carte-dsfr':
                for (const [key, value] of Object.entries(data)) {
                    if(key === 'code') {
                        [mapKey, formData] = handleCodeMapChart(value, formData);
                    }
    
                    if(key === 'valeur'){
                        for(let i = 0; i < value.length;i++){
                            formData[mapKey[i]] = value[i];
                        }
                    }
                }
                break;  
        }
        
        // On recharge le form pour reset les index des subforms, (comportement de joomla pas sympa)
        await loadCurrentComposantForm(formData);
        resultMessage.innerHTML = `<span style="color:green;">${processedData.message || 'Succès !'}</span>`;
    
    } catch(e){
        resultMessage.innerHTML = `<span style="color:red;">${e.message}</span>`;
    }
     
    

}


function handleCodeMapChart(value, formData){
    const prefix = formData['niveau'] + "_"
    const listKeyFormData = Object.keys(formData).filter((key) => key.startsWith(prefix))
    
    const duplicates = value.filter((val, index) => value.indexOf(val) !== index);

    if (duplicates.length > 0) {
        const uniqueDuplicates = [...new Set(duplicates)]; 
        throw new Error(`Les codes suivants ont été saisis plusieurs fois : ${uniqueDuplicates.join(', ')}.`);
    }

    const mapKey = value.map(val => prefix + val);

    const extraKeys = mapKey.filter(key => !listKeyFormData.includes(key));
    if (extraKeys.length > 0) {
        const displayExtra = extraKeys.map(key => key.replace(prefix, '')).join(', ');
        throw new Error(`Les codes suivants sont invalides ou en trop : ${displayExtra}. Vérifiez le niveau géographique, l'isolation des régions si elle est activée et l'existence de ces codes.`);
    }

    return [mapKey, formData];
}


export function initModelCSVDownload(key) {
    const btnDiv = document.getElementById('download-modele-csv');
    
    const defaultBtn = btnDiv.firstElementChild; 
    defaultBtn.href = '/media/com_dsfrchart/csv/modele-' + key + '.csv';
    defaultBtn.querySelector('.title-btn-modele-csv').textContent = 'Modèle CSV';
    // Reset des btn
    while (btnDiv.children.length > 1) {
        btnDiv.removeChild(btnDiv.lastChild);
    }

    if (key === 'graphe-carte-dsfr') {
        const defaultTitle = defaultBtn.querySelector('.title-btn-modele-csv');
        defaultTitle.textContent = "Modèle CSV département";

        const suffixes = [
            { id: 'aca', text: "Modèle CSV académique" },
            { id: 'monde', text: "Modèle CSV Monde" },
            { id: 'reg', text: "Modèle CSV région" }
        ];
        
        for (const s of suffixes) {
            const btnClone = defaultBtn.cloneNode(true); 
            btnClone.href = `/media/com_dsfrchart/csv/modele-${key}-${s.id}.csv`;
            
            const cloneTitle = btnClone.querySelector('.title-btn-modele-csv');
            cloneTitle.textContent = s.text;
        
            btnDiv.appendChild(btnClone);
        }
    }
}

export function initCSVRule(key){
    
    const listRule = document.getElementById('csv-rule');
    listRule.innerHTML = '';
    const communRules = [
        "Le séparateur de colonnes doit être le point-virgule (;).",
        "La première ligne est strictement réservée aux en-têtes.", 
    ]

    switch (key) {
        case "graphe-dsfr":
            const rulesGraphe = [ 
                "La 1ère colonne doit s'appeler valeurX.",
                "Les autres colonnes doivent s'appeler valeurY1, valeurY2, etc.",       
            ]
            for(const rule of communRules.concat(rulesGraphe)){
                const li = document.createElement('li');
                li.textContent = rule;
                listRule.appendChild(li)
            }
            break;
        case "graphe-barligne-dsfr":
            const rulesBarLine = [ 
                "La 1ère colonne doit s'appeler valeurX.",
                "Les deux colonnes suivante doivent s'appeler valeurBar et valeurLigne.",
            ]
            for(const rule of communRules.concat(rulesBarLine)){
                const li = document.createElement('li');
                li.textContent = rule;
                listRule.appendChild(li)
            }
            break;
        case "graphe-carte-dsfr":
            const rulesMap = [
                "La 1ère colonne doit s'appeler code.",
                "La 2ème colonne doit s'appeler valeur.",
                "Pour les départements : La clé doit être le code ISO 3166-2 (ex: '75').",
                "Pour les régions : La clé doit être le code ISO 3166-2 (ex: 'IDF').",
                "Pour les académies : La clé doit être le code de l'académie (ex: 'PARIS').",
                "Pour les pays du monde : La clé doit être le code ISO 3166-1 alpha-2 (ex: 'FR')."
            ]
            for(const rule of communRules.concat(rulesMap)){
                const li = document.createElement('li');
                li.textContent = rule;
                listRule.appendChild(li)
            }
            break;
    }  

}