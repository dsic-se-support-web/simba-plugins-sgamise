import { getTemplate } from "./api/api.js";

async function getTamponCarte(formData){
    let resultTampon = await getTemplate('graphe-carte-dsfr');

    const prefix = formData['niveau'] + '_'

    const data = Object.fromEntries(
    Object.entries(formData)
        .filter(([key]) => key.startsWith(prefix)) // On récup que les data que nous avons besoin
        .map(([key, value]) => [key.split('_')[1], parseInt(value)]) // On garde que les chiffres (dep_01 => 01)
    );


    resultTampon = resultTampon
        .replace('{{donnees}}', JSON.stringify(data))
        .replace('{{valeur_indicateur}}', formData['valeur_indicateur'])
        .replace('{{nom_indicateur}}', formData['nom_indicateur'])
        .replace('{{niveau}}', formData['niveau'])
        .replace('{{region}}', formData['region'])
        .replace('{{couleur}}', formData['couleur'])
        .replace('{{isolation_regional}}', formData['isolation_regional'] === '1' && formData['niveau'] === 'dep'  ? 'true' : 'false')
        .replace('{{couleur}}', formData['couleur']);

    return getTamponCommun(resultTampon, formData);
}

async function getTamponBarligne(formData){
    let resultTampon = await getTemplate('graphe-barligne-dsfr');
    resultTampon = resultTampon
        .replace('{{valeur_abscisse}}', formData['valeur_abscisse'].join(','))
        .replace('{{ordonnée_bar}}',formData['ordonnée_bar'].join(','))
        .replace('{{ordonnée_ligne}}',formData['ordonnée_ligne'].join(','))
        .replace('{{unité_donnée_bar}}',formData['unité_donnée_bar'])
        .replace('{{unité_donnée_ligne}}',formData['unité_donnée_ligne'])
        .replace('{{legende_bar}}',formData['legende_bar'])
        .replace('{{legende_ligne}}',formData['legende_ligne'])
        .replace('{{couleur}}', formData['couleur'])
    return getTamponCommun(resultTampon, formData);
}

async function getTamponGauge(formData){

    let resultTampon = await getTemplate('graphe-jauge-dsfr');

    resultTampon = resultTampon.replace('{{valeur}}',formData['valeur'])
        .replace('{{debut}}',formData['debut'])
        .replace('{{fin}}',formData['fin'])
        .replace('{{date_debut}}',formData['date_debut'])
        .replace('{{date_fin}}',formData['date_fin'])

    return getTamponCommun(resultTampon, formData);
}

async function getTamponGraphe(formData){

    let seriesYTampon = "";

    formData['y_series'].forEach(s => {
        const valstring = s.y_values.join(',');
        seriesYTampon += `{valeur-ordonnée y="${valstring}" legende="${s.legende}"}\n`;
    });

    let resultTampon = await getTemplate('graphe-dsfr')
    resultTampon = resultTampon.replace('{{type}}', formData['type'])
                            .replace('{{unite}}', formData['unite'])
                            .replace('{{couleur}}', formData['couleur'])
                            .replace('{{x_values}}', formData['x_values'].join(','))
                            .replace('{{y_values}}', seriesYTampon)
    return getTamponCommun(resultTampon, formData);
}


async function getTamponCommun(Tampon, formData){
    let resultTampon = await getTemplate('databox-template');
    
    Tampon = Tampon.replace('{{databox_params}}', resultTampon) 
    .replace('{{taille}}', formData['taille'])
    .replace('{{source}}', formData['source'])
    .replace('{{date}}', formData['date'])
    .replace('{{bulle_titre}}', formData['bulle_titre'])
    .replace('{{bulle_desc}}', formData['bulle_desc'])
    // .replace('{{plein_ecran}}', formData['plein_ecran'] === '1' ? 'true' : 'false')
    .replace('{{capture_ecran}}', formData['capture_ecran']=== '1' ? 'true' : 'false')
    .replace('{{telechargement}}', formData['telechargement']=== '1' ? 'true' : 'false')
    .replace('{{titre_graphe}}', formData['titre_graphe'])
    .replace('{{est_source_ia}}', formData['est_source_ia'] === '1' ? 'true' : 'false')
    .replace('{{lien_ia}}', formData['lien_ia'] || '')
    return Tampon

}

export {
    getTamponBarligne,
    getTamponCarte,
    getTamponGauge,
    getTamponGraphe,
}