<?php 
defined('_JEXEC') or die; 

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormFactoryInterface;
use Joomla\CMS\Uri\Uri;

$this->document->setHtml5(true); 

$wa = $this->document->getWebAssetManager();

$templatePath = Uri::root(true) . '/templates/cassiopeia_dsfr';
$formsPath = JPATH_SITE . '/media/com_dsfrchart/forms';


$componentConfigs = []; 
$formsHtml = ''; 

function getHTMLFieldset($fieldset, $form){
    $formsHtml = '';
    $cssClass = isset($fieldset->class) ? 'class="' . $fieldset->class . '"' : '';
    $idClass = isset($fieldset->id) ? 'id="' . $fieldset->id . '"' : '';
    $nameAttr = isset($fieldset->name) ? 'name="' . $fieldset->name . '"' : '';
    $formsHtml .= '<fieldset ' . $cssClass .' '.$idClass.' '.$nameAttr.' style="border: none; padding: 0; margin: 0;">';
    
    $fieldsetContent = $form->renderFieldset($fieldset->name); 
    $formsHtml .= $fieldsetContent;
    $formsHtml .= '</fieldset>';

    return $formsHtml;
}

function getDataBoxHTML($formsPath, $formFactory, $key){
    $files = glob($formsPath . '/databox.xml'); 
    $formDataBox = $formFactory->createForm($key, ['control' => $key]);
    $formDataBox->loadFile($files[0]);
    $formDataBoxHTML = '';
    foreach ($formDataBox->getFieldsets() as $fieldset) {
        $formDataBoxHTML .= getHTMLFieldset($fieldset, $formDataBox);
    }

    return $formDataBoxHTML;
}

if (is_dir($formsPath)) { 
    $files = glob($formsPath . '/*-dsfr.xml'); 
    
    $formFactory = Factory::getContainer()->get(FormFactoryInterface::class);
    
    foreach ($files as $file) { 
        $key = basename($file, '.xml'); 
       
        $form = $formFactory->createForm($key, ['control' => $key]);
        
        $form->loadFile($file);
        
        $title = $form->getField('form_title')->value;
        $desc = $form->getField('form_description')->value;
        $componentConfigs[] = [
            'key' => $key,
            'title' => $title,
            'description' => $desc
        ];
        
        // render dans le vide pour fix bug joomla des subforms qui ne fonctionne pas
        foreach ($form->getFieldsets() as $fieldset) {
            $form->renderFieldset($fieldset->name); 
        }
    } 
} 

$this->document->addScriptOptions('dsfrchart_data', [
    'editorId'          => $this->editorId,
    'componentConfig'   => $componentConfigs,
]);

$this->document->addStyleSheet($templatePath . '/dsfr/dsfr.min.css');
$this->document->addStyleSheet($templatePath . '/dsfr/core/core.min.css');
$this->document->addStyleSheet($templatePath . '/dsfr/utility/utility.min.css');
$this->document->addStyleSheet($templatePath . '/user.css');
$this->document->addStyleSheet(Uri::root(true) . '/media/com_dsfrchart/css/style.css');

$wa->registerScript(
    'com_dsfrchart.script',
    'media/com_dsfrchart/js/script.js',
    [],
    [
        'type'  => 'module',
        'defer' => true
    ]
);

$wa->useScript('com_dsfrchart.script');

$this->document->addScriptOptions('dsfr_paths', [
    'css' => [
        $templatePath . '/dsfr/dsfr.min.css',
        $templatePath . '/dsfr/core/core.min.css',
        $templatePath . '/dsfr/utility/utility.min.css',
        $templatePath . '/dsfr/DSFRChart/DSFRChart.css',
        $templatePath . '/user.css'
    ],
    'js' => [
        $templatePath . '/dsfr/dsfr.module.min.js',
        $templatePath . '/dsfr/core/core.module.min.js',
        $templatePath . '/dsfr/DSFRChart/DSFRChart.js'
    ]
]);
?> 

<div class="modal-layout"> 
    <div class="sidebar"> 
        <div class="sidebar-header"> 
            <button type="button" id="btn-back" class="fr-btn fr-btn--tertiary-no-outline fr-icon-arrow-left-line fr-btn--icon-left d-none">
                Retour accueil
            </button> 
            <h1 id="menu-title" class="h6 text-uppercase fw-bold text-muted">Composants</h1> 
        </div> 
        <div class="list-group list-group-flush" id="component-menu"></div> 
    </div> 

    <div class="main-content"> 
        
        <div id="empty-state" class="empty-state">
            <div class="empty-state-header">
                <h2 class="m-0 mb-1">
                    Graphiques DSFR
                </h2>
                Sélectionnez un graphique dans le menu de gauche
                pour afficher son formulaire de configuration.
                Vous pourrez ensuite :
                <ul>
                    <li>Configurer ses options</li>
                    <li>Prévisualiser le rendu DSFR</li>
                    <li>Insérer automatiquement le composant dans l'article</li>
                </ul>
            </div>

            <div class="empty-state-edit-list mt-4">
                <h3 class="m-0 mb-1">Modification des graphiques</h3>
                <p class="text-muted m-0 mb-1">Voici les composants présents dans votre article. Cliquez sur un composant pour le modifier :</p>
                <div class="fr-alert fr-alert--warning mb-1 d-none" id='msg-confirm-delete-graphe'>
                    <h3 class="fr-alert__title">Attention !</h3>
                    <p>Êtes-vous sûr de vouloir supprimer le graphique: <span id='graphe-name'></span> ? Il sera supprimé définitivement.</p>
                    <div class="text-end">
                        <button type="button" class="fr-btn fr-icon-close-circle-fill fr-btn--icon-left" id="btn-cancel-graphe">
                            Annuler
                        </button>
                        <button type="button" class="fr-btn fr-icon-delete-fill fr-btn--icon-left fr-btn--secondary" id="btn-delete-graphe">
                            Confirmer
                        </button>
                    </div>
                </div>
                <ul id="list-graphe">
                </ul>
            </div>

            <div class="fr-alert fr-alert--info">
                <h3 class="fr-alert__title">Important !</h3>
                <p>Pour cause d'une limitation de l'éditeur, les graphiques ne seront pas visibles après insertion dans l'article mais uniquement en prévisualisation et dans l'article en front office après enregistrement. </p>
            </div>
        </div>
            
            <div id="form-header">
                <h2 id="form-title"></h2>
                <p id="form-description"></p>
                <div class="fr-alert fr-alert--warning d-none mb-3" id="msg-alert-edit">
                    <h3 class="fr-alert__title">Attention !</h3>
                    <p>Vous êtes en mode modification ! Vous pouvez modifier les informations, mais n'oubliez pas d'enregistrer avant de quitter la page.</p>
                </div>
            </div> 
            
            <div class="card shadow-sm d-none mb-3" id="import-csv">
                <div class="card-header bg-white m-0" style="padding: 5px;">
                    <h5 class="card-title m-0" style="font-size: 1em;">Import de données</h5>
                </div>
                
                <div class="card-body d-flex flex-row gap-3">
                    
                    <div class="d-flex flex-column gap-3 w-50">
                        <div>
                            <label for="csvFileInput" class="form-label fw-bold">Fichier source (.csv)</label>
                            <input type="file" class="form-control" id="csvFileInput" accept=".csv" />
                        </div>
                        
                        <button type="button" id="btnUploadCsv" class="fr-btn fr-icon-upload-fill fr-btn--icon-left">
                            Importer le CSV
                        </button>

                        <div id="resultMessage" class="w-100"></div>
                    </div>

                    <div class="bg-light border rounded h-100 w-50 p-3">
                        <div class="d-flex justify-content-between align-items-center flex-wrap mb-2">
                            <span class="fw-bold text-dark">Règles à respecter :</span>
                            
                            <div id="download-modele-csv" class="d-flex gap-1 flex-wrap">
                                <a href="" download class="fr-btn--sm fr-btn--tertiary fr-icon-download-fill fr-btn--icon-left ">
                                    <span class="title-btn-modele-csv">Modèle CSV</span>
                                </a>
                            </div>
                        </div>
                        
                        <ul class="small text-muted m-0 ps-3" id="csv-rule">
                        </ul>
                    </div>

                </div>
            </div>

            <div id="form"></div>
            
            <div id="form-actions" class="mt-4 border-top pt-4 d-none"> 
                <div class="fr-alert fr-alert--info mb-1">
                    <h3 class="fr-alert__title">Important !</h3>
                    <p>Pour cause d'une limitation de l'éditeur, les graphiques ne seront pas visibles après insertion dans l'article mais uniquement en prévisualisation et dans l'article en front office après enregistrement. </p>
                </div>

                <div class="d-flex gap-1 justify-content-end">
                    <button type="button" class="fr-btn fr-icon-eye-fill fr-btn--icon-left fr-btn--secondary" id="btn-preview">
                        Générer l'aperçu
                    </button> 
                    <button type="button" class="fr-btn fr-icon-check-line fr-btn--icon-left" id="btn-insertion"> 
                        Insérer dans l'article 
                    </button> 
                </div>
                
            </div> 

            <div id="preview-container" style="margin-top: 20px; border: 1px dashed var(--border-color); padding: 10px; min-height: 200px;">
            </div>

    </div> 
</div>