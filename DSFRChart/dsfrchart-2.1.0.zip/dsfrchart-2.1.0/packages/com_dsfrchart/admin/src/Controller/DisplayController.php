<?php
namespace Joomla\Component\DsfrChart\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;
use Joomla\CMS\Response\JsonResponse;
use Joomla\CMS\Form\FormFactoryInterface;
use Exception;


class DisplayController extends BaseController {
    protected $default_view = 'modal';

    public function getForm(){
        $app = Factory::getApplication();
        $input = $app->getInput();
    
        $key = $input->get('key', '', 'cmd');
        $formsPath = JPATH_SITE . '/media/com_dsfrchart/forms';
        $formHTML = '';
        function getHTMLFieldset($fieldset, $form){
            $formsHtml = '';
            $cssClass = isset($fieldset->class) ? 'class="' . $fieldset->class . '"' : '';
            $idClass = isset($fieldset->id) ? 'id="' . $fieldset->id . '"' : '';
            $nameAttr = isset($fieldset->name) ? 'name="' . $fieldset->name . '"' : '';
            $formsHtml .= '<fieldset ' . $cssClass .' '.$idClass.' '.$nameAttr.' style="border: none; padding: 0; margin: 0;">';
            
            $fieldsetContent = $form->renderFieldset($fieldset->name); 
            $formsHtml .= $fieldsetContent;
            $formsHtml .= '</fieldset>';
        
            return $formsHtml;
        }
        
        function getDataBoxHTML($formsPath, $formFactory, $key){
            $files = glob($formsPath . '/databox.xml'); 
            $formDataBox = $formFactory->createForm($key, ['control' => $key]);
            $formDataBox->loadFile($files[0]);
            $formDataBoxHTML = '';
            foreach ($formDataBox->getFieldsets() as $fieldset) {
                $formDataBoxHTML .= getHTMLFieldset($fieldset, $formDataBox);
            }
        
            return $formDataBoxHTML;
        }
        
        if (is_dir($formsPath)) { 
            $files = glob($formsPath . '/'.$key.'.xml'); 
            $file = $files[0];
            $formFactory = Factory::getContainer()->get(FormFactoryInterface::class);
                        
            $form = $formFactory->createForm($key, ['control' => $key]);
            
            $form->loadFile($file);
            
            $formHTML .= '<form id="'. $key . '" class="jform-container">';
    
            foreach ($form->getFieldsets() as $fieldset) {
                if($fieldset->name === 'databox-params'){
                    $formHTML .= getDataBoxHTML($formsPath, $formFactory, $key);
    
                }else {
                    $formHTML .= getHTMLFieldset($fieldset, $form);
                }
            }
            
            $formHTML .= '</form>';
        
            echo new JsonResponse(['html' => $formHTML]);

        } 


    }

    public function getTemplate(){
    $app = Factory::getApplication();
    $input = $app->getInput();

    $name = $input->get('name', '', 'cmd');

    // Vérification que le nom est valide (caractères alphanumériques + tiret + point)
    if (!preg_match('/^[a-zA-Z0-9._-]+$/', $name)) {
        http_response_code(400);
        echo "Nom de fichier invalide.";
        return;
    }

    $tamponsPath = JPATH_SITE . '/media/com_dsfrchart/tampons/' . $name . '.txt';

    if (!file_exists($tamponsPath)) {
        http_response_code(404);
        echo 'Fichier ' . htmlspecialchars($tamponsPath) . ' introuvable.';
        return;
    }

    header('Content-Type: text/plain; charset=utf-8');

    echo file_get_contents($tamponsPath);
    }

    public function render()
    {
        $this->checkToken('post');

        $app   = Factory::getApplication();
        $input = $app->getInput();

        $shortcode = $input->post->get('shortcode', '', 'RAW');

        if (empty($shortcode)) {
            echo new JsonResponse(new \Exception('Shortcode vide'));
            $app->close();
        }
        
        $textFinal = \Joomla\CMS\HTML\HTMLHelper::_('content.prepare', $shortcode);
        echo new JsonResponse(['html' => $textFinal]);
        $app->close();
    }

    public function getDataFromCSV(){

        $app = Factory::getApplication();
        $input = $app->input;

        $file = $input->files->get('csv_file');
        $type = $input->post->get('type', '', 'cmd');
        $modelePath = JPATH_SITE . '/media/com_dsfrchart/csv/';

        $response = [
            'success' => false,
            'message' => '',
            'data'    => []
        ];

        try {
            
            if(!in_array($type, ['graphe-carte-dsfr','graphe-barligne-dsfr', 'graphe-dsfr'])){
                throw new Exception("Erreur: le type est incorrect");
            }    

            if (empty($file) || $file['error'] !== UPLOAD_ERR_OK) {
                throw new Exception("Erreur lors de l'envoi du fichier. Vérifier que le fichier est bien au format CSV");
            }
        
            $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if ($extension !== 'csv') {
                throw new Exception("Le fichier doit obligatoirement être au format CSV.");
            }
        
            $handle = fopen($file['tmp_name'], 'r');
            if ($handle === false) {
                throw new Exception("Impossible de lire le fichier temporaire.");
            }
            
            $firstLine = fgets($handle); 
            if(substr_count($firstLine, ';') === 0 ){
                throw new Exception("Le délimiteur doit obligatoirement être un point-virgule (;) ");
            }
        
            rewind($handle); // reset du cursos dans le csv
        
            $processedData = [];
            $header = fgetcsv($handle, 1000, ';');
            if ($header === false) {
                throw new Exception("Aucune en-tête trouvée: le fichier CSV est vide ou illisible.");
            }

            $modeleGraphe = fopen($modelePath . 'modele-'.$type.'.csv', 'r');
            $expectedHeaders= fgetcsv($modeleGraphe, 1000, ';');

            // Vérif des header
            // Création des sous tableaux pour récup les valeurs
            foreach ($header as $index => $head) {
                $head = trim($head); 
                // On enlève s'il a mis un ; à la fin
                if(empty($head) && $index === count($header)-1) { 
                    array_pop($header);
                    continue;
                }
                $colNum = $index + 1;
                $expectedName = '';
                
                if ($type === 'graphe-dsfr') {
                    $expectedName = ($index === 0) ? 'valeurX' : 'valeurY' . $index; // les valeurY il peut en avoir à l'inf
        
                } else { // graphe-barligne-dsfr et graphe-carte-dsfr 

                    $textType = $type === "graphe-barligne-dsfr" ? 'Bar Ligne' : 'Carte';
                    if (!isset($expectedHeaders[$index])) {
                        throw new Exception("Erreur de format : Le type '{$textType}' n'accepte que ".count($expectedHeaders)." colonnes.");
                    }
                    $expectedName = $expectedHeaders[$index];

                } 
        
                if ($head !== $expectedName) {
                    throw new Exception("Erreur de format : La colonne {$colNum} doit s'appeler '{$expectedName}'.");
                }
        
                $processedData[$head] = [];
            }
            fclose($modeleGraphe);
            
            $rowIndex = 1;
            while (($row = fgetcsv($handle, 1000, ";")) !== false) {
                $rowIndex++;
                
                // On enlève s'il a mis un ; à la fin
                if(end($row) === ""){
                    array_pop($row);
                }

                if (count($row) !== count($header)) {
                    throw new Exception("Erreur de format : La ligne {$rowIndex} ne contient pas le même nombre de colonnes que l'en-tête.");
                }
        
                foreach ($row as $index => $value) {
                    $columnName = trim($header[$index]);
                    $clearValue = trim($value);
                    if (preg_match('/^-?\d+,\d+$/', $clearValue)) {
                        $clearValue = str_replace(',', '.', $clearValue);
                    }
                    $processedData[$columnName][] = $clearValue;
                }
            }
            fclose($handle);
        
            $response['success'] = true;
            $response['message'] = 'Données importées avec succès';
            $response['data'] = $processedData;
            
        } catch (Exception $e) {
            $response['message'] = $e->getMessage();
        }        

        echo new JsonResponse($response['data'], $response['message'], !$response['success']);
        $app->close();
    }
}
