<?php

class DataBoxParams {
    public string $dataBoxID;
    public string $size;
    public string $title;
    public string $source;
    public string $date;
    public string $titleTooltip;
    public string $contentTooltip;
    // public string $fullscreen; // Pas utilisé car pas util pour l'instant, mais j'ai gardé le paramètre si necessaire de rajouter plus tard (voir MR-4)
    public string $screenshot;
    public string $download;
    public string $estSourceIA;
    public string $linkIA;
}

class MapParams {
    public string $dataBoxID;
    public string $data;
    public string $value;
    public string $name;
    public string $level;
    public string $region;
    public string $colorPalette;
}

class BarLineParams {
    public string $dataBoxID;
    public array $x;
    public array $yBar;
    public array $yLine;
    public string $legendeBar;
    public string $legendeLine;
    public string $unitBar;
    public string $unitLine;
    public string $colorPalette;
}

class GaugeParams {
    public string $dataBoxID;
    public string $size; // Obliger de garder la size car indépendant du databox
    public string $value;
    public string $init;
    public string $target;
    public string $initDate;
    public string $targetDate;
}

class TableParams {
    public string $dataBoxID;
    public array $x;
    public array $y;
    public array $legendes;
    public string $tableName;
}

class GraphParams {
    public string $dataBoxID;
    public array $x;
    public array $y;
    public array $legendes;
    public string $unitTooltip;
    public string $colorPalette;
}

?>