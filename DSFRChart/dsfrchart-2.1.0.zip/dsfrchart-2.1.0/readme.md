# DSFRChart

**dsic-se-support-web**

## Version

* [Dernière version](https://gitlab.sgami-se.minint.fr/sdev/simba/dsfrchart/-/releases)
* Version DSFR-chart utilisée : [v2.1.1](https://github.com/GouvernementFR/dsfr-chart/releases/tag/v2.1.1)

## Description

Ce package permet d'insérer des graphiques basés sur le [projet ChartJS du DSFR](https://github.com/GouvernementFR/dsfr-chart) dans l'éditeur d'articles TinyMCE au sein de Joomla!.

Il insère un tampon (format texte) dans l'éditeur, puis effectue la conversion en HTML lors du rendu final de la page.

## Contenu

Le package est divisé en 3 parties :

* **plg_dsfrchart** : Plugin permettant l'insertion du bouton dans le menu "Joomla" de l'éditeur et l'ouverture de la modale.
* **com_dsfrchart** : Composant contenant le formulaire pour l'insertion de graphiques dans l'éditeur.
* **dsfrchartformatter** : Plugin permettant de convertir le tampon en graphique lors du rendu final de la page.

---

## Mise à jour

Il est possible que le DSFR-chart fourni par le gouvernement subisse des mises à jour incluant des *breaking changes* ou des ajouts intéressants. Voici les étapes à suivre pour vous accompagner lors de ces modifications.

### dsfrchartformatter

Ce plugin assure la conversion d'un tampon (ex : `{graphe...}...{/graphe}`) vers du code HTML dans le contenu principal de l'article (sur la vue utilisateur et non administrateur).

> [!important]
> Il est important de bien vérifier si les expressions régulières (regex) fonctionnent à chaque changement, et de modifier les fonctions ou les regex si vous modifiez/ajoutez un élément dans les tampons.

### com_dsfrchart

Ce composant contient le formulaire pour l'insertion des graphiques dans l'éditeur. En cas de modification des tampons, il est indispensable de :

* Mettre à jour les formulaires dans le dossier `forms`.
* Mettre à jour les tampons dans le dossier `tampons`.
* Mettre à jour le générateur (`generator`) et le moteur de template (`template-engine`) si besoin.

### Template

Il est important de mettre à jour le template Simba. Vous pouvez retrouver les étapes détaillées sur le [wiki dédié](https://gitlab.sgami-se.minint.fr/sdev/simba/simba_dsfr/-/wikis/home/5-Mise-%C3%A0-jour-du-DSFR-dans-le-template#52-mise-%C3%A0-jour-de-dsfrchart).

---

## Ajout d'un nouveau composant

Si vous souhaitez rajouter un composant, suivez ces étapes :

### 1. Création du tampon

Pour commencer, vous devez créer le tampon destiné à l'insertion dans l'éditeur. Rendez-vous dans le dossier `com_dsfrchart\media\tampons`. Vous pouvez vous baser sur le fichier `graphe-dsfr`, qui est le plus commun.

> [!important] Dans le tampon, il est obligatoire de respecter la forme suivante :
> `{nom-tampon nom-arg="{{arg}}"....}....{/nom-tampon}`
> Il est obligatoire d'utiliser les doubles accolades `{{ }}` pour permettre le remplacement automatique qui sera fait dans le code plus tard.
Si votre composant est compatible avec les databox, il faut y ajouter la variable correspondante.
> [!note]
> La variable `{{databox_params}}` sera automatiquement remplacée par le contenu du tampon `databox-template.txt`. Exemple de structure finale :
> `{nom-tampon nom-arg="{{arg}}"....} {{databox_params}}... {/nom-tampon}`

### 2. Création du formulaire XML

Une fois le tampon créé, il faut générer le formulaire pour que l'utilisateur puisse créer votre composant. Le format XML est utilisé pour sa lisibilité, et Joomla! gère la conversion en HTML par la suite (`default.php`).

Rendez-vous dans le dossier `com_dsfrchart\media\forms`. Pour construire votre formulaire, voici les règles à suivre (vous pouvez prendre exemple sur `graphe-dsfr.xml`).

#### Forme générale (Fieldsets)

* Les formulaires sont divisés en `fieldset`, qui contiennent eux-mêmes des `field`.
* Chaque `fieldset` doit **obligatoirement** posséder un attribut unique `name`. Son importance est mineure, sauf si vous devez l'utiliser dans le JavaScript (ex dans le  avec les données `graphe-carte-dsfr.xml`).
* Le `fieldset` nommé `config` est **obligatoire**. Vous devez y définir le titre du formulaire ainsi que sa description.
* Les `fields` sont automatiquement affichés en orientation verticale (block). Pour un affichage horizontal (inline), ajoutez la classe `fieldset-inline` à votre `fieldset`.
* Vous pouvez ajouter des classes ou des ID personnalisés. Les styles CSS correspondants doivent être ajoutés dans le fichier `com_dsfrchart\media\css\style.css`.

#### Configuration des Champs (Fields)

> [!tip]
>Vous pouvez consulter tous les champs de formulaire (form fields) disponibles dans Joomla! [sur la documentation officielle](https://manual.joomla.org/docs/5.4/general-concepts/forms-fields/).

* Si vous utilisez la databox, il est obligatoire d'ajouter le fieldset suivant dans votre formulaire pour importer les champs nécessaires : `<fieldset name="databox-params"></fieldset>`

* L'attribut `name` de votre `field` doit **obligatoirement** porter le même nom que l'argument défini dans votre tampon (`{{arg}}`). Dans le cas contraire, l'insertion des valeurs sera impossible.

> [!caution]
> Concernant les subforms, il est impossible d'imbriquer des subforms sur 3 niveaux ; le maximum est de 2 (exemple avec les valeurs d'ordonnées des graphes). Ceci est dû à une limitation de Joomla! qui perd les inputs au-delà, rendant la récupération des valeurs impossible.

### 3. Nommage des fichiers

Il est primordial de bien nommer ses fichiers. La convention de nommage est `graphe-nomcomposant-dsfr` (à l'exception de `graphe-dsfr`) pour votre formulaire et votre tampon. Ce nom devient la clé d'identification de votre composant dans l'ensemble du code.

### 4. Template Engine

Maintenant que votre tampon et votre formulaire sont prêts, il faut les lier.
Dans le fichier `com_dsfrchart\media\js\template-engine.js`, créez une nouvelle fonction (vous pouvez utiliser `getTamponGraphe` comme modèle). Dans cette fonction, vous ferez le lien entre vos `formData` et votre template grâce à la méthode `.replace`.

> [!important]
> Si vous utilisez les databox, veillez à bien mettre `return getTamponCommun(resultTampon, formData)` comme valeur de retour afin de traiter les arguments de la databox.

### 5. Generator

Dans le fichier `com_dsfrchart\media\js\generator.js`, au niveau de la fonction `generate`, ajoutez votre composant dans l'instruction `switch`.

### 6. Form Updater

La fonction `updateForm` du fichier `com_dsfrchart\media\js\utils\formUdpater.js` est appelée automatiquement. Toutefois, si votre formulaire possède un comportement unique (comme ceux des cartes), créez ici les fonctions nécessaires.
Ensuite, dans la fonction `loadCurrentComposantForm`, ajoutez une condition `if` et intégrez votre updater (inspirez-vous du fonctionnement des cartes).

### 7. Mise à jour de dsfrchartformatter

Il faut désormais mettre à jour le formateur pour transformer notre tampon en HTML.

* **Regex** : Dans le fichier `dsfrchartformatter\RegexGenerator.php`, créez votre regex pour la lecture du tampon. Des constantes sont à votre disposition pour vous faciliter la tâche.
* **DTO** : Afin de garder un code lisible, les paramètres de chaque composant sont stockés dans des objets de transfert (DTO) via le fichier `dsfrchartformatter\Dto.php`.

> [!important]
> Si vous utilisez la databox, il est obligatoire de définir l'attribut `$dataBoxID` dans votre DTO.

* **ParamString** : Créez votre fonction afin de renvoyer les attributs de votre balise HTML dans le fichier `dsfrchartformatter\ParamString.php`.
* **HTML Generator** : Dans le fichier `dsfrchartformatter\HtmlGenerator.php`, créez la fonction qui génèrera et renverra le code HTML final de votre composant.
* **dsfrchartformatter** : Pour finir, dans le fichier principal de `dsfrchartformatter`, initialisez votre regex et créez la fonction qui coordonnera la conversion du tampon de votre composant.

> [!caution]
> Lors de la première vérification de la regex du tampon, si elle ne correspond pas, il est impératif de renvoyer le texte intact pour qu'il puisse être évalué par les autres *handlers*.

> [!tip]
> Des fonctions sont à votre disposition pour faciliter certains traitements. Vous pouvez ajouter les vôtres si nécessaire. Prenez le temps de bien étudier les autres *handlers* pour conserver la même logique et garantir la stabilité de l'application.

### 8. L'import CSV

Il est possible d'ajouter à votre composant un import CSV afin de faciliter l'ajout de données dans votre graphe.

#### Le fichier CSV

Pour commencer, vous devez d'abord créer votre modèle. Dans le dossier `\com_dsfrchart\media\csv`, vous avez déjà tous les modèles de CSV existants. Vous pouvez vous en inspirer afin de créer le vôtre.

Le fichier doit toujours utiliser le ";" (point-virgule) comme séparateur et il est important de bien nommer votre fichier `modele-' + key + '.csv`. Pour les en-têtes, vous êtes libre de choisir les noms, mais il est conseillé de choisir des noms cohérents et, si possible, déjà existants pour tout uniformiser.

#### csvImport.js

Dans le fichier `com_dsfrchart\media\js\utils\csvImport.js`, vous allez faire le lien entre le code et votre CSV ainsi que définir vos règles.

Pour commencer, dans la fonction `importCSVData`, ajoutez votre type dans le `switch`, puis faites le lien entre le `formData` (récupéré plus tôt) et votre CSV.

> [!tip]
> Si le code devient trop long dans le `switch`, créez une fonction privée afin d'avoir un code plus lisible.

Ensuite, dans la fonction `initModelCSVDownload`, si vous avez plusieurs modèles différents (comme la carte), vous pouvez y créer les boutons.

Et pour finir, dans la fonction `initCSVRule`, c'est ici que vous créez les règles à afficher au rédacteur. Inspirez-vous des autres composants. Pensez à bien indiquer dans les règles les noms que les colonnes doivent respecter.

#### DisplayController.php

Les CSV ont généralement un nombre d'en-têtes fixe. Mais si vous avez un nombre variable ou un comportement particulier (les noms des en-têtes n'ont pas d'importance), allez dans le fichier `com_dsfrchart\admin\src\Controller\DisplayController.php`. Dans la fonction `getDataFromCSV`, rajoutez votre composant à la suite des `if` lors de la vérification des *headers*. Et si vous avez un comportement précis (vérification sur les variables...), vous pouvez rajouter un `if` dans la boucle `while`.

> [!tip]
> Il est préférable d'effectuer en priorité les vérifications possibles (format, etc.) côté *back*, et le reste côté *front*