<?php

declare(strict_types=1);
namespace Joomla\Plugin\EditorsXtd\DsfrChart\Extension;

use Joomla\CMS\Editor\Button\Button;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\SubscriberInterface;
use Joomla\CMS\Event\Editor\EditorButtonsSetupEvent;

class DsfrChart extends CMSPlugin implements SubscriberInterface
{   

    public static function getSubscribedEvents(): array
    {
        return [
            'onEditorButtonsSetup' => 'onEditorButtonsSetup',
        ];
    }

    public function onEditorButtonsSetup(EditorButtonsSetupEvent $event)
    {
        $subject  = $event->getButtonsRegistry();
        $editorId = $event->getEditorId();

        $link = 'index.php?option=com_dsfrchart&view=modal&tmpl=component&editor_id=' . $editorId;

        $button = new Button('dsfrchart', [
            'action'  => 'modal',
            'link'    => $link,
            'text'    => 'Graphique DSFR',
            'icon'    => 'cube',
            'name'    => 'dsfrchart',
            'options' => [
                'height' => '600px',
                'width'  => '900px',
            ]
        ]);

        $subject->add($button);
    }
 
}