<?php
function getMapHTML($regionalSplit, $paramString){
    if($regionalSplit=='true'){
        $html = "<map-chart-reg $paramString></map-chart-reg>";
    }else{
        $html = "<map-chart $paramString></map-chart>";
    }
    
    return $html;
}


function getBarLineHTML($paramString){
    return "
    <bar-line-chart $paramString></bar-line-chart>";
}

function getGaugeHTML($paramString){
    return "<gauge-chart $paramString></gauge-chart>";
}

function getDataBoxHTML($paramString){
    return "<data-box $paramString></data-box>";
}

function getGrapheHTML($type, $paramString){
    switch($type){
        case 'line':
            return"<line-chart ".$paramString."></line-chart>";
            break;
        case 'bar':
            return "<bar-chart ".$paramString."></bar-chart>";
            break;
        case 'bar-horizontal':
            return"<bar-chart ".$paramString." horizontal='true'></bar-chart>";
            break;
        case 'bar-stack':
            return "<bar-chart ".$paramString." stacked='true'></bar-chart>";
            break;
        case 'pie':
            return "<pie-chart ".$paramString."></pie-chart>";
            break;
        case 'pie-fill':
            return "<pie-chart ".$paramString." fill='true'></pie-chart>";
            break;
        case 'scatter':
            return "<scatter-chart ".$paramString."></scatter-chart>";
            break;
        case 'radar':
            return "<radar-chart ".$paramString."></radar-chart>";
            break;
        default:
            throw new Exception("Erreur type du graphe inconnu");
            break;
    }
}

function getTableHTML($paramString){
    return "<table-chart ".$paramString."></table-chart>";
}


?>