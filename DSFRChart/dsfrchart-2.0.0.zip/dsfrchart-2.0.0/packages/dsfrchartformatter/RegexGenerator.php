<?php

class RegexGenerator
{

    private const START       = '\{\s*';             // Ouverture
    private const T_END     = '\s*\}/su';          // Fin du tag et modificateurs regex
    private const SPACE            = '\s+';               // Espace obligatoire entre les attributs
    
    // Captures de valeurs génériques
    private const VAL           = '\s*=\s*"([^"]*)"';  // Attribut classique : = "valeur"
    private const VAL_SQ        = '\s*=\s*\'([^\']*)\'';// Attribut avec single quote : = 'valeur'

    // Capture du contenu interne et préparation de la balise fermante
    // Équivaut à : } contenu { /
    private const CONTENT_START = '\s*\}\s*(.*?)\s*\{\s*\/';

    private const ENUM_TAILLE   = '\s*=\s*"(xs|s|m|l|xl)"';
    private const ENUM_BOOL     = '\s*=\s*"(true|false)"';
    private const ENUM_NIVEAU   = '\s*=\s*"(dep|reg|aca|monde)"';
    private const ENUM_COULEUR  = '\s*=\s*"(categorical|default|neutral|sequentialAscending|sequentialDescending|divergentAscending|divergentDescending)"';
    private const ENUM_TYPES    = '\s*=\s*"(line|bar|bar-horizontal|bar-stack|pie|pie-fill|scatter|radar)"';

    // Sous-motif pour le JSON interne (carte data) : "clé": nombre
    private const JSON_KEY_VAL  = '"[^"]+"\s*:\s*\d+(?:\.\d+)?';

    public const REGEX_SINGLE_GRAPHE = '/' . self::START . 'graphe'
        . self::SPACE . 'type' . self::ENUM_TYPES
        . self::SPACE . 'taille' . self::ENUM_TAILLE
        . self::SPACE . 'unité-donnée' . self::VAL
        . self::SPACE . 'source' . self::VAL
        . self::SPACE . 'date' . self::VAL
        . self::SPACE . 'couleur' . self::ENUM_COULEUR
        . self::CONTENT_START . 'graphe' . self::T_END;

    public const REGEX_VALEUR_X_GRAPHE = '/' . self::START . 'valeur-abscisse'
        . self::SPACE . 'x' . self::VAL 
        . self::T_END;

    public const REGEX_VALEUR_Y_GRAPHE = '/' . self::START . 'valeur-ordonnée'
        . self::SPACE . 'y' . self::VAL 
        . self::SPACE . 'legende' . self::VAL 
        . self::T_END;

    public const REGEX_ACTION_GRAPHE = '/' . self::START . 'action'
        // . self::SPACE . 'plein-écran' . self::ENUM_BOOL
        . self::SPACE . 'capture-écran' . self::ENUM_BOOL
        . self::SPACE . 'téléchargement' . self::ENUM_BOOL
        . self::T_END;

    public const REGEX_TOOLTIP_GRAPHE = '/' . self::START . 'bulleInfo'
        . self::SPACE . 'titre' . self::VAL
        . self::CONTENT_START . 'bulleInfo' . self::T_END;

    public const REGEX_IA_GRAPHE = '/' . self::START . 'sourceIA'
        . self::SPACE . 'estSourceIA' . self::ENUM_BOOL
        . self::CONTENT_START . 'sourceIA' . self::T_END;

    public const REGEX_GAUGE_GRAPHE = '/' . self::START . 'graphe-jauge'
        . self::SPACE . 'taille' . self::ENUM_TAILLE
        . self::SPACE . 'valeur' . self::VAL
        . self::SPACE . 'début' . self::VAL
        . self::SPACE . 'fin' . self::VAL
        . self::SPACE . 'date-début' . self::VAL
        . self::SPACE . 'date-fin' . self::VAL
        . self::SPACE . 'source' . self::VAL
        . self::SPACE . 'date' . self::VAL
        . self::CONTENT_START . 'graphe-jauge' . self::T_END;

    public const REGEX_BAR_LINE = '/' . self::START . 'graphe-barligne'
        . self::SPACE . 'taille' . self::ENUM_TAILLE
        . self::SPACE . 'valeur-abscisse' . self::VAL
        . self::SPACE . 'ordonnée-bar' . self::VAL
        . self::SPACE . 'ordonnée-ligne' . self::VAL
        . self::SPACE . 'unité-donnée-bar' . self::VAL
        . self::SPACE . 'unité-donnée-ligne' . self::VAL
        . self::SPACE . 'légende-bar' . self::VAL
        . self::SPACE . 'légende-ligne' . self::VAL
        . self::SPACE . 'source' . self::VAL
        . self::SPACE . 'date' . self::VAL
        . self::SPACE . 'couleur' . self::ENUM_COULEUR
        . self::CONTENT_START . 'graphe-barligne' . self::T_END;

    public const REGEX_MAP_GRAPHE = '/' . self::START . 'graphe-carte'
        . self::SPACE . 'taille' . self::ENUM_TAILLE
        . self::SPACE . 'données' . self::VAL_SQ
        . self::SPACE . 'valeur-indicateur' . self::VAL
        . self::SPACE . 'nom-indicateur' . self::VAL
        . self::SPACE . 'niveau' . self::ENUM_NIVEAU
        . self::SPACE . 'région' . self::VAL
        . self::SPACE . 'couleur' . self::ENUM_COULEUR
        . self::SPACE . 'source' . self::VAL
        . self::SPACE . 'date' . self::VAL
        . self::SPACE . 'isolation-régional' . self::ENUM_BOOL
        . self::CONTENT_START . 'graphe-carte' . self::T_END;

    // Concaténation pour le JSON: { "cle": valeur, "cle2": valeur2 }
    public const REGEX_MAP_GRAPHE_DATA = '/' . self::START 
        . '(?:' . self::JSON_KEY_VAL . '(?:\s*,\s*' . self::JSON_KEY_VAL . ')*)?' 
        . self::T_END;
}

?>