<?php

function getMapParamString(MapParams $params) {
    return sprintf(
        "databox-id='databox-%s' databox-type='chart' data='%s' value='%s' name='%s' level='%s' region='%s' selected-palette='%s'"?? '',
        $params->dataBoxID ?? ''?? '',
        $params->data ?? ''?? '',
        $params->value ?? ''?? '',
        $params->name ?? ''?? '',
        $params->level ?? '',
        $params->region ?? '',
        $params->colorPalette ?? ''
    );
}

function getBarLineParamString(BarLineParams $params) {
    return sprintf(
        "databox-id='databox-%s' databox-type='chart' x='%s' y-bar='%s' y-line='%s' name-bar='%s' name-line='%s' unit-tooltip-bar='%s' unit-tooltip-line='%s' selected-palette='%s'"?? '',
        $params->dataBoxID?? '',
        json_encode($params->x)?? '',
        json_encode($params->yBar)?? '',
        json_encode($params->yLine)?? '',
        $params->legendeBar?? '',
        $params->legendeLine?? '',
        $params->unitBar?? '',
        $params->unitLine?? '',
        $params->colorPalette ?? ''
    );
}

function getGaugeParamString(GaugeParams $params) {
    return sprintf(
        "class='graph-gauge-%s' databox-id='databox-%s' databox-type='chart' value='%s' init='%s' target='%s' init-date='%s' target-date='%s'"?? '',
        $params->size?? '',
        $params->dataBoxID?? '',
        $params->value?? '',
        $params->init?? '',
        $params->target?? '',
        $params->initDate?? '',
        $params->targetDate ?? ''
    );
}

function getTableParamString(TableParams $params) {
    return sprintf(
        "databox-id='databox-%s' databox-type='table' x='%s' y='%s' name='%s' table-name='%s'"?? '',
        $params->dataBoxID?? '',
        json_encode($params->x)?? '',
        json_encode($params->y)?? '',
        json_encode($params->legendes)?? '',
        $params->tableName ?? '' // C'est pour nommé la première colonne
    );
}

function getDataBoxParamString(DataBoxParams $params) {
    $iaPart = $params->estSourceIA === 'true' ? "text-ia='Données générées par Intelligence Artificielle (IA)' link-ia='{$params->linkIA}'" : '';
    
    return sprintf(
        "class='graph-%s' id='databox-%s' name='%s' source='%s' date='%s' tooltip-title='%s' tooltip-content='%s' screenshot='%s' download='%s' %s"?? '',
        $params->size?? '',
        $params->dataBoxID?? '',
        $params->title?? '',
        $params->source?? '',
        $params->date?? '',
        $params->titleTooltip?? '',
        $params->contentTooltip?? '',
        // $params->fullscreen?? '',
        $params->screenshot?? '',
        $params->download?? '',
        $iaPart ?? ''
    );
}

function getGrapheParamString(GraphParams $params) {
    return sprintf(
        "databox-id='databox-%s' databox-type='chart' x='%s' y='%s' name='%s' unit-tooltip='%s' selected-palette='%s'"?? '',
        $params->dataBoxID ?? '',
        json_encode($params->x) ?? '',
        json_encode($params->y)?? '',
        json_encode($params->legendes)?? '',
        $params->unitTooltip?? '',
        $params->colorPalette ?? ''
    );
}

?>