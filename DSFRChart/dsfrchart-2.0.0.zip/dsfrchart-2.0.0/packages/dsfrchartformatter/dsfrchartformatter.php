<?php defined('_JEXEC') or die();

use Joomla\CMS\Plugin\CMSPlugin;

require_once 'Dto.php';

require_once 'HtmlGenerator.php';
require_once 'ParamString.php';
require_once 'RegexGenerator.php';

class PlgContentdsfrchartformatter extends CMSPlugin {
    
    CONST REGEX_SINGLE_GRAPHE = RegexGenerator::REGEX_SINGLE_GRAPHE;
    CONST REGEX_VALEUR_Y_GRAPHE = RegexGenerator::REGEX_VALEUR_Y_GRAPHE;
    CONST REGEX_VALEUR_X_GRAPHE = RegexGenerator::REGEX_VALEUR_X_GRAPHE;
    CONST REGEX_ACTION_GRAPHE = RegexGenerator::REGEX_ACTION_GRAPHE;
    CONST REGEX_TOOLTIP_GRAPHE = RegexGenerator::REGEX_TOOLTIP_GRAPHE;
    CONST REGEX_IA_GRAPHE = RegexGenerator::REGEX_IA_GRAPHE;
    CONST REGEX_GAUGE_GRAPHE = RegexGenerator::REGEX_GAUGE_GRAPHE;
    CONST REGEX_BAR_LINE = RegexGenerator::REGEX_BAR_LINE;
    CONST REGEX_MAP_GRAPHE = RegexGenerator::REGEX_MAP_GRAPHE;
    CONST REGEX_MAP_GRAPHE_DATA = RegexGenerator::REGEX_MAP_GRAPHE_DATA;

    public function onContentPrepare($context, &$row, &$params, $page = 0){
        // Le texte est passé par tous les handler et est géré uniquement par celui qui lui correspond 

        $row->text = $this->handleSingleGraphe($row->text);
        $row->text = $this->handleGaugeGraphe($row->text);
        $row->text = $this->handleBarLineGraphe($row->text);
        $row->text = $this->handleMapGraphe($row->text); 

        return true;
    }   

    private function handleMapGraphe($text){
        // si ce n'est pas un tampon de la carte alors on passe au prochaine handler
        if (!preg_match_all(self::REGEX_MAP_GRAPHE, $text, $matches)) {
            return $text;
        }
        
        // Il peut avoir plusieurs tampons de graphe dans le texte donc on les gère tous
        foreach ($matches[0] as $i => $fullTag) {
            $mapParams = new MapParams();
            $tableParams = new TableParams();

            // Récup des info dans les groupes du regex
            $size          = $this->formatValue($matches[1][$i]);
            $mapParams->data          = $matches[2][$i];
            var_dump($matches[3][$i]);die();
            $mapParams->value         = $this->formatValue($matches[3][$i]);
            $mapParams->name          = $this->formatValue($matches[4][$i]);
            $mapParams->level         = $this->formatValue($matches[5][$i]);
            $mapParams->region        = $this->formatValue($matches[6][$i]);
            $mapParams->colorPalette  = $this->formatValue($matches[7][$i]);
            $source =  $this->formatValue($matches[8][$i]);
            $date =  $this->formatValue($matches[9][$i]);
            $regionalSplit = $this->formatValue($matches[10][$i]);
            $datas = $this->formatValue($matches[11][$i]);
            
            $id = $this->randomID();
            $mapParams->dataBoxID = $id;
            $tableParams->dataBoxID = $id;

            // Si le string au format json n'est pas valide alors on stop
            if(!preg_match(self::REGEX_MAP_GRAPHE_DATA, $mapParams->data )){
                return $text;
            }

            $html = $this->getDataBox($datas, $source, $date, $size, $id);

            // Récupération des paramètres de la balise carte
            $paramString = getMapParamString($mapParams);
            // Création et insertion de l'objet HTML, la mise au forme c'est DSFRChart.js qui prend le relais
            $html .= getMapHTML($regionalSplit, $paramString);

            $dataJson = json_decode($mapParams->data, true);
            // Extraction des clés et des valeurs dans deux tableaux distincts
            $cles = array_keys($dataJson);
            $valeurs = array_values($dataJson);
            if (json_last_error() !== JSON_ERROR_NONE) {
                return $text;
            }
            
            $tableParams->y = [$valeurs];
            $tableParams->legendes = ['Valeur indicateur'];
            $tableParams->x = $cles;
            $tableParams->tableName = 'Code';

            $paramStringTable = getTableParamString($tableParams);
            // Création et insertion de l'objet HTML, la mise au forme c'est DSFRChart.js qui prend le relais
            $html .= getTableHTML($paramStringTable);

            $text = str_replace($fullTag, $html, $text);
        }
    
        return $text;
    }

    private function handleBarLineGraphe($text){

        // si ce n'est pas un tampon d'un graphe barligne alors on passe au prochaine handler
        if(!preg_match_all(self::REGEX_BAR_LINE, $text, $matchsBarLine)){
            return $text;
        }

        // Il peut avoir plusieurs tampons de graphe dans le texte donc on les gère tous
        foreach($matchsBarLine[0] as $i=>$fullTag){
            $barLineParams = new BarLineParams();
            $tableParams = new TableParams();

            $size =  $this->formatValue($matchsBarLine[1][$i]);
            $barLineParams->x = $this->getValueTab($this->formatValue($matchsBarLine[2][$i]));


            $barLineParams->yBar =  $this->getValueTab($this->formatValue($matchsBarLine[3][$i]));
            $barLineParams->yLine =  $this->getValueTab($this->formatValue($matchsBarLine[4][$i]));
            $barLineParams->unitBar =  $this->formatValue($matchsBarLine[5][$i]);

            $barLineParams->unitLine =  $this->formatValue($matchsBarLine[6][$i]);
            $barLineParams->legendeBar =  $this->formatValue($matchsBarLine[7][$i]);
            $barLineParams->legendeLine =  $this->formatValue($matchsBarLine[8][$i]);
            $source =  $this->formatValue($matchsBarLine[9][$i]);
            $date =  $this->formatValue($matchsBarLine[10][$i]);
            $barLineParams->colorPalette =  $this->formatValue($matchsBarLine[11][$i]);
            $datas = $matchsBarLine[12][$i];

            // Création d'un randomID pour lier le graphe et le tableau a un databox pour la mise en forme
            $dataBoxID = $this->randomID();
            $barLineParams->dataBoxID = $dataBoxID;
            $tableParams->dataBoxID = $dataBoxID;
            
            $html = $this->getDataBox($datas, $source, $date, $size, $dataBoxID);

            $paramStringBarLine = getBarLineParamString($barLineParams);
            $html .= getBarLineHTML($paramStringBarLine);
            
            $tableParams->y = [$barLineParams->yBar, $barLineParams->yLine ];
            $tableParams->legendes = [$barLineParams->legendeBar, $barLineParams->legendeLine];
            $tableParams->x = $barLineParams->x;
            $paramStringTable = getTableParamString($tableParams);

            // Création et insertion de l'objet HTML, la mise au forme c'est DSFRChart.js qui prend le relais
            $html .= getTableHTML($paramStringTable);
            $text = str_replace($fullTag, $html, $text);
        }
        return $text;
		
    }

    private function handleGaugeGraphe($text){
        if(preg_match_all(self::REGEX_GAUGE_GRAPHE, $text, $matchsGauge)){
            foreach($matchsGauge[0] as $i=>$fullTag){
                $gaugeParams = new GaugeParams();
                $gaugeParams->size =  $this->formatValue($matchsGauge[1][$i]);
                $gaugeParams->value = $this->formatValue($matchsGauge[2][$i]);
                $gaugeParams->init =  $this->formatValue($matchsGauge[3][$i]);
                $gaugeParams->target =  $this->formatValue($matchsGauge[4][$i]);
                $gaugeParams->initDate =  $this->formatValue($matchsGauge[5][$i]);
                $gaugeParams->targetDate =  $this->formatValue($matchsGauge[6][$i]);
                $datas = $matchsGauge[9][$i];

                $tableParams = new TableParams();
                $source =  $this->formatValue($matchsGauge[7][$i]);
                $date =  $this->formatValue($matchsGauge[8][$i]);

                $id = $this->randomID();
                $gaugeParams->dataBoxID = $id;
                $tableParams->dataBoxID = $id;


                $html = $this->getDataBox($datas, $source, $date, $gaugeParams->size, $id);

                $paramStringGauge = getGaugeParamString($gaugeParams);
                $html .= getGaugeHTML($paramStringGauge);
                       
                $tableParams->y = [[$gaugeParams->init, $gaugeParams->target, $gaugeParams->value, $gaugeParams->initDate, $gaugeParams->targetDate]];
                $tableParams->legendes = ["Valeur"];
                $tableParams->x = ['Valeur Min', 'Valeur Max', 'Valeur', 'Date début', 'Date fin'];
                $paramStringTable = getTableParamString($tableParams);
                $html .= getTableHTML($paramStringTable);
                
                $text = str_replace($fullTag, $html, $text);
            }
            return $text;
        } else {
            return $text;
        }
    }

    private function handleSingleGraphe($text){
        if(preg_match_all(self::REGEX_SINGLE_GRAPHE, $text, $matchsSingle)){
            foreach($matchsSingle[0] as $i=>$fullTag){
                $graphParams = new GraphParams();
                $tableParams = new TableParams();

                $type =  $this->formatValue($matchsSingle[1][$i]);
                $size =  $this->formatValue($matchsSingle[2][$i]);
                $graphParams->unitTooltip =  $this->formatValue($matchsSingle[3][$i]);
                $source =  $this->formatValue($matchsSingle[4][$i]);
                $date =  $this->formatValue($matchsSingle[5][$i]);
                $graphParams->colorPalette =  $this->formatValue($matchsSingle[6][$i]);
                $datas =  $matchsSingle[7][$i];

                $dataBoxID = $this->randomID();
                $graphParams->dataBoxID = $dataBoxID;
                $tableParams->dataBoxID = $dataBoxID;

                $graphParams->y = $this->getValeurY($datas, self::REGEX_VALEUR_Y_GRAPHE);
                $graphParams->x = $this->getValeurX($datas, self::REGEX_VALEUR_X_GRAPHE, count($graphParams->y));
                $graphParams->legendes = $this->getLegende($datas, self::REGEX_VALEUR_Y_GRAPHE);
                    
                $html = $this->getDataBox($datas, $source, $date, $size, $dataBoxID);

                $paramStringGraphe = getGrapheParamString($graphParams);
                $html .= getGrapheHTML($type, $paramStringGraphe);
                
                $tableParams->x = $graphParams->x[0];
                $tableParams->y = $graphParams->y;
                $tableParams->legendes = $graphParams->legendes;
                $paramStringTable = getTableParamString($tableParams);
                $html .= getTableHTML($paramStringTable);
                

                $text = str_replace($fullTag, $html, $text);
            
				
			}
            return $text;
		}else{
            return $text;
        }
    }


    private function getDataBox($datas, $source, $date, $size, $id){
        $dataBoxParams = new DataBoxParams();
        $dataBoxParams->dataBoxID = $id;
        $dataBoxParams->title = $this->getTitle([self::REGEX_VALEUR_X_GRAPHE, self::REGEX_ACTION_GRAPHE, self::REGEX_TOOLTIP_GRAPHE, self::REGEX_VALEUR_Y_GRAPHE, self::REGEX_IA_GRAPHE], $datas);
        [$dataBoxParams->screenshot, $dataBoxParams->download] = $this->getDataFromRegex($datas, self::REGEX_ACTION_GRAPHE);
        [$dataBoxParams->titleTooltip, $dataBoxParams->contentTooltip] = $this->getDataFromRegex($datas, self::REGEX_TOOLTIP_GRAPHE);
        [$dataBoxParams->estSourceIA, $dataBoxParams->linkIA] = $this->getDataFromRegex($datas, self::REGEX_IA_GRAPHE);
        $dataBoxParams->source =  $this->formatValue($source);
        $dataBoxParams->date =  $this->formatValue($date);        
        $dataBoxParams->size =  $this->formatValue($size);

        $paramStringDataBox = getDataBoxParamString($dataBoxParams);
     
        return getDataBoxHTML($paramStringDataBox);
    }

    /**
     * Transforme les valeurs sous forme de liste en array
     * @param string $valeur sous la forme 12,134,.../legende1, legende2
     * @return array la liste sous forme d'array
    */
    private function getValueTab($valeur){
        if(empty($valeur)) return [];
        $elements = [];
        $elements = array_map('trim', explode(',', ($valeur ?? '')));
        return $elements;
    }

    /**
     * Nettoie la valeur passée en paramètre (sans espace et remplaçement des ' en ")
     * @param string $valeur 
     * @return string valeur nettoyée
    */
    private function formatValue($valeur){
        if(empty($valeur)) return '';
        return str_replace('\'', "&apos;", trim(($valeur ?? '')));
    }

    /**
     * @return string renvoie un id aléatoire
    */
    private function randomID(){
        $bytes = random_bytes(2);
        return bin2hex($bytes);
    }

    /**
     * Récupère le titre dans mon tampon
     * @param string $tableRegex c'est tout les regex qui doit être retirer pour recup le titre
     * @param string $datas c'est le contenu (...}(contenu){...) avec notre titre, souvent avec d'autres regex 
     * @return string titre
    */
    private function getTitle($tableRegex, $datas){
        if(empty($datas)) return '';
        return preg_replace(array_merge($tableRegex,['/\<p\>/', '/\<\/p\>/']), '', $datas); 
    }

    /**
     * Récupère les valeurs du regex dans notre contenu
     * @param string $datas c'est notre contenu 
     * @param string $regex le regex qui correspond aux données qu'on veut récup
     * @return array valeurs récup
    */
    private function getDataFromRegex($datas, $regex){
        if(empty($datas)) return [];
        if (!preg_match($regex, $datas, $matchs)){
            return [];
        }
        $values = [];
        for($i = 1; $i < count($matchs); $i++){
            $values[] = $this->formatValue($matchs[$i]);
        }
        return $values;
    }

    /**
     * Récupère les valeurs x du regex et les met au bon format pour DSFRChart
     * @param string $datas c'est notre contenu 
     * @param string $regex le regex qui correspond aux données x
     * @return array valeurs propres
    */
    private function getValeurX($datas, $regex, $sizeY){
        if(empty($datas) || empty($sizeY)) return [];
        if(preg_match($regex, $datas, $valeur)){
            $x = [];
            $elements = array_map('trim', explode(',', ($valeur[1] ?? '')));
            $x = array_fill(0, $sizeY, $elements);                
            return $x;
        }
    }

    /**
     * Récupère les valeurs y du regex et les met au bon format pour DSFRChart
     * @param string $datas c'est notre contenu 
     * @param string $regex le regex qui correspond aux données y
     * @return array valeurs propres
    */
    private function getValeurY($datas, $regex){
        if(empty($datas)) return [];
        if(preg_match_all($regex, $datas, $valeur)){
            $y = [];
            foreach ($valeur[0] as $j =>$_) {
                $y[] = array_map('trim', explode(',', ($valeur[1][$j] ?? '')));						
            }       
            return $y;
        }
    }
    /**
     * Récupère les légendes du regex et les met au bon format pour DSFRChart
     * @param string $datas c'est notre contenu 
     * @param string $regex le regex qui correspond aux légendes
     * @return array valeurs propres
    */
    private function getLegende($datas, $regex){
        if(empty($datas)) return [];
        if(preg_match_all($regex, $datas, $valeur)){
            foreach ($valeur[0] as $j =>$_) {
                $legende[] = $this->formatValue($valeur[2][$j]);
            }  
            return $legende;     
        }
    }

    

}