export function injectDsfrAttributes(
    html,
    id,
    values,
    componentName
) {
    const div = document.createElement('div')

    div.setAttribute(
        'data-dsfr-id',
        id
    );
    div.setAttribute(
        'data-dsfr-graphe',
        componentName
    );

    div.setAttribute('contentEditable', false)

    div.setAttribute(
        'data-dsfr-props',
        encodeURIComponent(JSON.stringify(values))
    );
    div.innerHTML = html
    return div.outerHTML
}