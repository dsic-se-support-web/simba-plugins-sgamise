const joomlaOptions = Joomla.getOptions('dsfrchart_data');

const componentConfig = joomlaOptions.componentConfig ?? []; 

let currentComponent = null; 

export function getCurrentComponent(){
    return currentComponent;
}

export function setCurrentComponentByIndex(index){
    currentComponent = componentConfig[index];
    return currentComponent;
}

export function getAllComponent(){
    return componentConfig
}

export function getComponent(index){
    return componentConfig[index];
}
