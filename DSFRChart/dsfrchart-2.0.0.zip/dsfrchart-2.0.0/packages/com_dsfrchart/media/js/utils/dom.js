function parseHtml(html) {
    return new DOMParser().parseFromString(html, 'text/html');
}

function getFirstElement(html) {
    return parseHtml(html).body.firstElementChild;
}

export {
    parseHtml,
    getFirstElement
}