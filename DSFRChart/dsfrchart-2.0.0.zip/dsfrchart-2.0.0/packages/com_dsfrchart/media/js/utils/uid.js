export function generateDsfrId() {
    return 'dsfr-' + crypto.randomUUID().slice(0, 8);
}