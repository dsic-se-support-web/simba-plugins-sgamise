
// Permet de renvoyer un formData valide
export function formatChartData(formData) {
    const result = {};

    // Transformation du data form 0: "Graphe-ligne[titre_graphe]" → "Titre", ....
    // en objet et sous objet titre_graphe : "Titre", x_values: [...]
    for (const [k, value] of formData.entries()) {
        // Ex: "Graphe-ligne[y_series][y_series0][legende]" devient ["y_series", "y_series0", "legende"]
        const keys = k.replace(/\]/g, '').split('[');
        keys.shift(); // Enlève "Graphe-ligne"
        // On est à la racine et on parcours chaque objet
        let current = result;

        for (let i = 0; i < keys.length; i++) {
            let key = keys[i]; // On parcours  ["y_series", "y_series0", "legende"]

            if (i === keys.length - 1) { // Si on est à la fin du chemin on récupère la valeur
                // On l'ajoute à l'objet courant
                current[key] = value;
            } else {
                // On est au milieu du chemin, on crée l'objet parent si besoin
                if (!current[key]) {
                    current[key] = {};
                }
                // On descend d'un niveau pour ajouter les futures objet enfant de celui-ci
                current = current[key];
            }
        }
    }

    // On applique le nettoyage sur l'objet qui a été créé
    const finalResult = convertSubformsToArrays(result);

    return finalResult;
}

// Transformation des objets qui correspondent aux subform en liste (exemple concret à la fin du fichier)
function convertSubformsToArrays(objDataForm) {
    // objDataForm est l'objet précédemment créer
    for (const key in objDataForm) { // titre_graphique, x_values, y_series,....
        // Si c'est un objet alors il a des enfants (on est au milieu/début)
        if (typeof objDataForm[key] === 'object' && objDataForm[key] !== null) {
            
            // Appel récursif pour traiter les enfants les plus profonds en premier et les formater             
            objDataForm[key] = convertSubformsToArrays(objDataForm[key]);
            
            // On récupère toutes les clés enfant
            const childKeys = Object.keys(objDataForm[key]);

            // Si les enfants ressemblent à des éléments de sous-formulaire Joomla (y_series0, x_values0, etc.)
            // Alors on va récupérer les valeurs
            if (childKeys.length > 0 && childKeys.every(k => k.startsWith(key) || !isNaN(k))) {
                
                let arrayValues = Object.values(objDataForm[key]);

                // Nettoyage pour extraire directement la valeur (ex: {value: "10"} devient "10")
                arrayValues = arrayValues.map(item => {
                    // Si c'est objet type {value :""}
                    if (typeof item === 'object' && item !== null && 'value' in item && Object.keys(item).length === 1) {
                        return item.value;
                    }
                    // Sinon, on laisse l'objet tel quel (ex: pour la légende et les y_values)
                    return item;
                });

                // on remplace l'objet complexe par le tableau de nos valeur
                // ex [1,2,..] ou [{ legende: "Série A", y_values: ["10", "20"] }] suivant le niveau
                objDataForm[key] = arrayValues;
            }
        }
    }
    return objDataForm; // On est à la fin on renvoi la valeur nettoyé 
}


/**
 * ----------------------------------------------------------
 * * ÉTAPE 1 : Objet brut généré après le parsing du FormData
 * {
    * "y_series": {
        * "y_series0": {
            * "legende": "Série A",
            * "y_values": {
                * "y_values0": { "value": "10" },
                * "y_values1": { "value": "20" }
 *               }
 *          }
 *      }
 * }
 * * ÉTAPE 2 : Pendant la récursivité (Enfants les plus profonds)
 * Transformation des sous-objets "y_values" en tableaux plats.
 * {
    * "y_series": {
        * "y_series0": {
            * "legende": "Série A",
            * "y_values": [ "10", "20" ]      
 *           }
 *      }
 * }
 * * ÉTAPE 3 : Fin de la récursivité (Remontée vers le parent)
 * Transformation du conteneur parent "y_series" en tableau d'objets.
 * {
 * "y_series": [                       
    * {
    * "legende": "Série A",
    * "y_values": [ "10", "20" ]
    * }, ....
 *  ]
 * }
 */






