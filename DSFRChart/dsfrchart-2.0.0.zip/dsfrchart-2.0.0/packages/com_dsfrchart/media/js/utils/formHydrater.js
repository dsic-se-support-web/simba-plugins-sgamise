export function hydrateForm(form, propsObject, componentName) {
    if (!form || !propsObject || typeof propsObject !== 'object' || !componentName) return;
    for (const [key, value] of Object.entries(propsObject)) {
        const fieldName = `${componentName}[${key}]`

        if (Array.isArray(value)) {
            value.forEach((val, index) => {
                if(isObjectAndValid(val)){ // subform complexe
                    const newComponentName = `${fieldName}[${key}${index}]`

                    // Si le subform n'existe pas (car si c'est un objet c'est que c'est un subform avec d'autre input et peut être d'autres subform simple ou complexe)
                    // On l'ajoute dynamiquement avant de l'hydrater
                    if (!getField(form,`div[data-group="${key}${index}"]`)){
                        const subformContainer = getField(form, `joomla-field-subform[name="${newComponentName}"]`);
                        addSubForm(form, subformContainer, newComponentName)
                    }
        
                    hydrateForm(form, val, newComponentName);
                    return;
                } 
                
                hydrateSimpleSubForm(form, val, index, fieldName)
            })
            continue;
        }
        
        // Cas input normal
        hydrateField(form, value, fieldName)
    }
}

function isObjectAndValid(val){
    return typeof val === 'object' && val !== null && Object.keys(val).length >= 1;
}

function hydrateField(form, value, fieldName){
    const fields = form.querySelectorAll(`[name="${fieldName}"]`);  
        
    fields.forEach(field => {
        if (field.type === 'checkbox' || field.type === 'radio' ) {
        if (field.value === value || (value === 'on' && field.type === 'checkbox' )) {
            field.checked = true;
        }
        } 
        else if (field.tagName === 'SELECT' && field.multiple) {
        Array.from(field.options).forEach(option => {
            if (option.value === value) {
            option.selected = true;
            }
        });
        } 
        else {
            field.value = value;
        }
    });
}

function addSubForm(form, subformContainer, fieldName){
    if(!subformContainer) {
        const match = fieldName.match(/^[^\[]+\[[^\]]+\]/);
        const parentFieldName = match[0]
        
        const subParentContainer = getField(form, `joomla-field-subform[name="${parentFieldName}"]`);
        clickAddButton(subParentContainer)
    }
}

function hydrateSimpleSubForm(form, val, index, fieldName){
    let subformInput = getSubFormInput(form, fieldName, index);
    
    if (subformInput) {
        subformInput.value = val;
        return
    }    

    let subformContainer = getField(form, `joomla-field-subform[name="${fieldName}"]`);

    if (clickAddButton(subformContainer)) {
        subformInput = getSubFormInput(form, fieldName, index);
        if (subformInput) {
            subformInput.value = val;
            return
        } 
    }    
    
    console.warn(`Ligne ajoutée, mais le champ pour ${fieldName} à l'index ${index} reste introuvable.`);
    
}

function getField(form, selector){
    return form.querySelector(selector)
}

function getSubFormInput(form, fieldName, index){
    return form.querySelectorAll(`[name^="${fieldName}"][name$="[value]"]`)[index];
}

function clickAddButton(container){
    if(!container) return false;
    const btnSelector = container.getAttribute('buttond-add') || '.group-add';
    const btn = container.querySelector(btnSelector);
    if(btn){
        btn.click();
        return true;
    }
    console.error(`Bouton "+" introuvable pour le sous-formulaire : ${container.getAttribute('name')}`);
    return false;
}

