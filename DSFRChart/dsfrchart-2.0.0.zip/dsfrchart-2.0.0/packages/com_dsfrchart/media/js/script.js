import {
    setCurrentComponentByIndex,
    getAllComponent,
    getComponent
} from './utils/component.js'

import {
    cleanPreview,
    preview
} from './preview.js'

import { genererEtInserer, getAllComponentInEditor } from './tinymce-bridge.js';
import { updateForm, updateFormMap } from './utils/formUdpater.js'
import {hydrateForm} from './utils/formHydrater.js'


let editMode = false;

document.addEventListener('DOMContentLoaded', () => { 
   

    fixBugSubFormJoomla();

    document.getElementById('btn-insertion').addEventListener('click', genererEtInserer);

    document.getElementById('btn-preview').addEventListener('click', preview);

    document.getElementById('btn-back').addEventListener('click', backHome);
    initMenu(getAllComponent());

    loadComponentInEditor();
}); 


function loadComponentInEditor(){
    const components = getAllComponentInEditor();
    if(components.length === 0) return;
    components.forEach((c) => {
        const propsObject = getPropsSelectedComponent(c);

        const ulComp = document.getElementById('list-graphe')
        const li = document.createElement('li')

        const divTitle = document.createElement('div');
        divTitle.classList.add('title-graphe');
        divTitle.textContent = propsObject.titre_graphe;

        const divType = document.createElement('div')
        divType.classList.add('type-graphe');
        divType.textContent = propsObject.form_title;

        li.appendChild(divTitle);
        li.appendChild(divType)

        li.onclick = () => {
            loadSelectedComponent(c)
        }

        ulComp.appendChild(li);
    });
}

// Charge le comp qui veut être modifié
function loadSelectedComponent(selectedComponent) {
    
    const propsObject = getPropsSelectedComponent(selectedComponent);
    const componentName = selectedComponent.dataset.dsfrGraphe
    if (!propsObject) {
        return;
    }
    const componentIndex = getAllComponent().findIndex(
        c => c.key === componentName
    );

    if (componentIndex === -1) {
        return;
    }

    disabledOtherForms(componentIndex);
    toggleEditMode(true);
    getComponent(componentIndex).dsfrId = selectedComponent.dataset.dsfrId
    loadComponent(componentIndex, propsObject);
}


function getPropsSelectedComponent(selectedComponent){
    if (!selectedComponent) return;
    const encodedProps = selectedComponent.dataset.dsfrProps;

    const decodedString = decodeURIComponent(encodedProps);

    const propsObject = JSON.parse(decodedString);

    return propsObject
}

function toggleEditMode(isEdit){
    document.getElementById('msg-alert-edit').classList.toggle('d-none', !isEdit);

    if(editMode){
        // On déshydrate tout les forms que si on à l'edit mode à true
        // Pour éviter de garder des anciennes valeurs ou de laisser les valeurs si on quite l'edit mode
        document.querySelectorAll('.jform-container').forEach(form => {
            form.reset();
        });
    }
    editMode = isEdit
}

function loadComponent(index, propsObject = null) { 
    const currentComponent = setCurrentComponentByIndex(index)
    if(!editMode) currentComponent.dsfrId = null; // Reset de l'id pour éviter que ça modif un graphe existant
    cleanPreview();

    toggleHomePage(false, currentComponent, index)

    // Afficher le form du comp select
    const activeContainer = document.getElementById('component-form-' + currentComponent.key);
    if (activeContainer) {
        activeContainer.classList.remove('d-none');
        if(propsObject) hydrateForm(activeContainer, propsObject, currentComponent.key)
        if (currentComponent.key === 'graphe-carte-dsfr'){
            updateFormMap()
        }
        updateForm()
    }
} 

// Permet de désactiver les autres formulaires quand tu es en mode modification
function disabledOtherForms(componentIndex) {
    document.querySelectorAll('#component-menu button').forEach(b => b.disabled = true); 
    document.querySelectorAll('#component-menu button')[componentIndex].disabled = false; 
}

function backHome(){
    setCurrentComponentByIndex(null);
    toggleHomePage(true);
    toggleEditMode(false);
}

function fixBugSubFormJoomla(){
    // Fix du bug joomla qui met un X à la place de 0 sur les premiers des inputs subform
    // Et vu que c'est dynamique alors il faut mettre un listener et à chaque changement du form (ajout d'un élément)
    document.addEventListener('joomla:updated', (event) => {
        const divParent = event.originalTarget;
        const inputs = divParent.querySelectorAll('input');
        if(divParent.classList.contains('subform-repeatable-group')) { // on verif bien que c'est un input d'un subform donc ajouté dynamiquement
            inputs.forEach((input) => {
                const regexX = /^([^[ ]+\[[^\] ]+\])\[[^\] ]+X\](.*)$/;
                input.name = input.name.replace(regexX, `$1[${divParent.dataset.group}]$2`); // Remplace 'X' par '0'
            })
        }
    });
   
}


function initMenu(components){
    const menu = document.getElementById('component-menu'); 
    if (components.length === 0) { 
        menu.innerHTML = '<div class="p-3 text-danger">Aucun composant XML trouvé.</div>'; 
        return; 
    } 
    components.forEach((comp, index) => { 
        const btn = document.createElement('button'); 
        btn.type = 'button'; 
        btn.className = 'list-group-item list-group-item-action py-3 menu-btn'; 
        btn.innerText = comp.title; 
        btn.onclick = () => loadComponent(index); 
        menu.appendChild(btn);
    }); 
}

function toggleHomePage(isHome, currentComponent = null, index = null) {
    document.getElementById('btn-back').classList.toggle('d-none', isHome);

    document.getElementById('form-title').innerText = isHome ? '' : currentComponent.title;
    document.getElementById('form-description').innerText = isHome ? '' : currentComponent.description;

    document.getElementById('form-actions').classList.toggle('d-none', isHome);

    // Cacher tous les formulaires
    document.querySelectorAll('.jform-container').forEach(container => {
        container.classList.add('d-none');
    });

    const menuButtons = document.querySelectorAll('#component-menu button');
    menuButtons.forEach(b => {
        b.classList.remove('active');
        if (isHome) b.disabled = false;
    });
    if (!isHome && index !== null) {
        menuButtons[index].classList.add('active');
    }

    document.getElementById('empty-state')?.classList.toggle('d-none', !isHome);
}


