import { fetchJson, fetchText } from '../utils/fetch.js';

const BASE = 'index.php?option=com_dsfrchart';

async function getTemplate(name){    
    return fetchText(
        `${BASE}&task=display.getTemplate&name=${name}&format=raw`
    )
}


async function renderPreview(shortcode) {

    const formData = new FormData();

    formData.append('shortcode', shortcode);
    formData.append(Joomla.getOptions('csrf.token'), '1');

    return fetchJson(
        `${BASE}&task=display.render&format=json`,
        {
            method: 'POST',
            body: formData
        }
    );
}

export {
    getTemplate,
    renderPreview
}