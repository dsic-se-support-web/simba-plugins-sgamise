import { generate } from "./generator.js";
const editorId = Joomla.getOptions('dsfrchart_data').editorId; 

export async function genererEtInserer() { 
    let resultHTML = await generate()
    if (resultHTML == -1) {
        return;
    }
    const parentJoomla = window.parent.Joomla;
    if (resultHTML) {
        const editor = getEditor()
        
        if (editor) { 
            try { 
                const divTemp = document.createElement('div');
                divTemp.innerHTML = resultHTML;
                const dsfrId = divTemp?.firstElementChild.getAttribute('data-dsfr-id');
                if (dsfrId) {

                    const existingNode = editor.dom.select(
                        `[data-dsfr-id="${dsfrId}"]`
                    )[0];
            
                    if (existingNode) {
                        const nextSibling = existingNode.nextElementSibling;
                        const previousSibling = existingNode.previousElementSibling;
                        if(!previousSibling || !previousSibling.matches('p')) resultHTML = '<p></p>' + resultHTML
                        if(!nextSibling || !nextSibling.matches('p')) resultHTML += '<p></p>';
                        
                        editor.dom.setOuterHTML(
                            existingNode,
                            resultHTML
                        );
            
                    }else {
                        resultHTML = '<p></p>' + resultHTML + '<p></p>'; // éviter un bug joomla
                        editor.insertContent(resultHTML);
                    }
                }
                
                if (parentJoomla?.Modal?.getCurrent()) { 
                    parentJoomla.Modal.getCurrent().close(); 
                } 
            } catch (e) { 
                console.error("Erreur d'insertion dans l'éditeur :", e); 
            } 
        } else {
            console.error("Éditeur introuvable pour l'ID :", editorId);
        }
    }
}

function getEditor() {
    return window.parent.tinymce?.get(editorId);
}

export function getAllComponentInEditor() {

    try {

        const editor = getEditor(editorId);
        if (!editor) {
            return '';
        }

        const components = editor.dom.select(
            `[data-dsfr-graphe]`
        );
        
        return components || [];

    } catch (e) {

        console.warn('Erreur TinyMCE', e);

        return '';
    }
}




