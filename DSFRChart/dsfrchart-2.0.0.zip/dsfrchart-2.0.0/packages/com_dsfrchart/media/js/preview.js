import { renderPreview } from './api/api.js';
import { generate } from './generator.js';
async function preview() {
    const previewContainer = document.getElementById('preview-container');
    
    const shortcode = await generate();
    if (shortcode == -1) return;

    let iframe = previewContainer.querySelector('iframe');
    
    if (!iframe) {
        initPreview();
    }

    const result = await renderPreview(shortcode);

    updatePreview(result.data.html);
}

function cleanPreview(){
    updatePreview('')
}

function updatePreview(text){
    const previewContainer = document.getElementById('preview-container');
    let iframe = previewContainer.querySelector('iframe');
     
    if (!iframe) { // Le cas ou il est appelé quand on ouvre un form mais que l'iframe n'a jamais été créer
        return;
    }

    const doc = iframe.contentDocument || iframe.contentWindow.document;
    const wrapper = doc.getElementById('preview-wrapper');
        
    if (wrapper) {
        wrapper.innerHTML = text
    }
}


function initPreview(){
    const previewContainer = document.getElementById('preview-container');
    let iframe = previewContainer.querySelector('iframe');
    previewContainer.innerHTML = '';
    iframe = document.createElement('iframe');
    iframe.id = 'dsfr-preview-frame';
    iframe.style.width = '100%';
    iframe.style.border = 'none';
    iframe.style.background = 'transparent';
    iframe.setAttribute('allowtransparency', 'true');
    previewContainer.appendChild(iframe);

    const dsfrPaths = Joomla.getOptions('dsfr_paths');
    const dsfrStyles = dsfrPaths.css.map(h => `<link rel="stylesheet" href="${h}">`).join('');
    const dsfrScripts = dsfrPaths.js.map(src => `<script type="module" src="${src}"></script>`).join('');

    const doc = iframe.contentDocument || iframe.contentWindow.document;
    doc.open();
    doc.write(`
        <html style="background: transparent;">
            <head>
                ${dsfrStyles}
                <style>
                    body { background: transparent !important; margin: 0; padding: 0; overflow: hidden; }
                    #preview-wrapper { padding: 10px; min-height: 50px; }
                    .fr-nav__link, .fr-nav__link:hover, .fr-nav__link:focus {
                        color: black !important;
                    }
                </style>
            </head>
            <body>
                <div id="preview-wrapper">Chargement en cours...</div>
                ${dsfrScripts}
                <script>
                    const updateHeight = () => {
                        window.frameElement.style.height = document.documentElement.scrollHeight + 'px';
                    };
                    new ResizeObserver(updateHeight).observe(document.body);
                </script>
            </body>
        </html>
    `);
    doc.close();
}


export {
    preview,
    cleanPreview
}