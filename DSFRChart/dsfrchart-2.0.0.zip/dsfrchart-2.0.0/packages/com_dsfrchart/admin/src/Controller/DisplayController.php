<?php
namespace Joomla\Component\DsfrChart\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;
use Joomla\CMS\Response\JsonResponse;

class DisplayController extends BaseController {
    protected $default_view = 'modal';

    public function getTemplate(){
    $app = Factory::getApplication();
    $input = $app->getInput();

    $name = $input->get('name', '', 'cmd');

    // Vérification que le nom est valide (caractères alphanumériques + tiret + point)
    if (!preg_match('/^[a-zA-Z0-9._-]+$/', $name)) {
        http_response_code(400);
        echo "Nom de fichier invalide.";
        return;
    }

    $tamponsPath = JPATH_SITE . '/media/com_dsfrchart/tampons/' . $name . '.txt';

    if (!file_exists($tamponsPath)) {
        http_response_code(404);
        echo 'Fichier ' . htmlspecialchars($tamponsPath) . ' introuvable.';
        return;
    }

    header('Content-Type: text/plain; charset=utf-8');

    echo file_get_contents($tamponsPath);
}

    public function render()
    {
        $this->checkToken('post');

        $app   = Factory::getApplication();
        $input = $app->getInput();

        $shortcode = $input->post->get('shortcode', '', 'RAW');

        if (empty($shortcode)) {
            echo new JsonResponse(new \Exception('Shortcode vide'));
            $app->close();
        }
        
        $textFinal = \Joomla\CMS\HTML\HTMLHelper::_('content.prepare', $shortcode);
        echo new JsonResponse(['html' => $textFinal]);
        $app->close();
    }
}
