<?php
namespace Joomla\Component\DsfrChart\Administrator\View\Modal;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Factory;

class HtmlView extends BaseHtmlView
{
    public $editorId;

    public function display($tpl = null)
    {
        $app = Factory::getApplication();
        
        $this->editorId = $app->getInput()->get('editor_id', '', 'cmd');
        return parent::display($tpl);
    }
}