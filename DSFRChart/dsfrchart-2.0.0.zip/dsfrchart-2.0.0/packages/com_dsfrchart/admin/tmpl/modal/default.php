<?php 
defined('_JEXEC') or die; 

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormFactoryInterface;
use Joomla\CMS\Uri\Uri;

$this->document->setHtml5(true); 

$wa = $this->document->getWebAssetManager();

$templatePath = Uri::root(true) . '/templates/cassiopeia_dsfr';
$formsPath = JPATH_SITE . '/media/com_dsfrchart/forms';


$componentConfigs = []; 
$formsHtml = ''; 

function getHTMLFieldset($fieldset, $form){
    $formsHtml = '';
    $cssClass = isset($fieldset->class) ? 'class="' . $fieldset->class . '"' : '';
    $idClass = isset($fieldset->id) ? 'id="' . $fieldset->id . '"' : '';
    $nameAttr = isset($fieldset->name) ? 'name="' . $fieldset->name . '"' : '';
    $formsHtml .= '<fieldset ' . $cssClass .' '.$idClass.' '.$nameAttr.' style="border: none; padding: 0; margin: 0;">';
    
    $fieldsetContent = $form->renderFieldset($fieldset->name); 
    $formsHtml .= $fieldsetContent;
    $formsHtml .= '</fieldset>';

    return $formsHtml;
}

function getDataBoxHTML($formsPath, $formFactory, $key){
    $files = glob($formsPath . '/databox.xml'); 
    $formDataBox = $formFactory->createForm($key, ['control' => $key]);
    $formDataBox->loadFile($files[0]);
    $formDataBoxHTML = '';
    foreach ($formDataBox->getFieldsets() as $fieldset) {
        $formDataBoxHTML .= getHTMLFieldset($fieldset, $formDataBox);
    }

    return $formDataBoxHTML;
}

if (is_dir($formsPath)) { 
    $files = glob($formsPath . '/*-dsfr.xml'); 
    
    $formFactory = Factory::getContainer()->get(FormFactoryInterface::class);
    
    foreach ($files as $file) { 
        $key = basename($file, '.xml'); 
       
        $form = $formFactory->createForm($key, ['control' => $key]);
        
        $form->loadFile($file);
        
        $title = $form->getField('form_title')->value;
        $desc = $form->getField('form_description')->value;
        $componentConfigs[] = [
            'key' => $key,
            'title' => $title,
            'description' => $desc
        ];
        $formsHtml .= '<form id="component-form-' . $key . '" class="jform-container d-none">';
        
        foreach ($form->getFieldsets() as $fieldset) {
            if($fieldset->name === 'databox-params'){
                $formsHtml .= getDataBoxHTML($formsPath, $formFactory, $key);

            }else {
                $formsHtml .= getHTMLFieldset($fieldset, $form);
            }
        }
        
        $formsHtml .= '</form>';

    } 
} 

$this->document->addScriptOptions('dsfrchart_data', [
    'editorId'          => $this->editorId,
    'componentConfig'   => $componentConfigs,
]);
$this->document->addStyleSheet(Uri::root(true) . '/media/com_dsfrchart/css/style.css');
$wa->registerScript(
    'com_dsfrchart.script',
    'media/com_dsfrchart/js/script.js',
    [],
    [
        'type'  => 'module',
        'defer' => true
    ]
);

$wa->useScript('com_dsfrchart.script');

$this->document->addScriptOptions('dsfr_paths', [
    'css' => [
        $templatePath . '/dsfr/dsfr.min.css',
        $templatePath . '/dsfr/core/core.min.css',
        $templatePath . '/dsfr/utility/utility.min.css',
        $templatePath . '/dsfr/DSFRChart/DSFRChart.css',
        $templatePath . '/user.css'
    ],
    'js' => [
        $templatePath . '/dsfr/dsfr.module.min.js',
        $templatePath . '/dsfr/core/core.module.min.js',
        $templatePath . '/dsfr/DSFRChart/DSFRChart.js'
    ]
]);
?> 

<div class="modal-layout"> 
    <div class="sidebar"> 
        <div class="p-3 bg-light border-bottom"> 
            <button type="button" id="btn-back" class="btn d-none mb-3 p-0">
                <span class="icon-arrow-left"></span> Retour accueil
            </button> 
            <h1 id='menu-title' class="h6 mb-0 text-uppercase fw-bold text-muted">Composants</h1> 
        </div> 
        <div class="list-group list-group-flush" id="component-menu"></div> 
    </div> 

    <div class="main-content"> 
        <div id="form-header" class="mb-4"> 
            <h2 id="form-title"></h2>
            <div class="alert alert-error d-none" id='msg-alert-edit'>Attention! Vous êtes en mode modification ! Vous pouvez modifier les informations, mais n'oubliez pas d'enregistrer avant de quitter la page </div>
            <p id="form-description" class="text-muted"></p>
        </div> 
        <div id="empty-state" class="empty-state">

            <h2>
                Graphique DSFR
            </h2>

            <p>
                Sélectionnez un graphique dans le menu de gauche
                pour afficher son formulaire de configuration.
            </p>

            <div>
                Vous pourrez ensuite :
                <ul>
                    <li>Configurer ses options</li>
                    <li>Prévisualiser le rendu DSFR</li>
                    <li>Insérer automatiquement le composant dans l'article</li>
                </ul>
            </div>
            <div>
                <h2>Modification des graphiques</h2>
                <p>Voici les composants présent dans votre article, cliquer sur un composant pour le modifier:</p>
                <ul id='list-graphe'>
                </ul>
            </div>

            <div class="alert alert-warning">Important ! Pour cause d'une limitation de l'éditeur, les graphiques ne seront pas visibles après insertion dans l'article mais uniquement en prévisualisation et dans l'article en front office après enregistrement. </div>

        </div>
        <?php echo $formsHtml; ?>
        
        <div id="form-actions" class="mt-4 d-none text-end border-top pt-3"> 
            <div class="alert alert-warning">Important ! Pour cause d'une limitation de l'éditeur, les graphiques ne sera pas visible après insertion dans l'article mais uniquement en prévisualisation et dans l'article en front office après enregistrement. </div>
            <button type="button" class="btn btn-primary" id="btn-insertion"> 
                <span class="icon-check"></span> Insérer dans l'article 
            </button> 
            <button type="button" id="btn-preview" class="btn btn-primary">
            <span class="icon-eye"></span> Générer l'aperçu</button>
            
        </div> 

        <div id="preview-container" style="margin-top: 20px; border: 1px dashed #ccc; padding: 10px; min-height: 200px;">
        </div>
    </div> 
</div>