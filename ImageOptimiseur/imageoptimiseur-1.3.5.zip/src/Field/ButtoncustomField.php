<?php

namespace Joomla\Plugin\System\Imageoptimiseur\Field;

defined('_JEXEC') or die;

use Joomla\CMS\Form\FormField;

class ButtoncustomField extends FormField
{
    protected $type="Buttoncustom";

    protected function getInput()
    {
         return '<input
                type="submit"
                class="btn btn-success"
                value="Lancer l\'optimisation"
                onclick="
                    Joomla.submitbutton(\'imageoptimiseur.optimizeExisting\');
                    return false;
                "
            />';
    }

    public function getLabel() {
        return '<span style="text-decoration: underline;">' . parent::getLabel() . '</span>';
    }
}