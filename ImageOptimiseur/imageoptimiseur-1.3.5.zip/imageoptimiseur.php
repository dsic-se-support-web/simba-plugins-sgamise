<?php
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Factory;

class PlgSystemImageOptimiseur extends CMSPlugin
{
    protected $autoloadLanguage = true;
    private $logFile; //debug

    // Génération du toast en session
    public function onAjaxImageoptimiseur()
    {
        $app = Factory::getApplication();
        $session = $app->getSession();
    
        $data = $session->get('imageoptimiseur_toast');

        if ($data) {
            $session->clear('imageoptimiseur_toast');
        }
        
        return $data;
    }

    // Affichage du toast d'information après upload
    public function onBeforeCompileHead()
    {
        $app = Factory::getApplication();
    
        if (!$app->isClient('administrator')) {
            return;
        }

        if ($app->input->getCmd('option') !== 'com_media') {
            return;
        }

        $doc = $app->getDocument();

        \Joomla\CMS\HTML\HTMLHelper::_('bootstrap.toast');
    
        $js = <<<'JS'
        document.addEventListener("DOMContentLoaded", function(){

        let toastShown = false;

        const origOpen = XMLHttpRequest.prototype.open;

        XMLHttpRequest.prototype.open = function(method, url){

        this.addEventListener("load", function(){

        try{

        if(url.includes("option=com_media") && url.includes("task=api.files")){

        const json = JSON.parse(this.responseText);

        if(json.success && json.data && json.data.type === "file"){

        if(!toastShown){
        toastShown = true;
        setTimeout(showOptimToast,300);
        }

        }

        }

        }catch(e){
        console.error("ImageOptimiseur XHR error", e);
        }

        });

        return origOpen.apply(this, arguments);

        };

        function showOptimToast(){

        fetch("index.php?option=com_ajax&plugin=imageoptimiseur&format=json")
        .then(r=>r.json())
        .then(resp=>{

        console.log("ImageOptimiseur AJAX:", resp);

        if(!resp.success || !resp.data || resp.data.length === 0) return;

        let d = resp.data[0];

        let html = `
        <div class="toast align-items-center text-bg-success border-0" data-bs-delay="5000">
        <div class="d-flex">
        <div class="toast-body">
        <strong>Image optimisée : ${d.file}</strong><br>
        ${d.w1}×${d.h1} → ${d.w2}×${d.h2}<br>
        Gain : ${d.gain} %
        </div>
        <button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
        </div>
        `;

        let container = document.getElementById("imgopt-toast");

        if(!container){
        container = document.createElement("div");
        container.id="imgopt-toast";
        container.className="toast-container position-fixed top-0 start-50 translate-middle-x p-3";
        document.body.appendChild(container);
        }

        container.insertAdjacentHTML("beforeend",html);

        let toastEl = container.lastElementChild;
        let toast = new bootstrap.Toast(toastEl);

        toast.show();

        });

        }

        });
        JS;
    
        $doc->addScriptDeclaration($js);
    }

    public function onAfterRoute()
    {
        $app = Factory::getApplication();
    
        if (!$app->isClient('administrator')) {
            return;
        }
    
        if ($app->input->getCmd('task') !== 'imageoptimiseur.optimizeExisting') {
            return;
        }
    
        if (!Factory::getUser()->authorise('core.admin')) {
            throw new \Exception('Accès interdit');
        }
    
        $result = $this->optimizeExistingImages();
    
        $app->enqueueMessage(
            sprintf(
                '%d images optimisées, %d ignorées.',
                $result['optimized'],
                $result['ignored']
            ),
            'success'
        );
    
        $app->redirect(
            'index.php?option=com_plugins&task=plugin.edit&extension_id=' .
            (int) $app->input->getInt('extension_id')
        );
    
        $app->close();
    }

    private function optimizeExistingImages()
    {
        $optimized = 0;
        $ignored = 0;
    
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator(
                JPATH_ROOT . '/images',
                \FilesystemIterator::SKIP_DOTS
            )
        );
    
        foreach ($iterator as $file) {
    
            if (!$file->isFile()) {
                continue;
            }
    
            $result = $this->processFile(
                $file->getPathname(),
                strtolower($file->getExtension())
            );
    
            if ($result) {
                $optimized++;
            } else {
                $ignored++;
            }
        }
    
        return [
            'optimized' => $optimized,
            'ignored'   => $ignored,
        ];
    }

    // Contruction des chemins avant traitement des images
	public function onContentAfterSave($context, $table, $isNew, $data = [])
	{
		if ($context !== 'com_media.file' || !$isNew) {
			return true;
		}

		// Début - Lignes pour débug
		$this->log("Upload détecté via onContentAfterSave");
		// Fin - Lignes pour débug

        // Nom du fichier
        $filename = is_array($data) ? ($data['name'] ?? '') : ($data->name ?? '');
        if (!$filename) {
            $this->log("Erreur : nom du fichier non défini");
            return true;
        }

        // Chemin renvoyé par le media manager (ex : "/", "/sampledata")
        $rawPath = $table->path ?? '';
        if (!$rawPath) {
            $this->log("Erreur : table->path est vide");
            return true;
        }

        $rawPath = str_replace('\\', '/', $rawPath);
        $this->log("Valeur brute table->path : $rawPath");

        // Récupérer un chemin relatif
        $cleanPath = trim($rawPath, '/');

        // Construire le chemin complet vers le dossier dans /images
        $folderPath = JPATH_ROOT . '/images';
        if ($cleanPath !== '') {
            $folderPath .= '/' . $cleanPath;
        }

        // Chemin final du fichier (mise en forme)
        $path = $folderPath . '/' . $filename;
        $path = str_replace('\\', '/', $path);

        $this->log("Chemin final fichier : $path");
        $this->log("Nom du fichier : $filename");

        // Extension
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $this->log("Extension : $ext");

        $result = $this->processFile($path, $ext);

        if ($result) {
        
            $session = Factory::getApplication()->getSession();
        
            $session->set('imageoptimiseur_toast', [
                'file' => $filename,
                'w1' => $result['width_before'],
                'h1' => $result['height_before'],
                'w2' => $result['width_after'],
                'h2' => $result['height_after'],
                'gain' => $result['gain']
            ]);
        }
        
        return true;
	}

	// Début - Fonction debug
    private function log($msg)
    {
        if (!$this->logFile)
        {
            $this->logFile = JPATH_ROOT . '/administrator/logs/ImageOptimiseur_debug.log';
        }

        file_put_contents(
            $this->logFile,
            date('Y-m-d H:i:s') . ' - ' . $msg . "\n",
            FILE_APPEND
        );
    }
	// Fin - Fonction debug

    /**
     * Vérifie formats supportés et GIF animés
     */
    private function processFile($path, $ext)
    {
        $supported = ['jpg','jpeg','png','gif','webp'];
    
        if (!in_array($ext, $supported)) {
            return null;
        }
    
        if ($ext === 'gif' && $this->isAnimatedGif($path)) {
            return null;
        }
    
        if ($ext === 'webp' && !$this->gdSupportsWebp()) {
            return null;
        }
    
        $params = [
            'enableResize'   => (int) $this->params->get('enable_resize', 1),
            'limit'          => (int) $this->params->get('max_limit', 800),
            'enableCompress' => (int) $this->params->get('enable_compression', 1),
            'compression'    => (int) $this->params->get('compression', 82),
        ];
    
        return $this->processImage($path, $ext, $params);
    }

    // Vérification du support Webp
    private function gdSupportsWebp()
    {
        $read  = (imagetypes() & IMG_WEBP);
        $write = function_exists('imagewebp');

        return ($read && $write);
    }

    // Vérification des gif animés (pour exclusion)
    private function isAnimatedGif($filename)
    {
        $file = @fopen($filename, 'rb');
        if (!$file) return false;

        $count = 0;
        while (!feof($file) && $count < 2) {
            $chunk = fread($file, 1024 * 100);
            $count += preg_match_all('#\x00\x21\xF9\x04#', $chunk);
        }

        fclose($file);
        return $count > 1;
    }

    // Optimisation des images
    private function processImage($path, $ext, $params)
    {
        $originalSize = filesize($path);
    
        switch ($ext) {
            case 'png':  $img = @imagecreatefrompng($path); break;
            case 'gif':  $img = @imagecreatefromgif($path); break;
            case 'webp': $img = @imagecreatefromwebp($path); break;
            default:     $img = @imagecreatefromjpeg($path);
        }
    
        if (!$img) return null;
    
        $w = imagesx($img);
        $h = imagesy($img);
    
        $nw = $w;
        $nh = $h;
    
        if ($params['enableResize'] && max($w, $h) > $params['limit']) {
            $ratio = $params['limit'] / max($w, $h);
            $nw = (int)($w * $ratio);
            $nh = (int)($h * $ratio);
        }
    
        if ($nw !== $w || $nh !== $h) {
    
            $new = imagecreatetruecolor($nw, $nh);
    
            if (in_array($ext, ['png','webp'])) {
                imagealphablending($new,false);
                imagesavealpha($new,true);
            }
    
            imagecopyresampled($new,$img,0,0,0,0,$nw,$nh,$w,$h);
    
            imagedestroy($img);
            $img = $new;
        }
    
        switch ($ext) {
    
            case 'png':
                $level = $params['enableCompress']
                    ? max(0,min(9,round((100-$params['compression'])/10)))
                    : 0;
                imagepng($img,$path,$level);
            break;
    
            case 'gif':
                imagegif($img,$path);
            break;
    
            case 'webp':
                $q = $params['enableCompress'] ? $params['compression'] : 100;
                imagewebp($img,$path,$q);
            break;
    
            default:
                $q = $params['enableCompress'] ? $params['compression'] : 100;
                imagejpeg($img,$path,$q);
        }
    
        imagedestroy($img);
    
        clearstatcache();
        $newSize = filesize($path);
    
        $gain = $originalSize > 0
            ? round((1 - ($newSize / $originalSize)) * 100)
            : 0;
    
        return [
            'width_before' => $w,
            'height_before'=> $h,
            'width_after'  => $nw,
            'height_after' => $nh,
            'gain'         => $gain
        ];
    }
}
