<?php
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Table\Table;

class PlgSystemImageOptimiseur extends CMSPlugin
{
    protected $autoloadLanguage = true;
    private $logFile; //debug

	public function onContentAfterSave($context, $table, $isNew, $data = [])
	{
		if ($context !== 'com_media.file' || !$isNew) {
			return true;
		}

		// Début - Lignes pour débug
		$this->log("Upload détecté via onContentAfterSave");
		// Fin - Lignes pour débug

        // Nom du fichier
        $filename = is_array($data) ? ($data['name'] ?? '') : ($data->name ?? '');
        if (!$filename) {
            $this->log("Erreur : nom du fichier non défini");
            return true;
        }

        // Chemin renvoyé par le media manager (ex : "/", "/sampledata")
        $rawPath = $table->path ?? '';
        if (!$rawPath) {
            $this->log("Erreur : table->path est vide");
            return true;
        }

        $rawPath = str_replace('\\', '/', $rawPath);
        $this->log("Valeur brute table->path : $rawPath");

        // Récupérer un chemin relatif
        $cleanPath = trim($rawPath, '/');

        // Construire le chemin complet vers le dossier dans /images
        $folderPath = JPATH_ROOT . '/images';
        if ($cleanPath !== '') {
            $folderPath .= '/' . $cleanPath;
        }

        // Chemin final du fichier (mise en forme)
        $path = $folderPath . '/' . $filename;
        $path = str_replace('\\', '/', $path);

        $this->log("Chemin final fichier : $path");
        $this->log("Nom du fichier : $filename");

        // Extension
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $this->log("Extension : $ext");

        $this->processFile($path, $ext);

        return true;
	}

	// Début - Fonction debug
    private function log($msg)
    {
        if (!$this->logFile)
        {
            $this->logFile = JPATH_ROOT . '/administrator/logs/ImageOptimiseur_debug.log';
        }

        file_put_contents(
            $this->logFile,
            date('Y-m-d H:i:s') . ' - ' . $msg . "\n",
            FILE_APPEND
        );
    }
	// Fin - Fonction debug

    /**
     * Vérifie formats supportés et GIF animés
     */
    private function processFile($path, $ext)
    {
        $supported = ['jpg','jpeg','png','gif','webp'];

        if (!in_array($ext, $supported)) {
            $this->log("Extension non supportée : $ext → ignorée");// débug
            return;
        }

        if ($ext === 'gif' && $this->isAnimatedGif($path)) {
            $this->log("GIF animé détecté → ignoré");// débug
            return;
        }

        if ($ext === 'webp' && !$this->gdSupportsWebp()) {
            $this->log("WebP non supporté par GD → ignoré");// débug
            return;
        }

        // Paramètres plugin
        $params = [
            'enableResize'   => (int) $this->params->get('enable_resize', 1),
            'limit'          => (int) $this->params->get('max_limit', 800),
            'enableCompress' => (int) $this->params->get('enable_compression', 1),
            'compression'    => (int) $this->params->get('compression', 82),
        ];

        $this->log("Paramètres: " . json_encode($params));// débug

        $this->processImage($path, $ext, $params);
    }

    private function gdSupportsWebp()
    {
        $read  = (imagetypes() & IMG_WEBP);
        $write = function_exists('imagewebp');

        return ($read && $write);
    }

    private function isAnimatedGif($filename)
    {
        $file = @fopen($filename, 'rb');
        if (!$file) return false;

        $count = 0;
        while (!feof($file) && $count < 2) {
            $chunk = fread($file, 1024 * 100);
            $count += preg_match_all('#\x00\x21\xF9\x04#', $chunk);
        }

        fclose($file);
        return $count > 1;
    }

    private function processImage($path, $ext, $params)
    {
        switch ($ext) {
            case 'png':  $img = @imagecreatefrompng($path); break;
            case 'gif':  $img = @imagecreatefromgif($path); break;
            case 'webp': $img = @imagecreatefromwebp($path); break;
            default:     $img = @imagecreatefromjpeg($path);
        }

        if (!$img) {
            $this->log("Erreur : impossible d’ouvrir $path");// débug
            return;
        }

        $w = imagesx($img);
        $h = imagesy($img);

        $this->log("Dimensions originales : {$w}x{$h}");// débug

        $nw = $w;
        $nh = $h;

        if ($params['enableResize'] && max($w, $h) > $params['limit']) {
            $ratio = $params['limit'] / max($w, $h);
            $nw = (int)($w * $ratio);
            $nh = (int)($h * $ratio);

            $this->log("Redimensionnement → {$nw}x{$nh}");// débug
        }

        if ($nw !== $w || $nh !== $h) {
            $new = imagecreatetruecolor($nw, $nh);

            if (in_array($ext, ['png', 'webp'])) {
                imagealphablending($new, false);
                imagesavealpha($new, true);
            }

            imagecopyresampled($new, $img, 0, 0, 0, 0, $nw, $nh, $w, $h);
            imagedestroy($img);
            $img = $new;
        }

        switch ($ext) {
            case 'gif':
                imagegif($img, $path);
                break;

            case 'png':
                $level = $params['enableCompress']
                    ? max(0, min(9, round((100 - $params['compression']) / 10)))
                    : 0;

                $this->log("Compression PNG niveau : $level");// débug
                imagepng($img, $path, $level);
                break;

            case 'webp':
                $q = $params['enableCompress'] ? $params['compression'] : 100;
                $this->log("Compression WebP : $q");// débug
                imagewebp($img, $path, $q);
                break;

            default:
                $q = $params['enableCompress'] ? $params['compression'] : 100;
                $this->log("Compression JPEG : $q");// débug
                imagejpeg($img, $path, $q);
        }

        imagedestroy($img);
        $this->log("Image optimisée");// débug
    }
}
