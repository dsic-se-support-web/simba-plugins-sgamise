Ce plugin permet d'appliquer à la volée des limites aux images téléversées dans les médias :

- Taux de compression réglable et appliqué si pris en charge par le format d'image
- Redimensionnement automatique sur la base d'une valeur hauteur ou largeur maximum
- Prise en charge des images GIF avec détection et exclusion de tout traitement des GIF animé
- Formats d'images supportés :
- - png (redimensionnement + compression)
- - jpg, jpeg (redimensionnement + compression)
- - gif non animés(redimensionnement)
- - webp statique (redimensionnement + compression) uniquement si Php v7.0+ et si GD est compilé avec WebP

Contraintes liées à la bibliothèque GD :
- Formats d'images non supportés : bmp, svg, (webp statique si GD n'est compilé avec WebP)
- Forte charge mémoire côté serveur