<?php
namespace Joomla\Plugin\Task\Actionlogprune\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\Database\DatabaseInterface;

class PurgeHelper
{
    public static function execute(): int
    {
        $container = Factory::getContainer();
        $db = $container->get(DatabaseInterface::class);

        $plugin = \Joomla\CMS\Plugin\PluginHelper::getPlugin('task', 'actionlogprune');
        $params = new \Joomla\Registry\Registry($plugin->params);

        $value = (int) $params->get('retention_value', 12);
        $unit  = $params->get('retention_unit', 'months');

        $date = new \DateTime();

        switch ($unit) {
            case 'days':
                $date->modify("-{$value} days");
                break;
            case 'years':
                $date->modify("-{$value} years");
                break;
            default:
                $date->modify("-{$value} months");
        }

        $limitDate = $date->format('Y-m-d H:i:s');

        $query = $db->getQuery(true)
            ->delete('#__action_logs')
            ->where('log_date < ' . $db->quote($limitDate));

        $db->setQuery($query);

        try {
            $db->execute();
        } catch (\Exception $e) {
            return 1; // FAILED
        }

        return 0; // OK
    }
}