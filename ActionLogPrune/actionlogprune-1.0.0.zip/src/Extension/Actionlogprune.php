<?php

namespace Joomla\Plugin\Task\Actionlogprune\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Component\Scheduler\Administrator\Traits\TaskPluginTrait;
use Joomla\Component\Scheduler\Administrator\Task\Status;
use Joomla\Component\Scheduler\Administrator\Event\ExecuteTaskEvent;
use Joomla\Event\SubscriberInterface;

class Actionlogprune extends CMSPlugin implements SubscriberInterface
{
    use TaskPluginTrait;

    protected $autoloadLanguage = true;

    private const TASKS_MAP = [
        'actionlogprune.purge' => [
            'langConstPrefix' => 'PLG_TASK_ACTIONLOGPURGE',
            'method'          => 'runPurge',
        ],
    ];

    public static function getSubscribedEvents(): array
    {
        return [
            'onTaskOptionsList' => 'advertiseRoutines',
            'onExecuteTask'     => 'standardRoutineHandler',
        ];
    }

    /**
     * Méthode appelée automatiquement via TaskPluginTrait
     */
    private function runPurge(ExecuteTaskEvent $event): int
    {
        $result = \Joomla\Plugin\Task\Actionlogprune\Helper\PurgeHelper::execute();

        return $result === 0 ? Status::OK : Status::FAILED;
    }
}