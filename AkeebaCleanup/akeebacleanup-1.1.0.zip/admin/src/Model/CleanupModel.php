<?php
namespace Joomla\Component\Akeebacleanup\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Factory;

class CleanupModel extends BaseDatabaseModel
{
    // Compte le nombre de backups obsolètes
    public function getObsoleteCount(): int
    {
        $db = Factory::getDbo();

        $query = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('filesexist') . ' = 0');

        $db->setQuery($query);

        return (int) $db->loadResult();
    }

    // Supprime les backups obsolètes
    public function deleteObsoleteBackups(): int
    {
        $db = Factory::getDbo();

        $count = $this->getObsoleteCount();

        $query = $db->getQuery(true)
            ->delete($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('filesexist') . ' = 0');

        $db->setQuery($query);
        $db->execute();

        return $count;
    }

    // Compte les backups en échec
    public function getFailedCount(): int
    {
        $db = Factory::getDbo();
    
        $query = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('status') . ' IN (' . $db->quote('fail') . ', ' . $db->quote('error') . ')');
    
        $db->setQuery($query);
    
        return (int) $db->loadResult();
    }

    // Supprimer les backups en échec
    public function deleteFailedBackups(): int
    {
        $db = Factory::getDbo();
    
        $count = $this->getFailedCount();
    
        $query = $db->getQuery(true)
            ->delete($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('status') . ' IN (' . $db->quote('fail') . ', ' . $db->quote('error') . ')');
    
        $db->setQuery($query);
        $db->execute();
    
        return $count;
    }
}
