<?php
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
?>

<div class="container">
    <h1>Akeeba – Nettoyage des sauvegardes obsolètes</h1>

    <p>
        <strong><?php echo $this->obsoleteCount; ?></strong>
        sauvegarde(s) obsolète(s) détectée(s).
    </p>

    <?php if ($this->obsoleteCount > 0) : ?>
        <form method="post"
      action="<?php echo Route::_('index.php?option=com_akeebacleanup&task=cleanup.deleteObsolete'); ?>"
      onsubmit="return confirm('Confirmer la suppression ?');">

            <button class="btn btn-danger">
                Supprimer toutes les sauvegardes obsolètes
            </button>

            <?php echo HTMLHelper::_('form.token'); ?>
        </form>
    <?php else : ?>
        <div class="alert alert-success">
            Aucune sauvegarde obsolète à nettoyer.
        </div>
    <?php endif; ?>
</div>

<hr>

<h2>Backups en échec</h2>

<p>
    <strong><?php echo $this->failedCount; ?></strong>
    sauvegarde(s) en échec détectée(s).
</p>

<?php if ($this->failedCount > 0) : ?>
    <form method="post"
          action="<?php echo Route::_('index.php?option=com_akeebacleanup&task=cleanup.deleteFailed'); ?>"
          onsubmit="return confirm('Supprimer toutes les sauvegardes en échec ?');">

        <button class="btn btn-warning">
            Supprimer les sauvegardes en échec
        </button>

        <?php echo HTMLHelper::_('form.token'); ?>
    </form>
<?php else : ?>
    <div class="alert alert-success">
        Aucune sauvegarde en échec détectée.
    </div>
<?php endif; ?>