<?php
namespace Joomla\Component\Akeebacleanup\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Factory;

/**
 * Modèle principal du composant Akeeba Cleanup.
 *
 * Gère l'accès à la table des sauvegardes Akeeba
 * et fournit les méthodes de comptage, suppression
 * et analyse des chaînes de sauvegarde.
 */
class CleanupModel extends BaseDatabaseModel
{
    /**
     * Retourne le nombre de sauvegardes obsolètes.
     *
     * Une sauvegarde est considérée comme obsolète lorsque
     * les fichiers associés n'existent plus sur le disque
     * (filesexist = 0).
     *
     * @return int Nombre de sauvegardes obsolètes
     */
    public function getObsoleteCount(): int
    {
        $db = Factory::getDbo();

        // Construction de la requête COUNT(*)
        $query = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('filesexist') . ' = 0');

        $db->setQuery($query);

        return (int) $db->loadResult();
    }

    /**
     * Supprime toutes les sauvegardes obsolètes.
     *
     * La méthode supprime les enregistrements dont
     * filesexist = 0 et retourne le nombre de lignes supprimées.
     *
     * @return int Nombre de sauvegardes supprimées
     */
    public function deleteObsoleteBackups(): int
    {
        $db = Factory::getDbo();

        // Construction de la requête DELETE
        $query = $db->getQuery(true)
            ->delete($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('filesexist') . ' = 0');

        $db->setQuery($query);
        $db->execute();

        return $db->getAffectedRows();
    }

    /**
     * Retourne le nombre de sauvegardes en échec.
     *
     * Une sauvegarde est considérée comme en échec lorsque
     * son statut est "fail" ou "error".
     *
     * @return int Nombre de sauvegardes en échec
     */
    public function getFailedCount(): int
    {
        $db = Factory::getDbo();
    
        // Requête COUNT(*) sur les statuts en erreur
        $query = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('status') . ' IN (' . $db->quote('fail') . ', ' . $db->quote('error') . ')');
    
        $db->setQuery($query);
    
        return (int) $db->loadResult();
    }

    /**
     * Supprime toutes les sauvegardes en échec.
     *
     * Supprime les sauvegardes dont le statut est
     * "fail" ou "error".
     *
     * @return int Nombre de sauvegardes supprimées
     */
    public function deleteFailedBackups(): int
    {
        $db = Factory::getDbo();
    
        // Requête DELETE sur les statuts en erreur
        $query = $db->getQuery(true)
            ->delete($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('status') . ' IN (' . $db->quote('fail') . ', ' . $db->quote('error') . ')');
    
        $db->setQuery($query);
        $db->execute();
    
        // Nombre de lignes réellement supprimées
        return $db->getAffectedRows();
    }

    /**
     * Récupère la liste des sauvegardes valides.
     *
     * Une sauvegarde valide est une sauvegarde dont
     * le statut est "complete".
     *
     * Les sauvegardes sont retournées par ordre chronologique
     * croissant (date de début).
     *
     * @return array Liste des sauvegardes valides (objets stdClass)
     */
    public function getValidBackups(): array
    {
        $db = Factory::getDbo();
    
        // Sélection uniquement des champs nécessaires à l'affichage
        $query = $db->getQuery(true)
            ->select([
                'id',
                'profile_id',
                'description',
                'type',
                'backupstart',
                'backupend'
            ])
            ->from($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('status') . ' = ' . $db->quote('complete'))
            ->order($db->quoteName('backupstart') . ' ASC');
    
        $db->setQuery($query);
    
        return $db->loadObjectList();
    }

    /**
     * Analyse la cohérence des chaînes de sauvegarde.
     *
     * Une chaîne valide est constituée de :
     * - 1 sauvegarde Full
     * - suivie de N sauvegardes incrémentielles
     * - puis idéalement une nouvelle Full
     *
     * Cette méthode détecte :
     * - trop d'incrémentielles après une Full
     * - des incrémentielles sans Full préalable
     * - l'absence de sauvegarde Full récente
     *
     * @param int $maxIncrementals    Nombre maximal d'incrémentielles autorisées
     * @param int $maxDaysWithoutFull Nombre maximal de jours sans sauvegarde Full
     *
     * @return array Tableau contenant les chaînes détectées et les alertes
     */
    public function analyzeBackupChains(
        int $maxIncrementals = 31,
        int $maxDaysWithoutFull = 30
    ): array {
        // Récupération des sauvegardes valides
        $backups = $this->getValidBackups();
    
        $chains = [];
        $alerts = [];
    
        $currentChain = null;
        $incrementalCount = 0;
    
        foreach ($backups as $backup)
        {
            // Détection d'une sauvegarde Full
            if ($backup->type === 'full')
            {
                // Vérifie si la chaîne précédente contient trop d'incrémentielles
                if ($currentChain && $incrementalCount > $maxIncrementals)
                {
                    $alerts[] = [
                        'type' => 'too_many_incrementals',
                        'message' => sprintf(
                            'Plus de %d sauvegardes incrémentielles après la Full du %s',
                            $maxIncrementals,
                            $currentChain['date']
                        )
                    ];
                }
    
                // Démarrage d'une nouvelle chaîne
                $currentChain = [
                    'date' => $backup->backupstart,
                    'incrementals' => []
                ];
    
                $incrementalCount = 0;
                $chains[] = &$currentChain;
            }
            // Détection d'une sauvegarde incrémentielle
            elseif ($backup->type === 'incremental')
            {
                if (!$currentChain)
                {
                    // Incrémentielle sans Full préalable
                    $alerts[] = [
                        'type' => 'incremental_without_full',
                        'message' => sprintf(
                            'Sauvegarde incrémentielle sans Full préalable (%s)',
                            $backup->backupstart
                        )
                    ];
                }
                else
                {
                    $currentChain['incrementals'][] = $backup;
                    $incrementalCount++;
                }
            }
        }
    
        // Vérifie si la dernière sauvegarde Full est trop ancienne
        if ($currentChain)
        {
            $lastFullDate = strtotime($currentChain['date']);
            $days = (time() - $lastFullDate) / 86400;
    
            if ($days > $maxDaysWithoutFull)
            {
                $alerts[] = [
                    'type' => 'no_recent_full',
                    'message' => sprintf(
                        'Aucune sauvegarde Full depuis %d jours',
                        (int) $days
                    )
                ];
            }
        }
    
        return [
            'chains' => $chains,
            'alerts' => $alerts
        ];
    }
    
}
