<?php
namespace Joomla\Component\Akeebacleanup\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

/**
 * Contrôleur d'affichage du composant Akeeba Cleanup.
 *
 * Ce contrôleur est utilisé comme point d'entrée par défaut
 * du composant dans l'administration Joomla.
 *
 * Il ne définit aucune action spécifique et se contente
 * de déléguer l'affichage à la vue par défaut (`cleanup`),
 * conformément au fonctionnement standard MVC de Joomla.
 *
 * @since 1.0.0
 */
class DisplayController extends BaseController
{
    /**
     * Vue par défaut du composant.
     *
     * Lorsque aucune vue n'est explicitement spécifiée
     * dans la requête, Joomla affichera automatiquement
     * la vue "cleanup".
     *
     * @var string
     *
     * @since 1.0.0
     */
    protected $default_view = 'cleanup';
}
