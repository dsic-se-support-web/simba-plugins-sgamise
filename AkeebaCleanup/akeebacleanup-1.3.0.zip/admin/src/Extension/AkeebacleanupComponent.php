<?php
namespace Joomla\Component\Akeebacleanup\Administrator\Extension;

use Joomla\CMS\Extension\MVCComponent;
use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Factory;

defined('_JEXEC') or die;

class AkeebacleanupComponent extends MVCComponent
{
    public function boot(CMSApplicationInterface $app)
    {
        // Chargement de la langue
        $lang = $app->getLanguage();
        $lang->load('com_akeebacleanup', JPATH_ADMINISTRATOR);
        $lang->load('joomla', JPATH_ADMINISTRATOR);

        // Forcer la vue par défaut si aucune n'est passée
        $input = $app->input;
        
        //error_log('Input layout=' . $app->input->getCmd('layout')); //debug
        return $this;
    }
}