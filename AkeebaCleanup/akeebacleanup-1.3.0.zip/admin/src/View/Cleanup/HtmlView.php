<?php
namespace Joomla\Component\Akeebacleanup\Administrator\View\Cleanup;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

/**
 * Vue HTML principale du composant Akeeba Cleanup.
 *
 * Cette vue est responsable de :
 *  - récupérer les données préparées par le modèle
 *  - les exposer au template d'affichage
 *  - rendre l'interface d'administration du composant
 *
 * Les données affichées concernent notamment :
 *  - le nombre de sauvegardes obsolètes
 *  - le nombre de sauvegardes en échec
 *  - la liste des sauvegardes valides
 *
 * @since 1.0.0
 */

class HtmlView extends BaseHtmlView
{
    /**
     * Nombre de sauvegardes obsolètes détectées.
     *
     * Une sauvegarde est considérée comme obsolète lorsque
     * les fichiers associés n'existent plus sur le disque
     * (filesexist = 0).
     *
     * @var int
     *
     * @since 1.0.0
     */
    public int $obsoleteCount;

    /**
     * Nombre de sauvegardes Akeeba en échec.
     *
     * Une sauvegarde est considérée comme en échec lorsque
     * son statut est "fail" ou "error".
     *
     * @var int
     *
     * @since 1.0.0
     */
    public int $failedCount;

    /**
     * Liste des sauvegardes valides (statut "complete").
     *
     * Chaque élément du tableau correspond à un objet
     * représentant une sauvegarde Akeeba valide, tel que
     * retourné par le modèle.
     *
     * @var array
     *
     * @since 1.0.0
     */
    public array $validBackups = [];

    /**
     * Liste des alertes liées à la stratégie de sauvegarde.
     *
     * Ce tableau est destiné à contenir les messages
     * générés par l'analyse des chaînes de sauvegarde
     * (par exemple : incrémentielles sans Full préalable).
     *
     * @var array
     *
     * @since 1.0.0
     */
    public array $backupAlerts = [];


    /**
     * Méthode d'affichage de la vue.
     *
     * Cette méthode :
     *  - définit explicitement le chemin des templates
     *  - récupère le modèle associé à la vue
     *  - appelle les méthodes du modèle pour obtenir
     *    les données nécessaires à l'affichage
     *  - délègue le rendu final au moteur de vues Joomla
     *
     * @param string|null $tpl Nom du template à utiliser
     *
     * @return void
     *
     * @since 1.0.0
     */
    public function display($tpl = null)
    {
        // Définition explicite du chemin des templates
        $this->_setPath('template', __DIR__ . '/tmpl');

        // Récupération du modèle associé
        $model = $this->getModel();

        // Chargement des données nécessaires à l'affichage
        $this->obsoleteCount = $model->getObsoleteCount();
        $this->failedCount   = $model->getFailedCount();
        $this->validBackups  = $model->getValidBackups();

        // Rendu final de la vue
        parent::display($tpl);
    }
}

