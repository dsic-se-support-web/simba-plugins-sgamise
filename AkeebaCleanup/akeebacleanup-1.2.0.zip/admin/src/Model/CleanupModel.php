<?php
namespace Joomla\Component\Akeebacleanup\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Factory;

class CleanupModel extends BaseDatabaseModel
{
    // Compte le nombre de backups obsolètes
    public function getObsoleteCount(): int
    {
        $db = Factory::getDbo();

        $query = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('filesexist') . ' = 0');

        $db->setQuery($query);

        return (int) $db->loadResult();
    }

    // Supprime les backups obsolètes
    public function deleteObsoleteBackups(): int
    {
        $db = Factory::getDbo();

        $count = $this->getObsoleteCount();

        $query = $db->getQuery(true)
            ->delete($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('filesexist') . ' = 0');

        $db->setQuery($query);
        $db->execute();

        return $count;
    }

    // Compte les backups en échec
    public function getFailedCount(): int
    {
        $db = Factory::getDbo();
    
        $query = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('status') . ' IN (' . $db->quote('fail') . ', ' . $db->quote('error') . ')');
    
        $db->setQuery($query);
    
        return (int) $db->loadResult();
    }

    // Supprimer les backups en échec
    public function deleteFailedBackups(): int
    {
        $db = Factory::getDbo();
    
        $count = $this->getFailedCount();
    
        $query = $db->getQuery(true)
            ->delete($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('status') . ' IN (' . $db->quote('fail') . ', ' . $db->quote('error') . ')');
    
        $db->setQuery($query);
        $db->execute();
    
        return $count;
    }

    public function getValidBackups(): array
    {
        $db = Factory::getDbo();
    
        $query = $db->getQuery(true)
            ->select([
                'id',
                'profile_id',
                'description',
                'type',
                'backupstart',
                'backupend'
            ])
            ->from($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('status') . ' = ' . $db->quote('complete'))
            ->order($db->quoteName('backupstart') . ' DESC');
    
        $db->setQuery($query);
    
        return $db->loadObjectList();
    }

    public function analyzeBackupChains(
        int $maxIncrementals = 31,
        int $maxDaysWithoutFull = 30
    ): array {
        $backups = $this->getValidBackups();
    
        $chains = [];
        $alerts = [];
    
        $currentChain = null;
        $incrementalCount = 0;
    
        foreach ($backups as $backup)
        {
            if ($backup->type === 'full')
            {
                // Nouvelle chaîne
                if ($currentChain && $incrementalCount > $maxIncrementals)
                {
                    $alerts[] = [
                        'type' => 'too_many_incrementals',
                        'message' => sprintf(
                            'Plus de %d sauvegardes incrémentielles après la Full du %s',
                            $maxIncrementals,
                            $currentChain['date']
                        )
                    ];
                }
    
                $currentChain = [
                    'date' => $backup->backupstart,
                    'incrementals' => []
                ];
    
                $incrementalCount = 0;
                $chains[] = &$currentChain;
            }
            elseif ($backup->type === 'incremental')
            {
                if (!$currentChain)
                {
                    // Incrémentielle sans Full
                    $alerts[] = [
                        'type' => 'incremental_without_full',
                        'message' => sprintf(
                            'Sauvegarde incrémentielle sans Full préalable (%s)',
                            $backup->backupstart
                        )
                    ];
                }
                else
                {
                    $currentChain['incrementals'][] = $backup;
                    $incrementalCount++;
                }
            }
        }
    
        // Vérifier absence de Full récente
        if ($currentChain)
        {
            $lastFullDate = strtotime($currentChain['date']);
            $days = (time() - $lastFullDate) / 86400;
    
            if ($days > $maxDaysWithoutFull)
            {
                $alerts[] = [
                    'type' => 'no_recent_full',
                    'message' => sprintf(
                        'Aucune sauvegarde Full depuis %d jours',
                        (int) $days
                    )
                ];
            }
        }
    
        return [
            'chains' => $chains,
            'alerts' => $alerts
        ];
    }
    
}
