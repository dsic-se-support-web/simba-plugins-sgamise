<?php
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
?>

<h1>Akeeba – Nettoyage des sauvegardes obsolètes</h1>

<!-- Contrôle de la startégie de sauvegarde -->
<?php if (!empty($this->backupAlerts)) : ?>
    <div class="alert alert-warning">
        <h4>⚠️ Problèmes détectés dans la stratégie de sauvegarde</h4>
        <ul>
            <?php foreach ($this->backupAlerts as $alert) : ?>
                <li><?php echo htmlspecialchars($alert['message']); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php else : ?>
    <div class="alert alert-success">
        ✔️ Plan de sauvegarde cohérent (Full + incrémentiels)
    </div>
<?php endif; ?>

<p>
    <strong><?php echo $this->obsoleteCount; ?></strong>
    sauvegarde(s) obsolète(s) détectée(s).
</p>

<?php if ($this->obsoleteCount > 0) : ?>
    <form method="post"
    action="<?php echo Route::_('index.php?option=com_akeebacleanup&task=cleanup.deleteObsolete'); ?>"
    onsubmit="return confirm('Confirmer la suppression ?');">

        <button class="btn btn-danger">
            Supprimer toutes les sauvegardes obsolètes
        </button>

        <?php echo HTMLHelper::_('form.token'); ?>
    </form>
<?php else : ?>
    <div class="alert alert-success">
        Aucune sauvegarde obsolète à nettoyer.
    </div>
<?php endif; ?>

<hr>

<h2>Backups en échec</h2>

<p>
    <strong><?php echo $this->failedCount; ?></strong>
    sauvegarde(s) en échec détectée(s).
</p>

<?php if ($this->failedCount > 0) : ?>
    <form method="post"
        action="<?php echo Route::_('index.php?option=com_akeebacleanup&task=cleanup.deleteFailed'); ?>"
        onsubmit="return confirm('Supprimer toutes les sauvegardes en échec ?');">

        <button class="btn btn-warning">
            Supprimer les sauvegardes en échec
        </button>

        <?php echo HTMLHelper::_('form.token'); ?>
    </form>
    <?php else : ?>
        <div class="alert alert-success">
            Aucune sauvegarde en échec détectée.
        </div>
    <?php endif; ?>

<hr>

<h2>Backups valides</h2>

<table class="table table-striped table-hover">
    <thead>
        <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Profil</th>
            <th>Description</th>
            <th>Durée</th>
        </tr>
    </thead>
    <tbody>

    <?php
        $hasFullBefore = false;
    ?>

<?php 
    usort($this->validBackups, function ($a, $b) {
        return strtotime($a->backupstart) <=> strtotime($b->backupstart);
    });

    foreach ($this->validBackups as $backup) : ?>

    <?php
        $rowClass = '';

        if ($backup->type === 'full') {
        $hasFullBefore = true;
        } else {
            // incrémentielle
            if (!$hasFullBefore) {
            $rowClass = 'table-danger';
            }
        }
    ?>

        <tr class="<?php echo $rowClass; ?>">
            <td><?php echo HTMLHelper::_('date', $backup->backupstart, 'd/m/Y H:i'); ?></td>
            <td>
                <?php if ($backup->type === 'full') : ?>
                    <span class="badge bg-success">Full</span>
                <?php else : ?>
                    <span class="badge bg-info">Incrémentielle</span>
                <?php endif; ?>
            </td>
            <td>#<?php echo (int) $backup->profile_id; ?></td>
            <td><?php echo htmlspecialchars($backup->description); ?></td>
            <td>
                <?php
                    $duration = strtotime($backup->backupend) - strtotime($backup->backupstart);
                    echo gmdate('H:i:s', max(0, $duration));
                ?>
            </td>
        </tr>

    <?php endforeach; ?>

    </tbody>
</table>

<p class="text-muted">
    🔎 Les lignes en rouge indiquent des sauvegardes incrémentielles sans sauvegarde Full valide préalable.
</p>