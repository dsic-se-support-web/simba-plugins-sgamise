<?php
namespace Joomla\Component\Akeebacleanup\Administrator\Extension;

use Joomla\CMS\Extension\MVCComponent;
use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Factory;

defined('_JEXEC') or die;

class AkeebacleanupComponent extends MVCComponent
{
    public function boot(CMSApplicationInterface $app)
    {
        // Charger la langue
        $lang = $app->getLanguage();
        $lang->load('com_akeebacleanup', JPATH_ADMINISTRATOR);

        // Forcer la vue par défaut si aucune n'est passée
        $input = $app->input;
        if (!$input->getCmd('view'))
        {
            //$input->set('view', 'cleanup');
            $input->set('layout', 'default');
        }
        
    // Debug : afficher controller et view
    error_log('Input view=' . $app->input->getCmd('view'));
    error_log('Input layout=' . $app->input->getCmd('layout'));
        return $this;
    }
}