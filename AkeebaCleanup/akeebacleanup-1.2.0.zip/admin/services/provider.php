<?php
defined('_JEXEC') or die;

use Joomla\CMS\Extension\ComponentInterface;
use Joomla\CMS\Extension\Service\Provider\ComponentDispatcherFactory;
use Joomla\CMS\Extension\Service\Provider\MVCFactory;
use Joomla\CMS\Dispatcher\ComponentDispatcherFactoryInterface;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class implements ServiceProviderInterface
{
    public function register(Container $container): void
    {
        //error_log('AKEEBA CLEANUP PROVIDER CHARGE'); //debug

        // Enregistrement du composant
        $container->registerServiceProvider(
            new MVCFactory(
                'Joomla\\Component\\Akeebacleanup',
                JPATH_ADMINISTRATOR . '/components/com_akeebacleanup/src'
            )
        );
        

        // DISPATCHER
        $container->registerServiceProvider(
            new ComponentDispatcherFactory(
                'Joomla\\Component\\Akeebacleanup'
            )
        );
        
        $container->set(
            ComponentInterface::class,
            function (Container $container) {
                $component = new \Joomla\Component\Akeebacleanup\Administrator\Extension\AkeebacleanupComponent(
                    $container->get(ComponentDispatcherFactoryInterface::class)
                );
        
                $component->setMVCFactory(
                    $container->get(MVCFactoryInterface::class)
                );

                $app = \Joomla\CMS\Factory::getApplication();
                $component->boot($app);
        
                return $component;
            }
        );

        //error_log('AKEEBA CLEANUP Provider::exécuté'); //Debug
    }
};
