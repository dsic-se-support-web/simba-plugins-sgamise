<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\User\User;
use Joomla\CMS\Component\ComponentHelper;

$app  = Factory::getApplication();
$user = $app->getIdentity();

if (!$user->authorise('core.manage', 'com_akeebacleanup'))
{
    throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), 403);
}

$component = $app->bootComponent('com_akeebacleanup');
$component->getDispatcher($app)->dispatch();