<?php
namespace Joomla\Component\Akeebacleanup\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;

/**
 * Controller principal du composant Akeeba Cleanup.
 *
 * Ce contrôleur gère les actions de maintenance liées
 * aux sauvegardes Akeeba Backup :
 *  - suppression des sauvegardes obsolètes (fichiers absents)
 *  - suppression des sauvegardes en échec
 *
 * Toutes les actions sont protégées par :
 *  - un contrôle de jeton CSRF
 *  - une vérification des droits ACL
 *
 * @since 1.0.0
 */

//error_log('CleanupController chargé'); // debug

class CleanupController extends BaseController
{
    /**
     * Vue par défaut du composant.
     *
     * @var string
     */
    protected $default_view = 'cleanup';

    /**
     * Supprime toutes les sauvegardes Akeeba obsolètes.
     *
     * Une sauvegarde est considérée comme obsolète lorsque
     * les fichiers associés n'existent plus sur le disque
     * (champ `filesexist = 0`).
     *
     * Étapes réalisées :
     *  - Vérification du droit ACL `core.manage`
     *  - Vérification du jeton CSRF
     *  - Appel du modèle pour supprimer les sauvegardes
     *  - Affichage d'un message de confirmation
     *  - Redirection vers la vue principale du composant
     *
     * @return void
     *
     * @throws \Exception Si l'utilisateur n'a pas les droits nécessaires
     *
     * @since 1.0.0
     */
    public function deleteObsolete(): void
    {
        //error_log('deleteObsolete appelé'); // debug

        // Protection CSRF
        Session::checkToken() or jexit('Invalid Token');

        // Suppression des sauvegardes obsolètes
        $model = $this->getModel();
        $count = $model->deleteObsoleteBackups();

        // Message de succès
        $this->setMessage(Text::sprintf('COM_AKEEBACLEANUP_SUCCESS', $count), 'success');

        // Redirection vers la vue principale
        $this->setRedirect(Route::_('index.php?option=com_akeebacleanup&view=cleanup', false));
    }


    /**
     * Supprime toutes les sauvegardes Akeeba en échec.
     *
     * Une sauvegarde est considérée comme en échec lorsque
     * son statut est "fail" ou "error".
     *
     * Étapes réalisées :
     *  - Vérification du jeton CSRF
     *  - Appel du modèle pour supprimer les sauvegardes en échec
     *  - Affichage d'un message de confirmation
     *  - Redirection vers la vue principale du composant
     *
     * @return void
     *
     * @since 1.0.0
     */
    public function deleteFailed(): void
    {    
        // Protection CSRF
        Session::checkToken() or jexit('Invalid Token');
    
        // Suppression des sauvegardes en échec
        $model = $this->getModel();
        $count = $model->deleteFailedBackups();
    
        // Message de succès
        $this->setMessage(
            Text::sprintf('COM_AKEEBACLEANUP_FAILED_SUCCESS', $count),
            'success'
        );
    
        // Redirection vers la vue principale
        $this->setRedirect(
            Route::_('index.php?option=com_akeebacleanup&view=cleanup', false)
        );
    }
}
