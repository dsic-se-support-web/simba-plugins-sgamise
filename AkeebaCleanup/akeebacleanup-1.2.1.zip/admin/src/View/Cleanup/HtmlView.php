<?php
namespace Joomla\Component\Akeebacleanup\Administrator\View\Cleanup;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

class HtmlView extends BaseHtmlView
{
    public int $obsoleteCount;
    public int $failedCount;
    public array $validBackups = [];
    public array $backupAlerts = [];

    // Ajout des fonctions dans la vue du composant
    public function display($tpl = null)
    {
        $this->_setPath('template', __DIR__ . '/tmpl');

        $model = $this->getModel();

        $this->obsoleteCount = $model->getObsoleteCount();
        $this->failedCount   = $model->getFailedCount();
        $this->validBackups  = $model->getValidBackups();

        parent::display($tpl);
    }
}

