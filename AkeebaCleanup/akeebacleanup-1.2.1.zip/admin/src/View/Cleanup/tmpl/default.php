<?php
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
?>

<!-- Purge des sauvegardes Akeeba obsolètes -->
<h1><?= Text::_('COM_AKEEBACLEANUP_PRUNE_OBSOLETES_TITLE') ?></h1>

<!-- Contrôle de la stratégie de sauvegarde -->
<?php if (!empty($this->backupAlerts)) : ?>
    <div class="alert alert-warning">
        <h4><?= Text::_('COM_AKEEBACLEANUP_BKP_WORKFLOW_ERROR') ?></h4>
        <ul>
            <?php foreach ($this->backupAlerts as $alert) : ?>
                <li><?php echo htmlspecialchars($alert['message']); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php else : ?>
    <div class="alert alert-success">
        <?= Text::_('COM_AKEEBACLEANUP_BKP_WORKFLOW_OK') ?>
    </div>
<?php endif; ?>

<p>
    <strong><?php echo $this->obsoleteCount; ?></strong>
    <?= Text::_('COM_AKEEBACLEANUP_OBSOLETE_BKP_FOUND') ?>
</p>

<?php if ($this->obsoleteCount > 0) : ?>
    <form method="post"
    action="<?php echo Route::_('index.php?option=com_akeebacleanup&task=cleanup.deleteObsolete'); ?>"
    onsubmit="return confirm(<?= Text::_('COM_AKEEBACLEANUP_CONFIRM_PRUNE') ?>);">

        <button class="btn btn-danger">
            <?= Text::_('COM_AKEEBACLEANUP_PRUNE_OBSOLETE_BKP') ?>
        </button>

        <?php echo HTMLHelper::_('form.token'); ?>
    </form>
<?php else : ?>
    <div class="alert alert-success">
        <?= Text::_('COM_AKEEBACLEANUP_NO_OBSOLETE_BKP') ?>
    </div>
<?php endif; ?>

<hr>

<!-- Purge des sauvegardes Akeeba en échec -->
<h2><?= Text::_('COM_AKEEBACLEANUP_PRUNE_KO_TITLE') ?></h2>

<p>
    <strong><?php echo $this->failedCount; ?></strong>
    <?= Text::_('COM_AKEEBACLEANUP_KO_BKP_FOUND') ?>
</p>

<?php if ($this->failedCount > 0) : ?>
    <form method="post"
        action="<?php echo Route::_('index.php?option=com_akeebacleanup&task=cleanup.deleteFailed'); ?>"
        onsubmit="return confirm(<?= Text::_('COM_AKEEBACLEANUP_CONFIRM_PRUNE') ?>);">

        <button class="btn btn-warning">
            <?= Text::_('COM_AKEEBACLEANUP_PRUNE_KO_BKP') ?>
        </button>

        <?php echo HTMLHelper::_('form.token'); ?>
    </form>
    <?php else : ?>
        <div class="alert alert-success">
            <?= Text::_('COM_AKEEBACLEANUP_NO_KO_BKP') ?>
        </div>
    <?php endif; ?>

<hr>

<!-- Liste des backups valides et contrôle de la stratégie de sauvegarde -->
<h2><?= Text::_('COM_AKEEBACLEANUP_LIST_OK_BKP_TITLE') ?></h2>

<table class="table table-striped table-hover">
    <thead>
        <tr>
            <th><?= Text::_('COM_AKEEBACLEANUP_LIST_OK_BKP_DATE') ?></th>
            <th><?= Text::_('COM_AKEEBACLEANUP_LIST_OK_BKP_TYPE') ?></th>
            <th><?= Text::_('COM_AKEEBACLEANUP_LIST_OK_BKP_PROFILE') ?></th>
            <th><?= Text::_('COM_AKEEBACLEANUP_LIST_OK_BKP_DESCRIPT') ?></th>
            <th><?= Text::_('COM_AKEEBACLEANUP_LIST_OK_BKP_DURATION') ?></th>
        </tr>
    </thead>
    <tbody>

    <?php
        $hasFullBefore = false;
 
        usort($this->validBackups, function ($a, $b) {
            return strtotime($a->backupstart) <=> strtotime($b->backupstart);
        });

        foreach ($this->validBackups as $backup) :

            $rowClass = '';

            if ($backup->type === 'full') {
            $hasFullBefore = true;
            } else {
                // bkp incrémentielle
                if (!$hasFullBefore) {
                $rowClass = 'table-danger';
                }
            }
    ?>

        <tr class="<?php echo $rowClass; ?>">
            <td><?php echo HTMLHelper::_('date', $backup->backupstart, 'd/m/Y H:i'); ?></td>
            <td>
                <?php if ($backup->type === 'full') : ?>
                    <span class="badge bg-success"><?= Text::_('COM_AKEEBACLEANUP_LIST_OK_BKP_FULL') ?></span>
                <?php else : ?>
                    <span class="badge bg-info"><?= Text::_('COM_AKEEBACLEANUP_LIST_OK_BKP_INCR') ?></span>
                <?php endif; ?>
            </td>
            <td>#<?php echo (int) $backup->profile_id; ?></td>
            <td><?php echo htmlspecialchars($backup->description); ?></td>
            <td>
                <?php
                    $duration = strtotime($backup->backupend) - strtotime($backup->backupstart);
                    echo gmdate('H:i:s', max(0, $duration));
                ?>
            </td>
        </tr>

    <?php endforeach; ?>

    </tbody>
</table>

<p class="text-muted">
    <?= Text::_('COM_AKEEBACLEANUP_LIST_OK_BKP_DISCLAIMER') ?>
</p>