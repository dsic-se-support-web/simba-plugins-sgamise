<?php
namespace Joomla\Component\Akeebacleanup\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;

//error_log('CleanupController chargé'); // debug

class CleanupController extends BaseController
{
    protected $default_view = 'cleanup';

    // Suppression des backups obsolètes
    public function deleteObsolete(): void
    {
        //error_log('deleteObsolete appelé'); // debug
        Session::checkToken() or jexit('Invalid Token');

        $model = $this->getModel();
        $count = $model->deleteObsoleteBackups();

        $this->setMessage(Text::sprintf('COM_AKEEBACLEANUP_SUCCESS', $count), 'success');
        $this->setRedirect(Route::_('index.php?option=com_akeebacleanup&view=cleanup', false));
    }

    // Suppression des backups en échec
    public function deleteFailed(): void
    {
        Session::checkToken() or jexit('Invalid Token');
    
        $model = $this->getModel();
        $count = $model->deleteFailedBackups();
    
        $this->setMessage(
            Text::sprintf('COM_AKEEBACLEANUP_FAILED_SUCCESS', $count),
            'success'
        );
    
        $this->setRedirect(
            Route::_('index.php?option=com_akeebacleanup&view=cleanup', false)
        );
    }
}
