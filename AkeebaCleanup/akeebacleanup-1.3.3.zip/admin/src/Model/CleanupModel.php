<?php
namespace Joomla\Component\Akeebacleanup\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper; // Pour charger l'API d'Akeeba Backup
use Joomla\CMS\Date\Date;


/**
 * Modèle principal du composant Akeeba Cleanup.
 *
 * Gère l'accès à la table des sauvegardes Akeeba
 * et fournit les méthodes de comptage, suppression
 * et analyse des chaînes de sauvegarde.
 */
class CleanupModel extends BaseDatabaseModel
{
    /**
     * Retourne le nombre de sauvegardes obsolètes.
     *
     * Une sauvegarde est considérée comme obsolète lorsque
     * les fichiers associés n'existent plus sur le disque
     * (filesexist = 0).
     *
     * @return int Nombre de sauvegardes obsolètes
     */
    public function getObsoleteCount(): int
    {
        $db = Factory::getDbo();

        // Construction de la requête COUNT(*)
        $query = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('filesexist') . ' = 0');

        $db->setQuery($query);

        return (int) $db->loadResult();
    }

    /**
     * Supprime toutes les sauvegardes obsolètes.
     *
     * La méthode supprime les enregistrements dont
     * filesexist = 0 et retourne le nombre de lignes supprimées.
     *
     * @return int Nombre de sauvegardes supprimées
     */
    public function deleteObsoleteBackups(): int
    {
        $db = Factory::getDbo();

        // Construction de la requête DELETE
        $query = $db->getQuery(true)
            ->delete($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('filesexist') . ' = 0');

        $db->setQuery($query);
        $db->execute();

        return $db->getAffectedRows();
    }

    /**
     * Retourne le nombre de sauvegardes en échec.
     *
     * Une sauvegarde est considérée comme en échec lorsque
     * son statut est "fail" ou "error".
     *
     * @return int Nombre de sauvegardes en échec
     */
    public function getFailedCount(): int
    {
        $db = Factory::getDbo();
    
        // Requête COUNT(*) sur les statuts en erreur
        $query = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('status') . ' IN (' . $db->quote('fail') . ', ' . $db->quote('error') . ')');
    
        $db->setQuery($query);
    
        return (int) $db->loadResult();
    }

    /**
     * Supprime toutes les sauvegardes en échec.
     *
     * Supprime les sauvegardes dont le statut est
     * "fail" ou "error".
     *
     * @return int Nombre de sauvegardes supprimées
     */
    public function deleteFailedBackups(): int
    {
        $db = Factory::getDbo();
    
        // Requête DELETE sur les statuts en erreur
        $query = $db->getQuery(true)
            ->delete($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('status') . ' IN (' . $db->quote('fail') . ', ' . $db->quote('error') . ')');
    
        $db->setQuery($query);
        $db->execute();
    
        // Nombre de lignes réellement supprimées
        return $db->getAffectedRows();
    }

    /**
     * Récupère la liste des sauvegardes valides.
     *
     * Une sauvegarde valide est une sauvegarde dont
     * le statut est "complete".
     *
     * Les sauvegardes sont retournées par ordre chronologique
     * croissant (date de début).
     *
     * @return array Liste des sauvegardes valides (objets stdClass)
     */
    public function getValidBackups(): array
    {
        $db = Factory::getDbo();
    
        // Sélection uniquement des champs nécessaires à l'affichage
        $query = $db->getQuery(true)
            ->select([
                'id',
                'profile_id',
                'description',
                'type',
                'backupstart',
                'backupend',
                'archivename',
                'absolute_path'
            ])
            ->from($db->quoteName('#__akeebabackup_backups'))
            ->where($db->quoteName('status') . ' = ' . $db->quote('complete'))
            ->order($db->quoteName('backupstart') . ' ASC');
    
        $db->setQuery($query);
    
        return $db->loadObjectList();
    }

    /**
     * Analyse la cohérence des chaînes de sauvegarde.
     *
     * Une chaîne valide est constituée de :
     * - 1 sauvegarde Full
     * - suivie de N sauvegardes incrémentielles
     * - puis idéalement une nouvelle Full
     *
     * Cette méthode détecte :
     * - trop d'incrémentielles après une Full
     * - des incrémentielles sans Full préalable
     * - l'absence de sauvegarde Full récente
     *
     * @param int $maxIncrementals    Nombre maximal d'incrémentielles autorisées
     * @param int $maxDaysWithoutFull Nombre maximal de jours sans sauvegarde Full
     *
     * @return array Tableau contenant les chaînes détectées et les alertes
     */
    public function analyzeBackupChains(
        int $maxIncrementals = 31,
        int $maxDaysWithoutFull = 30
    ): array {
        // Récupération des sauvegardes valides
        $backups = $this->getValidBackups();
    
        $chains = [];
        $alerts = [];
    
        $currentChain = null;
        $incrementalCount = 0;
    
        foreach ($backups as $backup)
        {
            // Détection d'une sauvegarde Full
            if ($backup->type === 'full')
            {
                // Vérifie si la chaîne précédente contient trop d'incrémentielles
                if ($currentChain && $incrementalCount > $maxIncrementals)
                {
                    $alerts[] = [
                        'type' => 'too_many_incrementals',
                        'message' => sprintf(
                            'Plus de %d sauvegardes incrémentielles après la Full du %s',
                            $maxIncrementals,
                            $currentChain['date']
                        )
                    ];
                }
    
                // Démarrage d'une nouvelle chaîne
                $currentChain = [
                    'date' => $backup->backupstart,
                    'incrementals' => []
                ];
    
                $incrementalCount = 0;
                $chains[] = &$currentChain;
            }
            // Détection d'une sauvegarde incrémentielle
            elseif (in_array($backup->type, ['inc', 'incfull', 'incremental'], true))
            {
                if (!$currentChain)
                {
                    // Incrémentielle sans Full préalable
                    $alerts[] = [
                        'type' => 'incremental_without_full',
                        'message' => sprintf(
                            'Sauvegarde incrémentielle sans Full préalable (%s)',
                            $backup->backupstart
                        )
                    ];
                }
                else
                {
                    $currentChain['incrementals'][] = $backup;
                    $incrementalCount++;
                }
            }
        }
    
        // Vérifie si la dernière sauvegarde Full est trop ancienne
        if ($currentChain)
        {
            $lastFullDate = strtotime($currentChain['date']);
            $days = (time() - $lastFullDate) / 86400;
    
            if ($days > $maxDaysWithoutFull)
            {
                $alerts[] = [
                    'type' => 'no_recent_full',
                    'message' => sprintf(
                        'Aucune sauvegarde Full depuis %d jours',
                        (int) $days
                    )
                ];
            }
        }
    
        return [
            'chains' => $chains,
            'alerts' => $alerts
        ];
    }

    /**
     * Identifie les sauvegardes incrémentielles orphelines.
     *
     * Une sauvegarde incrémentielle est considérée comme orpheline
     * lorsqu'elle apparaît avant toute sauvegarde de type "Full"
     * dans la chronologie des sauvegardes valides.
     *
     * Cette méthode :
     *  - récupère les sauvegardes valides (statut "complete")
     *  - les parcourt dans l'ordre chronologique
     *  - détecte les incrémentielles sans Full préalable
     *  - retourne leurs identifiants
     *
     * Types considérés comme incrémentiels :
     *  - inc
     *  - incfull
     *  - incremental
     *
     * @return int[] Liste des identifiants des sauvegardes incrémentielles orphelines
     *
     *
     */
    public function getOrphanIncrementalIds(): array
    {
        $backups = $this->getValidBackups();
        
        $hasFullBefore = false;
        $ids = [];
        
        foreach ($backups as $backup)
        {
            if ($backup->type === 'full')
            {
                $hasFullBefore = true;
            }
            elseif (in_array($backup->type, ['inc', 'incfull', 'incremental'], true))
            {
                if (!$hasFullBefore)
                {
                    $ids[] = (int) $backup->id;
                }
            }
        }
    
        return $ids;
    }


    /**
     * Supprime les sauvegardes incrémentielles orphelines.
     *
     * Cette méthode fonctionne de manière autonome, sans utiliser l'API Akeeba.
     *
     * Processus :
     *  1. Identifie les sauvegardes incrémentielles orphelines via getOrphanIncrementalIds()
     *  2. Récupère les informations nécessaires (nom d'archive, chemin)
     *  3. Supprime les fichiers de sauvegarde sur le disque
     *     - archive principale (.jpa, .jps, .zip)
     *     - parties multiples éventuelles (.j01, .j02, etc.)
     *  4. Supprime les entrées correspondantes en base de données
     *
     * Les fichiers sont recherchés :
     *  - soit via le champ absolute_path (prioritaire)
     *  - soit dans le dossier /backup à la racine du site
     *
     * Une vérification de sécurité empêche la suppression de fichiers
     * en dehors du répertoire prévu.
     *
     * En cas d'erreur sur un backup, la suppression continue
     * pour les autres éléments (tolérance aux erreurs).
     *
     * @return int Nombre de sauvegardes incrémentielles orphelines supprimées
     *
     * @since 1.3.0
     */
    public function deleteOrphanIncrementals(): int
    {
        $ids = $this->getOrphanIncrementalIds();
    
        if (empty($ids)) {
            return 0;
        }
    
        $db = Factory::getDbo();
    
        // Récupération des backups orphelins
        $query = $db->getQuery(true)
            ->select(['id', 'archivename', 'absolute_path', 'backupstart'])
            ->from($db->quoteName('#__akeebabackup_backups'))
            ->where('id IN (' . implode(',', array_map('intval', $ids)) . ')');
    
        $db->setQuery($query);
        $backups = $db->loadObjectList();
    
        $deleted = 0;
    
        foreach ($backups as $backup) {
            try {
                // Supprimer les fichiers de backup
                $this->deleteBackupFiles($backup);

                // Supprimer les fichiers log
                $this->deleteBackupLogs($backup);
    
                // Supprimer les entrées en base de données
                $query = $db->getQuery(true)
                    ->delete($db->quoteName('#__akeebabackup_backups'))
                    ->where('id = ' . (int) $backup->id);
    
                $db->setQuery($query);
                $db->execute();
    
                $deleted++;
    
            } catch (\Throwable $e) {
                // option pour log de debug
            }
        }
    
        return $deleted;
    }

    /**
     * Supprime les fichiers physiques associés à une sauvegarde Akeeba.
     *
     * Cette méthode supprime :
     *  - le fichier principal de l'archive (.jpa, .jps, .zip)
     *  - les éventuelles parties multiples (.j01, .j02, etc.)
     *
     * Détermination du chemin :
     *  - utilise absolute_path si disponible
     *  - sinon reconstruit le chemin à partir du dossier /backup du site
     *
     * Sécurité :
     *  - vérifie que le fichier se trouve bien dans le répertoire /backup
     *  - empêche toute suppression en dehors de ce périmètre
     *
     * Si le fichier n'existe pas, aucune action n'est effectuée.
     *
     * @param object $backup Objet contenant au minimum :
     *                       - archivename (string)
     *                       - absolute_path (string|null)
     *
     * @return void
     */
    private function deleteBackupFiles(object $backup): void
    {
        // Chemin des backups
        $baseDir = JPATH_ROOT . '/backup/';
    
        // Construction du chemin complet
        $filePath = !empty($backup->absolute_path) ? $backup->absolute_path : $baseDir . $backup->archivename;
    
        // Sécurité : évite les chemins hors site
        $realBase = realpath($baseDir);
        $realFile = realpath(dirname($filePath));
    
        if ($realBase === false || $realFile === false || strpos($realFile, $realBase) !== 0) {
            return;
        }
    
        if (!file_exists($filePath)) {
            return;
        }
    
        // Suppression du fichier principal
        @unlink($filePath);
    
        // Suppression des fichiers multi-part (.j01, .j02, etc.)
        $base = preg_replace('/\.(jpa|jps|zip)$/i', '', $filePath);
    
        $i = 1;
        while (true) {
            $part = sprintf('%s.j%02d', $base, $i);
    
            if (!file_exists($part)) {
                break;
            }
    
            @unlink($part);
            $i++;
        }
    }

    /**
     * Supprime les fichiers de logs associés à une sauvegarde Akeeba.
     *
     * Akeeba Backup génère pour chaque sauvegarde un ou plusieurs fichiers de logs
     * stockés dans le répertoire /backup du site Joomla. Ces fichiers ont
     * généralement le format suivant :
     *
     *     akeeba.joomla.id-YYYYMMDD-HHMMSS-xxxxx.log.php
     *
     * où :
     *  - YYYYMMDD-HHMMSS correspond à la date de début de la sauvegarde
     *  - xxxxx est un identifiant unique généré par Akeeba
     *
     * Cette méthode :
     *  1. Reconstruit le timestamp de la sauvegarde à partir du champ `backupstart`
     *  2. Génère un pattern de recherche basé sur ce timestamp
     *  3. Recherche tous les fichiers correspondants avec glob()
     *  4. Vérifie que chaque fichier se trouve bien dans le dossier /backup (sécurité)
     *  5. Supprime les fichiers trouvés
     *
     * Sécurité :
     *  - Utilise realpath() pour éviter toute suppression hors du répertoire prévu
     *  - Vérifie que le chemin du fichier commence bien par le répertoire de backup
     *
     * Limitations :
     *  - Basé uniquement sur le timestamp → peut ne pas couvrir 100% des cas
     *    si plusieurs sauvegardes très proches existent
     *  - Ne supprime que les logs correspondant au pattern standard Akeeba
     *
     * @param object $backup Objet contenant au minimum :
     *                       - backupstart (string, date de début de sauvegarde)
     *
     * @return void
     *
     * @since 1.3.0
     */
    private function deleteBackupLogs(object $backup): void
    {
        $baseDir = JPATH_ROOT . '/backup/';
    
        $realBase = realpath($baseDir);
        if ($realBase === false) {
            return;
        }
    
        // Conversion du timestamp en UTC (format Akeeba)
        $date = new \Joomla\CMS\Date\Date($backup->backupstart);
        $date->setTimezone(new \DateTimeZone('UTC'));
    
        $timestamp = $date->format('Ymd-His', true);
    
        // Pattern Akeeba (backend + joomla selon config)
        $patterns = [
            $realBase . '/akeeba.backend.id-' . $timestamp . '-*.log.php',
            $realBase . '/akeeba.joomla.id-' . $timestamp . '-*.log.php',
        ];
    
        foreach ($patterns as $pattern)
        {
            foreach (glob($pattern) as $logFile)
            {
                $realFile = realpath($logFile);
    
                if ($realFile && strpos($realFile, $realBase) === 0)
                {
                    @unlink($realFile);
                }
            }
        }
    }
}
